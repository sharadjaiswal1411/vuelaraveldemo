package com.appsflyer;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.params.ConnManagerParams;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

public class BackgroundHttpTask
  extends AsyncTask<String, Void, String>
{
  private static final int REGISTRATION_TIMEOUT = 3000;
  private static final int WAIT_TIMEOUT = 30000;
  public Map<String, String> bodyPaeameters;
  private String content = null;
  private boolean error = false;
  private final HttpClient httpclient = new DefaultHttpClient();
  private Context mContext;
  final HttpParams params = httpclient.getParams();
  HttpResponse response;
  
  public BackgroundHttpTask(Context paramContext)
  {
    mContext = paramContext;
  }
  
  private static String mapToString(Map paramMap)
    throws UnsupportedEncodingException
  {
    StringBuilder localStringBuilder = new StringBuilder();
    Iterator localIterator = paramMap.keySet().iterator();
    if (localIterator.hasNext())
    {
      String str2 = (String)localIterator.next();
      String str1 = (String)paramMap.get(str2);
      if (str1 == null) {}
      for (str1 = "";; str1 = URLEncoder.encode(str1, "UTF-8"))
      {
        if (localStringBuilder.length() > 0) {
          localStringBuilder.append('&');
        }
        localStringBuilder.append(str2).append('=').append(str1);
        break;
      }
    }
    return localStringBuilder.toString();
  }
  
  protected String doInBackground(String... paramVarArgs)
  {
    paramVarArgs = paramVarArgs[0];
    Object localObject = params;
    try
    {
      HttpConnectionParams.setSoTimeout((HttpParams)localObject, 30000);
      localObject = params;
      ConnManagerParams.setTimeout((HttpParams)localObject, 30000L);
      paramVarArgs = new HttpPost(paramVarArgs);
      localObject = bodyPaeameters;
      paramVarArgs.setEntity(new StringEntity(mapToString((Map)localObject)));
      localObject = bodyPaeameters;
      Log.i("body", mapToString((Map)localObject));
      localObject = httpclient;
      paramVarArgs = ((HttpClient)localObject).execute(paramVarArgs);
      response = paramVarArgs;
      paramVarArgs = response;
      paramVarArgs = paramVarArgs.getStatusLine();
      int i = paramVarArgs.getStatusCode();
      if (i != 200) {
        break label160;
      }
      paramVarArgs = new ByteArrayOutputStream();
      localObject = response;
      ((HttpResponse)localObject).getEntity().writeTo(paramVarArgs);
      paramVarArgs.close();
      paramVarArgs = paramVarArgs.toString();
      content = paramVarArgs;
    }
    catch (ClientProtocolException paramVarArgs)
    {
      for (;;)
      {
        Log.w("HTTP2:", paramVarArgs);
        content = paramVarArgs.getMessage();
        error = true;
        cancel(true);
      }
    }
    catch (IOException paramVarArgs)
    {
      for (;;)
      {
        Log.w("HTTP3:", paramVarArgs);
        content = ((IOException)paramVarArgs).getMessage();
        error = true;
        cancel(true);
      }
    }
    catch (Exception paramVarArgs)
    {
      for (;;)
      {
        Log.w("HTTP4:", paramVarArgs);
        content = ((Exception)paramVarArgs).getMessage();
        error = true;
        cancel(true);
      }
    }
    return content;
    label160:
    Log.w("HTTP1:", paramVarArgs.getReasonPhrase());
    localObject = response;
    ((HttpResponse)localObject).getEntity().getContent().close();
    paramVarArgs = new IOException(paramVarArgs.getReasonPhrase());
    throw paramVarArgs;
  }
  
  protected void onCancelled()
  {
    Log.i("AppsFlyer_1.17", "Connection cancelled");
  }
  
  protected void onPostExecute(String paramString)
  {
    if (error)
    {
      Log.i("AppsFlyer_1.17", "Connection error");
      return;
    }
    Log.i("AppsFlyer_1.17", "Connection call succeeded");
  }
  
  protected void onPreExecute() {}
}
