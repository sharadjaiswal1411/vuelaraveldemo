package com.appsflyer;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Random;
import java.util.UUID;

public class Installation
{
  private static final String INSTALLATION = "AF_INSTALLATION";
  private static String sID = null;
  
  public Installation() {}
  
  /* Error */
  public static String id(Context paramContext)
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: getstatic 13	com/appsflyer/Installation:sID	Ljava/lang/String;
    //   6: ifnonnull +40 -> 46
    //   9: new 25	java/io/File
    //   12: dup
    //   13: aload_0
    //   14: invokevirtual 31	android/content/Context:getFilesDir	()Ljava/io/File;
    //   17: ldc 8
    //   19: invokespecial 34	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   22: astore_2
    //   23: aload_2
    //   24: invokevirtual 38	java/io/File:exists	()Z
    //   27: istore_1
    //   28: iload_1
    //   29: ifne +8 -> 37
    //   32: aload_2
    //   33: aload_0
    //   34: invokestatic 42	com/appsflyer/Installation:writeInstallationFile	(Ljava/io/File;Landroid/content/Context;)V
    //   37: aload_2
    //   38: invokestatic 46	com/appsflyer/Installation:readInstallationFile	(Ljava/io/File;)Ljava/lang/String;
    //   41: astore_0
    //   42: aload_0
    //   43: putstatic 13	com/appsflyer/Installation:sID	Ljava/lang/String;
    //   46: getstatic 13	com/appsflyer/Installation:sID	Ljava/lang/String;
    //   49: astore_0
    //   50: ldc 2
    //   52: monitorexit
    //   53: aload_0
    //   54: areturn
    //   55: astore_0
    //   56: new 48	java/lang/RuntimeException
    //   59: dup
    //   60: aload_0
    //   61: invokespecial 51	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   64: athrow
    //   65: astore_0
    //   66: ldc 2
    //   68: monitorexit
    //   69: aload_0
    //   70: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	71	0	paramContext	Context
    //   27	2	1	bool	boolean
    //   22	16	2	localFile	File
    // Exception table:
    //   from	to	target	type
    //   23	28	55	java/lang/Exception
    //   32	37	55	java/lang/Exception
    //   37	42	55	java/lang/Exception
    //   3	23	65	java/lang/Throwable
    //   23	28	65	java/lang/Throwable
    //   32	37	65	java/lang/Throwable
    //   37	42	65	java/lang/Throwable
    //   42	46	65	java/lang/Throwable
    //   46	50	65	java/lang/Throwable
    //   56	65	65	java/lang/Throwable
  }
  
  private static String readInstallationFile(File paramFile)
    throws IOException
  {
    paramFile = new RandomAccessFile(paramFile, "r");
    byte[] arrayOfByte = new byte[(int)paramFile.length()];
    paramFile.readFully(arrayOfByte);
    paramFile.close();
    return new String(arrayOfByte);
  }
  
  private static void writeInstallationFile(File paramFile, Context paramContext)
    throws IOException, PackageManager.NameNotFoundException
  {
    FileOutputStream localFileOutputStream = new FileOutputStream(paramFile);
    paramFile = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0);
    if (Build.VERSION.SDK_INT >= 9) {}
    for (paramFile = firstInstallTime + "-" + Math.abs(new Random().nextLong());; paramFile = UUID.randomUUID().toString())
    {
      localFileOutputStream.write(paramFile.getBytes());
      localFileOutputStream.close();
      return;
    }
  }
}
