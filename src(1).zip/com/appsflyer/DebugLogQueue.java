package com.appsflyer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DebugLogQueue
{
  private static DebugLogQueue ourInstance = new DebugLogQueue();
  List<Item> queue = new ArrayList();
  
  private DebugLogQueue() {}
  
  public static DebugLogQueue getInstance()
  {
    return ourInstance;
  }
  
  public Item loadItems()
  {
    if (queue.size() == 0) {
      return null;
    }
    Item localItem = (Item)queue.get(0);
    queue.remove(0);
    return localItem;
  }
  
  public void push(String paramString)
  {
    queue.add(new Item(paramString));
  }
  
  public static class Item
  {
    private String mMsg;
    private long timestamp;
    
    public Item(String paramString)
    {
      mMsg = paramString;
      timestamp = new Date().getTime();
    }
    
    public String getMsg()
    {
      return mMsg;
    }
    
    public long getTimestamp()
    {
      return timestamp;
    }
  }
}
