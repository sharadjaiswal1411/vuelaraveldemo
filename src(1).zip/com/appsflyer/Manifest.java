package com.appsflyer;

public final class Manifest
{
  public Manifest() {}
}
