package com.appsflyer.cache;

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

public class CacheManager
{
  public static final String AF_CACHE_DIR = "AFRequestCache";
  public static final int CACHE_MAX_SIZE = 20;
  private static CacheManager ourInstance = new CacheManager();
  
  private CacheManager() {}
  
  private File getCacheDir(Context paramContext)
  {
    return new File(paramContext.getFilesDir(), "AFRequestCache");
  }
  
  public static CacheManager getInstance()
  {
    return ourInstance;
  }
  
  private RequestCacheData loadRequestData(File paramFile)
  {
    try
    {
      FileReader localFileReader = new FileReader(paramFile);
      long l = paramFile.length();
      Object localObject = new char[(int)l];
      localFileReader.read((char[])localObject);
      localObject = new RequestCacheData((char[])localObject);
      ((RequestCacheData)localObject).setCacheKey(paramFile.getName());
      localFileReader.close();
      return localObject;
    }
    catch (Exception paramFile) {}
    return null;
  }
  
  public void cacheRequest(RequestCacheData paramRequestCacheData, Context paramContext)
  {
    try
    {
      Object localObject = getCacheDir(paramContext);
      boolean bool = ((File)localObject).exists();
      if (!bool)
      {
        ((File)localObject).mkdir();
        return;
      }
      localObject = ((File)localObject).listFiles();
      if (localObject.length > 20)
      {
        Log.i("AppsFlyer_1.17", "reached cache limit, not caching request");
        return;
      }
    }
    catch (Exception paramRequestCacheData)
    {
      Log.i("AppsFlyer_1.17", "Could not cache request");
      return;
    }
    Log.i("AppsFlyer_1.17", "caching request...");
    paramContext = new File(getCacheDir(paramContext), Long.toString(System.currentTimeMillis()));
    paramContext.createNewFile();
    paramContext = new OutputStreamWriter(new FileOutputStream(paramContext.getPath(), true));
    paramContext.write("version=");
    paramContext.write(paramRequestCacheData.getVersion());
    paramContext.write(10);
    paramContext.write("url=");
    paramContext.write(paramRequestCacheData.getRequestURL());
    paramContext.write(10);
    paramContext.write("data=");
    paramContext.write(paramRequestCacheData.getPostData());
    paramContext.write(10);
    paramContext.flush();
    paramContext.close();
  }
  
  public void deleteRequest(String paramString, Context paramContext)
  {
    paramContext = new File(getCacheDir(paramContext), paramString);
    Log.i("AppsFlyer_1.17", "Deleting " + paramString + " from cache");
    if (paramContext.exists()) {
      try
      {
        paramContext.delete();
        return;
      }
      catch (Exception paramContext)
      {
        Log.i("AppsFlyer_1.17", "Could not delete " + paramString + " from cache", paramContext);
      }
    }
  }
  
  public List getCachedRequests(Context paramContext)
  {
    localArrayList = new ArrayList();
    try
    {
      paramContext = getCacheDir(paramContext);
      boolean bool = paramContext.exists();
      if (!bool)
      {
        paramContext.mkdir();
        return localArrayList;
      }
      paramContext = paramContext.listFiles();
      int j = paramContext.length;
      int i = 0;
      while (i < j)
      {
        File localFile = paramContext[i];
        Log.i("AppsFlyer_1.17", "Found cached request" + localFile.getName());
        localArrayList.add(loadRequestData(localFile));
        i += 1;
      }
      return localArrayList;
    }
    catch (Exception paramContext)
    {
      Log.i("AppsFlyer_1.17", "Could not cache request");
    }
  }
  
  public void init(Context paramContext)
  {
    try
    {
      boolean bool = getCacheDir(paramContext).exists();
      if (!bool)
      {
        getCacheDir(paramContext).mkdir();
        return;
      }
    }
    catch (Exception paramContext)
    {
      Log.i("AppsFlyer_1.17", "Could not create cache directory");
    }
  }
}
