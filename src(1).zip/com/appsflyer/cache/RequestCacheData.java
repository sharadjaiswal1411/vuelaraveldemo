package com.appsflyer.cache;

import java.util.Scanner;

public class RequestCacheData
{
  private String cacheKey;
  private String postData;
  private String requestURL;
  private String version;
  
  public RequestCacheData(String paramString1, String paramString2, String paramString3)
  {
    requestURL = paramString1;
    postData = paramString2;
    version = paramString3;
  }
  
  public RequestCacheData(char[] paramArrayOfChar)
  {
    paramArrayOfChar = new Scanner(new String(paramArrayOfChar));
    while (paramArrayOfChar.hasNextLine())
    {
      String str = paramArrayOfChar.nextLine();
      if (str.startsWith("url=")) {
        requestURL = str.substring("url=".length()).trim();
      } else if (str.startsWith("version=")) {
        version = str.substring("version=".length()).trim();
      } else if (str.startsWith("data=")) {
        postData = str.substring("data=".length()).trim();
      }
    }
    paramArrayOfChar.close();
  }
  
  public String getCacheKey()
  {
    return cacheKey;
  }
  
  public String getPostData()
  {
    return postData;
  }
  
  public String getRequestURL()
  {
    return requestURL;
  }
  
  public String getVersion()
  {
    return version;
  }
  
  public void setCacheKey(String paramString)
  {
    cacheKey = paramString;
  }
  
  public void setPostData(String paramString)
  {
    postData = paramString;
  }
  
  public void setRequestURL(String paramString)
  {
    requestURL = paramString;
  }
  
  public void setVersion(String paramString)
  {
    version = paramString;
  }
}
