package com.appsflyer;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AppsFlyerProperties
{
  public static final String ADDITIONAL_CUSTOM_DATA = "additionalCustomData";
  public static final String AF_KEY = "AppsFlyerKey";
  public static final String APP_ID = "appid";
  public static final String APP_USER_ID = "AppUserId";
  public static final String CHANNEL = "channel";
  public static final String COLLECT_ANDROID_ID = "collectAndroidId";
  public static final String COLLECT_IMEI = "collectIMEI";
  public static final String COLLECT_MAC = "collectMAC";
  public static final String CURRENCY_CODE = "currencyCode";
  public static final String DEVICE_TRACKING_DISABLED = "deviceTrackingDisabled";
  public static final String EMAIL_CRYPT_TYPE = "userEmailsCryptType";
  public static final String EXTENSION = "sdkExtension";
  public static final String IS_MONITOR = "shouldMonitor";
  public static final String IS_UPDATE = "IS_UPDATE";
  public static final String USER_EMAIL = "userEmail";
  public static final String USER_EMAILS = "userEmails";
  public static final String USE_HTTP_FALLBACK = "useHttpFallback";
  private static AppsFlyerProperties instance = new AppsFlyerProperties();
  static ArrayList<Activity> listOfRunningActivities = new ArrayList();
  private boolean isDisableLog;
  private boolean isLaunchCalled;
  private boolean isOnReceiveCalled;
  private Map<String, Object> properties = new HashMap();
  private String referrer;
  
  private AppsFlyerProperties() {}
  
  public static AppsFlyerProperties getInstance()
  {
    return instance;
  }
  
  public void check(String paramString, boolean paramBoolean)
  {
    properties.put(paramString, Boolean.toString(paramBoolean));
  }
  
  public void disableLogOutput(boolean paramBoolean)
  {
    isDisableLog = paramBoolean;
  }
  
  public boolean getBoolean(String paramString, boolean paramBoolean)
  {
    paramString = getString(paramString);
    if (paramString == null) {
      return paramBoolean;
    }
    return Boolean.valueOf(paramString).booleanValue();
  }
  
  public int getInt(String paramString, int paramInt)
  {
    paramString = getString(paramString);
    if (paramString == null) {
      return paramInt;
    }
    return Integer.valueOf(paramString).intValue();
  }
  
  public String getReferrer(Context paramContext)
  {
    if (referrer != null) {
      return referrer;
    }
    return paramContext.getSharedPreferences("appsflyer-data", 0).getString("referrer", null);
  }
  
  public void getSetting(String paramString, String[] paramArrayOfString)
  {
    properties.put(paramString, paramArrayOfString);
  }
  
  public String getString(String paramString)
  {
    return (String)properties.get(paramString);
  }
  
  public String[] getStringArray(String paramString)
  {
    return (String[])properties.get(paramString);
  }
  
  public boolean isDisableLog()
  {
    return isDisableLog;
  }
  
  protected boolean isLaunchCollectedReferrerd()
  {
    return isLaunchCalled;
  }
  
  protected boolean isOnReceiveCalled()
  {
    return isOnReceiveCalled;
  }
  
  public void put(String paramString1, String paramString2)
  {
    properties.put(paramString1, paramString2);
  }
  
  public void setCustomData(String paramString)
  {
    properties.put("additionalCustomData", paramString);
  }
  
  protected void setLaunchCollectedReferrer()
  {
    isLaunchCalled = true;
  }
  
  protected void setOnReceiveCalled()
  {
    isOnReceiveCalled = true;
  }
  
  protected void setReferrer(String paramString)
  {
    referrer = paramString;
  }
  
  public void writeValue(String paramString, int paramInt)
  {
    properties.put(paramString, Integer.toString(paramInt));
  }
  
  public static enum EmailsCryptType
  {
    NONE(0),  SHA1(1),  WIKI(2);
    
    private final int value;
    
    private EmailsCryptType(int paramInt)
    {
      value = paramInt;
    }
    
    public int getValue()
    {
      return value;
    }
  }
}
