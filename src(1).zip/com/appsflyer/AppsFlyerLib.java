package com.appsflyer;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Process;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.appsflyer.cache.CacheManager;
import com.appsflyer.cache.RequestCacheData;
import com.google.android.com.ads.identifier.AdvertisingIdClient;
import com.google.android.com.ads.identifier.AdvertisingIdClient.Info;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONException;
import org.json.JSONObject;

public class AppsFlyerLib
  extends BroadcastReceiver
{
  static final String AF_COUNTER_PREF = "appsFlyerCount";
  static final String AF_EVENT_COUNTER_PREF = "appsFlyerCount";
  protected static final String AF_SHARED_PREF = "appsflyer-data";
  static final String AF_TIME_PASSED_SINCE_LAST_LAUNCH = "AppsFlyerTimePassedSincePrevLaunch";
  private static final String ANDROID_ID_CACHED_PREF = "androidIdCached";
  public static final String APPS_TRACKING_URL = "https://t.appsflyer.com/api/v2.3/androidevent?buildnumber=1.17&app_id=";
  public static final String ATTRIBUTION_ID_COLUMN_NAME = "aid";
  public static final Uri ATTRIBUTION_ID_CONTENT_URI = Uri.parse("content://com.facebook.katana.provider.AttributionIdProvider");
  static final String ATTRIBUTION_ID_PREF = "attributionId";
  private static final String CACHED_CHANNEL_PREF = "CACHED_CHANNEL";
  private static final String CACHED_URL_PARAMTER = "&isCachedRequest=true";
  private static final String CALL_SERVER_ACTION = "call server.";
  private static final String DEEPLINK_ATTR_PREF = "deeplinkAttribution";
  private static final String ERROR_PREFIX = "ERROR:";
  public static final String EVENTS_TRACKING_URL = "https://events.appsflyer.com/api/v2.3/androidevent?buildnumber=1.17&app_id=";
  static final String FIRST_INSTALL_PREF = "appsFlyerFirstInstall";
  private static final List<String> IGNORABLE_KEYS = Arrays.asList(new String[] { "is_cache" });
  private static final String IMEI_CACHED_PREF = "imeiCached";
  private static final String INSTALL_STORE_PREF = "INSTALL_STORE";
  private static final String INSTALL_UPDATE_DATE_FORMAT = "yyyy-MM-dd_hhmmZ";
  private static final String IN_APP_EVENTS_API = "1";
  public static final String LOG_TAG = "AppsFlyer_1.17";
  private static final String ON_RECIEVE_CALLED = "onRecieve called. refferer=";
  private static final String PREPARE_DATA_ACTION = "collect data for server";
  private static final String PRE_INSTALL_PREF = "preInstallName";
  protected static final String REFERRER_PREF = "referrer";
  public static final String SDK_BUILD_NUMBER = "1.17";
  static final String SENT_SUCCESSFULLY_PREF = "sentSuccessfully";
  public static final String SERVER_BUILD_NUMBER = "2.3";
  private static final String SERVER_RESPONDED_ACTION = "response from server. status=";
  private static final String STATS_URL = "https://stats.appsflyer.com/stats";
  private static final String UNINSTALL_URL = "https://track.appsflyer.com/api/v2.3/uninsall?buildnumber=1.17";
  private static final String WARNING_PREFIX = "WARNING:";
  private static ScheduledExecutorService cacheScheduler = null;
  private static AppsFlyerConversionListener conversionDataListener = null;
  private static boolean isDuringCheckCache = false;
  private static long lastCacheCheck;
  private static long timeInApp = 0L;
  
  public AppsFlyerLib() {}
  
  private static void addAdvertiserIDData(Context paramContext, Map paramMap)
  {
    try
    {
      Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient");
      Object localObject = AdvertisingIdClient.getAdvertisingIdInfo(paramContext);
      String str = ((AdvertisingIdClient.Info)localObject).getId();
      paramMap.put("advertiserId", str);
      boolean bool = ((AdvertisingIdClient.Info)localObject).isLimitAdTrackingEnabled();
      if (!bool) {}
      for (bool = true;; bool = false)
      {
        localObject = Boolean.toString(bool);
        paramMap.put("advertiserIdEnabled", localObject);
        AppsFlyerProperties.getInstance().put("advertiserId", str);
        AppsFlyerProperties.getInstance().put("advertiserIdEnabled", (String)localObject);
        return;
      }
      return;
    }
    catch (ClassNotFoundException paramMap)
    {
      if (shouldLog(paramContext))
      {
        Log.i("AppsFlyer_1.17", "WARNING:Google Play services SDK jar is missing.");
        return;
      }
    }
    catch (Exception localException)
    {
      localObject = AppsFlyerProperties.getInstance().getString("advertiserId");
      if (localObject != null) {
        paramMap.put("advertiserId", localObject);
      }
      localObject = AppsFlyerProperties.getInstance().getString("advertiserIdEnabled");
      if (localObject != null) {
        paramMap.put("advertiserIdEnabled", localObject);
      }
      if (localException.getLocalizedMessage() != null) {
        Log.i("AppsFlyer_1.17", localException.getLocalizedMessage());
      }
      for (;;)
      {
        debugAction("Could not fetch advertiser id: ", localException.getLocalizedMessage(), paramContext);
        return;
        Log.i("AppsFlyer_1.17", localException.toString());
      }
    }
  }
  
  private static void addDeviceTracking(Context paramContext, Map paramMap)
  {
    if (AppsFlyerProperties.getInstance().getBoolean("deviceTrackingDisabled", false))
    {
      paramMap.put("deviceTrackingDisabled", "true");
      return;
    }
    SharedPreferences localSharedPreferences = paramContext.getSharedPreferences("appsflyer-data", 0);
    boolean bool = AppsFlyerProperties.getInstance().getBoolean("collectIMEI", true);
    String str = localSharedPreferences.getString("imeiCached", null);
    if (bool) {}
    for (;;)
    {
      try
      {
        localObject1 = paramContext.getSystemService("phone");
        localObject1 = (TelephonyManager)localObject1;
        localObject3 = localObject1.getClass();
        localObject3 = ((Class)localObject3).getMethod("getDeviceId", new Class[0]);
        localObject1 = ((Method)localObject3).invoke(localObject1, new Object[0]);
        localObject3 = (String)localObject1;
        if (localObject3 != null) {
          continue;
        }
        localObject1 = str;
      }
      catch (Exception localException)
      {
        Object localObject1;
        Object localObject3;
        Log.i("AppsFlyer_1.17", "WARNING:READ_PHONE_STATE is missing");
        continue;
        localException.commit();
        Object localObject2 = localObject3;
        continue;
        localObject2 = localSharedPreferences.edit();
        ((SharedPreferences.Editor)localObject2).putString("androidIdCached", str);
        if (Build.VERSION.SDK_INT < 9) {
          continue;
        }
        ((SharedPreferences.Editor)localObject2).apply();
        continue;
        ((SharedPreferences.Editor)localObject2).commit();
        continue;
      }
      if (localObject1 != null) {
        paramMap.put("imei", localObject1);
      }
      bool = AppsFlyerProperties.getInstance().getBoolean("collectAndroidId", true);
      localObject1 = localSharedPreferences.getString("androidIdCached", null);
      if (!bool) {
        return;
      }
      try
      {
        str = Settings.Secure.getString(paramContext.getContentResolver(), "android_id");
        paramContext = str;
        if (str != null) {
          continue;
        }
        paramContext = (Context)localObject1;
        if (paramContext == null) {
          return;
        }
        paramMap.put("android_id", paramContext);
        return;
      }
      catch (Exception paramContext)
      {
        return;
      }
      localObject1 = localObject3;
      if (str == null)
      {
        localObject1 = localSharedPreferences.edit();
        ((SharedPreferences.Editor)localObject1).putString("imeiCached", (String)localObject3);
        if (Build.VERSION.SDK_INT < 9) {
          continue;
        }
        ((SharedPreferences.Editor)localObject1).apply();
        localObject1 = localObject3;
      }
    }
  }
  
  private static Map attributionStringToMap(String paramString)
  {
    localHashMap = new HashMap();
    try
    {
      paramString = new JSONObject(paramString);
      Iterator localIterator = paramString.keys();
      for (;;)
      {
        boolean bool = localIterator.hasNext();
        if (!bool) {
          break;
        }
        Object localObject = localIterator.next();
        localObject = (String)localObject;
        List localList = IGNORABLE_KEYS;
        bool = localList.contains(localObject);
        if (!bool) {
          localHashMap.put(localObject, paramString.getString((String)localObject));
        }
      }
      return localHashMap;
    }
    catch (JSONException paramString)
    {
      Log.w("AppsFlyer_1.17", paramString);
      return null;
    }
  }
  
  /* Error */
  private static void callServer(URL paramURL, String paramString1, String paramString2, WeakReference paramWeakReference, String paramString3, String paramString4, boolean paramBoolean)
    throws IOException
  {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual 446	java/lang/ref/WeakReference:get	()Ljava/lang/Object;
    //   4: checkcast 325	android/content/Context
    //   7: astore 12
    //   9: aconst_null
    //   10: astore 9
    //   12: aload_0
    //   13: invokevirtual 452	java/net/URL:openConnection	()Ljava/net/URLConnection;
    //   16: checkcast 454	java/net/HttpURLConnection
    //   19: astore 10
    //   21: aload 10
    //   23: astore_0
    //   24: aload_0
    //   25: astore 9
    //   27: aload 10
    //   29: ldc_w 456
    //   32: invokevirtual 459	java/net/HttpURLConnection:setRequestMethod	(Ljava/lang/String;)V
    //   35: aload_0
    //   36: astore 9
    //   38: aload_1
    //   39: invokevirtual 463	java/lang/String:getBytes	()[B
    //   42: arraylength
    //   43: istore 7
    //   45: aload_0
    //   46: astore 9
    //   48: aload 10
    //   50: ldc_w 465
    //   53: new 467	java/lang/StringBuilder
    //   56: dup
    //   57: invokespecial 468	java/lang/StringBuilder:<init>	()V
    //   60: iload 7
    //   62: invokevirtual 472	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   65: ldc_w 474
    //   68: invokevirtual 477	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   71: invokevirtual 478	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   74: invokevirtual 481	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   77: aload_0
    //   78: astore 9
    //   80: aload 10
    //   82: ldc_w 483
    //   85: ldc_w 485
    //   88: invokevirtual 481	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   91: aload_0
    //   92: astore 9
    //   94: aload 10
    //   96: sipush 10000
    //   99: invokevirtual 489	java/net/HttpURLConnection:setConnectTimeout	(I)V
    //   102: aload_0
    //   103: astore 9
    //   105: aload 10
    //   107: iconst_1
    //   108: invokevirtual 493	java/net/HttpURLConnection:setDoOutput	(Z)V
    //   111: aconst_null
    //   112: astore 9
    //   114: new 495	java/io/OutputStreamWriter
    //   117: dup
    //   118: aload 10
    //   120: invokevirtual 499	java/net/HttpURLConnection:getOutputStream	()Ljava/io/OutputStream;
    //   123: invokespecial 502	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;)V
    //   126: astore 11
    //   128: aload 11
    //   130: aload_1
    //   131: invokevirtual 505	java/io/OutputStreamWriter:write	(Ljava/lang/String;)V
    //   134: aload 11
    //   136: ifnull +11 -> 147
    //   139: aload_0
    //   140: astore 9
    //   142: aload 11
    //   144: invokevirtual 507	java/io/OutputStreamWriter:close	()V
    //   147: aload_0
    //   148: astore 9
    //   150: aload 10
    //   152: invokevirtual 511	java/net/HttpURLConnection:getResponseCode	()I
    //   155: istore 7
    //   157: aload_0
    //   158: astore 9
    //   160: aload 12
    //   162: invokestatic 181	com/appsflyer/AppsFlyerLib:shouldLog	(Landroid/content/Context;)Z
    //   165: istore 8
    //   167: iload 8
    //   169: ifeq +33 -> 202
    //   172: aload_0
    //   173: astore 9
    //   175: aload 5
    //   177: new 467	java/lang/StringBuilder
    //   180: dup
    //   181: invokespecial 468	java/lang/StringBuilder:<init>	()V
    //   184: ldc_w 513
    //   187: invokevirtual 477	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: iload 7
    //   192: invokevirtual 472	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   195: invokevirtual 478	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   198: invokestatic 299	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   201: pop
    //   202: aload_0
    //   203: astore 9
    //   205: aload 12
    //   207: aload 5
    //   209: ldc_w 515
    //   212: iload 7
    //   214: invokestatic 520	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   217: invokestatic 524	com/appsflyer/AppsFlyerLib:monitor	(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   220: aload_0
    //   221: astore 9
    //   223: ldc 109
    //   225: iload 7
    //   227: invokestatic 520	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   230: aload 12
    //   232: invokestatic 312	com/appsflyer/AppsFlyerLib:debugAction	(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)V
    //   235: aload_0
    //   236: astore 9
    //   238: aload 12
    //   240: ldc 29
    //   242: iconst_0
    //   243: invokevirtual 329	android/content/Context:getSharedPreferences	(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   246: astore_1
    //   247: iload 7
    //   249: sipush 200
    //   252: if_icmpne +81 -> 333
    //   255: aload 4
    //   257: ifnull +16 -> 273
    //   260: aload_0
    //   261: astore 9
    //   263: invokestatic 529	com/appsflyer/cache/CacheManager:getInstance	()Lcom/appsflyer/cache/CacheManager;
    //   266: aload 4
    //   268: aload 12
    //   270: invokevirtual 533	com/appsflyer/cache/CacheManager:deleteRequest	(Ljava/lang/String;Landroid/content/Context;)V
    //   273: aload_0
    //   274: astore 9
    //   276: aload_3
    //   277: invokevirtual 446	java/lang/ref/WeakReference:get	()Ljava/lang/Object;
    //   280: astore_3
    //   281: aload_3
    //   282: ifnull +51 -> 333
    //   285: aload 4
    //   287: ifnonnull +46 -> 333
    //   290: aload_0
    //   291: astore 9
    //   293: aload_1
    //   294: invokeinterface 381 1 0
    //   299: astore_3
    //   300: aload_0
    //   301: astore 9
    //   303: aload_3
    //   304: ldc 103
    //   306: ldc_w 323
    //   309: invokeinterface 387 3 0
    //   314: pop
    //   315: aload_0
    //   316: astore 9
    //   318: aload_3
    //   319: invokeinterface 401 1 0
    //   324: pop
    //   325: aload_0
    //   326: astore 9
    //   328: aload 12
    //   330: invokestatic 537	com/appsflyer/AppsFlyerLib:checkCache	(Landroid/content/Context;)V
    //   333: aload_0
    //   334: astore 9
    //   336: aload_1
    //   337: ldc 46
    //   339: aconst_null
    //   340: invokeinterface 336 3 0
    //   345: astore_3
    //   346: aload_3
    //   347: ifnonnull +93 -> 440
    //   350: aload_2
    //   351: ifnull +89 -> 440
    //   354: iload 6
    //   356: ifeq +84 -> 440
    //   359: aload_0
    //   360: astore 9
    //   362: invokestatic 542	java/util/concurrent/Executors:newSingleThreadScheduledExecutor	()Ljava/util/concurrent/ScheduledExecutorService;
    //   365: astore_1
    //   366: aload_0
    //   367: astore 9
    //   369: aload_1
    //   370: new 17	com/appsflyer/AppsFlyerLib$InstallAttributionIdFetcher
    //   373: dup
    //   374: aload 12
    //   376: invokevirtual 546	android/content/Context:getApplicationContext	()Landroid/content/Context;
    //   379: aload_2
    //   380: aload_1
    //   381: invokespecial 549	com/appsflyer/AppsFlyerLib$InstallAttributionIdFetcher:<init>	(Landroid/content/Context;Ljava/lang/String;Ljava/util/concurrent/ScheduledExecutorService;)V
    //   384: ldc2_w 550
    //   387: getstatic 557	java/util/concurrent/TimeUnit:MILLISECONDS	Ljava/util/concurrent/TimeUnit;
    //   390: invokeinterface 563 5 0
    //   395: pop
    //   396: aload 10
    //   398: ifnull +152 -> 550
    //   401: aload 10
    //   403: invokevirtual 566	java/net/HttpURLConnection:disconnect	()V
    //   406: return
    //   407: astore_2
    //   408: aload 9
    //   410: astore_1
    //   411: aload_1
    //   412: ifnull +10 -> 422
    //   415: aload_0
    //   416: astore 9
    //   418: aload_1
    //   419: invokevirtual 507	java/io/OutputStreamWriter:close	()V
    //   422: aload_0
    //   423: astore 9
    //   425: aload_2
    //   426: athrow
    //   427: astore_0
    //   428: aload 9
    //   430: ifnull +8 -> 438
    //   433: aload 9
    //   435: invokevirtual 566	java/net/HttpURLConnection:disconnect	()V
    //   438: aload_0
    //   439: athrow
    //   440: aload_2
    //   441: ifnonnull +18 -> 459
    //   444: aload_0
    //   445: astore 9
    //   447: aload 5
    //   449: ldc_w 568
    //   452: invokestatic 570	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   455: pop
    //   456: goto -60 -> 396
    //   459: iload 6
    //   461: ifeq -65 -> 396
    //   464: aload_0
    //   465: astore 9
    //   467: getstatic 153	com/appsflyer/AppsFlyerLib:conversionDataListener	Lcom/appsflyer/AppsFlyerConversionListener;
    //   470: astore_2
    //   471: aload_2
    //   472: ifnull -76 -> 396
    //   475: aload_0
    //   476: astore 9
    //   478: aload_1
    //   479: ldc 46
    //   481: aconst_null
    //   482: invokeinterface 336 3 0
    //   487: astore_1
    //   488: aload_1
    //   489: ifnull -93 -> 396
    //   492: aload_0
    //   493: astore 9
    //   495: aload 12
    //   497: iconst_0
    //   498: invokestatic 213	com/appsflyer/AppsFlyerLib:getCounter	(Landroid/content/Context;Z)I
    //   501: istore 7
    //   503: iload 7
    //   505: iconst_1
    //   506: if_icmple -110 -> 396
    //   509: aload_0
    //   510: astore 9
    //   512: aload 12
    //   514: invokestatic 574	com/appsflyer/AppsFlyerLib:getConversionData	(Landroid/content/Context;)Ljava/util/Map;
    //   517: astore_1
    //   518: aload_1
    //   519: ifnull -123 -> 396
    //   522: getstatic 153	com/appsflyer/AppsFlyerLib:conversionDataListener	Lcom/appsflyer/AppsFlyerConversionListener;
    //   525: astore_2
    //   526: aload_0
    //   527: astore 9
    //   529: aload_2
    //   530: aload_1
    //   531: invokeinterface 580 2 0
    //   536: goto -140 -> 396
    //   539: astore_0
    //   540: goto -144 -> 396
    //   543: astore_2
    //   544: aload 11
    //   546: astore_1
    //   547: goto -136 -> 411
    //   550: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	551	0	paramURL	URL
    //   0	551	1	paramString1	String
    //   0	551	2	paramString2	String
    //   0	551	3	paramWeakReference	WeakReference
    //   0	551	4	paramString3	String
    //   0	551	5	paramString4	String
    //   0	551	6	paramBoolean	boolean
    //   43	464	7	i	int
    //   165	3	8	bool	boolean
    //   10	518	9	localURL	URL
    //   19	383	10	localHttpURLConnection	HttpURLConnection
    //   126	419	11	localOutputStreamWriter	java.io.OutputStreamWriter
    //   7	506	12	localContext	Context
    // Exception table:
    //   from	to	target	type
    //   114	128	407	java/lang/Throwable
    //   12	21	427	java/lang/Throwable
    //   27	35	427	java/lang/Throwable
    //   38	45	427	java/lang/Throwable
    //   48	77	427	java/lang/Throwable
    //   80	91	427	java/lang/Throwable
    //   94	102	427	java/lang/Throwable
    //   105	111	427	java/lang/Throwable
    //   142	147	427	java/lang/Throwable
    //   150	157	427	java/lang/Throwable
    //   160	167	427	java/lang/Throwable
    //   175	202	427	java/lang/Throwable
    //   205	220	427	java/lang/Throwable
    //   223	235	427	java/lang/Throwable
    //   238	247	427	java/lang/Throwable
    //   263	273	427	java/lang/Throwable
    //   276	281	427	java/lang/Throwable
    //   293	300	427	java/lang/Throwable
    //   303	315	427	java/lang/Throwable
    //   318	325	427	java/lang/Throwable
    //   328	333	427	java/lang/Throwable
    //   336	346	427	java/lang/Throwable
    //   362	366	427	java/lang/Throwable
    //   369	396	427	java/lang/Throwable
    //   418	422	427	java/lang/Throwable
    //   425	427	427	java/lang/Throwable
    //   447	456	427	java/lang/Throwable
    //   467	471	427	java/lang/Throwable
    //   478	488	427	java/lang/Throwable
    //   495	503	427	java/lang/Throwable
    //   512	518	427	java/lang/Throwable
    //   529	536	427	java/lang/Throwable
    //   512	518	539	com/appsflyer/AttributionIDNotReady
    //   529	536	539	com/appsflyer/AttributionIDNotReady
    //   128	134	543	java/lang/Throwable
  }
  
  private static void checkCache(Context paramContext)
  {
    if (!isDuringCheckCache)
    {
      if (System.currentTimeMillis() - lastCacheCheck < 15000L) {
        return;
      }
      if (cacheScheduler == null)
      {
        cacheScheduler = Executors.newSingleThreadScheduledExecutor();
        cacheScheduler.schedule(new CachedRequestSender(paramContext), 1L, TimeUnit.SECONDS);
      }
    }
  }
  
  private static void checkPlatform(Context paramContext, Map paramMap)
  {
    try
    {
      paramContext = Class.forName("com.unity3d.player.UnityPlayer");
      Log.i("AppsFlyer_1.17", "WARNING:checkPlatform Built using Unity 1." + paramContext.toString());
      return;
    }
    catch (ClassNotFoundException paramContext)
    {
      Log.i("AppsFlyer_1.17", "WARNING:checkPlatform Not Built using Unity 22.");
      return;
    }
    catch (Exception paramContext) {}
  }
  
  private static void debugAction(String paramString1, String paramString2, Context paramContext)
  {
    if ((paramContext != null) && ("com.appsflyer".equals(paramContext.getPackageName()))) {
      DebugLogQueue.getInstance().push(paramString1 + paramString2);
    }
  }
  
  public static String getAppId()
  {
    return getProperty("appid");
  }
  
  public static String getAppUserId()
  {
    return getProperty("AppUserId");
  }
  
  public static String getAppsFlyerUID(Context paramContext)
  {
    return Installation.id(paramContext);
  }
  
  /* Error */
  public static String getAttributionId(android.content.ContentResolver paramContentResolver)
  {
    // Byte code:
    //   0: aload_0
    //   1: getstatic 139	com/appsflyer/AppsFlyerLib:ATTRIBUTION_ID_CONTENT_URI	Landroid/net/Uri;
    //   4: iconst_1
    //   5: anewarray 141	java/lang/String
    //   8: dup
    //   9: iconst_0
    //   10: ldc 41
    //   12: aastore
    //   13: aconst_null
    //   14: aconst_null
    //   15: aconst_null
    //   16: invokevirtual 640	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   19: astore_3
    //   20: aconst_null
    //   21: astore_0
    //   22: aload_3
    //   23: ifnull +14 -> 37
    //   26: aload_3
    //   27: invokeinterface 645 1 0
    //   32: istore_1
    //   33: iload_1
    //   34: ifne +15 -> 49
    //   37: aload_3
    //   38: ifnull +91 -> 129
    //   41: aload_3
    //   42: invokeinterface 646 1 0
    //   47: aconst_null
    //   48: areturn
    //   49: aload_3
    //   50: aload_3
    //   51: ldc 41
    //   53: invokeinterface 650 2 0
    //   58: invokeinterface 652 2 0
    //   63: astore_2
    //   64: aload_2
    //   65: astore_0
    //   66: aload_3
    //   67: ifnull +11 -> 78
    //   70: aload_3
    //   71: invokeinterface 646 1 0
    //   76: aload_2
    //   77: astore_0
    //   78: aload_0
    //   79: areturn
    //   80: astore_2
    //   81: ldc 85
    //   83: ldc_w 654
    //   86: aload_2
    //   87: invokestatic 657	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   90: pop
    //   91: aload_3
    //   92: ifnull -14 -> 78
    //   95: aload_3
    //   96: invokeinterface 646 1 0
    //   101: aconst_null
    //   102: areturn
    //   103: astore_0
    //   104: aconst_null
    //   105: areturn
    //   106: astore_0
    //   107: aload_3
    //   108: ifnull +9 -> 117
    //   111: aload_3
    //   112: invokeinterface 646 1 0
    //   117: aload_0
    //   118: athrow
    //   119: astore_0
    //   120: aconst_null
    //   121: areturn
    //   122: astore_0
    //   123: aload_2
    //   124: areturn
    //   125: astore_2
    //   126: goto -9 -> 117
    //   129: aconst_null
    //   130: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	131	0	paramContentResolver	android.content.ContentResolver
    //   32	2	1	bool	boolean
    //   63	14	2	str	String
    //   80	44	2	localException1	Exception
    //   125	1	2	localException2	Exception
    //   19	93	3	localCursor	android.database.Cursor
    // Exception table:
    //   from	to	target	type
    //   26	33	80	java/lang/Exception
    //   49	64	80	java/lang/Exception
    //   95	101	103	java/lang/Exception
    //   26	33	106	java/lang/Throwable
    //   49	64	106	java/lang/Throwable
    //   81	91	106	java/lang/Throwable
    //   41	47	119	java/lang/Exception
    //   70	76	122	java/lang/Exception
    //   111	117	125	java/lang/Exception
  }
  
  private static String getCachedChannel(Context paramContext, String paramString)
    throws PackageManager.NameNotFoundException
  {
    paramContext = paramContext.getSharedPreferences("appsflyer-data", 0);
    if (paramContext.contains("CACHED_CHANNEL")) {
      return paramContext.getString("CACHED_CHANNEL", null);
    }
    paramContext = paramContext.edit();
    paramContext.putString("CACHED_CHANNEL", paramString);
    paramContext.commit();
    return paramString;
  }
  
  private static String getCachedStore(Context paramContext)
  {
    String str = null;
    Object localObject = paramContext.getSharedPreferences("appsflyer-data", 0);
    if (((SharedPreferences)localObject).contains("INSTALL_STORE")) {
      return ((SharedPreferences)localObject).getString("INSTALL_STORE", null);
    }
    boolean bool = isAppsFlyerFirstLaunch(paramContext);
    localObject = ((SharedPreferences)localObject).edit();
    if (bool) {
      str = getCurrentStore(paramContext);
    }
    ((SharedPreferences.Editor)localObject).putString("INSTALL_STORE", str);
    ((SharedPreferences.Editor)localObject).commit();
    return str;
  }
  
  private static String getConfiguredChannel(Context paramContext)
  {
    String str = AppsFlyerProperties.getInstance().getString("channel");
    if (str == null) {
      try
      {
        paramContext = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
        paramContext = metaData;
        if (paramContext != null)
        {
          paramContext = paramContext.get("CHANNEL");
          if (paramContext != null)
          {
            if ((paramContext instanceof String)) {
              return (String)paramContext;
            }
            paramContext = paramContext.toString();
            return paramContext;
          }
        }
      }
      catch (Exception paramContext)
      {
        Log.i("AppsFlyer_1.17", "Could not load CHANNEL value", paramContext);
      }
    }
    return str;
  }
  
  public static Map getConversionData(Context paramContext)
    throws AttributionIDNotReady
  {
    SharedPreferences localSharedPreferences = paramContext.getSharedPreferences("appsflyer-data", 0);
    String str = AppsFlyerProperties.getInstance().getReferrer(paramContext);
    if ((str != null) && (str.length() > 0) && (str.contains("af_tranid"))) {
      return referrerStringToMap(str, paramContext);
    }
    paramContext = localSharedPreferences.getString("attributionId", null);
    if ((paramContext != null) && (paramContext.length() > 0)) {
      return attributionStringToMap(paramContext);
    }
    throw new AttributionIDNotReady();
  }
  
  public static void getConversionData(Context paramContext, ConversionDataListener paramConversionDataListener)
  {
    registerConversionListener(paramContext, new AppsFlyerConversionListener()
    {
      public void onAppOpenAttribution(Map paramAnonymousMap) {}
      
      public void onAttributionFailure(String paramAnonymousString) {}
      
      public void onInstallConversionDataLoaded(Map paramAnonymousMap)
      {
        val$conversionDataListener.onConversionDataLoaded(paramAnonymousMap);
      }
      
      public void onInstallConversionFailure(String paramAnonymousString)
      {
        val$conversionDataListener.onConversionFailure(paramAnonymousString);
      }
    });
  }
  
  private static int getCounter(Context paramContext, boolean paramBoolean)
  {
    paramContext = paramContext.getSharedPreferences("appsflyer-data", 0);
    int j = paramContext.getInt("appsFlyerCount", 0);
    int i = j;
    if (paramBoolean)
    {
      i = j + 1;
      paramContext = paramContext.edit();
      paramContext.putInt("appsFlyerCount", i);
      paramContext.commit();
    }
    return i;
  }
  
  private static String getCurrentStore(Context paramContext)
  {
    try
    {
      Object localObject = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
      localObject = metaData;
      if (localObject != null)
      {
        localObject = ((Bundle)localObject).get("AF_STORE");
        if (localObject != null)
        {
          if ((localObject instanceof String)) {
            return (String)localObject;
          }
          localObject = localObject.toString();
          return localObject;
        }
      }
    }
    catch (Exception localException)
    {
      if (shouldLog(paramContext)) {
        Log.i("AppsFlyer_1.17", "Could not find AF_STORE value in the manifest", localException);
      }
    }
    return null;
  }
  
  private static String getEventTag(Map paramMap)
  {
    paramMap = (String)paramMap.get("af_timestamp");
    if ((paramMap == null) || (paramMap.length() < 5)) {
      return "AppsFlyer_1.17";
    }
    return "AppsFlyer_1.17-" + paramMap.substring(4);
  }
  
  private static String getFirstInstallDate(SimpleDateFormat paramSimpleDateFormat, Context paramContext)
  {
    SharedPreferences localSharedPreferences = paramContext.getSharedPreferences("appsflyer-data", 0);
    String str = localSharedPreferences.getString("appsFlyerFirstInstall", null);
    Object localObject = str;
    if (str == null)
    {
      if (!isAppsFlyerFirstLaunch(paramContext)) {
        break label123;
      }
      if (shouldLog(paramContext)) {
        Log.d("AppsFlyer_1.17", "AppsFlyer: first launch detected");
      }
    }
    label123:
    for (paramSimpleDateFormat = paramSimpleDateFormat.format(new Date());; paramSimpleDateFormat = "")
    {
      localObject = localSharedPreferences.edit();
      ((SharedPreferences.Editor)localObject).putString("appsFlyerFirstInstall", paramSimpleDateFormat);
      ((SharedPreferences.Editor)localObject).commit();
      localObject = paramSimpleDateFormat;
      if (!shouldLog(paramContext)) {
        break;
      }
      Log.i("AppsFlyer_1.17", "AppsFlyer: first launch date: " + (String)localObject);
      return localObject;
    }
    return localObject;
  }
  
  private static int getIAECounter(Context paramContext, boolean paramBoolean)
  {
    paramContext = paramContext.getSharedPreferences("appsflyer-data", 0);
    int j = paramContext.getInt("appsFlyerCount", 0);
    int i = j;
    if (paramBoolean)
    {
      i = j + 1;
      paramContext = paramContext.edit();
      paramContext.putInt("appsFlyerCount", i);
      paramContext.commit();
    }
    return i;
  }
  
  private static String getNetwork(Context paramContext)
  {
    paramContext = (ConnectivityManager)paramContext.getSystemService("connectivity");
    if (paramContext.getNetworkInfo(1).isConnectedOrConnecting()) {
      return "WIFI";
    }
    paramContext = paramContext.getNetworkInfo(0);
    if ((paramContext != null) && (paramContext.isConnectedOrConnecting())) {
      return "MOBILE";
    }
    return "unkown";
  }
  
  private static String getPreInstallName(Context paramContext)
  {
    localObject1 = paramContext.getSharedPreferences("appsflyer-data", 0);
    if (((SharedPreferences)localObject1).contains("preInstallName")) {
      return ((SharedPreferences)localObject1).getString("preInstallName", null);
    }
    boolean bool = isAppsFlyerFirstLaunch(paramContext);
    SharedPreferences.Editor localEditor = ((SharedPreferences)localObject1).edit();
    localObject2 = null;
    localObject1 = localObject2;
    if (bool) {}
    for (;;)
    {
      try
      {
        localObject1 = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
        localObject3 = metaData;
        localObject1 = localObject2;
        if (localObject3 != null)
        {
          localObject3 = ((Bundle)localObject3).get("AF_PRE_INSTALL_NAME");
          localObject1 = localObject2;
          if (localObject3 != null)
          {
            if (!(localObject3 instanceof String)) {
              continue;
            }
            localObject1 = (String)localObject3;
          }
        }
      }
      catch (Exception localException)
      {
        Object localObject3;
        localObject1 = localObject2;
        if (!shouldLog(paramContext)) {
          continue;
        }
        Log.i("AppsFlyer_1.17", "Could not find AF_PRE_INSTALL_NAME value in the manifest", localException);
        localObject1 = localObject2;
        continue;
      }
      localEditor.putString("preInstallName", (String)localObject1);
      localEditor.commit();
      return localObject1;
      localObject1 = localObject3.toString();
    }
  }
  
  public static String getProperty(String paramString)
  {
    return AppsFlyerProperties.getInstance().getString(paramString);
  }
  
  private static long getTimePassedSinceLastLaunch(Context paramContext)
  {
    paramContext = paramContext.getSharedPreferences("appsflyer-data", 0);
    long l = paramContext.getLong("AppsFlyerTimePassedSincePrevLaunch", 0L);
    paramContext = paramContext.edit();
    if (l > 0L) {}
    for (l = new Date().getTime() - l;; l = -1L)
    {
      paramContext.putLong("AppsFlyerTimePassedSincePrevLaunch", new Date().getTime());
      paramContext.commit();
      return l / 1000L;
    }
  }
  
  private static boolean isAppsFlyerFirstLaunch(Context paramContext)
  {
    return !paramContext.getSharedPreferences("appsflyer-data", 0).contains("appsFlyerCount");
  }
  
  public static boolean isPreInstalledApp(Context paramContext)
  {
    try
    {
      paramContext = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 0);
      if ((flags & 0x1) != 0) {
        return true;
      }
    }
    catch (PackageManager.NameNotFoundException paramContext)
    {
      Log.e("AppsFlyer_1.17", "Could not check if app is pre installed", paramContext);
    }
    return false;
  }
  
  private static String mapToString(Map paramMap)
    throws UnsupportedEncodingException
  {
    StringBuilder localStringBuilder = new StringBuilder();
    Iterator localIterator = paramMap.keySet().iterator();
    if (localIterator.hasNext())
    {
      String str2 = (String)localIterator.next();
      String str1 = (String)paramMap.get(str2);
      if (str1 == null) {}
      for (str1 = "";; str1 = URLEncoder.encode(str1, "UTF-8"))
      {
        if (localStringBuilder.length() > 0) {
          localStringBuilder.append('&');
        }
        localStringBuilder.append(str2).append('=').append(str1);
        break;
      }
    }
    return localStringBuilder.toString();
  }
  
  private static void monitor(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
    if (AppsFlyerProperties.getInstance().getBoolean("shouldMonitor", false))
    {
      Intent localIntent = new Intent("com.appsflyer.MonitorBroadcast");
      localIntent.setPackage("com.appsflyer.nightvision");
      localIntent.putExtra("message", paramString2);
      localIntent.putExtra("value", paramString3);
      localIntent.putExtra("packageName", "true");
      localIntent.putExtra("pid", new Integer(Process.myPid()));
      localIntent.putExtra("eventIdentifier", paramString1);
      localIntent.putExtra("sdk", "2.3.1.17");
      paramContext.sendBroadcast(localIntent);
    }
  }
  
  public static void onActivityPause(Activity paramActivity)
  {
    if (AppsFlyerProperties.listOfRunningActivities.size() > 0)
    {
      int i = 0;
      for (;;)
      {
        if (i < AppsFlyerProperties.listOfRunningActivities.size())
        {
          if (((Activity)AppsFlyerProperties.listOfRunningActivities.get(i)).equals(paramActivity)) {
            AppsFlyerProperties.listOfRunningActivities.remove(paramActivity);
          }
        }
        else
        {
          if (AppsFlyerProperties.listOfRunningActivities.size() != 0) {
            break;
          }
          Log.i("AppsFlyer_1.17", "app goes to background");
          long l1 = new Date().getTime();
          long l2 = timeInApp;
          HashMap localHashMap = new HashMap();
          String str = getProperty("AppsFlyerKey");
          localHashMap.put("app_id", paramActivity.getApplicationContext().getPackageName());
          localHashMap.put("devkey", str);
          localHashMap.put("uid", getAppsFlyerUID(paramActivity.getApplicationContext()));
          localHashMap.put("time_in_app", String.valueOf((l1 - l2) / 1000L));
          localHashMap.put("statType", "user_closed_app");
          localHashMap.put("platform", "Android");
          localHashMap.put("launch_counter", Integer.toString(getCounter(paramActivity.getApplicationContext(), false)));
          paramActivity = new BackgroundHttpTask(paramActivity.getApplicationContext());
          bodyPaeameters = localHashMap;
          paramActivity.execute(new String[] { "https://stats.appsflyer.com/stats" });
          return;
        }
        i += 1;
      }
    }
  }
  
  public static void onActivityResume(Activity paramActivity)
  {
    if (AppsFlyerProperties.listOfRunningActivities.size() == 0)
    {
      AppsFlyerProperties.listOfRunningActivities.add(paramActivity);
      timeInApp = new Date().getTime();
      return;
    }
    int i = 0;
    while (i < AppsFlyerProperties.listOfRunningActivities.size())
    {
      if (!((Activity)AppsFlyerProperties.listOfRunningActivities.get(i)).equals(paramActivity)) {
        AppsFlyerProperties.listOfRunningActivities.add(paramActivity);
      }
      i += 1;
    }
  }
  
  private static Map referrerStringToMap(String paramString, Context paramContext)
  {
    int k = 0;
    int i = 0;
    HashMap localHashMap = new HashMap();
    int m = paramString.indexOf('&');
    int j = k;
    if (m >= 0)
    {
      j = k;
      if (paramString.length() > m + 1)
      {
        String[] arrayOfString = paramString.split("\\&");
        k = arrayOfString.length;
        j = 0;
        if (j < k)
        {
          paramString = arrayOfString[j].split("=");
          Object localObject1;
          label88:
          Object localObject2;
          if (paramString.length > 1)
          {
            localObject1 = paramString[1];
            localObject2 = paramString[0];
            if (!localObject2.equals("c")) {
              break label134;
            }
            paramString = "campaign";
          }
          for (;;)
          {
            localHashMap.put(paramString, localObject1);
            j += 1;
            break;
            localObject1 = "";
            break label88;
            label134:
            if (localObject2.equals("pid"))
            {
              paramString = "media_source";
            }
            else
            {
              paramString = localObject2;
              if (localObject2.equals("af_prt"))
              {
                i = 1;
                localHashMap.put(localObject2, localObject1);
                paramString = "agency";
              }
            }
          }
        }
      }
    }
    try
    {
      boolean bool = localHashMap.containsKey("install_time");
      if (!bool)
      {
        paramString = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0);
        long l = firstInstallTime;
        paramString = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        localHashMap.put("install_time", paramString.format(new Date(l)));
      }
    }
    catch (Exception paramString)
    {
      for (;;)
      {
        Log.w("AppsFlyer_1.17", "Could not fetch install time");
      }
    }
    j = i;
    if (!localHashMap.containsKey("af_status"))
    {
      localHashMap.put("af_status", "Non-organic");
      j = i;
    }
    if (j != 0)
    {
      localHashMap.remove("media_source");
      return localHashMap;
    }
    return localHashMap;
  }
  
  public static void registerConversionListener(Context paramContext, AppsFlyerConversionListener paramAppsFlyerConversionListener)
  {
    if (paramAppsFlyerConversionListener == null) {
      return;
    }
    conversionDataListener = paramAppsFlyerConversionListener;
  }
  
  private static void runInBackground(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean)
  {
    ScheduledExecutorService localScheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
    localScheduledExecutorService.schedule(new DataCollector(paramContext, paramString1, paramString2, paramString3, paramString4, paramBoolean, localScheduledExecutorService, null), 5L, TimeUnit.MILLISECONDS);
  }
  
  private static void sendRequestToServer(String paramString1, String paramString2, String paramString3, WeakReference paramWeakReference, String paramString4, String paramString5, boolean paramBoolean)
    throws IOException
  {
    URL localURL = new URL(paramString1);
    if (shouldLog((Context)paramWeakReference.get())) {
      Log.i(paramString5, "url: " + localURL.toString());
    }
    debugAction("call server.", "\n" + localURL.toString() + "\nPOST:" + paramString2, (Context)paramWeakReference.get());
    if (shouldLog((Context)paramWeakReference.get())) {
      LogMessages.logMessageMaskKey("data: " + paramString2);
    }
    monitor((Context)paramWeakReference.get(), paramString5, "EVENT_DATA", paramString2);
    if (paramBoolean) {
      AppsFlyerProperties.getInstance().setLaunchCollectedReferrer();
    }
    try
    {
      callServer(localURL, paramString2, paramString3, paramWeakReference, paramString4, paramString5, paramBoolean);
      return;
    }
    catch (IOException localIOException)
    {
      if (AppsFlyerProperties.getInstance().getBoolean("useHttpFallback", false))
      {
        debugAction("https failed: " + localIOException.getLocalizedMessage(), "", (Context)paramWeakReference.get());
        callServer(new URL(paramString1.replace("https:", "http:")), paramString2, paramString3, paramWeakReference, paramString4, paramString5, paramBoolean);
        return;
      }
      Log.i(paramString5, "failed to send requeset to server. " + localIOException.getLocalizedMessage());
      monitor((Context)paramWeakReference.get(), paramString5, "ERROR", localIOException.getLocalizedMessage());
    }
  }
  
  public static void sendTracking(Context paramContext)
  {
    sendTracking(paramContext, null);
    if (shouldLog(paramContext)) {
      Log.i("AppsFlyer_1.17", "Start tracking package: " + paramContext.getPackageName());
    }
  }
  
  public static void sendTracking(Context paramContext, String paramString)
  {
    sendTrackingWithEvent(paramContext, paramString, null, null);
  }
  
  public static void sendTrackingWithEvent(Context paramContext, String paramString1, String paramString2)
  {
    sendTrackingWithEvent(paramContext, null, paramString1, paramString2);
  }
  
  public static void sendTrackingWithEvent(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
    if ((paramString2 != null) && (paramString3 != null) && (paramString3.matches("-?\\d+(\\.\\d+)?"))) {
      Log.i("AppsFlyer_1.17", "AppsFLyer: numeric value '" + paramString3 + "' for event '" + paramString2 + "' will be categorized as a revenue event.");
    }
    String str = AppsFlyerProperties.getInstance().getReferrer(paramContext);
    if (str == null) {
      str = "";
    }
    for (;;)
    {
      runInBackground(paramContext, paramString1, paramString2, paramString3, str, false);
      return;
    }
  }
  
  private static void sendTrackingWithEvent(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean)
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a49 = a48\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
  }
  
  /* Error */
  private void sendUninstall(String paramString, Context paramContext)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 6
    //   3: aload 6
    //   5: astore 5
    //   7: new 467	java/lang/StringBuilder
    //   10: dup
    //   11: invokespecial 468	java/lang/StringBuilder:<init>	()V
    //   14: ldc 115
    //   16: invokevirtual 477	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   19: invokevirtual 478	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   22: astore 7
    //   24: aload 6
    //   26: astore 5
    //   28: aload_2
    //   29: invokestatic 181	com/appsflyer/AppsFlyerLib:shouldLog	(Landroid/content/Context;)Z
    //   32: istore 4
    //   34: iload 4
    //   36: ifeq +34 -> 70
    //   39: aload 6
    //   41: astore 5
    //   43: ldc 85
    //   45: new 467	java/lang/StringBuilder
    //   48: dup
    //   49: invokespecial 468	java/lang/StringBuilder:<init>	()V
    //   52: ldc_w 1071
    //   55: invokevirtual 477	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: aload 7
    //   60: invokevirtual 477	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: invokevirtual 478	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   66: invokestatic 299	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   69: pop
    //   70: aload 6
    //   72: astore 5
    //   74: new 405	java/util/HashMap
    //   77: dup
    //   78: invokespecial 406	java/util/HashMap:<init>	()V
    //   81: astore 8
    //   83: aload 6
    //   85: astore 5
    //   87: aload 8
    //   89: ldc_w 854
    //   92: aload_1
    //   93: invokeinterface 271 3 0
    //   98: pop
    //   99: aload 6
    //   101: astore 5
    //   103: aload_2
    //   104: aload 8
    //   106: invokestatic 1073	com/appsflyer/AppsFlyerLib:addAdvertiserIDData	(Landroid/content/Context;Ljava/util/Map;)V
    //   109: aload 6
    //   111: astore 5
    //   113: aload_2
    //   114: aload 8
    //   116: invokestatic 1075	com/appsflyer/AppsFlyerLib:addDeviceTracking	(Landroid/content/Context;Ljava/util/Map;)V
    //   119: aload 6
    //   121: astore 5
    //   123: aload 8
    //   125: invokestatic 228	com/appsflyer/AppsFlyerLib:mapToString	(Ljava/util/Map;)Ljava/lang/String;
    //   128: astore 10
    //   130: aload 6
    //   132: astore 5
    //   134: new 448	java/net/URL
    //   137: dup
    //   138: aload 7
    //   140: invokespecial 1001	java/net/URL:<init>	(Ljava/lang/String;)V
    //   143: invokevirtual 452	java/net/URL:openConnection	()Ljava/net/URLConnection;
    //   146: checkcast 454	java/net/HttpURLConnection
    //   149: astore 9
    //   151: aload 9
    //   153: astore 6
    //   155: aload 6
    //   157: astore 5
    //   159: aload 9
    //   161: ldc_w 456
    //   164: invokevirtual 459	java/net/HttpURLConnection:setRequestMethod	(Ljava/lang/String;)V
    //   167: aload 6
    //   169: astore 5
    //   171: aload 10
    //   173: invokevirtual 463	java/lang/String:getBytes	()[B
    //   176: arraylength
    //   177: istore_3
    //   178: aload 6
    //   180: astore 5
    //   182: aload 9
    //   184: ldc_w 465
    //   187: new 467	java/lang/StringBuilder
    //   190: dup
    //   191: invokespecial 468	java/lang/StringBuilder:<init>	()V
    //   194: iload_3
    //   195: invokevirtual 472	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   198: ldc_w 474
    //   201: invokevirtual 477	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   204: invokevirtual 478	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   207: invokevirtual 481	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   210: aload 6
    //   212: astore 5
    //   214: aload 9
    //   216: ldc_w 483
    //   219: ldc_w 485
    //   222: invokevirtual 481	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   225: aload 6
    //   227: astore 5
    //   229: aload 9
    //   231: sipush 10000
    //   234: invokevirtual 489	java/net/HttpURLConnection:setConnectTimeout	(I)V
    //   237: aload 6
    //   239: astore 5
    //   241: aload 9
    //   243: iconst_1
    //   244: invokevirtual 493	java/net/HttpURLConnection:setDoOutput	(Z)V
    //   247: aconst_null
    //   248: astore 7
    //   250: new 495	java/io/OutputStreamWriter
    //   253: dup
    //   254: aload 9
    //   256: invokevirtual 499	java/net/HttpURLConnection:getOutputStream	()Ljava/io/OutputStream;
    //   259: invokespecial 502	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;)V
    //   262: astore 8
    //   264: aload 8
    //   266: aload 10
    //   268: invokevirtual 505	java/io/OutputStreamWriter:write	(Ljava/lang/String;)V
    //   271: aload 8
    //   273: ifnull +12 -> 285
    //   276: aload 6
    //   278: astore 5
    //   280: aload 8
    //   282: invokevirtual 507	java/io/OutputStreamWriter:close	()V
    //   285: aload 6
    //   287: astore 5
    //   289: aload 9
    //   291: invokevirtual 511	java/net/HttpURLConnection:getResponseCode	()I
    //   294: istore_3
    //   295: iload_3
    //   296: sipush 200
    //   299: if_icmpne +146 -> 445
    //   302: aload 6
    //   304: astore 5
    //   306: aload_2
    //   307: invokestatic 181	com/appsflyer/AppsFlyerLib:shouldLog	(Landroid/content/Context;)Z
    //   310: istore 4
    //   312: iload 4
    //   314: ifeq +33 -> 347
    //   317: aload 6
    //   319: astore 5
    //   321: ldc 85
    //   323: new 467	java/lang/StringBuilder
    //   326: dup
    //   327: invokespecial 468	java/lang/StringBuilder:<init>	()V
    //   330: ldc_w 1077
    //   333: invokevirtual 477	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   336: aload_1
    //   337: invokevirtual 477	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   340: invokevirtual 478	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   343: invokestatic 299	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   346: pop
    //   347: aload 9
    //   349: ifnull +170 -> 519
    //   352: aload 9
    //   354: invokevirtual 566	java/net/HttpURLConnection:disconnect	()V
    //   357: return
    //   358: astore 8
    //   360: aload 7
    //   362: ifnull +12 -> 374
    //   365: aload 6
    //   367: astore 5
    //   369: aload 7
    //   371: invokevirtual 507	java/io/OutputStreamWriter:close	()V
    //   374: aload 6
    //   376: astore 5
    //   378: aload 8
    //   380: athrow
    //   381: astore 6
    //   383: aload_2
    //   384: invokestatic 181	com/appsflyer/AppsFlyerLib:shouldLog	(Landroid/content/Context;)Z
    //   387: istore 4
    //   389: iload 4
    //   391: ifeq +43 -> 434
    //   394: ldc 85
    //   396: new 467	java/lang/StringBuilder
    //   399: dup
    //   400: invokespecial 468	java/lang/StringBuilder:<init>	()V
    //   403: ldc_w 1079
    //   406: invokevirtual 477	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   409: aload_1
    //   410: invokevirtual 477	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   413: ldc_w 1081
    //   416: invokevirtual 477	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   419: aload 6
    //   421: invokevirtual 1082	java/lang/Throwable:getLocalizedMessage	()Ljava/lang/String;
    //   424: invokevirtual 477	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   427: invokevirtual 478	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   430: invokestatic 299	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   433: pop
    //   434: aload 5
    //   436: ifnull +83 -> 519
    //   439: aload 5
    //   441: invokevirtual 566	java/net/HttpURLConnection:disconnect	()V
    //   444: return
    //   445: aload 6
    //   447: astore 5
    //   449: aload_2
    //   450: invokestatic 181	com/appsflyer/AppsFlyerLib:shouldLog	(Landroid/content/Context;)Z
    //   453: istore 4
    //   455: iload 4
    //   457: ifeq -110 -> 347
    //   460: aload 6
    //   462: astore 5
    //   464: ldc 85
    //   466: new 467	java/lang/StringBuilder
    //   469: dup
    //   470: invokespecial 468	java/lang/StringBuilder:<init>	()V
    //   473: ldc_w 1079
    //   476: invokevirtual 477	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   479: aload_1
    //   480: invokevirtual 477	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   483: invokevirtual 478	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   486: invokestatic 299	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   489: pop
    //   490: goto -143 -> 347
    //   493: astore_1
    //   494: aload 5
    //   496: ifnull +8 -> 504
    //   499: aload 5
    //   501: invokevirtual 566	java/net/HttpURLConnection:disconnect	()V
    //   504: aload_1
    //   505: athrow
    //   506: astore 5
    //   508: aload 8
    //   510: astore 7
    //   512: aload 5
    //   514: astore 8
    //   516: goto -156 -> 360
    //   519: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	520	0	this	AppsFlyerLib
    //   0	520	1	paramString	String
    //   0	520	2	paramContext	Context
    //   177	123	3	i	int
    //   32	424	4	bool	boolean
    //   5	495	5	localObject1	Object
    //   506	7	5	localThrowable1	Throwable
    //   1	374	6	localObject2	Object
    //   381	80	6	localThrowable2	Throwable
    //   22	489	7	localObject3	Object
    //   81	200	8	localObject4	Object
    //   358	151	8	localThrowable3	Throwable
    //   514	1	8	localThrowable4	Throwable
    //   149	204	9	localHttpURLConnection	HttpURLConnection
    //   128	139	10	str	String
    // Exception table:
    //   from	to	target	type
    //   250	264	358	java/lang/Throwable
    //   7	24	381	java/lang/Throwable
    //   28	34	381	java/lang/Throwable
    //   43	70	381	java/lang/Throwable
    //   74	83	381	java/lang/Throwable
    //   87	99	381	java/lang/Throwable
    //   103	109	381	java/lang/Throwable
    //   113	119	381	java/lang/Throwable
    //   123	130	381	java/lang/Throwable
    //   134	151	381	java/lang/Throwable
    //   159	167	381	java/lang/Throwable
    //   171	178	381	java/lang/Throwable
    //   182	210	381	java/lang/Throwable
    //   214	225	381	java/lang/Throwable
    //   229	237	381	java/lang/Throwable
    //   241	247	381	java/lang/Throwable
    //   280	285	381	java/lang/Throwable
    //   289	295	381	java/lang/Throwable
    //   306	312	381	java/lang/Throwable
    //   321	347	381	java/lang/Throwable
    //   369	374	381	java/lang/Throwable
    //   378	381	381	java/lang/Throwable
    //   449	455	381	java/lang/Throwable
    //   464	490	381	java/lang/Throwable
    //   383	389	493	java/lang/Throwable
    //   394	434	493	java/lang/Throwable
    //   264	271	506	java/lang/Throwable
  }
  
  public static void setAdditionalData(HashMap paramHashMap)
  {
    paramHashMap = new JSONObject(paramHashMap);
    AppsFlyerProperties.getInstance().setCustomData(paramHashMap.toString());
  }
  
  public static void setAppId(String paramString)
  {
    setProperty("appid", paramString);
  }
  
  public static void setAppUserId(String paramString)
  {
    setProperty("AppUserId", paramString);
  }
  
  public static void setAppsFlyerKey(String paramString)
  {
    setProperty("AppsFlyerKey", paramString);
    LogMessages.setDevKey(paramString);
  }
  
  public static void setCollectAndroidID(boolean paramBoolean)
  {
    setProperty("collectAndroidId", Boolean.toString(paramBoolean));
  }
  
  public static void setCollectIMEI(boolean paramBoolean)
  {
    setProperty("collectIMEI", Boolean.toString(paramBoolean));
  }
  
  public static void setCollectMACAddress(boolean paramBoolean)
  {
    setProperty("collectMAC", Boolean.toString(paramBoolean));
  }
  
  public static void setCurrencyCode(String paramString)
  {
    AppsFlyerProperties.getInstance().put("currencyCode", paramString);
  }
  
  public static void setDeviceTrackingDisabled(boolean paramBoolean)
  {
    AppsFlyerProperties.getInstance().check("deviceTrackingDisabled", paramBoolean);
  }
  
  public static void setExtension(String paramString)
  {
    AppsFlyerProperties.getInstance().put("sdkExtension", paramString);
  }
  
  public static void setIsUpdate(boolean paramBoolean)
  {
    AppsFlyerProperties.getInstance().check("IS_UPDATE", paramBoolean);
  }
  
  protected static void setProperty(String paramString1, String paramString2)
  {
    AppsFlyerProperties.getInstance().put(paramString1, paramString2);
  }
  
  public static void setUseHTTPFalback(boolean paramBoolean)
  {
    setProperty("useHttpFallback", Boolean.toString(paramBoolean));
  }
  
  public static void setUserEmail(String paramString)
  {
    setProperty("userEmail", paramString);
  }
  
  public static void setUserEmails(AppsFlyerProperties.EmailsCryptType paramEmailsCryptType, String... paramVarArgs)
  {
    AppsFlyerProperties.getInstance().getSetting("userEmails", paramVarArgs);
    AppsFlyerProperties.getInstance().writeValue("userEmailsCryptType", paramEmailsCryptType.getValue());
  }
  
  public static void setUserEmails(String... paramVarArgs)
  {
    AppsFlyerProperties.getInstance().getSetting("userEmails", paramVarArgs);
  }
  
  private static boolean shouldLog(Context paramContext)
  {
    return !AppsFlyerProperties.getInstance().isDisableLog();
  }
  
  public static void trackEvent(Context paramContext, String paramString, Map paramMap)
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a5 = a4\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
  }
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    if ("android.intent.action.PACKAGE_REMOVED".equals(paramIntent.getAction()))
    {
      sendUninstall(paramIntent.getDataString(), paramContext);
      return;
    }
    Object localObject = paramIntent.getStringExtra("shouldMonitor");
    if (localObject != null)
    {
      Log.i("AppsFlyer_1.17", "Turning on monitoring.");
      AppsFlyerProperties.getInstance().check("shouldMonitor", ((String)localObject).equals("true"));
      monitor(paramContext, null, "START_TRACKING", paramContext.getPackageName());
      return;
    }
    Log.i("AppsFlyer_1.17", "****** onReceive called *******");
    debugAction("******* onReceive: ", "", paramContext);
    AppsFlyerProperties.getInstance().setOnReceiveCalled();
    paramIntent = paramIntent.getStringExtra("referrer");
    if (shouldLog(paramContext)) {
      Log.i("AppsFlyer_1.17", "Play store referrer: " + paramIntent);
    }
    if (paramIntent != null)
    {
      debugAction("BroadcastReceiver got referrer: ", paramIntent, paramContext);
      debugAction("onRecieve called. refferer=", paramIntent, paramContext);
      localObject = paramContext.getSharedPreferences("appsflyer-data", 0).edit();
      ((SharedPreferences.Editor)localObject).putString("referrer", paramIntent);
      ((SharedPreferences.Editor)localObject).commit();
      AppsFlyerProperties.getInstance().setReferrer(paramIntent);
      if (AppsFlyerProperties.getInstance().isLaunchCollectedReferrerd())
      {
        Log.i("AppsFlyer_1.17", "onReceive: isLaunchCalled");
        runInBackground(paramContext, null, null, null, paramIntent, false);
      }
    }
  }
  
  private static abstract class AttributionIdFetcher
    implements Runnable
  {
    private static AtomicInteger currentRequestsCounter = new AtomicInteger(0);
    private String appsFlyerDevKey;
    private WeakReference<Context> ctxReference = null;
    private ScheduledExecutorService executorService;
    
    public AttributionIdFetcher(Context paramContext, String paramString, ScheduledExecutorService paramScheduledExecutorService)
    {
      ctxReference = new WeakReference(paramContext);
      appsFlyerDevKey = paramString;
      executorService = paramScheduledExecutorService;
    }
    
    protected abstract void callback(Map paramMap);
    
    protected abstract void callbackFailure(String paramString);
    
    public abstract String getUrl();
    
    public void run()
    {
      Object localObject5;
      if (appsFlyerDevKey != null)
      {
        if (appsFlyerDevKey.length() == 0) {
          return;
        }
        currentRequestsCounter.incrementAndGet();
        HttpURLConnection localHttpURLConnection = null;
        localObject5 = localHttpURLConnection;
        for (;;)
        {
          Object localObject6;
          try
          {
            localContext = (Context)ctxReference.get();
            if (localContext == null)
            {
              currentRequestsCounter.decrementAndGet();
              return;
            }
            localObject5 = localHttpURLConnection;
            localObject4 = AppsFlyerLib.getCachedChannel(localContext, AppsFlyerLib.access$1000(localContext));
            localObject1 = "";
            if (localObject4 != null)
            {
              localObject5 = localHttpURLConnection;
              localObject1 = "-" + (String)localObject4;
            }
            localObject5 = localHttpURLConnection;
            localObject1 = new StringBuilder().append(getUrl()).append(localContext.getPackageName()).append((String)localObject1).append("?devkey=").append(appsFlyerDevKey).append("&device_id=").append(AppsFlyerLib.getAppsFlyerUID(localContext));
            localObject5 = localHttpURLConnection;
            bool = AppsFlyerLib.shouldLog(localContext);
            if (bool)
            {
              localObject5 = localHttpURLConnection;
              LogMessages.logMessageMaskKey("Calling server for attribution url: " + ((StringBuilder)localObject1).toString());
            }
            localObject5 = localHttpURLConnection;
            localHttpURLConnection = (HttpURLConnection)new URL(((StringBuilder)localObject1).toString()).openConnection();
            localObject4 = localHttpURLConnection;
            localObject5 = localObject4;
            localHttpURLConnection.setRequestMethod("GET");
            localObject5 = localObject4;
            localHttpURLConnection.setConnectTimeout(10000);
            localObject5 = localObject4;
            localHttpURLConnection.setRequestProperty("Connection", "close");
            localObject5 = localObject4;
            localHttpURLConnection.connect();
            localObject5 = localObject4;
            i = localHttpURLConnection.getResponseCode();
            if (i == 200)
            {
              localObject7 = null;
              localObject5 = localObject4;
              localStringBuilder = new StringBuilder();
              localObject5 = null;
            }
          }
          catch (Throwable localThrowable1)
          {
            try
            {
              Object localObject1;
              localAppsFlyerConversionListener = AppsFlyerLib.conversionDataListener;
              if (localAppsFlyerConversionListener != null) {
                callbackFailure(localThrowable1.getMessage());
              }
              Log.e("AppsFlyer_1.17", localThrowable1.getMessage(), localThrowable1);
              currentRequestsCounter.decrementAndGet();
              if (localObject5 != null) {
                ((HttpURLConnection)localObject5).disconnect();
              }
              executorService.shutdown();
              return;
            }
            catch (Throwable localThrowable2)
            {
              Context localContext;
              Object localObject4;
              boolean bool;
              int i;
              Object localObject7;
              StringBuilder localStringBuilder;
              Object localObject8;
              AppsFlyerConversionListener localAppsFlyerConversionListener;
              Object localObject2;
              currentRequestsCounter.decrementAndGet();
              if (localObject6 == null) {
                break label899;
              }
              localObject6.disconnect();
              throw localThrowable2;
            }
            if (localObject8 != null)
            {
              localObject5 = localObject4;
              ((BufferedReader)localObject8).close();
            }
            if (localThrowable1 != null)
            {
              localObject5 = localObject4;
              localThrowable1.close();
            }
            localObject5 = localObject4;
            bool = AppsFlyerLib.shouldLog(localContext);
            if (bool)
            {
              localObject5 = localObject4;
              LogMessages.logMessageMaskKey("Attribution data: " + localStringBuilder.toString());
            }
            localObject5 = localObject4;
            i = localStringBuilder.length();
            if ((i > 0) && (localContext != null))
            {
              localObject5 = localObject4;
              localObject2 = AppsFlyerLib.attributionStringToMap(localStringBuilder.toString());
              localObject5 = localObject4;
              localObject7 = (String)((Map)localObject2).get("iscache");
              if (localObject7 != null)
              {
                localObject5 = localObject4;
                bool = "true".equals(localObject7);
                if (!bool) {}
              }
              else
              {
                localObject5 = localObject4;
                localObject8 = localContext.getSharedPreferences("appsflyer-data", 0).edit();
                localObject5 = localObject4;
                ((SharedPreferences.Editor)localObject8).putString("attributionId", localStringBuilder.toString());
                localObject5 = localObject4;
                ((SharedPreferences.Editor)localObject8).commit();
                localObject5 = localObject4;
                bool = AppsFlyerLib.shouldLog(localContext);
                if (bool)
                {
                  localObject5 = localObject4;
                  Log.d("AppsFlyer_1.17", "iscache=" + (String)localObject7 + " caching conversion data");
                }
              }
              localObject5 = localObject4;
              localObject7 = AppsFlyerLib.conversionDataListener;
              if (localObject7 != null)
              {
                localObject5 = localObject4;
                i = currentRequestsCounter.intValue();
                if (i <= 1) {
                  localObject5 = localObject4;
                }
              }
            }
            try
            {
              localObject7 = AppsFlyerLib.getConversionData(localContext);
              localObject2 = localObject7;
            }
            catch (AttributionIDNotReady localAttributionIDNotReady)
            {
              continue;
            }
            localObject5 = localObject4;
            callback((Map)localObject2);
            currentRequestsCounter.decrementAndGet();
            if (localAppsFlyerConversionListener == null) {
              continue;
            }
            localAppsFlyerConversionListener.disconnect();
            continue;
            localObject6 = localObject4;
            localObject7 = AppsFlyerLib.conversionDataListener;
            if (localObject7 != null)
            {
              localObject6 = localObject4;
              callbackFailure("Error connection to server: " + localAppsFlyerConversionListener.getResponseCode());
            }
            localObject6 = localObject4;
            bool = AppsFlyerLib.shouldLog(localContext);
            if (!bool) {
              continue;
            }
            localObject6 = localObject4;
            LogMessages.logMessageMaskKey("AttributionIdFetcher response code: " + localAppsFlyerConversionListener.getResponseCode() + "  url: " + localObject2);
            continue;
          }
          try
          {
            localObject1 = new InputStreamReader(localHttpURLConnection.getInputStream());
          }
          catch (Throwable localThrowable4)
          {
            Object localObject3 = localObject6;
            continue;
          }
          try
          {
            localObject8 = new BufferedReader((Reader)localObject1);
            try
            {
              localObject5 = ((BufferedReader)localObject8).readLine();
              if (localObject5 == null) {
                continue;
              }
              localStringBuilder.append((String)localObject5).append('\n');
              continue;
              if (localObject7 == null) {
                continue;
              }
            }
            catch (Throwable localThrowable3)
            {
              localObject7 = localObject8;
            }
          }
          catch (Throwable localThrowable5) {}
        }
        localObject5 = localObject4;
        ((BufferedReader)localObject7).close();
        if (localObject1 != null)
        {
          localObject5 = localObject4;
          ((InputStreamReader)localObject1).close();
        }
        localObject5 = localObject4;
        throw localThrowable3;
      }
      label899:
    }
  }
  
  private static class CachedRequestSender
    implements Runnable
  {
    private WeakReference<Context> ctxReference = null;
    
    public CachedRequestSender(Context paramContext)
    {
      ctxReference = new WeakReference(paramContext);
    }
    
    /* Error */
    public void run()
    {
      // Byte code:
      //   0: invokestatic 34	com/appsflyer/AppsFlyerLib:access$1400	()Z
      //   3: ifeq +4 -> 7
      //   6: return
      //   7: invokestatic 40	java/lang/System:currentTimeMillis	()J
      //   10: invokestatic 44	com/appsflyer/AppsFlyerLib:access$1502	(J)J
      //   13: pop2
      //   14: aload_0
      //   15: getfield 19	com/appsflyer/AppsFlyerLib$CachedRequestSender:ctxReference	Ljava/lang/ref/WeakReference;
      //   18: ifnull +231 -> 249
      //   21: iconst_1
      //   22: invokestatic 48	com/appsflyer/AppsFlyerLib:access$1402	(Z)Z
      //   25: pop
      //   26: ldc 50
      //   28: invokestatic 54	com/appsflyer/AppsFlyerLib:getProperty	(Ljava/lang/String;)Ljava/lang/String;
      //   31: astore_2
      //   32: aload_0
      //   33: getfield 19	com/appsflyer/AppsFlyerLib$CachedRequestSender:ctxReference	Ljava/lang/ref/WeakReference;
      //   36: astore_1
      //   37: aload_1
      //   38: monitorenter
      //   39: invokestatic 60	com/appsflyer/cache/CacheManager:getInstance	()Lcom/appsflyer/cache/CacheManager;
      //   42: aload_0
      //   43: getfield 19	com/appsflyer/AppsFlyerLib$CachedRequestSender:ctxReference	Ljava/lang/ref/WeakReference;
      //   46: invokevirtual 64	java/lang/ref/WeakReference:get	()Ljava/lang/Object;
      //   49: checkcast 66	android/content/Context
      //   52: invokevirtual 70	com/appsflyer/cache/CacheManager:getCachedRequests	(Landroid/content/Context;)Ljava/util/List;
      //   55: invokeinterface 76 1 0
      //   60: astore_3
      //   61: aload_3
      //   62: invokeinterface 81 1 0
      //   67: ifeq +164 -> 231
      //   70: aload_3
      //   71: invokeinterface 84 1 0
      //   76: checkcast 86	com/appsflyer/cache/RequestCacheData
      //   79: astore 4
      //   81: aload_0
      //   82: getfield 19	com/appsflyer/AppsFlyerLib$CachedRequestSender:ctxReference	Ljava/lang/ref/WeakReference;
      //   85: invokevirtual 64	java/lang/ref/WeakReference:get	()Ljava/lang/Object;
      //   88: checkcast 66	android/content/Context
      //   91: invokestatic 90	com/appsflyer/AppsFlyerLib:access$1200	(Landroid/content/Context;)Z
      //   94: ifeq +32 -> 126
      //   97: ldc 92
      //   99: new 94	java/lang/StringBuilder
      //   102: dup
      //   103: invokespecial 95	java/lang/StringBuilder:<init>	()V
      //   106: ldc 97
      //   108: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   111: aload 4
      //   113: invokevirtual 105	com/appsflyer/cache/RequestCacheData:getRequestURL	()Ljava/lang/String;
      //   116: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   119: invokevirtual 108	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   122: invokestatic 114	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
      //   125: pop
      //   126: new 94	java/lang/StringBuilder
      //   129: dup
      //   130: invokespecial 95	java/lang/StringBuilder:<init>	()V
      //   133: aload 4
      //   135: invokevirtual 105	com/appsflyer/cache/RequestCacheData:getRequestURL	()Ljava/lang/String;
      //   138: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   141: ldc 116
      //   143: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   146: invokevirtual 108	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   149: astore 5
      //   151: aload 4
      //   153: invokevirtual 119	com/appsflyer/cache/RequestCacheData:getPostData	()Ljava/lang/String;
      //   156: astore 6
      //   158: aload_0
      //   159: getfield 19	com/appsflyer/AppsFlyerLib$CachedRequestSender:ctxReference	Ljava/lang/ref/WeakReference;
      //   162: astore 7
      //   164: aload 5
      //   166: aload 6
      //   168: aload_2
      //   169: aload 7
      //   171: aload 4
      //   173: invokevirtual 122	com/appsflyer/cache/RequestCacheData:getCacheKey	()Ljava/lang/String;
      //   176: ldc 92
      //   178: iconst_0
      //   179: invokestatic 126	com/appsflyer/AppsFlyerLib:access$800	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ref/WeakReference;Ljava/lang/String;Ljava/lang/String;Z)V
      //   182: goto -121 -> 61
      //   185: astore 4
      //   187: ldc 92
      //   189: ldc -128
      //   191: invokestatic 114	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
      //   194: pop
      //   195: goto -134 -> 61
      //   198: astore_2
      //   199: aload_1
      //   200: monitorexit
      //   201: aload_2
      //   202: athrow
      //   203: astore_1
      //   204: ldc 92
      //   206: ldc -126
      //   208: invokestatic 133	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
      //   211: pop
      //   212: iconst_0
      //   213: invokestatic 48	com/appsflyer/AppsFlyerLib:access$1402	(Z)Z
      //   216: pop
      //   217: invokestatic 137	com/appsflyer/AppsFlyerLib:access$1600	()Ljava/util/concurrent/ScheduledExecutorService;
      //   220: invokeinterface 142 1 0
      //   225: aconst_null
      //   226: invokestatic 146	com/appsflyer/AppsFlyerLib:access$1602	(Ljava/util/concurrent/ScheduledExecutorService;)Ljava/util/concurrent/ScheduledExecutorService;
      //   229: pop
      //   230: return
      //   231: aload_1
      //   232: monitorexit
      //   233: iconst_0
      //   234: invokestatic 48	com/appsflyer/AppsFlyerLib:access$1402	(Z)Z
      //   237: pop
      //   238: goto -21 -> 217
      //   241: astore_1
      //   242: iconst_0
      //   243: invokestatic 48	com/appsflyer/AppsFlyerLib:access$1402	(Z)Z
      //   246: pop
      //   247: aload_1
      //   248: athrow
      //   249: return
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	250	0	this	CachedRequestSender
      //   36	164	1	localWeakReference1	WeakReference
      //   203	29	1	localException1	Exception
      //   241	7	1	localThrowable1	Throwable
      //   31	138	2	str1	String
      //   198	4	2	localThrowable2	Throwable
      //   60	11	3	localIterator	Iterator
      //   79	93	4	localRequestCacheData	RequestCacheData
      //   185	1	4	localException2	Exception
      //   149	16	5	str2	String
      //   156	11	6	str3	String
      //   162	8	7	localWeakReference2	WeakReference
      // Exception table:
      //   from	to	target	type
      //   126	158	185	java/lang/Exception
      //   164	182	185	java/lang/Exception
      //   39	61	198	java/lang/Throwable
      //   61	126	198	java/lang/Throwable
      //   126	158	198	java/lang/Throwable
      //   164	182	198	java/lang/Throwable
      //   187	195	198	java/lang/Throwable
      //   199	201	198	java/lang/Throwable
      //   231	233	198	java/lang/Throwable
      //   26	32	203	java/lang/Exception
      //   201	203	203	java/lang/Exception
      //   26	32	241	java/lang/Throwable
      //   32	39	241	java/lang/Throwable
      //   201	203	241	java/lang/Throwable
      //   204	212	241	java/lang/Throwable
    }
  }
  
  private static class DataCollector
    implements Runnable
  {
    private String appsFlyerKey;
    private Context context;
    private String eventName;
    private String eventValue;
    private ExecutorService executor;
    private boolean isNewAPI;
    private String referrer;
    
    private DataCollector(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean, ExecutorService paramExecutorService)
    {
      context = paramContext;
      appsFlyerKey = paramString1;
      eventName = paramString2;
      eventValue = paramString3;
      referrer = paramString4;
      isNewAPI = paramBoolean;
      executor = paramExecutorService;
    }
    
    public void run()
    {
      AppsFlyerLib.sendTrackingWithEvent(context, appsFlyerKey, eventName, eventValue, referrer, isNewAPI);
      executor.shutdown();
    }
  }
  
  private static class InstallAttributionIdFetcher
    extends AppsFlyerLib.AttributionIdFetcher
  {
    public InstallAttributionIdFetcher(Context paramContext, String paramString, ScheduledExecutorService paramScheduledExecutorService)
    {
      super(paramString, paramScheduledExecutorService);
    }
    
    protected void callback(Map paramMap)
    {
      AppsFlyerLib.conversionDataListener.onInstallConversionDataLoaded(paramMap);
    }
    
    protected void callbackFailure(String paramString)
    {
      AppsFlyerLib.conversionDataListener.onInstallConversionFailure(paramString);
    }
    
    public String getUrl()
    {
      return "https://api.appsflyer.com/install_data/v3/";
    }
  }
  
  private static class SendToServerRunnable
    implements Runnable
  {
    private WeakReference<Context> ctxReference = null;
    boolean isLaunch;
    Map<String, String> params;
    private String urlString;
    
    private SendToServerRunnable(String paramString, Map paramMap, Context paramContext, boolean paramBoolean)
    {
      urlString = paramString;
      params = paramMap;
      ctxReference = new WeakReference(paramContext);
      isLaunch = paramBoolean;
    }
    
    public void run()
    {
      String str2 = null;
      String str3 = AppsFlyerLib.getEventTag(params);
      try
      {
        Object localObject1 = ctxReference;
        String str1 = str2;
        try
        {
          localObject1 = ((WeakReference)localObject1).get();
          localObject1 = (Context)localObject1;
          boolean bool1 = false;
          int i;
          if (localObject1 != null)
          {
            str1 = str2;
            localObject2 = AppsFlyerProperties.getInstance().getReferrer((Context)localObject1);
            if (localObject2 != null)
            {
              str1 = str2;
              i = ((String)localObject2).length();
              if (i > 0)
              {
                localObject3 = params;
                str1 = str2;
                localObject3 = ((Map)localObject3).get("referrer");
                if (localObject3 == null)
                {
                  localObject3 = params;
                  str1 = str2;
                  ((Map)localObject3).put("referrer", localObject2);
                }
              }
            }
            str1 = str2;
            localObject2 = ((Context)localObject1).getSharedPreferences("appsflyer-data", 0);
            str1 = str2;
            boolean bool2 = "true".equals(((SharedPreferences)localObject2).getString("sentSuccessfully", ""));
            localObject2 = params;
            str1 = str2;
            localObject2 = ((Map)localObject2).get("eventName");
            localObject2 = (String)localObject2;
            localObject3 = params;
            if (localObject2 == null)
            {
              bool1 = true;
              str1 = str2;
              ((Map)localObject3).put("counter", Integer.toString(AppsFlyerLib.getCounter((Context)localObject1, bool1)));
              localObject3 = params;
              if (localObject2 == null) {
                break label384;
              }
              bool1 = true;
              label236:
              str1 = str2;
              ((Map)localObject3).put("iaecounter", Integer.toString(AppsFlyerLib.getIAECounter((Context)localObject1, bool1)));
              localObject2 = params;
              str1 = str2;
              ((Map)localObject2).put("timepassedsincelastlaunch", Long.toString(AppsFlyerLib.getTimePassedSinceLastLaunch((Context)localObject1)));
              bool1 = bool2;
            }
          }
          else
          {
            localObject1 = params;
            if (bool1) {
              break label389;
            }
          }
          label384:
          label389:
          for (bool1 = true;; bool1 = false)
          {
            str1 = str2;
            ((Map)localObject1).put("isFirstCall", Boolean.toString(bool1));
            localObject1 = params;
            str1 = str2;
            localObject1 = ((Map)localObject1).get("appsflyerKey");
            localObject1 = (String)localObject1;
            if (localObject1 != null)
            {
              str1 = str2;
              i = ((String)localObject1).length();
              if (i != 0) {
                break label394;
              }
            }
            str1 = str2;
            Log.d(str3, "Not sending data yet, waiting for dev key");
            return;
            bool1 = false;
            break;
            bool1 = false;
            break label236;
          }
          label394:
          str1 = str2;
          Object localObject2 = new HashUtils();
          Object localObject3 = params;
          str1 = str2;
          localObject2 = ((HashUtils)localObject2).getHashCode((Map)localObject3);
          localObject3 = params;
          str1 = str2;
          ((Map)localObject3).put("af_v", localObject2);
          localObject2 = params;
          str1 = str2;
          str2 = AppsFlyerLib.mapToString((Map)localObject2);
          str1 = str2;
          localObject2 = urlString;
          localObject3 = ctxReference;
          bool1 = isLaunch;
          AppsFlyerLib.sendRequestToServer((String)localObject2, str2, (String)localObject1, (WeakReference)localObject3, null, str3, bool1);
          return;
        }
        catch (IOException localIOException)
        {
          if (str1 == null) {
            return;
          }
        }
        if ((ctxReference != null) && (!urlString.contains("&isCachedRequest=true")))
        {
          Log.e(str3, localIOException.getMessage(), localIOException);
          CacheManager.getInstance().cacheRequest(new RequestCacheData(urlString, str1, "1.17"), (Context)ctxReference.get());
          return;
        }
      }
      catch (Throwable localThrowable)
      {
        Log.e(str3, localThrowable.getMessage(), localThrowable);
      }
    }
  }
}
