package com.appsflyer;

import java.util.Map;

public abstract interface ReferrerListener
{
  public abstract void onReferrerNotFound();
  
  public abstract void onReferrerReceived(Map paramMap);
}
