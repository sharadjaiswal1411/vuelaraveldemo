package com.appsflyer;

import java.util.Map;

public abstract interface ConversionDataListener
{
  public abstract void onConversionDataLoaded(Map paramMap);
  
  public abstract void onConversionFailure(String paramString);
}
