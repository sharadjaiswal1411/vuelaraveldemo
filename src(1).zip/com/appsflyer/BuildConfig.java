package com.appsflyer;

public final class BuildConfig
{
  public static final boolean DEBUG = false;
  
  public BuildConfig() {}
}
