package com.appsflyer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class TestReciever
  extends BroadcastReceiver
{
  public TestReciever() {}
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    Log.i("AppsFlyer_1.17", "test dummy receiver - in onReceive");
    try
    {
      Thread.sleep(2000L);
      return;
    }
    catch (InterruptedException paramContext)
    {
      paramContext.printStackTrace();
    }
  }
}
