package com.appsflyer;

import java.util.Map;

public abstract interface AppsFlyerConversionListener
{
  public abstract void onAppOpenAttribution(Map paramMap);
  
  public abstract void onAttributionFailure(String paramString);
  
  public abstract void onInstallConversionDataLoaded(Map paramMap);
  
  public abstract void onInstallConversionFailure(String paramString);
}
