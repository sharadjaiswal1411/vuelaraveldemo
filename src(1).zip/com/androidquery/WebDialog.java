package com.androidquery;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.androidquery.util.AQUtility;

public class WebDialog
  extends Dialog
{
  private LinearLayout buttons;
  private WebViewClient client;
  private String message;
  private String url;
  private WebView webView;
  
  public WebDialog(Context paramContext, String paramString, WebViewClient paramWebViewClient)
  {
    super(paramContext, 16973830);
    url = paramString;
    client = paramWebViewClient;
  }
  
  private void setupProgress(RelativeLayout paramRelativeLayout)
  {
    Object localObject1 = getContext();
    buttons = new LinearLayout((Context)localObject1);
    Object localObject2 = new ProgressBar((Context)localObject1);
    int i = AQUtility.dip2pixel((Context)localObject1, 30.0F);
    LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(i, i);
    buttons.addView((View)localObject2, localLayoutParams);
    if (message != null)
    {
      localObject2 = new TextView((Context)localObject1);
      localLayoutParams = new LinearLayout.LayoutParams(-2, -2);
      leftMargin = AQUtility.dip2pixel((Context)localObject1, 5.0F);
      gravity = 16;
      ((TextView)localObject2).setText(message);
      buttons.addView((View)localObject2, localLayoutParams);
    }
    localObject1 = new RelativeLayout.LayoutParams(-2, -2);
    ((RelativeLayout.LayoutParams)localObject1).addRule(13);
    paramRelativeLayout.addView(buttons, (ViewGroup.LayoutParams)localObject1);
  }
  
  private void setupWebView(RelativeLayout paramRelativeLayout)
  {
    webView = new WebView(getContext());
    webView.setVerticalScrollBarEnabled(false);
    webView.setHorizontalScrollBarEnabled(false);
    if (client == null) {
      client = new WebViewClient();
    }
    webView.setWebViewClient(new DialogWebViewClient(null));
    webView.getSettings().setJavaScriptEnabled(true);
    RelativeLayout.LayoutParams localLayoutParams = new RelativeLayout.LayoutParams(-1, -1);
    paramRelativeLayout.addView(webView, localLayoutParams);
  }
  
  private void showProgress(boolean paramBoolean)
  {
    if (buttons != null)
    {
      if (paramBoolean)
      {
        buttons.setVisibility(0);
        return;
      }
      buttons.setVisibility(8);
    }
  }
  
  public void dismiss()
  {
    try
    {
      super.dismiss();
      return;
    }
    catch (Exception localException) {}
  }
  
  public void load()
  {
    if (webView != null) {
      webView.loadUrl(url);
    }
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    paramBundle = new RelativeLayout(getContext());
    paramBundle.setBackgroundColor(-1);
    setupWebView(paramBundle);
    setupProgress(paramBundle);
    addContentView(paramBundle, new FrameLayout.LayoutParams(-1, -1));
  }
  
  public void setLoadingMessage(String paramString)
  {
    message = paramString;
  }
  
  private class DialogWebViewClient
    extends WebViewClient
  {
    private DialogWebViewClient() {}
    
    public void onPageFinished(WebView paramWebView, String paramString)
    {
      WebDialog.this.showProgress(false);
      client.onPageFinished(paramWebView, paramString);
    }
    
    public void onPageStarted(WebView paramWebView, String paramString, Bitmap paramBitmap)
    {
      client.onPageStarted(paramWebView, paramString, paramBitmap);
    }
    
    public void onReceivedError(WebView paramWebView, int paramInt, String paramString1, String paramString2)
    {
      client.onReceivedError(paramWebView, paramInt, paramString1, paramString2);
    }
    
    public boolean shouldOverrideUrlLoading(WebView paramWebView, String paramString)
    {
      return client.shouldOverrideUrlLoading(paramWebView, paramString);
    }
  }
}
