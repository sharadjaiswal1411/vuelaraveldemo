package com.androidquery;

import android.app.Activity;
import android.content.Context;
import android.view.View;

public class AQuery
  extends AbstractAQuery<AQuery>
{
  public AQuery(Activity paramActivity)
  {
    super(paramActivity);
  }
  
  public AQuery(Activity paramActivity, View paramView)
  {
    super(paramActivity, paramView);
  }
  
  public AQuery(Context paramContext)
  {
    super(paramContext);
  }
  
  public AQuery(View paramView)
  {
    super(paramView);
  }
}
