package com.androidquery.callback;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.net.Uri;
import android.os.Build.VERSION;
import android.view.View;
import com.androidquery.auth.AccountHandle;
import com.androidquery.auth.GoogleHandle;
import com.androidquery.util.AQUtility;
import com.androidquery.util.Common;
import com.androidquery.util.Progress;
import com.androidquery.util.XmlDom;
import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.net.URI;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.params.ConnManagerParams;
import org.apache.http.conn.params.ConnPerRouteBean;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.scheme.SocketFactory;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.protocol.HttpContext;
import org.xmlpull.v1.XmlPullParser;

public abstract class AbstractAjaxCallback<T, K>
  implements Runnable
{
  private static String AGENT;
  private static final Class<?>[] DEFAULT_SIG = { String.class, Object.class, AjaxStatus.class };
  private static boolean GZIP = false;
  private static int NETWORK_POOL = 0;
  private static int NET_TIMEOUT = 30000;
  private static boolean REUSE_CLIENT = false;
  private static boolean SIMULATE_ERROR = false;
  private static final String boundary = "*****";
  private static DefaultHttpClient client;
  private static ExecutorService fetchExe;
  private static int lastStatus = 200;
  private static final String lineEnd = "\r\n";
  private static ProxyHandle proxyHandle;
  private static SocketFactory ssf;
  private static Transformer st;
  private static final String twoHyphens = "--";
  private boolean abort;
  private WeakReference<Activity> act;
  protected AccountHandle ah;
  private boolean blocked;
  private File cacheDir;
  private String callback;
  private boolean completed;
  protected Map<String, String> cookies;
  private String encoding = "UTF-8";
  private long expire;
  protected boolean fileCache;
  private Object handler;
  protected Map<String, String> headers;
  protected boolean memCache;
  private int method = 4;
  private String networkUrl;
  protected Map<String, Object> params;
  private int policy = 0;
  private WeakReference<Object> progress;
  private HttpHost proxy;
  private boolean reauth;
  private boolean redirect = true;
  private boolean refresh;
  private HttpUriRequest request;
  protected T result;
  private int retry = 0;
  protected AjaxStatus status;
  private File targetFile;
  private int timeout = 0;
  private Transformer transformer;
  private Class<T> type;
  private boolean uiCallback = true;
  private String url;
  private Reference<Object> whandler;
  
  static
  {
    AGENT = null;
    NETWORK_POOL = 4;
    GZIP = true;
    REUSE_CLIENT = true;
    SIMULATE_ERROR = false;
  }
  
  public AbstractAjaxCallback() {}
  
  private void afterWork()
  {
    if ((url != null) && (memCache)) {
      memPut(url, result);
    }
    callback();
    clear();
  }
  
  private void backgroundWork()
  {
    if ((!refresh) && (fileCache)) {
      fileWork();
    }
    if (result == null) {
      datastoreWork();
    }
    if (result == null) {
      networkWork();
    }
  }
  
  public static void cancel()
  {
    if (fetchExe != null)
    {
      fetchExe.shutdownNow();
      fetchExe = null;
    }
    BitmapAjaxCallback.clearTasks();
  }
  
  private void clear()
  {
    whandler = null;
    handler = null;
    progress = null;
    request = null;
    transformer = null;
    ah = null;
    act = null;
  }
  
  private void copy(InputStream paramInputStream, OutputStream paramOutputStream, int paramInt)
    throws IOException
  {
    Object localObject = null;
    if (progress != null) {
      localObject = progress.get();
    }
    Progress localProgress = null;
    if (localObject != null) {
      localProgress = new Progress(localObject);
    }
    AQUtility.copy(paramInputStream, paramOutputStream, paramInt, localProgress);
  }
  
  private void copy(InputStream paramInputStream, OutputStream paramOutputStream, int paramInt, File paramFile1, File paramFile2)
    throws IOException
  {
    if (paramFile2 == null)
    {
      copy(paramInputStream, paramOutputStream, paramInt);
      return;
    }
    try
    {
      copy(paramInputStream, paramOutputStream, paramInt);
      paramInputStream.close();
      paramOutputStream.close();
      paramFile1.renameTo(paramFile2);
      return;
    }
    catch (IOException localIOException)
    {
      AQUtility.debug("copy failed, deleting files");
      paramFile1.delete();
      paramFile2.delete();
      AQUtility.close(paramInputStream);
      AQUtility.close(paramOutputStream);
      throw localIOException;
    }
  }
  
  private String correctEncoding(byte[] paramArrayOfByte, String paramString, AjaxStatus paramAjaxStatus)
  {
    Object localObject2 = null;
    Object localObject1 = localObject2;
    for (;;)
    {
      boolean bool;
      try
      {
        bool = "utf-8".equalsIgnoreCase(paramString);
        if (!bool)
        {
          localObject1 = localObject2;
          paramArrayOfByte = new String(paramArrayOfByte, paramString);
          return paramArrayOfByte;
        }
        localObject1 = localObject2;
        paramString = parseCharset(paramAjaxStatus.getHeader("Content-Type"));
        localObject1 = localObject2;
        AQUtility.debug("parsing header", paramString);
        if (paramString != null)
        {
          localObject1 = localObject2;
          paramArrayOfByte = new String(paramArrayOfByte, paramString);
          return paramArrayOfByte;
        }
      }
      catch (Exception paramArrayOfByte)
      {
        AQUtility.report(paramArrayOfByte);
        return localObject1;
      }
      localObject1 = localObject2;
      paramString = new String(paramArrayOfByte, "utf-8");
      try
      {
        localObject1 = getCharset(paramString);
        AQUtility.debug("parsing needed", localObject1);
        if (localObject1 == null) {
          break;
        }
        bool = "utf-8".equalsIgnoreCase((String)localObject1);
        if (bool) {
          break;
        }
        AQUtility.debug("correction needed", localObject1);
        paramArrayOfByte = new String(paramArrayOfByte, (String)localObject1);
        localObject1 = paramArrayOfByte;
        paramAjaxStatus.data(paramArrayOfByte.getBytes("utf-8"));
        return paramArrayOfByte;
      }
      catch (Exception paramArrayOfByte)
      {
        localObject1 = paramString;
      }
    }
    return paramString;
  }
  
  private void datastoreWork()
  {
    result = datastoreGet(url);
    if (result != null) {
      status.source(2).done();
    }
  }
  
  private HttpResponse execute(HttpUriRequest paramHttpUriRequest, DefaultHttpClient paramDefaultHttpClient, HttpContext paramHttpContext)
    throws ClientProtocolException, IOException
  {
    if (paramHttpUriRequest.getURI().getAuthority().contains("_"))
    {
      Object localObject = paramHttpUriRequest.getURI().toURL();
      if (((URL)localObject).getPort() == -1) {}
      for (localObject = new HttpHost(((URL)localObject).getHost(), 80, ((URL)localObject).getProtocol());; localObject = new HttpHost(((URL)localObject).getHost(), ((URL)localObject).getPort(), ((URL)localObject).getProtocol())) {
        return paramDefaultHttpClient.execute((HttpHost)localObject, paramHttpUriRequest, paramHttpContext);
      }
    }
    return paramDefaultHttpClient.execute(paramHttpUriRequest, paramHttpContext);
  }
  
  public static void execute(Runnable paramRunnable)
  {
    if (fetchExe == null) {
      fetchExe = Executors.newFixedThreadPool(NETWORK_POOL);
    }
    fetchExe.execute(paramRunnable);
  }
  
  private static Map extractParams(Uri paramUri)
  {
    HashMap localHashMap = new HashMap();
    paramUri = paramUri.getQuery().split("&");
    int j = paramUri.length;
    int i = 0;
    if (i >= j) {
      return localHashMap;
    }
    String[] arrayOfString = paramUri[i].split("=");
    if (arrayOfString.length >= 2) {
      localHashMap.put(arrayOfString[0], arrayOfString[1]);
    }
    for (;;)
    {
      i += 1;
      break;
      if (arrayOfString.length == 1) {
        localHashMap.put(arrayOfString[0], "");
      }
    }
  }
  
  private static String extractUrl(Uri paramUri)
  {
    String str = paramUri.getScheme() + "://" + paramUri.getAuthority() + paramUri.getPath();
    paramUri = paramUri.getFragment();
    if (paramUri != null) {
      return str + "#" + paramUri;
    }
    return str;
  }
  
  private void filePut()
  {
    if ((result != null) && (fileCache))
    {
      byte[] arrayOfByte = status.getData();
      Object localObject1;
      if (arrayOfByte != null) {
        localObject1 = status;
      }
      for (;;)
      {
        try
        {
          int i = ((AjaxStatus)localObject1).getSource();
          if (i == 1)
          {
            localObject1 = getCacheFile();
            Object localObject2 = status;
            bool = ((AjaxStatus)localObject2).getInvalid();
            if (bool) {
              continue;
            }
            localObject2 = url;
            Object localObject3 = result;
            filePut((String)localObject2, localObject3, (File)localObject1, arrayOfByte);
          }
        }
        catch (Exception localException)
        {
          boolean bool;
          AQUtility.debug(localException);
          continue;
        }
        status.data(null);
        return;
        bool = ((File)localObject1).exists();
        if (bool) {
          ((File)localObject1).delete();
        }
      }
    }
    if (status.getCode() == -103)
    {
      File localFile = getCacheFile();
      if (localFile.exists())
      {
        localFile.delete();
        AQUtility.debug("invalidated cache due to transform error");
      }
    }
  }
  
  private void fileWork()
  {
    File localFile = accessFile(cacheDir, getCacheUrl());
    if (localFile != null)
    {
      status.source(3);
      result = fileGet(url, localFile, status);
      if (result != null) {
        status.time(new Date(localFile.lastModified())).done();
      }
    }
  }
  
  public static int getActiveCount()
  {
    if ((fetchExe instanceof ThreadPoolExecutor)) {
      return ((ThreadPoolExecutor)fetchExe).getActiveCount();
    }
    return 0;
  }
  
  private String getCacheUrl()
  {
    if (ah != null) {
      return ah.getCacheUrl(url);
    }
    return url;
  }
  
  private String getCharset(String paramString)
  {
    paramString = Pattern.compile("<meta [^>]*http-equiv[^>]*\"Content-Type\"[^>]*>", 2).matcher(paramString);
    if (!paramString.find()) {
      return null;
    }
    return parseCharset(paramString.group());
  }
  
  private static DefaultHttpClient getClient()
  {
    BasicHttpParams localBasicHttpParams;
    SchemeRegistry localSchemeRegistry;
    if ((client == null) || (!REUSE_CLIENT))
    {
      AQUtility.debug("creating http client");
      localBasicHttpParams = new BasicHttpParams();
      HttpConnectionParams.setConnectionTimeout(localBasicHttpParams, NET_TIMEOUT);
      HttpConnectionParams.setSoTimeout(localBasicHttpParams, NET_TIMEOUT);
      ConnManagerParams.setMaxConnectionsPerRoute(localBasicHttpParams, new ConnPerRouteBean(25));
      HttpConnectionParams.setSocketBufferSize(localBasicHttpParams, 8192);
      localSchemeRegistry = new SchemeRegistry();
      localSchemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
      if (ssf != null) {
        break label141;
      }
    }
    label141:
    for (Object localObject = SSLSocketFactory.getSocketFactory();; localObject = ssf)
    {
      localSchemeRegistry.register(new Scheme("https", (SocketFactory)localObject, 443));
      client = new DefaultHttpClient(new ThreadSafeClientConnManager(localBasicHttpParams, localSchemeRegistry), localBasicHttpParams);
      return client;
    }
  }
  
  private String getEncoding(HttpEntity paramHttpEntity)
  {
    if (paramHttpEntity == null) {
      return null;
    }
    paramHttpEntity = paramHttpEntity.getContentEncoding();
    if (paramHttpEntity != null) {
      return paramHttpEntity.getValue();
    }
    return null;
  }
  
  protected static int getLastStatus()
  {
    return lastStatus;
  }
  
  private String getNetworkUrl(String paramString)
  {
    if (networkUrl != null) {
      paramString = networkUrl;
    }
    String str = paramString;
    if (ah != null) {
      str = ah.getNetworkUrl(paramString);
    }
    return str;
  }
  
  private File getPreFile()
  {
    boolean bool = isStreamingContent();
    Object localObject = null;
    if (bool)
    {
      if (targetFile == null) {
        break label49;
      }
      localObject = targetFile;
    }
    while ((localObject != null) && (!((File)localObject).exists()))
    {
      try
      {
        ((File)localObject).getParentFile().mkdirs();
        ((File)localObject).createNewFile();
        return localObject;
      }
      catch (Exception localException)
      {
        label49:
        File localFile;
        AQUtility.report(localException);
        return null;
      }
      if (fileCache)
      {
        localObject = getCacheFile();
      }
      else
      {
        localFile = AQUtility.getTempDir();
        localObject = localFile;
        if (localFile == null) {
          localObject = cacheDir;
        }
        localObject = AQUtility.getCacheFile((File)localObject, url);
      }
    }
    return localException;
  }
  
  private void httpDelete(String paramString, AjaxStatus paramAjaxStatus)
    throws IOException
  {
    AQUtility.debug("get", paramString);
    paramString = patchUrl(paramString);
    httpDo(new HttpDelete(paramString), paramString, paramAjaxStatus);
  }
  
  /* Error */
  private void httpDo(HttpUriRequest paramHttpUriRequest, String paramString, AjaxStatus paramAjaxStatus)
    throws ClientProtocolException, IOException
  {
    // Byte code:
    //   0: invokestatic 638	com/androidquery/callback/AbstractAjaxCallback:getClient	()Lorg/apache/http/impl/client/DefaultHttpClient;
    //   3: astore 21
    //   5: getstatic 640	com/androidquery/callback/AbstractAjaxCallback:proxyHandle	Lcom/androidquery/callback/ProxyHandle;
    //   8: ifnull +13 -> 21
    //   11: getstatic 640	com/androidquery/callback/AbstractAjaxCallback:proxyHandle	Lcom/androidquery/callback/ProxyHandle;
    //   14: aload_0
    //   15: aload_1
    //   16: aload 21
    //   18: invokevirtual 646	com/androidquery/callback/ProxyHandle:applyProxy	(Lcom/androidquery/callback/AbstractAjaxCallback;Lorg/apache/http/HttpRequest;Lorg/apache/http/impl/client/DefaultHttpClient;)V
    //   21: getstatic 100	com/androidquery/callback/AbstractAjaxCallback:AGENT	Ljava/lang/String;
    //   24: ifnull +267 -> 291
    //   27: aload_1
    //   28: ldc_w 648
    //   31: getstatic 100	com/androidquery/callback/AbstractAjaxCallback:AGENT	Ljava/lang/String;
    //   34: invokeinterface 654 3 0
    //   39: aload_0
    //   40: getfield 656	com/androidquery/callback/AbstractAjaxCallback:headers	Ljava/util/Map;
    //   43: ifnull +29 -> 72
    //   46: aload_0
    //   47: getfield 656	com/androidquery/callback/AbstractAjaxCallback:headers	Ljava/util/Map;
    //   50: invokeinterface 660 1 0
    //   55: invokeinterface 666 1 0
    //   60: astore 9
    //   62: aload 9
    //   64: invokeinterface 671 1 0
    //   69: ifne +249 -> 318
    //   72: getstatic 104	com/androidquery/callback/AbstractAjaxCallback:GZIP	Z
    //   75: ifeq +37 -> 112
    //   78: aload_0
    //   79: getfield 656	com/androidquery/callback/AbstractAjaxCallback:headers	Ljava/util/Map;
    //   82: ifnull +18 -> 100
    //   85: aload_0
    //   86: getfield 656	com/androidquery/callback/AbstractAjaxCallback:headers	Ljava/util/Map;
    //   89: ldc_w 673
    //   92: invokeinterface 677 2 0
    //   97: ifne +15 -> 112
    //   100: aload_1
    //   101: ldc_w 673
    //   104: ldc_w 679
    //   107: invokeinterface 654 3 0
    //   112: aload_0
    //   113: getfield 196	com/androidquery/callback/AbstractAjaxCallback:ah	Lcom/androidquery/auth/AccountHandle;
    //   116: ifnull +12 -> 128
    //   119: aload_0
    //   120: getfield 196	com/androidquery/callback/AbstractAjaxCallback:ah	Lcom/androidquery/auth/AccountHandle;
    //   123: aload_0
    //   124: aload_1
    //   125: invokevirtual 683	com/androidquery/auth/AccountHandle:applyToken	(Lcom/androidquery/callback/AbstractAjaxCallback;Lorg/apache/http/HttpRequest;)V
    //   128: aload_0
    //   129: invokespecial 686	com/androidquery/callback/AbstractAjaxCallback:makeCookie	()Ljava/lang/String;
    //   132: astore 9
    //   134: aload 9
    //   136: ifnull +14 -> 150
    //   139: aload_1
    //   140: ldc_w 688
    //   143: aload 9
    //   145: invokeinterface 654 3 0
    //   150: aload_1
    //   151: invokeinterface 692 1 0
    //   156: astore 9
    //   158: aload_0
    //   159: getfield 694	com/androidquery/callback/AbstractAjaxCallback:proxy	Lorg/apache/http/HttpHost;
    //   162: ifnull +18 -> 180
    //   165: aload 9
    //   167: ldc_w 696
    //   170: aload_0
    //   171: getfield 694	com/androidquery/callback/AbstractAjaxCallback:proxy	Lorg/apache/http/HttpHost;
    //   174: invokeinterface 702 3 0
    //   179: pop
    //   180: aload_0
    //   181: getfield 126	com/androidquery/callback/AbstractAjaxCallback:timeout	I
    //   184: ifle +39 -> 223
    //   187: aload 9
    //   189: ldc_w 704
    //   192: aload_0
    //   193: getfield 126	com/androidquery/callback/AbstractAjaxCallback:timeout	I
    //   196: invokestatic 709	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   199: invokeinterface 702 3 0
    //   204: pop
    //   205: aload 9
    //   207: ldc_w 711
    //   210: aload_0
    //   211: getfield 126	com/androidquery/callback/AbstractAjaxCallback:timeout	I
    //   214: invokestatic 709	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   217: invokeinterface 702 3 0
    //   222: pop
    //   223: aload_0
    //   224: getfield 128	com/androidquery/callback/AbstractAjaxCallback:redirect	Z
    //   227: ifne +15 -> 242
    //   230: aload 9
    //   232: ldc_w 713
    //   235: iconst_0
    //   236: invokeinterface 717 3 0
    //   241: pop
    //   242: new 719	org/apache/http/protocol/BasicHttpContext
    //   245: dup
    //   246: invokespecial 720	org/apache/http/protocol/BasicHttpContext:<init>	()V
    //   249: astore 22
    //   251: aload 22
    //   253: ldc_w 722
    //   256: new 724	org/apache/http/impl/client/BasicCookieStore
    //   259: dup
    //   260: invokespecial 725	org/apache/http/impl/client/BasicCookieStore:<init>	()V
    //   263: invokeinterface 730 3 0
    //   268: aload_0
    //   269: aload_1
    //   270: putfield 192	com/androidquery/callback/AbstractAjaxCallback:request	Lorg/apache/http/client/methods/HttpUriRequest;
    //   273: aload_0
    //   274: getfield 732	com/androidquery/callback/AbstractAjaxCallback:abort	Z
    //   277: ifeq +78 -> 355
    //   280: new 202	java/io/IOException
    //   283: dup
    //   284: ldc_w 734
    //   287: invokespecial 735	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   290: athrow
    //   291: getstatic 100	com/androidquery/callback/AbstractAjaxCallback:AGENT	Ljava/lang/String;
    //   294: ifnonnull -255 -> 39
    //   297: getstatic 104	com/androidquery/callback/AbstractAjaxCallback:GZIP	Z
    //   300: ifeq -261 -> 39
    //   303: aload_1
    //   304: ldc_w 648
    //   307: ldc_w 679
    //   310: invokeinterface 654 3 0
    //   315: goto -276 -> 39
    //   318: aload 9
    //   320: invokeinterface 738 1 0
    //   325: checkcast 112	java/lang/String
    //   328: astore 10
    //   330: aload_1
    //   331: aload 10
    //   333: aload_0
    //   334: getfield 656	com/androidquery/callback/AbstractAjaxCallback:headers	Ljava/util/Map;
    //   337: aload 10
    //   339: invokeinterface 741 2 0
    //   344: checkcast 112	java/lang/String
    //   347: invokeinterface 654 3 0
    //   352: goto -290 -> 62
    //   355: getstatic 108	com/androidquery/callback/AbstractAjaxCallback:SIMULATE_ERROR	Z
    //   358: ifeq +14 -> 372
    //   361: new 202	java/io/IOException
    //   364: dup
    //   365: ldc_w 743
    //   368: invokespecial 735	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   371: athrow
    //   372: aload_0
    //   373: aload_1
    //   374: aload 21
    //   376: aload 22
    //   378: invokespecial 745	com/androidquery/callback/AbstractAjaxCallback:execute	(Lorg/apache/http/client/methods/HttpUriRequest;Lorg/apache/http/impl/client/DefaultHttpClient;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/HttpResponse;
    //   381: astore 12
    //   383: aconst_null
    //   384: astore 17
    //   386: aconst_null
    //   387: astore 14
    //   389: aload_2
    //   390: astore 11
    //   392: aload 12
    //   394: invokeinterface 751 1 0
    //   399: invokeinterface 756 1 0
    //   404: istore 4
    //   406: aload 12
    //   408: invokeinterface 751 1 0
    //   413: invokeinterface 759 1 0
    //   418: astore 23
    //   420: aconst_null
    //   421: astore 16
    //   423: aconst_null
    //   424: astore 18
    //   426: aconst_null
    //   427: astore_1
    //   428: aload 12
    //   430: invokeinterface 763 1 0
    //   435: astore 24
    //   437: aconst_null
    //   438: astore 15
    //   440: aconst_null
    //   441: astore 10
    //   443: iload 4
    //   445: sipush 200
    //   448: if_icmplt +11 -> 459
    //   451: iload 4
    //   453: sipush 300
    //   456: if_icmplt +281 -> 737
    //   459: aconst_null
    //   460: astore 10
    //   462: aconst_null
    //   463: astore 13
    //   465: aconst_null
    //   466: astore 9
    //   468: aload 24
    //   470: ifnull +72 -> 542
    //   473: aload 13
    //   475: astore 9
    //   477: aload 24
    //   479: invokeinterface 767 1 0
    //   484: astore 13
    //   486: aload 13
    //   488: astore_1
    //   489: aload_1
    //   490: astore 10
    //   492: aload_1
    //   493: astore 9
    //   495: aload_0
    //   496: aload_0
    //   497: aload 24
    //   499: invokespecial 769	com/androidquery/callback/AbstractAjaxCallback:getEncoding	(Lorg/apache/http/HttpEntity;)Ljava/lang/String;
    //   502: aload 13
    //   504: invokespecial 773	com/androidquery/callback/AbstractAjaxCallback:toData	(Ljava/lang/String;Ljava/io/InputStream;)[B
    //   507: astore 13
    //   509: aload_1
    //   510: astore 10
    //   512: aload_1
    //   513: astore 9
    //   515: new 112	java/lang/String
    //   518: dup
    //   519: aload 13
    //   521: ldc -126
    //   523: invokespecial 261	java/lang/String:<init>	([BLjava/lang/String;)V
    //   526: astore 13
    //   528: ldc_w 775
    //   531: aload 13
    //   533: invokestatic 275	com/androidquery/util/AQUtility:debug	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   536: aload_1
    //   537: astore 9
    //   539: aload 13
    //   541: astore_1
    //   542: aload 9
    //   544: invokestatic 248	com/androidquery/util/AQUtility:close	(Ljava/io/Closeable;)V
    //   547: aload 15
    //   549: astore 13
    //   551: aload 14
    //   553: astore 10
    //   555: aload_1
    //   556: astore 9
    //   558: ldc_w 777
    //   561: iload 4
    //   563: invokestatic 709	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   566: invokestatic 275	com/androidquery/util/AQUtility:debug	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   569: aload 10
    //   571: ifnull +13 -> 584
    //   574: aload 10
    //   576: arraylength
    //   577: invokestatic 709	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   580: aload_2
    //   581: invokestatic 275	com/androidquery/util/AQUtility:debug	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   584: aload_3
    //   585: iload 4
    //   587: invokevirtual 780	com/androidquery/callback/AjaxStatus:code	(I)Lcom/androidquery/callback/AjaxStatus;
    //   590: aload 23
    //   592: invokevirtual 784	com/androidquery/callback/AjaxStatus:message	(Ljava/lang/String;)Lcom/androidquery/callback/AjaxStatus;
    //   595: aload 9
    //   597: invokevirtual 786	com/androidquery/callback/AjaxStatus:error	(Ljava/lang/String;)Lcom/androidquery/callback/AjaxStatus;
    //   600: aload 11
    //   602: invokevirtual 788	com/androidquery/callback/AjaxStatus:redirect	(Ljava/lang/String;)Lcom/androidquery/callback/AjaxStatus;
    //   605: new 469	java/util/Date
    //   608: dup
    //   609: invokespecial 789	java/util/Date:<init>	()V
    //   612: invokevirtual 480	com/androidquery/callback/AjaxStatus:time	(Ljava/util/Date;)Lcom/androidquery/callback/AjaxStatus;
    //   615: aload 10
    //   617: invokevirtual 294	com/androidquery/callback/AjaxStatus:data	([B)Lcom/androidquery/callback/AjaxStatus;
    //   620: aload 13
    //   622: invokevirtual 793	com/androidquery/callback/AjaxStatus:file	(Ljava/io/File;)Lcom/androidquery/callback/AjaxStatus;
    //   625: aload 21
    //   627: invokevirtual 796	com/androidquery/callback/AjaxStatus:client	(Lorg/apache/http/impl/client/DefaultHttpClient;)Lcom/androidquery/callback/AjaxStatus;
    //   630: aload 22
    //   632: invokevirtual 800	com/androidquery/callback/AjaxStatus:context	(Lorg/apache/http/protocol/HttpContext;)Lcom/androidquery/callback/AjaxStatus;
    //   635: aload 12
    //   637: invokeinterface 804 1 0
    //   642: invokevirtual 807	com/androidquery/callback/AjaxStatus:headers	([Lorg/apache/http/Header;)Lcom/androidquery/callback/AjaxStatus;
    //   645: pop
    //   646: return
    //   647: astore 10
    //   649: aload_0
    //   650: getfield 694	com/androidquery/callback/AbstractAjaxCallback:proxy	Lorg/apache/http/HttpHost;
    //   653: ifnull +35 -> 688
    //   656: ldc_w 809
    //   659: invokestatic 241	com/androidquery/util/AQUtility:debug	(Ljava/lang/Object;)V
    //   662: aload 9
    //   664: ldc_w 696
    //   667: aconst_null
    //   668: invokeinterface 702 3 0
    //   673: pop
    //   674: aload_0
    //   675: aload_1
    //   676: aload 21
    //   678: aload 22
    //   680: invokespecial 745	com/androidquery/callback/AbstractAjaxCallback:execute	(Lorg/apache/http/client/methods/HttpUriRequest;Lorg/apache/http/impl/client/DefaultHttpClient;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/HttpResponse;
    //   683: astore 12
    //   685: goto -302 -> 383
    //   688: aload 10
    //   690: athrow
    //   691: astore 13
    //   693: aload 10
    //   695: astore_1
    //   696: aload 18
    //   698: astore 10
    //   700: aload_1
    //   701: astore 9
    //   703: aload 13
    //   705: invokestatic 449	com/androidquery/util/AQUtility:debug	(Ljava/lang/Throwable;)V
    //   708: aload_1
    //   709: invokestatic 248	com/androidquery/util/AQUtility:close	(Ljava/io/Closeable;)V
    //   712: aload 10
    //   714: astore 9
    //   716: aload 14
    //   718: astore 10
    //   720: aload 15
    //   722: astore 13
    //   724: goto -166 -> 558
    //   727: astore_2
    //   728: aload 9
    //   730: astore_1
    //   731: aload_1
    //   732: invokestatic 248	com/androidquery/util/AQUtility:close	(Ljava/io/Closeable;)V
    //   735: aload_2
    //   736: athrow
    //   737: aload 22
    //   739: ldc_w 811
    //   742: invokeinterface 814 2 0
    //   747: checkcast 342	org/apache/http/HttpHost
    //   750: astore_1
    //   751: aload 22
    //   753: ldc_w 816
    //   756: invokeinterface 814 2 0
    //   761: checkcast 314	org/apache/http/client/methods/HttpUriRequest
    //   764: astore 9
    //   766: new 398	java/lang/StringBuilder
    //   769: dup
    //   770: aload_1
    //   771: invokevirtual 819	org/apache/http/HttpHost:toURI	()Ljava/lang/String;
    //   774: invokestatic 405	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   777: invokespecial 408	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   780: aload 9
    //   782: invokeinterface 318 1 0
    //   787: invokevirtual 822	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   790: invokevirtual 421	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   793: astore 18
    //   795: bipush 32
    //   797: ldc_w 823
    //   800: aload 24
    //   802: invokeinterface 826 1 0
    //   807: l2i
    //   808: invokestatic 832	java/lang/Math:min	(II)I
    //   811: invokestatic 835	java/lang/Math:max	(II)I
    //   814: istore 5
    //   816: aconst_null
    //   817: astore 9
    //   819: aconst_null
    //   820: astore 11
    //   822: aload 9
    //   824: astore 14
    //   826: aload 11
    //   828: astore_1
    //   829: aload_0
    //   830: invokespecial 837	com/androidquery/callback/AbstractAjaxCallback:getPreFile	()Ljava/io/File;
    //   833: astore 19
    //   835: aload 19
    //   837: astore 13
    //   839: aload 19
    //   841: ifnonnull +196 -> 1037
    //   844: aload 9
    //   846: astore 14
    //   848: aload 11
    //   850: astore_1
    //   851: new 839	com/androidquery/util/PredefinedBAOS
    //   854: dup
    //   855: iload 5
    //   857: invokespecial 840	com/androidquery/util/PredefinedBAOS:<init>	(I)V
    //   860: astore 9
    //   862: aload 10
    //   864: astore 15
    //   866: aload 9
    //   868: astore 14
    //   870: aload 11
    //   872: astore_1
    //   873: aload 24
    //   875: invokeinterface 767 1 0
    //   880: astore 20
    //   882: aload 20
    //   884: astore 11
    //   886: aload 9
    //   888: astore 14
    //   890: aload 11
    //   892: astore_1
    //   893: ldc_w 679
    //   896: aload_0
    //   897: aload 24
    //   899: invokespecial 769	com/androidquery/callback/AbstractAjaxCallback:getEncoding	(Lorg/apache/http/HttpEntity;)Ljava/lang/String;
    //   902: invokevirtual 258	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   905: istore 6
    //   907: aload 11
    //   909: astore 10
    //   911: iload 6
    //   913: ifeq +21 -> 934
    //   916: aload 9
    //   918: astore 14
    //   920: aload 11
    //   922: astore_1
    //   923: new 842	java/util/zip/GZIPInputStream
    //   926: dup
    //   927: aload 20
    //   929: invokespecial 845	java/util/zip/GZIPInputStream:<init>	(Ljava/io/InputStream;)V
    //   932: astore 10
    //   934: aload 9
    //   936: astore 14
    //   938: aload 10
    //   940: astore_1
    //   941: aload 24
    //   943: invokeinterface 826 1 0
    //   948: l2i
    //   949: istore 5
    //   951: aload 9
    //   953: astore 14
    //   955: aload 10
    //   957: astore_1
    //   958: aload_0
    //   959: aload 10
    //   961: checkcast 224	java/io/InputStream
    //   964: aload 9
    //   966: checkcast 229	java/io/OutputStream
    //   969: iload 5
    //   971: aload 15
    //   973: aload 19
    //   975: invokespecial 847	com/androidquery/callback/AbstractAjaxCallback:copy	(Ljava/io/InputStream;Ljava/io/OutputStream;ILjava/io/File;Ljava/io/File;)V
    //   978: aload 19
    //   980: ifnonnull +104 -> 1084
    //   983: aload 9
    //   985: astore 14
    //   987: aload 10
    //   989: astore_1
    //   990: aload 9
    //   992: checkcast 839	com/androidquery/util/PredefinedBAOS
    //   995: invokevirtual 850	com/androidquery/util/PredefinedBAOS:toByteArray	()[B
    //   998: astore 11
    //   1000: aload 13
    //   1002: astore_1
    //   1003: aload 10
    //   1005: checkcast 852	java/io/Closeable
    //   1008: invokestatic 248	com/androidquery/util/AQUtility:close	(Ljava/io/Closeable;)V
    //   1011: aload 9
    //   1013: checkcast 852	java/io/Closeable
    //   1016: invokestatic 248	com/androidquery/util/AQUtility:close	(Ljava/io/Closeable;)V
    //   1019: aload 16
    //   1021: astore 9
    //   1023: aload 11
    //   1025: astore 10
    //   1027: aload 18
    //   1029: astore 11
    //   1031: aload_1
    //   1032: astore 13
    //   1034: goto -476 -> 558
    //   1037: aload 9
    //   1039: astore 14
    //   1041: aload 11
    //   1043: astore_1
    //   1044: aload_0
    //   1045: aload 19
    //   1047: invokespecial 856	com/androidquery/callback/AbstractAjaxCallback:makeTempFile	(Ljava/io/File;)Ljava/io/File;
    //   1050: astore 10
    //   1052: aload 10
    //   1054: astore 15
    //   1056: aload 9
    //   1058: astore 14
    //   1060: aload 11
    //   1062: astore_1
    //   1063: new 858	java/io/BufferedOutputStream
    //   1066: dup
    //   1067: new 860	java/io/FileOutputStream
    //   1070: dup
    //   1071: aload 10
    //   1073: invokespecial 863	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   1076: invokespecial 866	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   1079: astore 9
    //   1081: goto -215 -> 866
    //   1084: aload 9
    //   1086: astore 14
    //   1088: aload 10
    //   1090: astore_1
    //   1091: aload 19
    //   1093: invokevirtual 447	java/io/File:exists	()Z
    //   1096: istore 6
    //   1098: iload 6
    //   1100: ifeq +31 -> 1131
    //   1103: aload 9
    //   1105: astore 14
    //   1107: aload 10
    //   1109: astore_1
    //   1110: aload 19
    //   1112: invokevirtual 869	java/io/File:length	()J
    //   1115: lstore 7
    //   1117: aload 17
    //   1119: astore 11
    //   1121: aload 13
    //   1123: astore_1
    //   1124: lload 7
    //   1126: lconst_0
    //   1127: lcmp
    //   1128: ifne -125 -> 1003
    //   1131: aconst_null
    //   1132: astore_1
    //   1133: aload 17
    //   1135: astore 11
    //   1137: goto -134 -> 1003
    //   1140: astore_2
    //   1141: aload_1
    //   1142: checkcast 852	java/io/Closeable
    //   1145: invokestatic 248	com/androidquery/util/AQUtility:close	(Ljava/io/Closeable;)V
    //   1148: aload 14
    //   1150: checkcast 852	java/io/Closeable
    //   1153: invokestatic 248	com/androidquery/util/AQUtility:close	(Ljava/io/Closeable;)V
    //   1156: aload_2
    //   1157: athrow
    //   1158: astore_2
    //   1159: goto -428 -> 731
    //   1162: astore 9
    //   1164: aload 13
    //   1166: astore 10
    //   1168: aload 9
    //   1170: astore 13
    //   1172: goto -472 -> 700
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	1175	0	this	AbstractAjaxCallback
    //   0	1175	1	paramHttpUriRequest	HttpUriRequest
    //   0	1175	2	paramString	String
    //   0	1175	3	paramAjaxStatus	AjaxStatus
    //   404	182	4	i	int
    //   814	156	5	j	int
    //   905	194	6	bool	boolean
    //   1115	10	7	l	long
    //   60	1044	9	localObject1	Object
    //   1162	7	9	localException1	Exception
    //   328	288	10	localObject2	Object
    //   647	47	10	localHttpHostConnectException	org.apache.http.conn.HttpHostConnectException
    //   698	469	10	localObject3	Object
    //   390	746	11	localObject4	Object
    //   381	303	12	localHttpResponse	HttpResponse
    //   463	158	13	localObject5	Object
    //   691	13	13	localException2	Exception
    //   722	449	13	localObject6	Object
    //   387	762	14	localObject7	Object
    //   438	617	15	localObject8	Object
    //   421	599	16	localObject9	Object
    //   384	750	17	localObject10	Object
    //   424	604	18	str1	String
    //   833	278	19	localFile	File
    //   880	48	20	localInputStream	InputStream
    //   3	674	21	localDefaultHttpClient	DefaultHttpClient
    //   249	503	22	localBasicHttpContext	org.apache.http.protocol.BasicHttpContext
    //   418	173	23	str2	String
    //   435	507	24	localHttpEntity	HttpEntity
    // Exception table:
    //   from	to	target	type
    //   372	383	647	org/apache/http/conn/HttpHostConnectException
    //   477	486	691	java/lang/Exception
    //   495	509	691	java/lang/Exception
    //   515	528	691	java/lang/Exception
    //   477	486	727	java/lang/Throwable
    //   495	509	727	java/lang/Throwable
    //   515	528	727	java/lang/Throwable
    //   703	708	727	java/lang/Throwable
    //   829	835	1140	java/lang/Throwable
    //   851	862	1140	java/lang/Throwable
    //   873	882	1140	java/lang/Throwable
    //   893	907	1140	java/lang/Throwable
    //   923	934	1140	java/lang/Throwable
    //   941	951	1140	java/lang/Throwable
    //   958	978	1140	java/lang/Throwable
    //   990	1000	1140	java/lang/Throwable
    //   1044	1052	1140	java/lang/Throwable
    //   1063	1081	1140	java/lang/Throwable
    //   1091	1098	1140	java/lang/Throwable
    //   1110	1117	1140	java/lang/Throwable
    //   528	536	1158	java/lang/Throwable
    //   528	536	1162	java/lang/Exception
  }
  
  private void httpEntity(String paramString, HttpEntityEnclosingRequestBase paramHttpEntityEnclosingRequestBase, Map paramMap, AjaxStatus paramAjaxStatus)
    throws ClientProtocolException, IOException
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a11 = a10\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
  }
  
  private void httpGet(String paramString, AjaxStatus paramAjaxStatus)
    throws IOException
  {
    AQUtility.debug("get", paramString);
    paramString = patchUrl(paramString);
    httpDo(new HttpGet(paramString), paramString, paramAjaxStatus);
  }
  
  private void httpMulti(String paramString, Map paramMap, AjaxStatus paramAjaxStatus)
    throws IOException
  {
    AQUtility.debug("multipart", paramString);
    Object localObject2 = new URL(paramString);
    Object localObject1 = null;
    label85:
    label172:
    label246:
    int i;
    Object localObject3;
    String str;
    if (proxy != null)
    {
      AQUtility.debug("proxy", proxy);
      localObject1 = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxy.getHostName(), proxy.getPort()));
      if (localObject1 != null) {
        break label432;
      }
      localObject1 = (HttpURLConnection)((URL)localObject2).openConnection();
      ((HttpURLConnection)localObject1).setInstanceFollowRedirects(false);
      ((HttpURLConnection)localObject1).setConnectTimeout(NET_TIMEOUT * 4);
      ((HttpURLConnection)localObject1).setDoInput(true);
      ((HttpURLConnection)localObject1).setDoOutput(true);
      ((HttpURLConnection)localObject1).setUseCaches(false);
      ((HttpURLConnection)localObject1).setRequestMethod("POST");
      ((HttpURLConnection)localObject1).setRequestProperty("Connection", "Keep-Alive");
      ((HttpURLConnection)localObject1).setRequestProperty("Content-Type", "multipart/form-data;charset=utf-8;boundary=*****");
      if (headers != null)
      {
        localObject2 = headers.keySet().iterator();
        if (((Iterator)localObject2).hasNext()) {
          break label447;
        }
      }
      localObject2 = makeCookie();
      if (localObject2 != null) {
        ((HttpURLConnection)localObject1).setRequestProperty("Cookie", (String)localObject2);
      }
      if (ah != null) {
        ah.applyToken(this, (HttpURLConnection)localObject1);
      }
      localObject2 = new DataOutputStream(((HttpURLConnection)localObject1).getOutputStream());
      paramMap = paramMap.entrySet().iterator();
      if (paramMap.hasNext()) {
        break label483;
      }
      ((DataOutputStream)localObject2).writeBytes("--*****--\r\n");
      ((DataOutputStream)localObject2).flush();
      ((DataOutputStream)localObject2).close();
      ((HttpURLConnection)localObject1).connect();
      i = ((HttpURLConnection)localObject1).getResponseCode();
      localObject3 = ((HttpURLConnection)localObject1).getResponseMessage();
      paramMap = null;
      str = ((HttpURLConnection)localObject1).getContentEncoding();
      localObject2 = null;
      if ((i >= 200) && (i < 300)) {
        break label519;
      }
      localObject1 = new String(toData(str, ((HttpURLConnection)localObject1).getErrorStream()), "UTF-8");
      AQUtility.debug("error", localObject1);
    }
    for (;;)
    {
      AQUtility.debug("response", Integer.valueOf(i));
      if (paramMap != null) {
        AQUtility.debug(Integer.valueOf(paramMap.length), paramString);
      }
      paramAjaxStatus.code(i).message((String)localObject3).redirect(paramString).time(new Date()).data(paramMap).error((String)localObject1).client(null);
      return;
      if (proxyHandle == null) {
        break;
      }
      localObject1 = proxyHandle.makeProxy(this);
      break;
      label432:
      localObject1 = (HttpURLConnection)((URL)localObject2).openConnection((Proxy)localObject1);
      break label85;
      label447:
      localObject3 = (String)((Iterator)localObject2).next();
      ((HttpURLConnection)localObject1).setRequestProperty((String)localObject3, (String)headers.get(localObject3));
      break label172;
      label483:
      localObject3 = (Map.Entry)paramMap.next();
      writeObject((DataOutputStream)localObject2, (String)((Map.Entry)localObject3).getKey(), ((Map.Entry)localObject3).getValue());
      break label246;
      label519:
      paramMap = toData(str, ((HttpURLConnection)localObject1).getInputStream());
      localObject1 = localObject2;
    }
  }
  
  private void httpPost(String paramString, Map paramMap, AjaxStatus paramAjaxStatus)
    throws ClientProtocolException, IOException
  {
    AQUtility.debug("post", paramString);
    httpEntity(paramString, new HttpPost(paramString), paramMap, paramAjaxStatus);
  }
  
  private void httpPut(String paramString, Map paramMap, AjaxStatus paramAjaxStatus)
    throws ClientProtocolException, IOException
  {
    AQUtility.debug("put", paramString);
    httpEntity(paramString, new HttpPut(paramString), paramMap, paramAjaxStatus);
  }
  
  private boolean isActive()
  {
    if (act == null) {
      return true;
    }
    Activity localActivity = (Activity)act.get();
    return (localActivity != null) && (!localActivity.isFinishing());
  }
  
  private static boolean isMultiPart(Map paramMap)
  {
    paramMap = paramMap.entrySet().iterator();
    Object localObject;
    do
    {
      if (!paramMap.hasNext()) {
        return false;
      }
      Map.Entry localEntry = (Map.Entry)paramMap.next();
      localObject = localEntry.getValue();
      AQUtility.debug(localEntry.getKey(), localObject);
    } while ((!(localObject instanceof File)) && (!(localObject instanceof byte[])) && (!(localObject instanceof InputStream)));
    return true;
  }
  
  private static String makeAuthHeader(String paramString1, String paramString2)
  {
    paramString1 = (paramString1 + ":" + paramString2).getBytes();
    return "Basic " + new String(AQUtility.encode64(paramString1, 0, paramString1.length));
  }
  
  private String makeCookie()
  {
    if ((cookies == null) || (cookies.size() == 0)) {
      return null;
    }
    Iterator localIterator = cookies.keySet().iterator();
    StringBuilder localStringBuilder = new StringBuilder();
    for (;;)
    {
      if (!localIterator.hasNext()) {
        return localStringBuilder.toString();
      }
      String str1 = (String)localIterator.next();
      String str2 = (String)cookies.get(str1);
      localStringBuilder.append(str1);
      localStringBuilder.append("=");
      localStringBuilder.append(str2);
      if (localIterator.hasNext()) {
        localStringBuilder.append("; ");
      }
    }
  }
  
  private File makeTempFile(File paramFile)
    throws IOException
  {
    paramFile = new File(paramFile.getAbsolutePath() + ".tmp");
    paramFile.createNewFile();
    return paramFile;
  }
  
  private void network()
    throws IOException
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a11 = a10\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
  }
  
  private void network(int paramInt)
    throws IOException
  {
    if (paramInt <= 1)
    {
      network();
      return;
    }
    int i = 0;
    while (i < paramInt) {
      try
      {
        network();
        return;
      }
      catch (IOException localIOException)
      {
        if (i == paramInt - 1) {
          throw localIOException;
        }
        i += 1;
      }
    }
  }
  
  private void networkWork()
  {
    if (url == null)
    {
      status.code(-101).done();
      return;
    }
    Object localObject1 = null;
    int i = retry;
    try
    {
      network(i + 1);
      if (ah != null)
      {
        localObject2 = ah;
        localAjaxStatus = status;
        boolean bool = ((AccountHandle)localObject2).expired(this, localAjaxStatus);
        if ((bool) && (!reauth))
        {
          localObject2 = status;
          AQUtility.debug("reauth needed", ((AjaxStatus)localObject2).getMessage());
          reauth = true;
          localObject2 = ah;
          bool = ((AccountHandle)localObject2).reauth(this);
          if (!bool) {
            break label208;
          }
          network();
        }
      }
      localObject2 = status;
      localObject2 = ((AjaxStatus)localObject2).getData();
      localObject1 = localObject2;
    }
    catch (IOException localIOException)
    {
      for (;;)
      {
        Object localObject2;
        AjaxStatus localAjaxStatus;
        AQUtility.debug("IOException");
        str = ((IOException)localIOException).getMessage();
        if ((str != null) && (str.contains("No authentication challenges found"))) {
          status.code(401).message(str);
        } else {
          status.code(-101).message("network error");
        }
      }
    }
    catch (Exception localException1)
    {
      for (;;)
      {
        AQUtility.debug(localException1);
        status.code(-101).message("network error");
      }
    }
    localObject2 = url;
    localAjaxStatus = status;
    try
    {
      localObject2 = transform((String)localObject2, localObject1, localAjaxStatus);
      result = localObject2;
    }
    catch (Exception localException2)
    {
      for (;;)
      {
        label208:
        String str;
        AQUtility.debug(localException2);
      }
    }
    if ((result == null) && (localObject1 != null)) {
      status.code(-103).message("transform error");
    }
    lastStatus = status.getCode();
    status.done();
    return;
    localObject2 = status;
    ((AjaxStatus)localObject2).reauth(true);
  }
  
  private String parseCharset(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    int k = paramString.indexOf("charset");
    if (k != -1)
    {
      int j = paramString.indexOf(";", k);
      int i = j;
      if (j == -1) {
        i = paramString.length();
      }
      return paramString.substring(k + 7, i).replaceAll("[^\\w-]", "");
    }
    return null;
  }
  
  private static String patchUrl(String paramString)
  {
    return paramString.replaceAll(" ", "%20").replaceAll("\\|", "%7C");
  }
  
  private Object self()
  {
    return this;
  }
  
  public static void setAgent(String paramString)
  {
    AGENT = paramString;
  }
  
  public static void setGZip(boolean paramBoolean)
  {
    GZIP = paramBoolean;
  }
  
  public static void setNetworkLimit(int paramInt)
  {
    NETWORK_POOL = Math.max(1, Math.min(25, paramInt));
    fetchExe = null;
    AQUtility.debug("setting network limit", Integer.valueOf(NETWORK_POOL));
  }
  
  public static void setProxyHandle(ProxyHandle paramProxyHandle)
  {
    proxyHandle = paramProxyHandle;
  }
  
  public static void setReuseHttpClient(boolean paramBoolean)
  {
    REUSE_CLIENT = paramBoolean;
    client = null;
  }
  
  public static void setSSF(SocketFactory paramSocketFactory)
  {
    ssf = paramSocketFactory;
    client = null;
  }
  
  public static void setSimulateError(boolean paramBoolean)
  {
    SIMULATE_ERROR = paramBoolean;
  }
  
  public static void setTimeout(int paramInt)
  {
    NET_TIMEOUT = paramInt;
  }
  
  public static void setTransformer(Transformer paramTransformer)
  {
    st = paramTransformer;
  }
  
  private byte[] toData(String paramString, InputStream paramInputStream)
    throws IOException
  {
    Object localObject = paramInputStream;
    if ("gzip".equalsIgnoreCase(paramString)) {
      localObject = new GZIPInputStream((InputStream)paramInputStream);
    }
    return AQUtility.toBytes((InputStream)localObject);
  }
  
  private void wake()
  {
    if (!blocked) {
      return;
    }
    try
    {
      notifyAll();
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
    catch (Exception localException)
    {
      for (;;) {}
    }
  }
  
  private void work(Context paramContext)
  {
    Object localObject = memGet(url);
    if (localObject != null)
    {
      result = localObject;
      status.source(4).done();
      callback();
      return;
    }
    cacheDir = AQUtility.getCacheDir(paramContext, policy);
    execute(this);
  }
  
  private static void writeData(DataOutputStream paramDataOutputStream, String paramString1, String paramString2, InputStream paramInputStream)
    throws IOException
  {
    paramDataOutputStream.writeBytes("--*****\r\n");
    paramDataOutputStream.writeBytes("Content-Disposition: form-data; name=\"" + paramString1 + "\";" + " filename=\"" + paramString2 + "\"" + "\r\n");
    paramDataOutputStream.writeBytes("Content-Type: application/octet-stream");
    paramDataOutputStream.writeBytes("\r\n");
    paramDataOutputStream.writeBytes("Content-Transfer-Encoding: binary");
    paramDataOutputStream.writeBytes("\r\n");
    paramDataOutputStream.writeBytes("\r\n");
    AQUtility.copy(paramInputStream, paramDataOutputStream);
    paramDataOutputStream.writeBytes("\r\n");
  }
  
  private static void writeField(DataOutputStream paramDataOutputStream, String paramString1, String paramString2)
    throws IOException
  {
    paramDataOutputStream.writeBytes("--*****\r\n");
    paramDataOutputStream.writeBytes("Content-Disposition: form-data; name=\"" + paramString1 + "\"");
    paramDataOutputStream.writeBytes("\r\n");
    paramDataOutputStream.writeBytes("\r\n");
    paramDataOutputStream.write(paramString2.getBytes("UTF-8"));
    paramDataOutputStream.writeBytes("\r\n");
  }
  
  private static void writeObject(DataOutputStream paramDataOutputStream, String paramString, Object paramObject)
    throws IOException
  {
    if (paramObject == null) {
      return;
    }
    if ((paramObject instanceof File))
    {
      paramObject = (File)paramObject;
      writeData(paramDataOutputStream, paramString, paramObject.getName(), new FileInputStream(paramObject));
      return;
    }
    if ((paramObject instanceof byte[]))
    {
      writeData(paramDataOutputStream, paramString, paramString, new ByteArrayInputStream((byte[])paramObject));
      return;
    }
    if ((paramObject instanceof InputStream))
    {
      writeData(paramDataOutputStream, paramString, paramString, (InputStream)paramObject);
      return;
    }
    writeField(paramDataOutputStream, paramString, paramObject.toString());
  }
  
  public void abort()
  {
    abort = true;
    if ((request != null) && (!request.isAborted())) {
      request.abort();
    }
  }
  
  protected File accessFile(File paramFile, String paramString)
  {
    if (expire < 0L) {
      return null;
    }
    paramFile = AQUtility.getExistedCacheByUrl(paramFile, paramString);
    if ((paramFile != null) && (expire != 0L) && (System.currentTimeMillis() - paramFile.lastModified() > expire)) {
      return null;
    }
    return paramFile;
  }
  
  public void async(Activity paramActivity)
  {
    if (paramActivity.isFinishing()) {
      AQUtility.warn("Warning", "Possible memory leak. Calling ajax with a terminated activity.");
    }
    if (type == null)
    {
      AQUtility.warn("Warning", "type() is not called with response type.");
      return;
    }
    act = new WeakReference(paramActivity);
    async(paramActivity);
  }
  
  public void async(Context paramContext)
  {
    if (status == null)
    {
      status = new AjaxStatus();
      status.redirect(url).refresh(refresh);
    }
    for (;;)
    {
      showProgress(true);
      if ((ah == null) || (ah.authenticated())) {
        break;
      }
      AQUtility.debug("auth needed", url);
      ah.auth(this);
      return;
      if (status.getDone())
      {
        status.reset();
        result = null;
      }
    }
    work(paramContext);
  }
  
  public Object auth(Activity paramActivity, String paramString1, String paramString2)
  {
    if ((Build.VERSION.SDK_INT >= 5) && (paramString1.startsWith("g."))) {
      ah = new GoogleHandle(paramActivity, paramString1, paramString2);
    }
    return self();
  }
  
  public Object auth(AccountHandle paramAccountHandle)
  {
    ah = paramAccountHandle;
    return self();
  }
  
  public void block()
  {
    if (AQUtility.isUIThread()) {
      throw new IllegalStateException("Cannot block UI thread.");
    }
    if (completed) {
      return;
    }
    try
    {
      blocked = true;
      wait(NET_TIMEOUT + 5000);
      return;
    }
    catch (Throwable localThrowable)
    {
      try
      {
        throw localThrowable;
      }
      catch (Exception localException) {}
    }
  }
  
  protected boolean cacheAvailable(Context paramContext)
  {
    return (fileCache) && (AQUtility.getExistedCacheByUrl(AQUtility.getCacheDir(paramContext, policy), url) != null);
  }
  
  void callback()
  {
    showProgress(false);
    completed = true;
    Object localObject1;
    Object localObject2;
    Object localObject3;
    if (isActive()) {
      if (callback != null)
      {
        localObject1 = getHandler();
        localObject2 = type;
        localObject3 = callback;
        Class[] arrayOfClass = DEFAULT_SIG;
        String str = url;
        Object localObject4 = result;
        AjaxStatus localAjaxStatus = status;
        AQUtility.invokeHandler(localObject1, (String)localObject3, true, true, new Class[] { String.class, localObject2, AjaxStatus.class }, arrayOfClass, new Object[] { str, localObject4, localAjaxStatus });
      }
    }
    for (;;)
    {
      filePut();
      if (!blocked) {
        status.close();
      }
      wake();
      AQUtility.debugNotify();
      return;
      localObject1 = url;
      localObject2 = result;
      localObject3 = status;
      try
      {
        callback((String)localObject1, localObject2, (AjaxStatus)localObject3);
      }
      catch (Exception localException)
      {
        AQUtility.report(localException);
      }
      continue;
      skip(url, result, status);
    }
  }
  
  public void callback(String paramString, Object paramObject, AjaxStatus paramAjaxStatus) {}
  
  public Object cookie(String paramString1, String paramString2)
  {
    if (cookies == null) {
      cookies = new HashMap();
    }
    cookies.put(paramString1, paramString2);
    return self();
  }
  
  public Object cookies(Map paramMap)
  {
    cookies = paramMap;
    return self();
  }
  
  protected Object datastoreGet(String paramString)
  {
    return null;
  }
  
  public Object encoding(String paramString)
  {
    encoding = paramString;
    return self();
  }
  
  public Object expire(long paramLong)
  {
    expire = paramLong;
    return self();
  }
  
  public void failure(int paramInt, String paramString)
  {
    if (status != null)
    {
      status.code(paramInt).message(paramString).done();
      if (uiCallback)
      {
        AQUtility.post(this);
        return;
      }
      afterWork();
    }
  }
  
  public Object fileCache(boolean paramBoolean)
  {
    fileCache = paramBoolean;
    return self();
  }
  
  protected Object fileGet(String paramString, File paramFile, AjaxStatus paramAjaxStatus)
  {
    Object localObject = null;
    try
    {
      boolean bool = isStreamingContent();
      if (bool) {
        paramAjaxStatus.file(paramFile);
      }
      for (paramFile = localObject;; paramFile = AQUtility.toBytes(new FileInputStream(paramFile)))
      {
        paramString = transform(paramString, paramFile, paramAjaxStatus);
        return paramString;
      }
      return null;
    }
    catch (Exception paramString)
    {
      AQUtility.debug(paramString);
    }
  }
  
  protected void filePut(String paramString, Object paramObject, File paramFile, byte[] paramArrayOfByte)
  {
    if (paramFile != null)
    {
      if (paramArrayOfByte == null) {
        return;
      }
      AQUtility.storeAsync(paramFile, paramArrayOfByte, 0L);
    }
  }
  
  protected File getCacheFile()
  {
    return AQUtility.getCacheFile(cacheDir, getCacheUrl());
  }
  
  public String getCallback()
  {
    return callback;
  }
  
  public String getEncoding()
  {
    return encoding;
  }
  
  public Object getHandler()
  {
    if (handler != null) {
      return handler;
    }
    if (whandler == null) {
      return null;
    }
    return whandler.get();
  }
  
  public Object getResult()
  {
    return result;
  }
  
  public AjaxStatus getStatus()
  {
    return status;
  }
  
  public Class getType()
  {
    return type;
  }
  
  public String getUrl()
  {
    return url;
  }
  
  public Object handler(Object paramObject, String paramString)
  {
    handler = paramObject;
    callback = paramString;
    whandler = null;
    return self();
  }
  
  public Object header(String paramString1, String paramString2)
  {
    if (headers == null) {
      headers = new HashMap();
    }
    headers.put(paramString1, paramString2);
    return self();
  }
  
  public Object headers(Map paramMap)
  {
    headers = paramMap;
    return self();
  }
  
  protected boolean isStreamingContent()
  {
    return (File.class.equals(type)) || (XmlPullParser.class.equals(type)) || (InputStream.class.equals(type)) || (XmlDom.class.equals(type));
  }
  
  public Object memCache(boolean paramBoolean)
  {
    memCache = paramBoolean;
    return self();
  }
  
  protected Object memGet(String paramString)
  {
    return null;
  }
  
  protected void memPut(String paramString, Object paramObject) {}
  
  public Object method(int paramInt)
  {
    method = paramInt;
    return self();
  }
  
  public Object networkUrl(String paramString)
  {
    networkUrl = paramString;
    return self();
  }
  
  public Object param(String paramString, Object paramObject)
  {
    if (params == null) {
      params = new HashMap();
    }
    params.put(paramString, paramObject);
    return self();
  }
  
  public Object params(Map paramMap)
  {
    params = paramMap;
    return self();
  }
  
  public Object policy(int paramInt)
  {
    policy = paramInt;
    return self();
  }
  
  public Object progress(Dialog paramDialog)
  {
    return progress(paramDialog);
  }
  
  public Object progress(View paramView)
  {
    return progress(paramView);
  }
  
  public Object progress(Object paramObject)
  {
    if (paramObject != null) {
      progress = new WeakReference(paramObject);
    }
    return self();
  }
  
  public Object proxy(String paramString, int paramInt)
  {
    proxy = new HttpHost(paramString, paramInt);
    return self();
  }
  
  public Object proxy(String paramString1, int paramInt, String paramString2, String paramString3)
  {
    proxy(paramString1, paramInt);
    paramString1 = makeAuthHeader(paramString2, paramString3);
    AQUtility.debug("proxy auth", paramString1);
    return header("Proxy-Authorization", paramString1);
  }
  
  public Object redirect(boolean paramBoolean)
  {
    redirect = paramBoolean;
    return self();
  }
  
  public Object refresh(boolean paramBoolean)
  {
    refresh = paramBoolean;
    return self();
  }
  
  public Object retry(int paramInt)
  {
    retry = paramInt;
    return self();
  }
  
  public void run()
  {
    if (!status.getDone()) {
      try
      {
        backgroundWork();
        if (status.getReauth()) {
          return;
        }
        if (uiCallback)
        {
          AQUtility.post(this);
          return;
        }
      }
      catch (Throwable localThrowable)
      {
        for (;;)
        {
          AQUtility.debug(localThrowable);
          status.code(-101).done();
        }
        afterWork();
        return;
      }
    }
    afterWork();
  }
  
  protected void showProgress(final boolean paramBoolean)
  {
    final Object localObject;
    if (progress == null) {
      localObject = null;
    }
    while (localObject != null) {
      if (AQUtility.isUIThread())
      {
        Common.showProgress(localObject, url, paramBoolean);
        return;
        localObject = progress.get();
      }
      else
      {
        AQUtility.post(new Runnable()
        {
          public void run()
          {
            Common.showProgress(localObject, url, paramBoolean);
          }
        });
      }
    }
  }
  
  protected void skip(String paramString, Object paramObject, AjaxStatus paramAjaxStatus) {}
  
  public Object targetFile(File paramFile)
  {
    targetFile = paramFile;
    return self();
  }
  
  public Object timeout(int paramInt)
  {
    timeout = paramInt;
    return self();
  }
  
  /* Error */
  protected Object transform(String paramString, byte[] paramArrayOfByte, AjaxStatus paramAjaxStatus)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 1221	com/androidquery/callback/AbstractAjaxCallback:type	Ljava/lang/Class;
    //   4: ifnonnull +5 -> 9
    //   7: aconst_null
    //   8: areturn
    //   9: aload_3
    //   10: invokevirtual 1382	com/androidquery/callback/AjaxStatus:getFile	()Ljava/io/File;
    //   13: astore 4
    //   15: aload_2
    //   16: ifnull +270 -> 286
    //   19: aload_0
    //   20: getfield 1221	com/androidquery/callback/AbstractAjaxCallback:type	Ljava/lang/Class;
    //   23: ldc_w 1384
    //   26: invokevirtual 1338	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   29: ifeq +11 -> 40
    //   32: aload_2
    //   33: iconst_0
    //   34: aload_2
    //   35: arraylength
    //   36: invokestatic 1390	android/graphics/BitmapFactory:decodeByteArray	([BII)Landroid/graphics/Bitmap;
    //   39: areturn
    //   40: aload_0
    //   41: getfield 1221	com/androidquery/callback/AbstractAjaxCallback:type	Ljava/lang/Class;
    //   44: ldc_w 1392
    //   47: invokevirtual 1338	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   50: ifeq +48 -> 98
    //   53: aconst_null
    //   54: astore_1
    //   55: aload_0
    //   56: getfield 132	com/androidquery/callback/AbstractAjaxCallback:encoding	Ljava/lang/String;
    //   59: astore_3
    //   60: new 112	java/lang/String
    //   63: dup
    //   64: aload_2
    //   65: aload_3
    //   66: invokespecial 261	java/lang/String:<init>	([BLjava/lang/String;)V
    //   69: astore_2
    //   70: new 1394	org/json/JSONTokener
    //   73: dup
    //   74: aload_2
    //   75: invokespecial 1395	org/json/JSONTokener:<init>	(Ljava/lang/String;)V
    //   78: invokevirtual 1398	org/json/JSONTokener:nextValue	()Ljava/lang/Object;
    //   81: astore_1
    //   82: aload_1
    //   83: checkcast 1392	org/json/JSONObject
    //   86: areturn
    //   87: astore_2
    //   88: aload_2
    //   89: invokestatic 449	com/androidquery/util/AQUtility:debug	(Ljava/lang/Throwable;)V
    //   92: aload_1
    //   93: invokestatic 241	com/androidquery/util/AQUtility:debug	(Ljava/lang/Object;)V
    //   96: aconst_null
    //   97: areturn
    //   98: aload_0
    //   99: getfield 1221	com/androidquery/callback/AbstractAjaxCallback:type	Ljava/lang/Class;
    //   102: ldc_w 1400
    //   105: invokevirtual 1338	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   108: ifeq +42 -> 150
    //   111: aload_0
    //   112: getfield 132	com/androidquery/callback/AbstractAjaxCallback:encoding	Ljava/lang/String;
    //   115: astore_1
    //   116: new 112	java/lang/String
    //   119: dup
    //   120: aload_2
    //   121: aload_1
    //   122: invokespecial 261	java/lang/String:<init>	([BLjava/lang/String;)V
    //   125: astore_1
    //   126: new 1394	org/json/JSONTokener
    //   129: dup
    //   130: aload_1
    //   131: invokespecial 1395	org/json/JSONTokener:<init>	(Ljava/lang/String;)V
    //   134: invokevirtual 1398	org/json/JSONTokener:nextValue	()Ljava/lang/Object;
    //   137: astore_1
    //   138: aload_1
    //   139: checkcast 1400	org/json/JSONArray
    //   142: areturn
    //   143: astore_1
    //   144: aload_1
    //   145: invokestatic 449	com/androidquery/util/AQUtility:debug	(Ljava/lang/Throwable;)V
    //   148: aconst_null
    //   149: areturn
    //   150: aload_0
    //   151: getfield 1221	com/androidquery/callback/AbstractAjaxCallback:type	Ljava/lang/Class;
    //   154: ldc 112
    //   156: invokevirtual 1338	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   159: ifeq +58 -> 217
    //   162: aload_3
    //   163: invokevirtual 434	com/androidquery/callback/AjaxStatus:getSource	()I
    //   166: iconst_1
    //   167: if_icmpne +20 -> 187
    //   170: ldc_w 1401
    //   173: invokestatic 241	com/androidquery/util/AQUtility:debug	(Ljava/lang/Object;)V
    //   176: aload_0
    //   177: aload_2
    //   178: aload_0
    //   179: getfield 132	com/androidquery/callback/AbstractAjaxCallback:encoding	Ljava/lang/String;
    //   182: aload_3
    //   183: invokespecial 1403	com/androidquery/callback/AbstractAjaxCallback:correctEncoding	([BLjava/lang/String;Lcom/androidquery/callback/AjaxStatus;)Ljava/lang/String;
    //   186: areturn
    //   187: ldc_w 1404
    //   190: invokestatic 241	com/androidquery/util/AQUtility:debug	(Ljava/lang/Object;)V
    //   193: aload_0
    //   194: getfield 132	com/androidquery/callback/AbstractAjaxCallback:encoding	Ljava/lang/String;
    //   197: astore_1
    //   198: new 112	java/lang/String
    //   201: dup
    //   202: aload_2
    //   203: aload_1
    //   204: invokespecial 261	java/lang/String:<init>	([BLjava/lang/String;)V
    //   207: astore_1
    //   208: aload_1
    //   209: areturn
    //   210: astore_1
    //   211: aload_1
    //   212: invokestatic 449	com/androidquery/util/AQUtility:debug	(Ljava/lang/Throwable;)V
    //   215: aconst_null
    //   216: areturn
    //   217: aload_0
    //   218: getfield 1221	com/androidquery/callback/AbstractAjaxCallback:type	Ljava/lang/Class;
    //   221: ldc_w 1024
    //   224: invokevirtual 1338	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   227: ifeq +5 -> 232
    //   230: aload_2
    //   231: areturn
    //   232: aload_0
    //   233: getfield 194	com/androidquery/callback/AbstractAjaxCallback:transformer	Lcom/androidquery/callback/Transformer;
    //   236: ifnull +24 -> 260
    //   239: aload_0
    //   240: getfield 194	com/androidquery/callback/AbstractAjaxCallback:transformer	Lcom/androidquery/callback/Transformer;
    //   243: aload_1
    //   244: aload_0
    //   245: getfield 1221	com/androidquery/callback/AbstractAjaxCallback:type	Ljava/lang/Class;
    //   248: aload_0
    //   249: getfield 132	com/androidquery/callback/AbstractAjaxCallback:encoding	Ljava/lang/String;
    //   252: aload_2
    //   253: aload_3
    //   254: invokeinterface 1409 6 0
    //   259: areturn
    //   260: getstatic 1135	com/androidquery/callback/AbstractAjaxCallback:st	Lcom/androidquery/callback/Transformer;
    //   263: ifnull +179 -> 442
    //   266: getstatic 1135	com/androidquery/callback/AbstractAjaxCallback:st	Lcom/androidquery/callback/Transformer;
    //   269: aload_1
    //   270: aload_0
    //   271: getfield 1221	com/androidquery/callback/AbstractAjaxCallback:type	Ljava/lang/Class;
    //   274: aload_0
    //   275: getfield 132	com/androidquery/callback/AbstractAjaxCallback:encoding	Ljava/lang/String;
    //   278: aload_2
    //   279: aload_3
    //   280: invokeinterface 1409 6 0
    //   285: areturn
    //   286: aload 4
    //   288: ifnull +154 -> 442
    //   291: aload_0
    //   292: getfield 1221	com/androidquery/callback/AbstractAjaxCallback:type	Ljava/lang/Class;
    //   295: ldc -24
    //   297: invokevirtual 1338	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   300: ifeq +6 -> 306
    //   303: aload 4
    //   305: areturn
    //   306: aload_0
    //   307: getfield 1221	com/androidquery/callback/AbstractAjaxCallback:type	Ljava/lang/Class;
    //   310: ldc_w 1342
    //   313: invokevirtual 1338	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   316: ifeq +36 -> 352
    //   319: new 1185	java/io/FileInputStream
    //   322: dup
    //   323: aload 4
    //   325: invokespecial 1186	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   328: astore_1
    //   329: new 1342	com/androidquery/util/XmlDom
    //   332: dup
    //   333: aload_1
    //   334: invokespecial 1410	com/androidquery/util/XmlDom:<init>	(Ljava/io/InputStream;)V
    //   337: astore_2
    //   338: aload_3
    //   339: aload_1
    //   340: invokevirtual 1413	com/androidquery/callback/AjaxStatus:closeLater	(Ljava/io/Closeable;)V
    //   343: aload_2
    //   344: areturn
    //   345: astore_1
    //   346: aload_1
    //   347: invokestatic 279	com/androidquery/util/AQUtility:report	(Ljava/lang/Throwable;)V
    //   350: aconst_null
    //   351: areturn
    //   352: aload_0
    //   353: getfield 1221	com/androidquery/callback/AbstractAjaxCallback:type	Ljava/lang/Class;
    //   356: ldc_w 1340
    //   359: invokevirtual 1338	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   362: ifeq +46 -> 408
    //   365: invokestatic 1419	android/util/Xml:newPullParser	()Lorg/xmlpull/v1/XmlPullParser;
    //   368: astore_1
    //   369: new 1185	java/io/FileInputStream
    //   372: dup
    //   373: aload 4
    //   375: invokespecial 1186	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   378: astore_2
    //   379: aload_0
    //   380: getfield 132	com/androidquery/callback/AbstractAjaxCallback:encoding	Ljava/lang/String;
    //   383: astore 4
    //   385: aload_1
    //   386: aload_2
    //   387: aload 4
    //   389: invokeinterface 1423 3 0
    //   394: aload_3
    //   395: aload_2
    //   396: invokevirtual 1413	com/androidquery/callback/AjaxStatus:closeLater	(Ljava/io/Closeable;)V
    //   399: aload_1
    //   400: areturn
    //   401: astore_1
    //   402: aload_1
    //   403: invokestatic 279	com/androidquery/util/AQUtility:report	(Ljava/lang/Throwable;)V
    //   406: aconst_null
    //   407: areturn
    //   408: aload_0
    //   409: getfield 1221	com/androidquery/callback/AbstractAjaxCallback:type	Ljava/lang/Class;
    //   412: ldc -32
    //   414: invokevirtual 1338	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   417: ifeq +25 -> 442
    //   420: new 1185	java/io/FileInputStream
    //   423: dup
    //   424: aload 4
    //   426: invokespecial 1186	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   429: astore_1
    //   430: aload_3
    //   431: aload_1
    //   432: invokevirtual 1413	com/androidquery/callback/AjaxStatus:closeLater	(Ljava/io/Closeable;)V
    //   435: aload_1
    //   436: areturn
    //   437: astore_1
    //   438: aload_1
    //   439: invokestatic 279	com/androidquery/util/AQUtility:report	(Ljava/lang/Throwable;)V
    //   442: aconst_null
    //   443: areturn
    //   444: astore_1
    //   445: goto -99 -> 346
    //   448: astore_3
    //   449: aload_2
    //   450: astore_1
    //   451: aload_3
    //   452: astore_2
    //   453: goto -365 -> 88
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	456	0	this	AbstractAjaxCallback
    //   0	456	1	paramString	String
    //   0	456	2	paramArrayOfByte	byte[]
    //   0	456	3	paramAjaxStatus	AjaxStatus
    //   13	412	4	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   60	70	87	java/lang/Exception
    //   116	126	143	java/lang/Exception
    //   126	138	143	java/lang/Exception
    //   198	208	210	java/lang/Exception
    //   319	329	345	java/lang/Exception
    //   329	338	345	java/lang/Exception
    //   369	379	401	java/lang/Exception
    //   385	399	401	java/lang/Exception
    //   420	435	437	java/lang/Exception
    //   338	343	444	java/lang/Exception
    //   70	82	448	java/lang/Exception
  }
  
  public Object transformer(Transformer paramTransformer)
  {
    transformer = paramTransformer;
    return self();
  }
  
  public Object type(Class paramClass)
  {
    type = paramClass;
    return self();
  }
  
  public Object uiCallback(boolean paramBoolean)
  {
    uiCallback = paramBoolean;
    return self();
  }
  
  public Object url(String paramString)
  {
    url = paramString;
    return self();
  }
  
  public Object weakHandler(Object paramObject, String paramString)
  {
    whandler = new WeakReference(paramObject);
    callback = paramString;
    handler = null;
    return self();
  }
}
