package com.androidquery.callback;

import java.net.Proxy;
import org.apache.http.HttpRequest;
import org.apache.http.impl.client.DefaultHttpClient;

public abstract class ProxyHandle
{
  public ProxyHandle() {}
  
  public abstract void applyProxy(AbstractAjaxCallback paramAbstractAjaxCallback, HttpRequest paramHttpRequest, DefaultHttpClient paramDefaultHttpClient);
  
  public abstract Proxy makeProxy(AbstractAjaxCallback paramAbstractAjaxCallback);
}
