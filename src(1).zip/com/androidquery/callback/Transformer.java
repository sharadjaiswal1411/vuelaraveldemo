package com.androidquery.callback;

public abstract interface Transformer
{
  public abstract Object transform(String paramString1, Class paramClass, String paramString2, byte[] paramArrayOfByte, AjaxStatus paramAjaxStatus);
}
