package com.androidquery.callback;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.view.View;
import android.widget.ImageView;
import com.androidquery.auth.AccountHandle;
import com.androidquery.util.AQUtility;
import com.androidquery.util.BitmapCache;
import com.androidquery.util.Common;
import com.androidquery.util.Constants;
import com.androidquery.util.RatioDrawable;
import java.io.File;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import org.apache.http.HttpHost;

public class BitmapAjaxCallback
  extends AbstractAjaxCallback<Bitmap, BitmapAjaxCallback>
{
  private static int BIG_MAX = 0;
  private static int BIG_PIXELS = 0;
  private static int BIG_TPIXELS = 0;
  private static boolean DELAY_WRITE = false;
  private static final int FADE_DUR = 300;
  private static int SMALL_MAX = 20;
  private static int SMALL_PIXELS;
  private static Map<String, Bitmap> bigCache;
  private static Bitmap dummy = Bitmap.createBitmap(1, 1, Bitmap.Config.ALPHA_8);
  private static Bitmap empty;
  private static Map<String, Bitmap> invalidCache;
  private static HashMap<String, WeakHashMap<ImageView, BitmapAjaxCallback>> queueMap;
  private static Map<String, Bitmap> smallCache;
  private float anchor = Float.MAX_VALUE;
  private int animation;
  private Bitmap bm;
  private int fallback;
  private File imageFile;
  private boolean invalid;
  private Bitmap preset;
  private float ratio;
  private boolean rotate;
  private int round;
  private boolean targetDim = true;
  private int targetWidth;
  private WeakReference<ImageView> v;
  
  static
  {
    BIG_MAX = 20;
    SMALL_PIXELS = 2500;
    BIG_PIXELS = 160000;
    BIG_TPIXELS = 1000000;
    DELAY_WRITE = false;
    queueMap = new HashMap();
    empty = Bitmap.createBitmap(1, 1, Bitmap.Config.ALPHA_8);
  }
  
  public BitmapAjaxCallback()
  {
    ((BitmapAjaxCallback)((BitmapAjaxCallback)((BitmapAjaxCallback)type(Bitmap.class)).memCache(true)).fileCache(true)).url("");
  }
  
  private void addQueue(String paramString, ImageView paramImageView)
  {
    WeakHashMap localWeakHashMap = (WeakHashMap)queueMap.get(paramString);
    if (localWeakHashMap == null)
    {
      if (queueMap.containsKey(paramString))
      {
        localWeakHashMap = new WeakHashMap();
        localWeakHashMap.put(paramImageView, this);
        queueMap.put(paramString, localWeakHashMap);
        return;
      }
      queueMap.put(paramString, null);
      return;
    }
    localWeakHashMap.put(paramImageView, this);
  }
  
  public static void async(Activity paramActivity, Context paramContext, ImageView paramImageView, String paramString1, Object paramObject, AccountHandle paramAccountHandle, ImageOptions paramImageOptions, HttpHost paramHttpHost, String paramString2)
  {
    async(paramActivity, paramContext, paramImageView, paramString1, memCache, fileCache, targetWidth, fallback, preset, animation, ratio, anchor, paramObject, paramAccountHandle, policy, round, paramHttpHost, paramString2);
  }
  
  public static void async(Activity paramActivity, Context paramContext, ImageView paramImageView, String paramString1, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2, Bitmap paramBitmap, int paramInt3, float paramFloat1, float paramFloat2, Object paramObject, AccountHandle paramAccountHandle, int paramInt4, int paramInt5, HttpHost paramHttpHost, String paramString2)
  {
    Object localObject = null;
    if (paramBoolean1) {
      localObject = memGet(paramString1, paramInt1, paramInt5);
    }
    if (localObject != null)
    {
      paramImageView.setTag(1090453505, paramString1);
      Common.showProgress(paramObject, paramString1, false);
      setBmAnimate(paramImageView, (Bitmap)localObject, paramBitmap, paramInt2, paramInt3, paramFloat1, paramFloat2, 4);
      return;
    }
    localObject = new BitmapAjaxCallback();
    ((BitmapAjaxCallback)((BitmapAjaxCallback)((BitmapAjaxCallback)((BitmapAjaxCallback)((BitmapAjaxCallback)((BitmapAjaxCallback)((AbstractAjaxCallback)localObject).url(paramString1)).imageView(paramImageView).memCache(paramBoolean1)).fileCache(paramBoolean2)).targetWidth(paramInt1).fallback(paramInt2).preset(paramBitmap).animation(paramInt3).ratio(paramFloat1).anchor(paramFloat2).progress(paramObject)).auth(paramAccountHandle)).policy(paramInt4)).round(paramInt5).networkUrl(paramString2);
    if (paramHttpHost != null) {
      ((AbstractAjaxCallback)localObject).proxy(paramHttpHost.getHostName(), paramHttpHost.getPort());
    }
    if (paramActivity != null)
    {
      ((AbstractAjaxCallback)localObject).async(paramActivity);
      return;
    }
    ((BitmapAjaxCallback)localObject).async(paramContext);
  }
  
  private Bitmap bmGet(String paramString, byte[] paramArrayOfByte)
  {
    return getResizedImage(paramString, paramArrayOfByte, targetWidth, targetDim, round, rotate);
  }
  
  private void checkCb(BitmapAjaxCallback paramBitmapAjaxCallback, String paramString, ImageView paramImageView, Bitmap paramBitmap, AjaxStatus paramAjaxStatus)
  {
    if (paramImageView != null)
    {
      if (paramBitmapAjaxCallback == null) {
        return;
      }
      if (paramString.equals(paramImageView.getTag(1090453505)))
      {
        if (!(paramImageView instanceof ImageView)) {
          break label45;
        }
        paramBitmapAjaxCallback.callback(paramString, paramImageView, paramBitmap, paramAjaxStatus);
      }
      for (;;)
      {
        paramBitmapAjaxCallback.showProgress(false);
        return;
        label45:
        paramBitmapAjaxCallback.setBitmap(paramString, paramImageView, paramBitmap, false);
      }
    }
  }
  
  public static void clearCache()
  {
    bigCache = null;
    smallCache = null;
    invalidCache = null;
  }
  
  protected static void clearTasks()
  {
    queueMap.clear();
  }
  
  private static Bitmap decode(String paramString, byte[] paramArrayOfByte, BitmapFactory.Options paramOptions, boolean paramBoolean)
  {
    Bitmap localBitmap = null;
    if (paramString != null) {
      localBitmap = decodeFile(paramString, paramOptions, paramBoolean);
    }
    while ((localBitmap == null) && (paramOptions != null) && (!inJustDecodeBounds))
    {
      AQUtility.debug("decode image failed", paramString);
      return localBitmap;
      if (paramArrayOfByte != null) {
        localBitmap = BitmapFactory.decodeByteArray(paramArrayOfByte, 0, paramArrayOfByte.length, paramOptions);
      }
    }
    return localBitmap;
  }
  
  /* Error */
  private static Bitmap decodeFile(String paramString, BitmapFactory.Options paramOptions, boolean paramBoolean)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 7
    //   3: aconst_null
    //   4: astore 5
    //   6: aload_1
    //   7: astore 4
    //   9: aload_1
    //   10: ifnonnull +12 -> 22
    //   13: new 280	android/graphics/BitmapFactory$Options
    //   16: dup
    //   17: invokespecial 302	android/graphics/BitmapFactory$Options:<init>	()V
    //   20: astore 4
    //   22: aload 4
    //   24: invokestatic 306	com/androidquery/callback/BitmapAjaxCallback:isInputSharable	()Z
    //   27: putfield 309	android/graphics/BitmapFactory$Options:inInputShareable	Z
    //   30: aload 4
    //   32: iconst_1
    //   33: putfield 312	android/graphics/BitmapFactory$Options:inPurgeable	Z
    //   36: aconst_null
    //   37: astore_1
    //   38: aconst_null
    //   39: astore 6
    //   41: new 314	java/io/FileInputStream
    //   44: dup
    //   45: aload_0
    //   46: invokespecial 317	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
    //   49: astore_3
    //   50: aload 7
    //   52: astore_1
    //   53: aload_3
    //   54: invokevirtual 321	java/io/FileInputStream:getFD	()Ljava/io/FileDescriptor;
    //   57: aconst_null
    //   58: aload 4
    //   60: invokestatic 325	android/graphics/BitmapFactory:decodeFileDescriptor	(Ljava/io/FileDescriptor;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    //   63: astore 5
    //   65: aload 5
    //   67: astore_1
    //   68: aload_1
    //   69: astore 4
    //   71: aload 5
    //   73: ifnull +18 -> 91
    //   76: aload_1
    //   77: astore 4
    //   79: iload_2
    //   80: ifeq +11 -> 91
    //   83: aload_0
    //   84: aload 5
    //   86: invokestatic 328	com/androidquery/callback/BitmapAjaxCallback:rotate	(Ljava/lang/String;Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    //   89: astore 4
    //   91: aload_3
    //   92: invokestatic 332	com/androidquery/util/AQUtility:close	(Ljava/io/Closeable;)V
    //   95: aload 4
    //   97: areturn
    //   98: astore 4
    //   100: aload 6
    //   102: astore_0
    //   103: aload 5
    //   105: astore_3
    //   106: aload_0
    //   107: astore_1
    //   108: aload 4
    //   110: invokestatic 336	com/androidquery/util/AQUtility:report	(Ljava/lang/Throwable;)V
    //   113: aload_0
    //   114: invokestatic 332	com/androidquery/util/AQUtility:close	(Ljava/io/Closeable;)V
    //   117: aload_3
    //   118: areturn
    //   119: astore_0
    //   120: aload_1
    //   121: invokestatic 332	com/androidquery/util/AQUtility:close	(Ljava/io/Closeable;)V
    //   124: aload_0
    //   125: athrow
    //   126: astore_0
    //   127: aload_3
    //   128: astore_1
    //   129: goto -9 -> 120
    //   132: astore 4
    //   134: aload_3
    //   135: astore_0
    //   136: aload_1
    //   137: astore_3
    //   138: goto -32 -> 106
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	141	0	paramString	String
    //   0	141	1	paramOptions	BitmapFactory.Options
    //   0	141	2	paramBoolean	boolean
    //   49	89	3	localObject1	Object
    //   7	89	4	localObject2	Object
    //   98	11	4	localIOException1	java.io.IOException
    //   132	1	4	localIOException2	java.io.IOException
    //   4	100	5	localBitmap	Bitmap
    //   39	62	6	localObject3	Object
    //   1	50	7	localObject4	Object
    // Exception table:
    //   from	to	target	type
    //   41	50	98	java/io/IOException
    //   41	50	119	java/lang/Throwable
    //   108	113	119	java/lang/Throwable
    //   53	65	126	java/lang/Throwable
    //   83	91	126	java/lang/Throwable
    //   53	65	132	java/io/IOException
    //   83	91	132	java/io/IOException
  }
  
  private static boolean fadeIn(int paramInt1, int paramInt2)
  {
    boolean bool = true;
    switch (paramInt1)
    {
    default: 
      break;
    }
    do
    {
      bool = false;
      return bool;
    } while ((paramInt2 != 3) && (paramInt2 != 1));
    return true;
  }
  
  private static Bitmap filter(View paramView, Bitmap paramBitmap, int paramInt)
  {
    Bitmap localBitmap = paramBitmap;
    if (paramBitmap != null)
    {
      localBitmap = paramBitmap;
      if (paramBitmap.getWidth() == 1)
      {
        localBitmap = paramBitmap;
        if (paramBitmap.getHeight() == 1)
        {
          localBitmap = paramBitmap;
          if (paramBitmap != empty) {
            localBitmap = null;
          }
        }
      }
    }
    if (localBitmap != null)
    {
      paramView.setVisibility(0);
      return localBitmap;
    }
    if (paramInt == -2)
    {
      paramView.setVisibility(8);
      return localBitmap;
    }
    if (paramInt == -1) {
      paramView.setVisibility(4);
    }
    return localBitmap;
  }
  
  private static Map getBCache()
  {
    if (bigCache == null) {
      bigCache = Collections.synchronizedMap(new BitmapCache(BIG_MAX, BIG_PIXELS, BIG_TPIXELS));
    }
    return bigCache;
  }
  
  public static Bitmap getEmptyBitmap()
  {
    return empty;
  }
  
  private Bitmap getFallback()
  {
    View localView = (View)v.get();
    Bitmap localBitmap1;
    if (localView != null)
    {
      String str = Integer.toString(fallback);
      Bitmap localBitmap2 = memGet(str);
      localBitmap1 = localBitmap2;
      if (localBitmap2 == null)
      {
        localBitmap2 = BitmapFactory.decodeResource(localView.getResources(), fallback);
        localBitmap1 = localBitmap2;
        if (localBitmap2 != null)
        {
          memPut(str, localBitmap2);
          return localBitmap2;
        }
      }
    }
    else
    {
      return null;
    }
    return localBitmap1;
  }
  
  private static Map getICache()
  {
    if (invalidCache == null) {
      invalidCache = Collections.synchronizedMap(new BitmapCache(100, BIG_PIXELS, 250000));
    }
    return invalidCache;
  }
  
  private static String getKey(String paramString, int paramInt1, int paramInt2)
  {
    String str = paramString;
    if (paramInt1 > 0) {
      str = paramString + "#" + paramInt1;
    }
    paramString = str;
    if (paramInt2 > 0) {
      paramString = str + "#" + paramInt2;
    }
    return paramString;
  }
  
  public static Bitmap getMemoryCached(Context paramContext, int paramInt)
  {
    String str = Integer.toString(paramInt);
    Bitmap localBitmap = memGet(str, 0, 0);
    Object localObject = localBitmap;
    if (localBitmap == null)
    {
      paramContext = BitmapFactory.decodeResource(paramContext.getResources(), paramInt);
      localObject = paramContext;
      if (paramContext != null)
      {
        memPut(str, 0, 0, paramContext, false);
        localObject = paramContext;
      }
    }
    return localObject;
  }
  
  public static Bitmap getMemoryCached(String paramString, int paramInt)
  {
    return memGet(paramString, paramInt, 0);
  }
  
  public static Bitmap getResizedImage(String paramString, byte[] paramArrayOfByte, int paramInt1, boolean paramBoolean, int paramInt2)
  {
    return getResizedImage(paramString, paramArrayOfByte, paramInt1, paramBoolean, paramInt2, false);
  }
  
  public static Bitmap getResizedImage(String paramString, byte[] paramArrayOfByte, int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2)
  {
    if ((paramString == null) && (paramArrayOfByte == null)) {
      return null;
    }
    BitmapFactory.Options localOptions = null;
    if (paramInt1 > 0)
    {
      localOptions = new BitmapFactory.Options();
      inJustDecodeBounds = true;
      decode(paramString, paramArrayOfByte, localOptions, paramBoolean2);
      int j = outWidth;
      int i = j;
      if (!paramBoolean1) {
        i = Math.max(j, outHeight);
      }
      paramInt1 = sampleSize(i, paramInt1);
      localOptions = new BitmapFactory.Options();
      inSampleSize = paramInt1;
    }
    Object localObject = null;
    try
    {
      paramString = decode(paramString, paramArrayOfByte, localOptions, paramBoolean2);
      if (paramInt2 > 0) {
        return getRoundedCornerBitmap(paramString, paramInt2);
      }
    }
    catch (OutOfMemoryError paramString)
    {
      for (;;)
      {
        clearCache();
        AQUtility.report(paramString);
        paramString = localObject;
      }
    }
    return paramString;
  }
  
  private static Matrix getRotateMatrix(int paramInt)
  {
    Matrix localMatrix = new Matrix();
    switch (paramInt)
    {
    default: 
      return localMatrix;
    case 2: 
      localMatrix.setScale(-1.0F, 1.0F);
      return localMatrix;
    case 3: 
      localMatrix.setRotate(180.0F);
      return localMatrix;
    case 4: 
      localMatrix.setRotate(180.0F);
      localMatrix.postScale(-1.0F, 1.0F);
      return localMatrix;
    case 5: 
      localMatrix.setRotate(90.0F);
      localMatrix.postScale(-1.0F, 1.0F);
      return localMatrix;
    case 6: 
      localMatrix.setRotate(90.0F);
      return localMatrix;
    case 7: 
      localMatrix.setRotate(-90.0F);
      localMatrix.postScale(-1.0F, 1.0F);
      return localMatrix;
    }
    localMatrix.setRotate(-90.0F);
    return localMatrix;
  }
  
  private static Bitmap getRoundedCornerBitmap(Bitmap paramBitmap, int paramInt)
  {
    Bitmap localBitmap = Bitmap.createBitmap(paramBitmap.getWidth(), paramBitmap.getHeight(), Bitmap.Config.ARGB_8888);
    Canvas localCanvas = new Canvas(localBitmap);
    Paint localPaint = new Paint();
    Rect localRect = new Rect(0, 0, paramBitmap.getWidth(), paramBitmap.getHeight());
    RectF localRectF = new RectF(localRect);
    float f = paramInt;
    localPaint.setAntiAlias(true);
    localCanvas.drawARGB(0, 0, 0, 0);
    localPaint.setColor(-12434878);
    localCanvas.drawRoundRect(localRectF, f, f, localPaint);
    localPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
    localCanvas.drawBitmap(paramBitmap, localRect, localRect, localPaint);
    return localBitmap;
  }
  
  private static Map getSCache()
  {
    if (smallCache == null) {
      smallCache = Collections.synchronizedMap(new BitmapCache(SMALL_MAX, SMALL_PIXELS, 250000));
    }
    return smallCache;
  }
  
  private static boolean isInputSharable()
  {
    AQUtility.debug("level", Integer.valueOf(Constants.SDK_INT));
    return Constants.SDK_INT < 19;
  }
  
  public static boolean isMemoryCached(String paramString)
  {
    return (getBCache().containsKey(paramString)) || (getSCache().containsKey(paramString)) || (getICache().containsKey(paramString));
  }
  
  private static Drawable makeDrawable(ImageView paramImageView, Bitmap paramBitmap, float paramFloat1, float paramFloat2)
  {
    if (paramFloat1 > 0.0F) {
      return new RatioDrawable(paramImageView.getResources(), paramBitmap, paramImageView, paramFloat1, paramFloat2);
    }
    return new BitmapDrawable(paramImageView.getResources(), paramBitmap);
  }
  
  private static Bitmap memGet(String paramString, int paramInt1, int paramInt2)
  {
    String str = getKey(paramString, paramInt1, paramInt2);
    Object localObject = (Bitmap)getBCache().get(str);
    paramString = (String)localObject;
    if (localObject == null) {
      paramString = (Bitmap)getSCache().get(str);
    }
    localObject = paramString;
    if (paramString == null)
    {
      paramString = (Bitmap)getICache().get(str);
      localObject = paramString;
      if (paramString != null)
      {
        localObject = paramString;
        if (AbstractAjaxCallback.getLastStatus() == 200)
        {
          invalidCache = null;
          return null;
        }
      }
    }
    return localObject;
  }
  
  private static void memPut(String paramString, int paramInt1, int paramInt2, Bitmap paramBitmap, boolean paramBoolean)
  {
    if (paramBitmap == null) {
      return;
    }
    int i = paramBitmap.getWidth();
    int j = paramBitmap.getHeight();
    Map localMap;
    if (paramBoolean) {
      localMap = getICache();
    }
    while ((paramInt1 > 0) || (paramInt2 > 0))
    {
      localMap.put(getKey(paramString, paramInt1, paramInt2), paramBitmap);
      if (localMap.containsKey(paramString)) {
        return;
      }
      localMap.put(paramString, null);
      return;
      if (i * j <= SMALL_PIXELS) {
        localMap = getSCache();
      } else {
        localMap = getBCache();
      }
    }
    localMap.put(paramString, paramBitmap);
  }
  
  private void presetBitmap(String paramString, ImageView paramImageView)
  {
    if ((!paramString.equals(paramImageView.getTag(1090453505))) || (preset != null))
    {
      paramImageView.setTag(1090453505, paramString);
      if ((preset != null) && (!cacheAvailable(paramImageView.getContext())))
      {
        setBitmap(paramString, paramImageView, preset, true);
        return;
      }
      setBitmap(paramString, paramImageView, null, true);
    }
  }
  
  private static Bitmap rotate(String paramString, Bitmap paramBitmap)
  {
    if (paramBitmap == null) {
      return null;
    }
    int i = 1;
    try
    {
      int j = new ExifInterface(paramString).getAttributeInt("Orientation", 1);
      i = j;
    }
    catch (Exception paramString)
    {
      for (;;)
      {
        AQUtility.debug(paramString);
      }
    }
    if (i > 0)
    {
      paramString = getRotateMatrix(i);
      paramString = Bitmap.createBitmap(paramBitmap, 0, 0, paramBitmap.getWidth(), paramBitmap.getHeight(), paramString, true);
      AQUtility.debug("before", paramBitmap.getWidth() + ":" + paramBitmap.getHeight());
      AQUtility.debug("after", paramString.getWidth() + ":" + paramString.getHeight());
      if (paramBitmap != paramString)
      {
        paramBitmap.recycle();
        return paramString;
      }
    }
    else
    {
      return paramBitmap;
    }
    return paramString;
  }
  
  private static int sampleSize(int paramInt1, int paramInt2)
  {
    int i = 1;
    int k = 0;
    int j = paramInt1;
    paramInt1 = k;
    for (;;)
    {
      if (paramInt1 >= 10) {
        return i;
      }
      if (j < paramInt2 * 2) {
        break;
      }
      j /= 2;
      i *= 2;
      paramInt1 += 1;
    }
    return i;
  }
  
  private void setBitmap(String paramString, ImageView paramImageView, Bitmap paramBitmap, boolean paramBoolean)
  {
    if (paramBitmap == null)
    {
      paramImageView.setImageDrawable(null);
      return;
    }
    if (paramBoolean)
    {
      paramImageView.setImageDrawable(makeDrawable(paramImageView, paramBitmap, ratio, anchor));
      return;
    }
    if (status != null) {
      setBmAnimate(paramImageView, paramBitmap, preset, fallback, animation, ratio, anchor, status.getSource());
    }
  }
  
  private static void setBmAnimate(ImageView paramImageView, Bitmap paramBitmap1, Bitmap paramBitmap2, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, int paramInt3)
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a13 = a12\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
  }
  
  public static void setCacheLimit(int paramInt)
  {
    BIG_MAX = paramInt;
    clearCache();
  }
  
  public static void setDelayWrite(boolean paramBoolean)
  {
    DELAY_WRITE = paramBoolean;
  }
  
  public static void setIconCacheLimit(int paramInt)
  {
    SMALL_MAX = paramInt;
    clearCache();
  }
  
  public static void setMaxPixelLimit(int paramInt)
  {
    BIG_TPIXELS = paramInt;
    clearCache();
  }
  
  public static void setPixelLimit(int paramInt)
  {
    BIG_PIXELS = paramInt;
    clearCache();
  }
  
  public static void setSmallPixel(int paramInt)
  {
    SMALL_PIXELS = paramInt;
    clearCache();
  }
  
  protected File accessFile(File paramFile, String paramString)
  {
    if ((imageFile != null) && (imageFile.exists())) {
      return imageFile;
    }
    return super.accessFile(paramFile, paramString);
  }
  
  public BitmapAjaxCallback anchor(float paramFloat)
  {
    anchor = paramFloat;
    return this;
  }
  
  public BitmapAjaxCallback animation(int paramInt)
  {
    animation = paramInt;
    return this;
  }
  
  public void async(Context paramContext)
  {
    paramContext = getUrl();
    ImageView localImageView = (ImageView)v.get();
    if (paramContext == null)
    {
      showProgress(false);
      setBitmap(paramContext, localImageView, null, false);
      return;
    }
    Bitmap localBitmap = memGet(paramContext);
    if (localBitmap != null)
    {
      localImageView.setTag(1090453505, paramContext);
      status = new AjaxStatus().source(4).done();
      callback(paramContext, localBitmap, status);
      return;
    }
    presetBitmap(paramContext, localImageView);
    if (!queueMap.containsKey(paramContext))
    {
      addQueue(paramContext, localImageView);
      super.async(localImageView.getContext());
      return;
    }
    showProgress(true);
    addQueue(paramContext, localImageView);
  }
  
  public BitmapAjaxCallback bitmap(Bitmap paramBitmap)
  {
    bm = paramBitmap;
    return this;
  }
  
  public final void callback(String paramString, Bitmap paramBitmap, AjaxStatus paramAjaxStatus)
  {
    Object localObject = (ImageView)v.get();
    WeakHashMap localWeakHashMap = (WeakHashMap)queueMap.remove(paramString);
    if ((localWeakHashMap == null) || (!localWeakHashMap.containsKey(localObject))) {
      checkCb(this, paramString, (ImageView)localObject, paramBitmap, paramAjaxStatus);
    }
    if (localWeakHashMap != null)
    {
      localObject = localWeakHashMap.keySet().iterator();
      for (;;)
      {
        if (!((Iterator)localObject).hasNext()) {
          return;
        }
        ImageView localImageView = (ImageView)((Iterator)localObject).next();
        BitmapAjaxCallback localBitmapAjaxCallback = (BitmapAjaxCallback)localWeakHashMap.get(localImageView);
        status = paramAjaxStatus;
        checkCb(localBitmapAjaxCallback, paramString, localImageView, paramBitmap, paramAjaxStatus);
      }
    }
  }
  
  protected void callback(String paramString, ImageView paramImageView, Bitmap paramBitmap, AjaxStatus paramAjaxStatus)
  {
    setBitmap(paramString, paramImageView, paramBitmap, false);
  }
  
  public BitmapAjaxCallback fallback(int paramInt)
  {
    fallback = paramInt;
    return this;
  }
  
  public BitmapAjaxCallback file(File paramFile)
  {
    imageFile = paramFile;
    return this;
  }
  
  protected Bitmap fileGet(String paramString, File paramFile, AjaxStatus paramAjaxStatus)
  {
    return bmGet(paramFile.getAbsolutePath(), null);
  }
  
  public BitmapAjaxCallback imageView(ImageView paramImageView)
  {
    v = new WeakReference(paramImageView);
    return this;
  }
  
  protected boolean isStreamingContent()
  {
    return !DELAY_WRITE;
  }
  
  protected Bitmap memGet(String paramString)
  {
    if (bm != null) {
      return bm;
    }
    if (!memCache) {
      return null;
    }
    return memGet(paramString, targetWidth, round);
  }
  
  protected void memPut(String paramString, Bitmap paramBitmap)
  {
    memPut(paramString, targetWidth, round, paramBitmap, invalid);
  }
  
  public BitmapAjaxCallback preset(Bitmap paramBitmap)
  {
    preset = paramBitmap;
    return this;
  }
  
  public BitmapAjaxCallback ratio(float paramFloat)
  {
    ratio = paramFloat;
    return this;
  }
  
  public BitmapAjaxCallback rotate(boolean paramBoolean)
  {
    rotate = paramBoolean;
    return this;
  }
  
  public BitmapAjaxCallback round(int paramInt)
  {
    round = paramInt;
    return this;
  }
  
  protected void skip(String paramString, Bitmap paramBitmap, AjaxStatus paramAjaxStatus)
  {
    queueMap.remove(paramString);
  }
  
  public BitmapAjaxCallback targetWidth(int paramInt)
  {
    targetWidth = paramInt;
    return this;
  }
  
  public Bitmap transform(String paramString, byte[] paramArrayOfByte, AjaxStatus paramAjaxStatus)
  {
    paramString = null;
    File localFile = paramAjaxStatus.getFile();
    if (localFile != null) {
      paramString = localFile.getAbsolutePath();
    }
    paramArrayOfByte = bmGet(paramString, paramArrayOfByte);
    paramString = paramArrayOfByte;
    if (paramArrayOfByte == null)
    {
      if (fallback > 0) {
        paramString = getFallback();
      }
      for (;;)
      {
        if (paramAjaxStatus.getCode() != 200) {
          invalid = true;
        }
        if ((paramAjaxStatus.getSource() != 1) || (localFile == null)) {
          break;
        }
        AQUtility.debug("invalid bm from net");
        localFile.delete();
        return paramString;
        if ((fallback == -2) || (fallback == -1)) {
          paramString = dummy;
        } else if (fallback == -3) {
          paramString = preset;
        }
      }
    }
    return paramArrayOfByte;
    return paramString;
  }
}
