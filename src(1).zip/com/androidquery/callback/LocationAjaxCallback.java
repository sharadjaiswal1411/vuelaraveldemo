package com.androidquery.callback;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import com.androidquery.util.AQUtility;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class LocationAjaxCallback
  extends AbstractAjaxCallback<Location, LocationAjaxCallback>
{
  private float accuracy = 1000.0F;
  private int ascii = 0;
  private boolean gpsEnabled = false;
  private Listener gpsListener;
  private long initTime;
  private long interval = 1000L;
  private int iteration = 3;
  private LocationManager locationManager;
  private boolean networkEnabled = false;
  private Listener networkListener;
  private long timeout = 30000L;
  private float tolerance = 10.0F;
  
  public LocationAjaxCallback()
  {
    ((LocationAjaxCallback)type(Location.class)).url("device");
  }
  
  private void callback(Location paramLocation)
  {
    result = paramLocation;
    status(paramLocation, 200);
    callback();
  }
  
  private void check(Location paramLocation)
  {
    if ((paramLocation != null) && (isBetter(paramLocation)))
    {
      ascii += 1;
      int i;
      boolean bool2;
      boolean bool3;
      if (ascii >= iteration)
      {
        i = 1;
        bool2 = isAccurate(paramLocation);
        bool3 = isDiff(paramLocation);
        if ((!gpsEnabled) || ("gps".equals(paramLocation.getProvider()))) {
          break label139;
        }
      }
      label139:
      for (boolean bool1 = false;; bool1 = true)
      {
        AQUtility.debug(Integer.valueOf(ascii), Integer.valueOf(iteration));
        AQUtility.debug("acc", Boolean.valueOf(bool2));
        AQUtility.debug("best", Boolean.valueOf(bool1));
        if (!bool3) {
          return;
        }
        if (i == 0) {
          break label144;
        }
        if ((!bool2) || (!bool1)) {
          return;
        }
        stop();
        callback(paramLocation);
        return;
        i = 0;
        break;
      }
      label144:
      if ((bool2) && (bool1)) {
        stop();
      }
      callback(paramLocation);
    }
  }
  
  private static float distFrom(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    double d = Math.toRadians(paramDouble3 - paramDouble1);
    paramDouble2 = Math.toRadians(paramDouble4 - paramDouble2);
    paramDouble1 = Math.sin(d / 2.0D) * Math.sin(d / 2.0D) + Math.cos(Math.toRadians(paramDouble1)) * Math.cos(Math.toRadians(paramDouble3)) * Math.sin(paramDouble2 / 2.0D) * Math.sin(paramDouble2 / 2.0D);
    return (float)(3958.75D * (2.0D * Math.atan2(Math.sqrt(paramDouble1), Math.sqrt(1.0D - paramDouble1)))) * 1609.0F;
  }
  
  private void failure()
  {
    if ((gpsListener == null) && (networkListener == null)) {
      return;
    }
    AQUtility.debug("fail");
    result = null;
    status(null, -103);
    stop();
    callback();
  }
  
  private Location getBestLocation()
  {
    Location localLocation1 = locationManager.getLastKnownLocation("gps");
    Location localLocation2 = locationManager.getLastKnownLocation("network");
    if (localLocation2 == null) {
      return localLocation1;
    }
    if (localLocation1 == null) {
      return localLocation2;
    }
    if (localLocation1.getTime() <= localLocation2.getTime()) {
      return localLocation2;
    }
    return localLocation1;
  }
  
  private boolean isAccurate(Location paramLocation)
  {
    return paramLocation.getAccuracy() < accuracy;
  }
  
  private boolean isBetter(Location paramLocation)
  {
    if (result == null) {
      return true;
    }
    if ((((Location)result).getTime() > initTime) && (((Location)result).getProvider().equals("gps")) && (paramLocation.getProvider().equals("network")))
    {
      AQUtility.debug("inferior location");
      return false;
    }
    return true;
  }
  
  private boolean isDiff(Location paramLocation)
  {
    if (result == null) {
      return true;
    }
    if (distFrom(((Location)result).getLatitude(), ((Location)result).getLongitude(), paramLocation.getLatitude(), paramLocation.getLongitude()) < tolerance)
    {
      AQUtility.debug("duplicate location");
      return false;
    }
    return true;
  }
  
  private void status(Location paramLocation, int paramInt)
  {
    if (status == null) {
      status = new AjaxStatus();
    }
    if (paramLocation != null) {
      status.time(new Date(paramLocation.getTime()));
    }
    status.code(paramInt).done().source(5);
  }
  
  private void work()
  {
    Location localLocation = getBestLocation();
    Timer localTimer = new Timer(false);
    if (networkEnabled)
    {
      AQUtility.debug("register net");
      networkListener = new Listener(null);
      locationManager.requestLocationUpdates("network", interval, 0.0F, networkListener, Looper.getMainLooper());
      localTimer.schedule(networkListener, timeout);
    }
    if (gpsEnabled)
    {
      AQUtility.debug("register gps");
      gpsListener = new Listener(null);
      locationManager.requestLocationUpdates("gps", interval, 0.0F, gpsListener, Looper.getMainLooper());
      localTimer.schedule(gpsListener, timeout);
    }
    if ((iteration > 1) && (localLocation != null))
    {
      ascii += 1;
      callback(localLocation);
    }
    initTime = System.currentTimeMillis();
  }
  
  public LocationAjaxCallback accuracy(float paramFloat)
  {
    accuracy = paramFloat;
    return this;
  }
  
  public void async(Context paramContext)
  {
    locationManager = ((LocationManager)paramContext.getSystemService("location"));
    gpsEnabled = locationManager.isProviderEnabled("gps");
    networkEnabled = locationManager.isProviderEnabled("network");
    work();
  }
  
  public LocationAjaxCallback iteration(int paramInt)
  {
    iteration = paramInt;
    return this;
  }
  
  public void stop()
  {
    AQUtility.debug("stop");
    Listener localListener = gpsListener;
    if (localListener != null)
    {
      locationManager.removeUpdates(localListener);
      localListener.cancel();
    }
    localListener = networkListener;
    if (localListener != null)
    {
      locationManager.removeUpdates(localListener);
      localListener.cancel();
    }
    gpsListener = null;
    networkListener = null;
  }
  
  public LocationAjaxCallback timeout(long paramLong)
  {
    timeout = paramLong;
    return this;
  }
  
  public LocationAjaxCallback tolerance(float paramFloat)
  {
    tolerance = paramFloat;
    return this;
  }
  
  private class Listener
    extends TimerTask
    implements LocationListener
  {
    private Listener() {}
    
    public void onLocationChanged(Location paramLocation)
    {
      AQUtility.debug("changed", paramLocation);
      LocationAjaxCallback.this.check(paramLocation);
    }
    
    public void onProviderDisabled(String paramString)
    {
      AQUtility.debug("onProviderDisabled");
    }
    
    public void onProviderEnabled(String paramString)
    {
      AQUtility.debug("onProviderEnabled");
      LocationAjaxCallback.this.check(LocationAjaxCallback.access$1(LocationAjaxCallback.this));
      locationManager.removeUpdates(this);
    }
    
    public void onStatusChanged(String paramString, int paramInt, Bundle paramBundle)
    {
      AQUtility.debug("onStatusChanged");
    }
    
    public void run()
    {
      LocationAjaxCallback.this.failure();
    }
  }
}
