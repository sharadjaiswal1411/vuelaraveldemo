package com.androidquery.callback;

public class AjaxCallback<T>
  extends AbstractAjaxCallback<T, AjaxCallback<T>>
{
  public AjaxCallback() {}
}
