package com.androidquery.auth;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.androidquery.AQuery;
import com.androidquery.AbstractAQuery;
import com.androidquery.WebDialog;
import com.androidquery.callback.AbstractAjaxCallback;
import com.androidquery.callback.AjaxCallback;
import com.androidquery.callback.AjaxStatus;
import com.androidquery.util.AQUtility;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.json.JSONObject;

public class FacebookHandle
  extends AccountHandle
{
  private static final String CANCEL_URI = "fbconnect:cancel";
  public static final String FB_APP_SIGNATURE = "30820268308201d102044a9c4610300d06092a864886f70d0101040500307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e3020170d3039303833313231353231365a180f32303530303932353231353231365a307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e30819f300d06092a864886f70d010101050003818d0030818902818100c207d51df8eb8c97d93ba0c8c1002c928fab00dc1b42fca5e66e99cc3023ed2d214d822bc59e8e35ddcf5f44c7ae8ade50d7e0c434f500e6c131f4a2834f987fc46406115de2018ebbb0d5a3c261bd97581ccfef76afc7135a6d59e8855ecd7eacc8f8737e794c60a761c536b72b11fac8e603f5da1a2d54aa103b8a13c0dbc10203010001300d06092a864886f70d0101040500038181005ee9be8bcbb250648d3b741290a82a1c9dc2e76a0af2f2228f1d9f9c4007529c446a70175c5a900d5141812866db46be6559e2141616483998211f4a673149fb2232a10d247663b26a9031e15f84bc1c74d141ff98a02d76f85b2c8ab2571b6469b232d8e768a7f7ca04f7abe4a775615916c07940656b58717457b42bd928a2";
  private static final String FB_PERMISSION = "aq.fb.permission";
  private static final String FB_TOKEN = "aq.fb.token";
  private static final String OAUTH_ENDPOINT = "https://graph.facebook.com/oauth/authorize";
  private static final String REDIRECT_URI = "https://www.facebook.com/connect/login_success.html";
  private static Boolean hasSSO;
  private Activity activity;
  private String appId;
  private boolean data;
  private WebDialog dialog;
  private boolean first;
  private String message;
  private String permissions;
  private int requestId;
  private String token;
  
  public FacebookHandle(Activity paramActivity, String paramString1, String paramString2)
  {
    this(paramActivity, paramString1, paramString2, null);
  }
  
  public FacebookHandle(Activity paramActivity, String paramString1, String paramString2, String paramString3)
  {
    appId = paramString1;
    activity = paramActivity;
    permissions = paramString2;
    token = paramString3;
    if ((token == null) && (permissionOk(paramString2, fetchPermission()))) {
      token = fetchToken();
    }
    if (token == null) {}
    for (boolean bool = true;; bool = false)
    {
      first = bool;
      return;
    }
  }
  
  private static Bundle decodeUrl(String paramString)
  {
    Bundle localBundle = new Bundle();
    if (paramString != null)
    {
      paramString = paramString.split("&");
      int j = paramString.length;
      int i = 0;
      for (;;)
      {
        if (i >= j) {
          return localBundle;
        }
        String[] arrayOfString = paramString[i].split("=");
        localBundle.putString(arrayOfString[0], arrayOfString[1]);
        i += 1;
      }
    }
    return localBundle;
  }
  
  private void dismiss()
  {
    if (dialog != null)
    {
      new AQuery(activity).dismiss(dialog);
      dialog = null;
    }
  }
  
  private static String encodeUrl(Bundle paramBundle)
  {
    if (paramBundle == null) {
      return "";
    }
    StringBuilder localStringBuilder = new StringBuilder();
    int i = 1;
    Iterator localIterator = paramBundle.keySet().iterator();
    if (!localIterator.hasNext()) {
      return localStringBuilder.toString();
    }
    String str = (String)localIterator.next();
    if (i != 0) {
      i = 0;
    }
    for (;;)
    {
      localStringBuilder.append(str + "=" + paramBundle.getString(str));
      break;
      localStringBuilder.append("&");
    }
  }
  
  private boolean equals()
  {
    if (!data) {
      return false;
    }
    return startSingleSignOn(activity, appId, permissions, requestId);
  }
  
  private String extractToken(String paramString)
  {
    paramString = Uri.parse(paramString.replace('#', '?')).getQueryParameter("access_token");
    AQUtility.debug("token", paramString);
    return paramString;
  }
  
  private void failure()
  {
    failure("cancel");
  }
  
  private void failure(String paramString)
  {
    dismiss();
    failure(activity, -102, paramString);
  }
  
  private String fetchPermission()
  {
    return PreferenceManager.getDefaultSharedPreferences(activity).getString("aq.fb.permission", null);
  }
  
  private String fetchToken()
  {
    return PreferenceManager.getDefaultSharedPreferences(activity).getString("aq.fb.token", null);
  }
  
  public static String getToken(Context paramContext)
  {
    return PreferenceManager.getDefaultSharedPreferences(paramContext).getString("aq.fb.token", null);
  }
  
  private void hide()
  {
    if (dialog != null)
    {
      WebDialog localWebDialog = dialog;
      try
      {
        localWebDialog.hide();
        return;
      }
      catch (Exception localException)
      {
        AQUtility.debug(localException);
      }
    }
  }
  
  private static Bundle parseUrl(String paramString)
  {
    try
    {
      paramString = new URL(paramString);
      Bundle localBundle = decodeUrl(paramString.getQuery());
      localBundle.putAll(decodeUrl(paramString.getRef()));
      return localBundle;
    }
    catch (MalformedURLException paramString) {}
    return new Bundle();
  }
  
  private boolean permissionOk(String paramString1, String paramString2)
  {
    if (paramString1 == null) {
      return true;
    }
    if (paramString2 == null) {
      return false;
    }
    paramString2 = new HashSet(Arrays.asList(paramString2.split("[,\\s]+")));
    paramString1 = paramString1.split("[,\\s]+");
    int i = 0;
    while (i < paramString1.length)
    {
      if (!paramString2.contains(paramString1[i]))
      {
        AQUtility.debug("perm mismatch");
        return false;
      }
      i += 1;
    }
    return true;
  }
  
  private void show()
  {
    if (dialog != null) {
      new AQuery(activity).show(dialog);
    }
  }
  
  private boolean startSingleSignOn(Activity paramActivity, String paramString1, String paramString2, int paramInt)
  {
    Intent localIntent = new Intent();
    localIntent.setClassName("com.facebook.katana", "com.facebook.katana.ProxyAuth");
    localIntent.putExtra("client_id", paramString1);
    if (paramString2 != null) {
      localIntent.putExtra("scope", paramString2);
    }
    if (!validateAppSignatureForIntent(paramActivity, localIntent)) {
      return false;
    }
    try
    {
      paramActivity.startActivityForResult(localIntent, paramInt);
      return true;
    }
    catch (ActivityNotFoundException paramActivity) {}
    return false;
  }
  
  private void storeToken(String paramString1, String paramString2)
  {
    SharedPreferences.Editor localEditor = PreferenceManager.getDefaultSharedPreferences(activity).edit();
    localEditor.putString("aq.fb.token", paramString1).putString("aq.fb.permission", paramString2);
    AQUtility.apply(localEditor);
  }
  
  private boolean validateAppSignatureForIntent(Context paramContext, Intent paramIntent)
  {
    paramContext = paramContext.getPackageManager();
    paramIntent = paramContext.resolveActivity(paramIntent, 0);
    if (paramIntent == null) {
      return false;
    }
    paramIntent = activityInfo.packageName;
    for (;;)
    {
      int i;
      try
      {
        paramContext = paramContext.getPackageInfo(paramIntent, 64);
        paramContext = signatures;
        int j = paramContext.length;
        i = 0;
        if (i >= j) {
          break;
        }
        if (paramContext[i].toCharsString().equals("30820268308201d102044a9c4610300d06092a864886f70d0101040500307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e3020170d3039303833313231353231365a180f32303530303932353231353231365a307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e30819f300d06092a864886f70d010101050003818d0030818902818100c207d51df8eb8c97d93ba0c8c1002c928fab00dc1b42fca5e66e99cc3023ed2d214d822bc59e8e35ddcf5f44c7ae8ade50d7e0c434f500e6c131f4a2834f987fc46406115de2018ebbb0d5a3c261bd97581ccfef76afc7135a6d59e8855ecd7eacc8f8737e794c60a761c536b72b11fac8e603f5da1a2d54aa103b8a13c0dbc10203010001300d06092a864886f70d0101040500038181005ee9be8bcbb250648d3b741290a82a1c9dc2e76a0af2f2228f1d9f9c4007529c446a70175c5a900d5141812866db46be6559e2141616483998211f4a673149fb2232a10d247663b26a9031e15f84bc1c74d141ff98a02d76f85b2c8ab2571b6469b232d8e768a7f7ca04f7abe4a775615916c07940656b58717457b42bd928a2")) {
          return true;
        }
      }
      catch (PackageManager.NameNotFoundException paramContext)
      {
        return false;
      }
      i += 1;
    }
    return false;
  }
  
  private void webAuth()
  {
    AQUtility.debug("web auth");
    Object localObject = new Bundle();
    ((Bundle)localObject).putString("client_id", appId);
    ((Bundle)localObject).putString("type", "user_agent");
    if (permissions != null) {
      ((Bundle)localObject).putString("scope", permissions);
    }
    ((Bundle)localObject).putString("redirect_uri", "https://www.facebook.com/connect/login_success.html");
    localObject = "https://graph.facebook.com/oauth/authorize?" + encodeUrl((Bundle)localObject);
    FbWebViewClient localFbWebViewClient = new FbWebViewClient(null);
    dialog = new WebDialog(activity, (String)localObject, localFbWebViewClient);
    dialog.setLoadingMessage(message);
    dialog.setOnCancelListener(localFbWebViewClient);
    show();
    if ((!first) || (token != null))
    {
      AQUtility.debug("auth hide");
      hide();
    }
    dialog.load();
    AQUtility.debug("auth started");
  }
  
  public void ajaxProfile(AjaxCallback paramAjaxCallback)
  {
    ajaxProfile(paramAjaxCallback, 0L);
  }
  
  public void ajaxProfile(AjaxCallback paramAjaxCallback, long paramLong)
  {
    ((AQuery)new AQuery(activity).auth(this)).ajax("https://graph.facebook.com/me", JSONObject.class, paramLong, paramAjaxCallback);
  }
  
  protected void auth()
  {
    if (activity.isFinishing()) {
      return;
    }
    boolean bool = equals();
    AQUtility.debug("authing", Boolean.valueOf(bool));
    if (!bool) {
      webAuth();
    }
  }
  
  protected void authenticated(String paramString) {}
  
  public boolean authenticated()
  {
    return token != null;
  }
  
  public boolean expired(AbstractAjaxCallback paramAbstractAjaxCallback, AjaxStatus paramAjaxStatus)
  {
    int i = paramAjaxStatus.getCode();
    if (i == 200) {
      return false;
    }
    paramAjaxStatus = paramAjaxStatus.getError();
    if ((paramAjaxStatus != null) && (paramAjaxStatus.contains("OAuthException")))
    {
      AQUtility.debug("fb token expired");
      return true;
    }
    paramAbstractAjaxCallback = paramAbstractAjaxCallback.getUrl();
    return ((i != 400) || ((!paramAbstractAjaxCallback.endsWith("/likes")) && (!paramAbstractAjaxCallback.endsWith("/comments")) && (!paramAbstractAjaxCallback.endsWith("/checkins")))) && ((i != 403) || ((!paramAbstractAjaxCallback.endsWith("/feed")) && (!paramAbstractAjaxCallback.contains("method=delete")))) && ((i == 400) || (i == 401) || (i == 403));
  }
  
  public String getCacheUrl(String paramString)
  {
    return getNetworkUrl(paramString);
  }
  
  public String getNetworkUrl(String paramString)
  {
    if (paramString.indexOf('?') == -1) {}
    for (paramString = paramString + "?";; paramString = paramString + "&") {
      return paramString + "access_token=" + token;
    }
  }
  
  public String getToken()
  {
    return token;
  }
  
  public boolean isSSOAvailable()
  {
    if (hasSSO == null)
    {
      Intent localIntent = new Intent();
      localIntent.setClassName("com.facebook.katana", "com.facebook.katana.ProxyAuth");
      hasSSO = Boolean.valueOf(validateAppSignatureForIntent(activity, localIntent));
    }
    return hasSSO.booleanValue();
  }
  
  public FacebookHandle merge(int paramInt)
  {
    data = true;
    requestId = paramInt;
    return this;
  }
  
  public FacebookHandle message(String paramString)
  {
    message = paramString;
    return this;
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    AQUtility.debug("on result", Integer.valueOf(paramInt2));
    if (paramInt2 == -1)
    {
      String str2 = paramIntent.getStringExtra("error");
      String str1 = str2;
      if (str2 == null) {
        str1 = paramIntent.getStringExtra("error_type");
      }
      if (str1 != null)
      {
        AQUtility.debug("error", str1);
        if ((str1.equals("service_disabled")) || (str1.equals("AndroidAuthKillSwitchException")))
        {
          webAuth();
          return;
        }
        paramIntent = paramIntent.getStringExtra("error_description");
        AQUtility.debug("fb error", paramIntent);
        Log.e("fb error", paramIntent);
        failure(paramIntent);
        return;
      }
      token = paramIntent.getStringExtra("access_token");
      AQUtility.debug("onComplete", token);
      if (token != null)
      {
        storeToken(token, permissions);
        first = false;
        authenticated(token);
        success(activity);
        return;
      }
      failure();
      return;
    }
    if (paramInt2 == 0) {
      failure();
    }
  }
  
  public boolean reauth(final AbstractAjaxCallback paramAbstractAjaxCallback)
  {
    AQUtility.debug("reauth requested");
    token = null;
    AQUtility.post(new Runnable()
    {
      public void run()
      {
        auth(paramAbstractAjaxCallback);
      }
    });
    return false;
  }
  
  public FacebookHandle setLoadingMessage(int paramInt)
  {
    message = activity.getString(paramInt);
    return this;
  }
  
  public void unauth()
  {
    token = null;
    CookieSyncManager.createInstance(activity);
    CookieManager.getInstance().removeAllCookie();
    storeToken(null, null);
  }
  
  private class FbWebViewClient
    extends WebViewClient
    implements DialogInterface.OnCancelListener
  {
    private FbWebViewClient() {}
    
    private boolean checkDone(String paramString)
    {
      if (paramString.startsWith("https://www.facebook.com/connect/login_success.html"))
      {
        String str = FacebookHandle.parseUrl(paramString).getString("error_reason");
        AQUtility.debug("error", str);
        if (str == null) {
          token = FacebookHandle.this.extractToken(paramString);
        }
        if (token != null)
        {
          FacebookHandle.this.dismiss();
          FacebookHandle.this.storeToken(token, permissions);
          first = false;
          authenticated(token);
          success(activity);
          return true;
        }
        FacebookHandle.this.failure();
        return true;
      }
      if (paramString.startsWith("fbconnect:cancel"))
      {
        AQUtility.debug("cancelled");
        FacebookHandle.this.failure();
        return true;
      }
      return false;
    }
    
    public void onCancel(DialogInterface paramDialogInterface)
    {
      FacebookHandle.this.failure();
    }
    
    public void onPageFinished(WebView paramWebView, String paramString)
    {
      super.onPageFinished(paramWebView, paramString);
      FacebookHandle.this.show();
      AQUtility.debug("finished", paramString);
    }
    
    public void onPageStarted(WebView paramWebView, String paramString, Bitmap paramBitmap)
    {
      AQUtility.debug("started", paramString);
      if (!checkDone(paramString)) {
        super.onPageStarted(paramWebView, paramString, paramBitmap);
      }
    }
    
    public void onReceivedError(WebView paramWebView, int paramInt, String paramString1, String paramString2)
    {
      FacebookHandle.this.failure();
    }
    
    public boolean shouldOverrideUrlLoading(WebView paramWebView, String paramString)
    {
      AQUtility.debug("return url: " + paramString);
      return checkDone(paramString);
    }
  }
}
