package com.androidquery.auth;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.androidquery.AQuery;
import com.androidquery.AbstractAQuery;
import com.androidquery.WebDialog;
import com.androidquery.callback.AbstractAjaxCallback;
import com.androidquery.callback.AjaxStatus;
import com.androidquery.util.AQUtility;
import java.net.HttpURLConnection;
import oauth.signpost.OAuthConsumer;
import oauth.signpost.basic.DefaultOAuthConsumer;
import oauth.signpost.commonshttp.CommonsHttpOAuthConsumer;
import oauth.signpost.commonshttp.CommonsHttpOAuthProvider;
import org.apache.http.HttpRequest;

public class TwitterHandle
  extends AccountHandle
{
  private static final String CALLBACK_URI = "twitter://callback";
  private static final String CANCEL_URI = "twitter://cancel";
  private static final String OAUTH_ACCESS_TOKEN = "https://api.twitter.com/oauth/access_token";
  private static final String OAUTH_AUTHORIZE = "https://api.twitter.com/oauth/authorize";
  private static final String OAUTH_REQUEST_TOKEN = "https://api.twitter.com/oauth/request_token";
  private static final String TW_SECRET = "aq.tw.secret";
  private static final String TW_TOKEN = "aq.tw.token";
  private CommonsHttpOAuthConsumer consumer;
  private WebDialog dialog;
  private CommonsHttpOAuthProvider provider;
  private String secret;
  private Activity this$0;
  private String token;
  
  public TwitterHandle(Activity paramActivity, String paramString1, String paramString2)
  {
    this$0 = paramActivity;
    consumer = new CommonsHttpOAuthConsumer(paramString1, paramString2);
    token = fetchToken("aq.tw.token");
    secret = fetchToken("aq.tw.secret");
    if ((token != null) && (secret != null)) {
      consumer.setTokenWithSecret(token, secret);
    }
    provider = new CommonsHttpOAuthProvider("https://api.twitter.com/oauth/request_token", "https://api.twitter.com/oauth/access_token", "https://api.twitter.com/oauth/authorize");
  }
  
  private void dismiss()
  {
    if (dialog != null)
    {
      new AQuery(this$0).dismiss(dialog);
      dialog = null;
    }
  }
  
  private String extract(String paramString1, String paramString2)
  {
    return Uri.parse(paramString1).getQueryParameter(paramString2);
  }
  
  private void failure()
  {
    dismiss();
    failure(this$0, 401, "cancel");
  }
  
  private String fetchToken(String paramString)
  {
    return PreferenceManager.getDefaultSharedPreferences(this$0).getString(paramString, null);
  }
  
  private void show()
  {
    if (dialog != null) {
      new AQuery(this$0).show(dialog);
    }
  }
  
  private void storeToken(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    PreferenceManager.getDefaultSharedPreferences(this$0).edit().putString(paramString1, paramString2).putString(paramString3, paramString4).commit();
  }
  
  public void applyToken(AbstractAjaxCallback paramAbstractAjaxCallback, HttpURLConnection paramHttpURLConnection)
  {
    AQUtility.debug("apply token multipart", paramAbstractAjaxCallback.getUrl());
    paramAbstractAjaxCallback = new DefaultOAuthConsumer(consumer.getConsumerKey(), consumer.getConsumerSecret());
    paramAbstractAjaxCallback.setTokenWithSecret(consumer.getToken(), consumer.getTokenSecret());
    try
    {
      paramAbstractAjaxCallback.sign(paramHttpURLConnection);
      return;
    }
    catch (Exception paramAbstractAjaxCallback)
    {
      AQUtility.report(paramAbstractAjaxCallback);
    }
  }
  
  public void applyToken(AbstractAjaxCallback paramAbstractAjaxCallback, HttpRequest paramHttpRequest)
  {
    AQUtility.debug("apply token", paramAbstractAjaxCallback.getUrl());
    paramAbstractAjaxCallback = consumer;
    try
    {
      paramAbstractAjaxCallback.sign(paramHttpRequest);
      return;
    }
    catch (Exception paramAbstractAjaxCallback)
    {
      AQUtility.report(paramAbstractAjaxCallback);
    }
  }
  
  protected void auth()
  {
    new Task(null).execute(new String[0]);
  }
  
  public void authenticate(boolean paramBoolean)
  {
    if ((!paramBoolean) && (token != null) && (secret != null))
    {
      authenticated(secret, token);
      return;
    }
    auth();
  }
  
  protected void authenticated(String paramString1, String paramString2) {}
  
  public boolean authenticated()
  {
    return (token != null) && (secret != null);
  }
  
  public boolean expired(AbstractAjaxCallback paramAbstractAjaxCallback, AjaxStatus paramAjaxStatus)
  {
    int i = paramAjaxStatus.getCode();
    return (i == 400) || (i == 401);
  }
  
  public String getSecret()
  {
    return secret;
  }
  
  public String getToken()
  {
    return token;
  }
  
  public boolean reauth(AbstractAjaxCallback paramAbstractAjaxCallback)
  {
    token = null;
    secret = null;
    storeToken("aq.tw.token", null, "aq.tw.secret", null);
    Taskhost = paramAbstractAjaxCallback;
    AQUtility.post(paramAbstractAjaxCallback);
    return false;
  }
  
  public void unauth()
  {
    token = null;
    secret = null;
    CookieSyncManager.createInstance(this$0);
    CookieManager.getInstance().removeAllCookie();
    storeToken("aq.tw.token", null, "aq.tw.secret", null);
  }
  
  private class Task
    extends AsyncTask<String, String, String>
    implements DialogInterface.OnCancelListener, Runnable
  {
    private AbstractAjaxCallback<?, ?> host;
    
    private Task() {}
    
    protected String doInBackground(String... paramVarArgs)
    {
      paramVarArgs = TwitterHandle.this;
      try
      {
        paramVarArgs = provider;
        TwitterHandle localTwitterHandle = TwitterHandle.this;
        paramVarArgs = paramVarArgs.retrieveRequestToken(consumer, "twitter://callback");
        return paramVarArgs;
      }
      catch (Exception paramVarArgs)
      {
        AQUtility.report(paramVarArgs);
      }
      return null;
    }
    
    public void onCancel(DialogInterface paramDialogInterface)
    {
      TwitterHandle.this.failure();
    }
    
    protected void onPostExecute(String paramString)
    {
      if (paramString != null)
      {
        dialog = new WebDialog(this$0, paramString, new TwitterHandle.TwWebViewClient(TwitterHandle.this, null));
        dialog.setOnCancelListener(this);
        TwitterHandle.this.show();
        dialog.load();
        return;
      }
      TwitterHandle.this.failure();
    }
    
    public void run()
    {
      auth(host);
    }
  }
  
  private class Task2
    extends AsyncTask<String, String, String>
  {
    private Task2() {}
    
    protected String doInBackground(String... paramVarArgs)
    {
      Object localObject1 = TwitterHandle.this;
      try
      {
        localObject1 = provider;
        Object localObject2 = TwitterHandle.this;
        localObject2 = consumer;
        paramVarArgs = paramVarArgs[0];
        ((CommonsHttpOAuthProvider)localObject1).retrieveAccessToken((OAuthConsumer)localObject2, paramVarArgs);
        return "";
      }
      catch (Exception paramVarArgs)
      {
        AQUtility.report(paramVarArgs);
      }
      return null;
    }
    
    protected void onPostExecute(String paramString)
    {
      if (paramString != null)
      {
        token = consumer.getToken();
        secret = consumer.getTokenSecret();
        AQUtility.debug("token", token);
        AQUtility.debug("secret", secret);
        TwitterHandle.this.storeToken("aq.tw.token", token, "aq.tw.secret", secret);
        TwitterHandle.this.dismiss();
        success(this$0);
        authenticated(secret, token);
        return;
      }
      TwitterHandle.this.failure();
      authenticated(null, null);
    }
  }
  
  private class TwWebViewClient
    extends WebViewClient
  {
    private TwWebViewClient() {}
    
    private boolean checkDone(String paramString)
    {
      if (paramString.startsWith("twitter://callback"))
      {
        paramString = TwitterHandle.this.extract(paramString, "oauth_verifier");
        TwitterHandle.this.dismiss();
        new TwitterHandle.Task2(TwitterHandle.this, null).execute(new String[] { paramString });
        return true;
      }
      if (paramString.startsWith("twitter://cancel"))
      {
        TwitterHandle.this.failure();
        return true;
      }
      return false;
    }
    
    public void onPageFinished(WebView paramWebView, String paramString)
    {
      AQUtility.debug("finished", paramString);
      super.onPageFinished(paramWebView, paramString);
      TwitterHandle.this.show();
    }
    
    public void onPageStarted(WebView paramWebView, String paramString, Bitmap paramBitmap)
    {
      AQUtility.debug("started", paramString);
      if (!checkDone(paramString)) {
        super.onPageStarted(paramWebView, paramString, paramBitmap);
      }
    }
    
    public void onReceivedError(WebView paramWebView, int paramInt, String paramString1, String paramString2)
    {
      TwitterHandle.this.failure();
    }
    
    public boolean shouldOverrideUrlLoading(WebView paramWebView, String paramString)
    {
      return checkDone(paramString);
    }
  }
}
