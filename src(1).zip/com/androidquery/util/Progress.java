package com.androidquery.util;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.view.View;
import android.widget.ProgressBar;
import com.androidquery.AQuery;
import com.androidquery.AbstractAQuery;

public class Progress
  implements Runnable
{
  private Activity act;
  private int bytes;
  private int current;
  private ProgressBar pb;
  private ProgressDialog pd;
  private boolean unknown;
  private String url;
  private View view;
  
  public Progress(Object paramObject)
  {
    if ((paramObject instanceof ProgressBar))
    {
      pb = ((ProgressBar)paramObject);
      return;
    }
    if ((paramObject instanceof ProgressDialog))
    {
      pd = ((ProgressDialog)paramObject);
      return;
    }
    if ((paramObject instanceof Activity))
    {
      act = ((Activity)paramObject);
      return;
    }
    if ((paramObject instanceof View)) {
      view = ((View)paramObject);
    }
  }
  
  private void dismiss(String paramString)
  {
    if (pd != null) {
      new AQuery(pd.getContext()).dismiss(pd);
    }
    if (act != null)
    {
      act.setProgressBarIndeterminateVisibility(false);
      act.setProgressBarVisibility(false);
    }
    if (pb != null)
    {
      pb.setTag(1090453505, paramString);
      pb.setVisibility(0);
    }
    Object localObject2 = pb;
    Object localObject1 = localObject2;
    if (localObject2 == null) {
      localObject1 = view;
    }
    if (localObject1 != null)
    {
      localObject2 = ((View)localObject1).getTag(1090453505);
      if ((localObject2 == null) || (localObject2.equals(paramString)))
      {
        ((View)localObject1).setTag(1090453505, null);
        if ((pb != null) && (pb.isIndeterminate())) {
          ((View)localObject1).setVisibility(8);
        }
      }
    }
  }
  
  private void showProgress(Object paramObject, String paramString, boolean paramBoolean)
  {
    if (paramObject != null) {
      if ((paramObject instanceof View))
      {
        View localView = (View)paramObject;
        ProgressBar localProgressBar = null;
        if ((paramObject instanceof ProgressBar)) {
          localProgressBar = (ProgressBar)paramObject;
        }
        if (paramBoolean)
        {
          localView.setTag(1090453505, paramString);
          localView.setVisibility(0);
          if (localProgressBar != null)
          {
            localProgressBar.setProgress(0);
            localProgressBar.setMax(100);
          }
        }
        else
        {
          paramObject = localView.getTag(1090453505);
          if ((paramObject == null) || (paramObject.equals(paramString)))
          {
            localView.setTag(1090453505, null);
            if ((localProgressBar != null) && (localProgressBar.isIndeterminate())) {
              localView.setVisibility(8);
            }
          }
        }
      }
      else
      {
        if ((paramObject instanceof Dialog))
        {
          paramObject = (Dialog)paramObject;
          paramString = new AQuery(paramObject.getContext());
          if (paramBoolean)
          {
            paramString.show(paramObject);
            return;
          }
          paramString.dismiss(paramObject);
          return;
        }
        if ((paramObject instanceof Activity))
        {
          paramObject = (Activity)paramObject;
          paramObject.setProgressBarIndeterminateVisibility(paramBoolean);
          paramObject.setProgressBarVisibility(paramBoolean);
          if (paramBoolean) {
            paramObject.setProgress(0);
          }
        }
      }
    }
  }
  
  public void done()
  {
    if (pb != null) {
      pb.setProgress(pb.getMax());
    }
    if (pd != null) {
      pd.setProgress(pd.getMax());
    }
    if (act != null) {
      act.setProgress(9999);
    }
  }
  
  public void hide(String paramString)
  {
    if (AQUtility.isUIThread())
    {
      dismiss(paramString);
      return;
    }
    url = paramString;
    AQUtility.post(this);
  }
  
  public void increment(int paramInt)
  {
    int j = 1;
    Object localObject;
    int i;
    if (pb != null)
    {
      localObject = pb;
      if (unknown)
      {
        i = 1;
        ((ProgressBar)localObject).incrementProgressBy(i);
      }
    }
    else
    {
      if (pd != null)
      {
        localObject = pd;
        if (!unknown) {
          break label111;
        }
        i = j;
        label52:
        ((ProgressDialog)localObject).incrementProgressBy(i);
      }
      if (act == null) {
        return;
      }
      if (!unknown) {
        break label116;
      }
      paramInt = current;
      current = (paramInt + 1);
    }
    for (;;)
    {
      i = paramInt;
      if (paramInt > 9999) {
        i = 9999;
      }
      act.setProgress(i);
      return;
      i = paramInt;
      break;
      label111:
      i = paramInt;
      break label52;
      label116:
      current += paramInt;
      paramInt = current * 10000 / bytes;
    }
  }
  
  public void reset()
  {
    if (pb != null)
    {
      pb.setProgress(0);
      pb.setMax(10000);
    }
    if (pd != null)
    {
      pd.setProgress(0);
      pd.setMax(10000);
    }
    if (act != null) {
      act.setProgress(0);
    }
    unknown = false;
    current = 0;
    bytes = 10000;
  }
  
  public void run()
  {
    dismiss(url);
  }
  
  public void setBytes(int paramInt)
  {
    int i = paramInt;
    if (paramInt <= 0)
    {
      unknown = true;
      i = 10000;
    }
    bytes = i;
    if (pb != null)
    {
      pb.setProgress(0);
      pb.setMax(i);
    }
    if (pd != null)
    {
      pd.setProgress(0);
      pd.setMax(i);
    }
  }
  
  public void show(String paramString)
  {
    reset();
    if (pd != null) {
      new AQuery(pd.getContext()).show(pd);
    }
    if (act != null)
    {
      act.setProgressBarIndeterminateVisibility(true);
      act.setProgressBarVisibility(true);
    }
    if (pb != null)
    {
      pb.setTag(1090453505, paramString);
      pb.setVisibility(0);
    }
    if (view != null)
    {
      view.setTag(1090453505, paramString);
      view.setVisibility(0);
    }
  }
}
