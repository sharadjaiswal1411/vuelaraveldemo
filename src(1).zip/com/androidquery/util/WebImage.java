package com.androidquery.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Picture;
import android.os.Build.VERSION;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebView.PictureListener;
import android.webkit.WebViewClient;

public class WebImage
  extends WebViewClient
{
  private static final String DOUBLE_TAP_TOAST_COUNT = "double_tap_toast_count";
  private static final String PREF_FILE = "WebViewSettings";
  private static String template;
  private int color;
  private boolean control;
  private Object progress;
  private String url;
  private WebView wv;
  private boolean zoom;
  
  public WebImage(WebView paramWebView, String paramString, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt)
  {
    wv = paramWebView;
    url = paramString;
    progress = paramObject;
    zoom = paramBoolean1;
    control = paramBoolean2;
    color = paramInt;
  }
  
  private void delaySetup()
  {
    wv.setPictureListener(new WebView.PictureListener()
    {
      public void onNewPicture(WebView paramAnonymousWebView, Picture paramAnonymousPicture)
      {
        wv.setPictureListener(null);
        WebImage.this.setup();
      }
    });
    wv.loadData("<html></html>", "text/html", "utf-8");
    wv.setBackgroundColor(color);
  }
  
  private static void disableZoomControl(WebView paramWebView)
  {
    if (Build.VERSION.SDK_INT < 11) {
      return;
    }
    AQUtility.invokeHandler(paramWebView.getSettings(), "setDisplayZoomControls", false, false, new Class[] { Boolean.TYPE }, new Object[] { Boolean.valueOf(false) });
  }
  
  private void done(WebView paramWebView)
  {
    if (progress != null)
    {
      paramWebView.setVisibility(0);
      Common.showProgress(progress, url, false);
    }
    paramWebView.setWebViewClient(null);
  }
  
  private static void fixWebviewTip(Context paramContext)
  {
    paramContext = paramContext.getSharedPreferences("WebViewSettings", 0);
    if (paramContext.getInt("double_tap_toast_count", 1) > 0) {
      paramContext.edit().putInt("double_tap_toast_count", 0).commit();
    }
  }
  
  private static String getSource(Context paramContext)
  {
    if (template == null) {}
    try
    {
      paramContext = paramContext.getClassLoader().getResourceAsStream("com/androidquery/util/web_image.html");
      paramContext = new String(AQUtility.toBytes(paramContext));
      template = paramContext;
    }
    catch (Exception paramContext)
    {
      for (;;)
      {
        AQUtility.debug(paramContext);
      }
    }
    return template;
  }
  
  private void setup()
  {
    String str = getSource(wv.getContext()).replace("@src", url).replace("@color", Integer.toHexString(color));
    wv.setWebViewClient(this);
    wv.loadDataWithBaseURL(null, str, "text/html", "utf-8", null);
    wv.setBackgroundColor(color);
  }
  
  public void load()
  {
    if (url.equals(wv.getTag(1090453505))) {
      return;
    }
    wv.setTag(1090453505, url);
    if (Build.VERSION.SDK_INT <= 10) {
      wv.setDrawingCacheEnabled(true);
    }
    fixWebviewTip(wv.getContext());
    WebSettings localWebSettings = wv.getSettings();
    localWebSettings.setSupportZoom(zoom);
    localWebSettings.setBuiltInZoomControls(zoom);
    if (!control) {
      disableZoomControl(wv);
    }
    localWebSettings.setJavaScriptEnabled(true);
    wv.setBackgroundColor(color);
    if (progress != null) {
      Common.showProgress(progress, url, true);
    }
    if (wv.getWidth() > 0)
    {
      setup();
      return;
    }
    delaySetup();
  }
  
  public void onPageFinished(WebView paramWebView, String paramString)
  {
    done(paramWebView);
  }
  
  public void onReceivedError(WebView paramWebView, int paramInt, String paramString1, String paramString2)
  {
    done(paramWebView);
  }
  
  public void onScaleChanged(WebView paramWebView, float paramFloat1, float paramFloat2) {}
}
