package com.androidquery.util;

import java.io.ByteArrayOutputStream;

public class PredefinedBAOS
  extends ByteArrayOutputStream
{
  public PredefinedBAOS(int paramInt)
  {
    super(paramInt);
  }
  
  public byte[] toByteArray()
  {
    if (count == buf.length) {
      return buf;
    }
    return super.toByteArray();
  }
}
