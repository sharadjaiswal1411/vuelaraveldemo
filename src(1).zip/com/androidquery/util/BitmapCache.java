package com.androidquery.util;

import android.graphics.Bitmap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

public class BitmapCache
  extends LinkedHashMap<String, Bitmap>
{
  private static final long serialVersionUID = 1L;
  private int maxCount;
  private int maxPixels;
  private int maxTotalPixels;
  private int pixels;
  
  public BitmapCache(int paramInt1, int paramInt2, int paramInt3)
  {
    super(8, 0.75F, true);
    maxCount = paramInt1;
    maxPixels = paramInt2;
    maxTotalPixels = paramInt3;
  }
  
  private int pixels(Bitmap paramBitmap)
  {
    if (paramBitmap == null) {
      return 0;
    }
    return paramBitmap.getWidth() * paramBitmap.getHeight();
  }
  
  private void shrink()
  {
    if (pixels > maxTotalPixels)
    {
      Iterator localIterator = keySet().iterator();
      do
      {
        if (!localIterator.hasNext()) {
          return;
        }
        localIterator.next();
        localIterator.remove();
      } while (pixels > maxTotalPixels);
    }
  }
  
  public void clear()
  {
    super.clear();
    pixels = 0;
  }
  
  public Bitmap put(String paramString, Bitmap paramBitmap)
  {
    int i = pixels(paramBitmap);
    if (i <= maxPixels)
    {
      pixels += i;
      paramString = (Bitmap)super.put(paramString, paramBitmap);
      if (paramString != null)
      {
        pixels -= pixels(paramString);
        return paramString;
      }
    }
    else
    {
      return null;
    }
    return paramString;
  }
  
  public Bitmap remove(Object paramObject)
  {
    paramObject = (Bitmap)super.remove(paramObject);
    if (paramObject != null) {
      pixels -= pixels(paramObject);
    }
    return paramObject;
  }
  
  public boolean removeEldestEntry(Map.Entry paramEntry)
  {
    if ((pixels > maxTotalPixels) || (size() > maxCount)) {
      remove(paramEntry.getKey());
    }
    shrink();
    return false;
  }
}
