package com.androidquery;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.webkit.WebView;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.Gallery;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import com.androidquery.auth.AccountHandle;
import com.androidquery.callback.AbstractAjaxCallback;
import com.androidquery.callback.AjaxCallback;
import com.androidquery.callback.BitmapAjaxCallback;
import com.androidquery.callback.ImageOptions;
import com.androidquery.callback.Transformer;
import com.androidquery.util.AQUtility;
import com.androidquery.util.Common;
import com.androidquery.util.Constants;
import com.androidquery.util.WebImage;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Constructor;
import java.nio.channels.FileChannel;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.entity.StringEntity;
import org.json.JSONObject;

public abstract class AbstractAQuery<T extends AbstractAQuery<T>>
  implements Constants
{
  private static Class<?>[] LAYER_TYPE_SIG = { Integer.TYPE, Paint.class };
  private static final Class<?>[] ON_CLICK_SIG = { View.class };
  private static Class<?>[] ON_ITEM_SIG = { AdapterView.class, View.class, Integer.TYPE, Long.TYPE };
  private static Class<?>[] ON_SCROLLED_STATE_SIG = { AbsListView.class, Integer.TYPE };
  private static final Class<?>[] OVER_SCROLL_SIG;
  private static Class<?>[] PENDING_TRANSITION_SIG;
  private static final Class<?>[] TEXT_CHANGE_SIG = { CharSequence.class, Integer.TYPE, Integer.TYPE, Integer.TYPE };
  private static WeakHashMap<Dialog, Void> dialogs = new WeakHashMap();
  private Activity act;
  protected AccountHandle ah;
  private Constructor<T> constructor;
  private Context context;
  private int policy = 0;
  protected Object progress;
  private HttpHost proxy;
  private View root;
  private Transformer trans;
  protected View view;
  
  static
  {
    PENDING_TRANSITION_SIG = new Class[] { Integer.TYPE, Integer.TYPE };
    OVER_SCROLL_SIG = new Class[] { Integer.TYPE };
  }
  
  public AbstractAQuery(Activity paramActivity)
  {
    act = paramActivity;
  }
  
  public AbstractAQuery(Activity paramActivity, View paramView)
  {
    root = paramView;
    view = paramView;
    act = paramActivity;
  }
  
  public AbstractAQuery(Context paramContext)
  {
    context = paramContext;
  }
  
  public AbstractAQuery(View paramView)
  {
    root = paramView;
    view = paramView;
  }
  
  private View findView(int paramInt)
  {
    if (root != null) {
      return root.findViewById(paramInt);
    }
    if (act != null) {
      return act.findViewById(paramInt);
    }
    return null;
  }
  
  private View findView(String paramString)
  {
    if (root != null) {
      return root.findViewWithTag(paramString);
    }
    if (act != null)
    {
      View localView = ((ViewGroup)act.findViewById(16908290)).getChildAt(0);
      if (localView != null) {
        return localView.findViewWithTag(paramString);
      }
    }
    return null;
  }
  
  private View findView(int... paramVarArgs)
  {
    View localView = findView(paramVarArgs[0]);
    int i = 1;
    while (i < paramVarArgs.length)
    {
      if (localView == null) {
        return localView;
      }
      localView = localView.findViewById(paramVarArgs[i]);
      i += 1;
    }
    return localView;
  }
  
  private Constructor getConstructor()
  {
    if (constructor == null) {}
    try
    {
      Object localObject = getClass();
      localObject = ((Class)localObject).getConstructor(new Class[] { View.class });
      constructor = ((Constructor)localObject);
    }
    catch (Exception localException)
    {
      for (;;)
      {
        localException.printStackTrace();
      }
    }
    return constructor;
  }
  
  private Common setScrollListener()
  {
    AbsListView localAbsListView = (AbsListView)view;
    Common localCommon2 = (Common)localAbsListView.getTag(1090453506);
    Common localCommon1 = localCommon2;
    if (localCommon2 == null)
    {
      localCommon1 = new Common();
      localAbsListView.setOnScrollListener(localCommon1);
      localAbsListView.setTag(1090453506, localCommon1);
      AQUtility.debug("set scroll listenr");
    }
    return localCommon1;
  }
  
  private void size(boolean paramBoolean1, int paramInt, boolean paramBoolean2)
  {
    if (view != null)
    {
      ViewGroup.LayoutParams localLayoutParams = view.getLayoutParams();
      Context localContext = getContext();
      int i = paramInt;
      if (paramInt > 0)
      {
        i = paramInt;
        if (paramBoolean2) {
          i = AQUtility.dip2pixel(localContext, paramInt);
        }
      }
      if (paramBoolean1) {
        width = i;
      }
      for (;;)
      {
        view.setLayoutParams(localLayoutParams);
        return;
        height = i;
      }
    }
  }
  
  public AbstractAQuery adapter(Adapter paramAdapter)
  {
    if ((view instanceof AdapterView)) {
      ((AdapterView)view).setAdapter(paramAdapter);
    }
    return self();
  }
  
  public AbstractAQuery adapter(ExpandableListAdapter paramExpandableListAdapter)
  {
    if ((view instanceof ExpandableListView)) {
      ((ExpandableListView)view).setAdapter(paramExpandableListAdapter);
    }
    return self();
  }
  
  public AbstractAQuery ajax(AjaxCallback paramAjaxCallback)
  {
    return invoke(paramAjaxCallback);
  }
  
  public AbstractAQuery ajax(String paramString, Class paramClass, long paramLong, AjaxCallback paramAjaxCallback)
  {
    ((AjaxCallback)((AjaxCallback)((AjaxCallback)paramAjaxCallback.type(paramClass)).url(paramString)).fileCache(true)).expire(paramLong);
    return ajax(paramAjaxCallback);
  }
  
  public AbstractAQuery ajax(String paramString1, Class paramClass, long paramLong, Object paramObject, String paramString2)
  {
    AjaxCallback localAjaxCallback = new AjaxCallback();
    ((AjaxCallback)((AjaxCallback)((AjaxCallback)localAjaxCallback.type(paramClass)).weakHandler(paramObject, paramString2)).fileCache(true)).expire(paramLong);
    return ajax(paramString1, paramClass, localAjaxCallback);
  }
  
  public AbstractAQuery ajax(String paramString, Class paramClass, AjaxCallback paramAjaxCallback)
  {
    ((AjaxCallback)paramAjaxCallback.type(paramClass)).url(paramString);
    return ajax(paramAjaxCallback);
  }
  
  public AbstractAQuery ajax(String paramString1, Class paramClass, Object paramObject, String paramString2)
  {
    AjaxCallback localAjaxCallback = new AjaxCallback();
    ((AjaxCallback)localAjaxCallback.type(paramClass)).weakHandler(paramObject, paramString2);
    return ajax(paramString1, paramClass, localAjaxCallback);
  }
  
  public AbstractAQuery ajax(String paramString, Map paramMap, Class paramClass, AjaxCallback paramAjaxCallback)
  {
    ((AjaxCallback)((AjaxCallback)paramAjaxCallback.type(paramClass)).url(paramString)).params(paramMap);
    return ajax(paramAjaxCallback);
  }
  
  public AbstractAQuery ajax(String paramString1, Map paramMap, Class paramClass, Object paramObject, String paramString2)
  {
    AjaxCallback localAjaxCallback = new AjaxCallback();
    ((AjaxCallback)localAjaxCallback.type(paramClass)).weakHandler(paramObject, paramString2);
    return ajax(paramString1, paramMap, paramClass, localAjaxCallback);
  }
  
  public AbstractAQuery ajaxCancel()
  {
    AbstractAjaxCallback.cancel();
    return self();
  }
  
  public AbstractAQuery animate(int paramInt)
  {
    return animate(paramInt, null);
  }
  
  public AbstractAQuery animate(int paramInt, Animation.AnimationListener paramAnimationListener)
  {
    Animation localAnimation = AnimationUtils.loadAnimation(getContext(), paramInt);
    localAnimation.setAnimationListener(paramAnimationListener);
    return animate(localAnimation);
  }
  
  public AbstractAQuery animate(Animation paramAnimation)
  {
    if ((view != null) && (paramAnimation != null)) {
      view.startAnimation(paramAnimation);
    }
    return self();
  }
  
  public AbstractAQuery auth(AccountHandle paramAccountHandle)
  {
    ah = paramAccountHandle;
    return self();
  }
  
  public AbstractAQuery background(int paramInt)
  {
    if (view != null)
    {
      if (paramInt == 0) {
        break label24;
      }
      view.setBackgroundResource(paramInt);
    }
    for (;;)
    {
      return self();
      label24:
      view.setBackgroundDrawable(null);
    }
  }
  
  public AbstractAQuery backgroundColor(int paramInt)
  {
    if (view != null) {
      view.setBackgroundColor(paramInt);
    }
    return self();
  }
  
  public AbstractAQuery backgroundColorId(int paramInt)
  {
    if (view != null) {
      view.setBackgroundColor(getContext().getResources().getColor(paramInt));
    }
    return self();
  }
  
  public AbstractAQuery cache(String paramString, long paramLong)
  {
    return ajax(paramString, [B.class, paramLong, null, null);
  }
  
  public AbstractAQuery checked(boolean paramBoolean)
  {
    if ((view instanceof CompoundButton)) {
      ((CompoundButton)view).setChecked(paramBoolean);
    }
    return self();
  }
  
  public AbstractAQuery clear()
  {
    Object localObject;
    if (view != null)
    {
      if (!(view instanceof ImageView)) {
        break label43;
      }
      localObject = (ImageView)view;
      ((ImageView)localObject).setImageBitmap(null);
      ((View)localObject).setTag(1090453505, null);
    }
    for (;;)
    {
      return self();
      label43:
      if ((view instanceof WebView))
      {
        localObject = (WebView)view;
        ((WebView)localObject).stopLoading();
        ((WebView)localObject).clearView();
        ((View)localObject).setTag(1090453505, null);
      }
      else if ((view instanceof TextView))
      {
        ((TextView)view).setText("");
      }
    }
  }
  
  public AbstractAQuery click()
  {
    if (view != null) {
      view.performClick();
    }
    return self();
  }
  
  public AbstractAQuery clickable(boolean paramBoolean)
  {
    if (view != null) {
      view.setClickable(paramBoolean);
    }
    return self();
  }
  
  public AbstractAQuery clicked(View.OnClickListener paramOnClickListener)
  {
    if (view != null) {
      view.setOnClickListener(paramOnClickListener);
    }
    return self();
  }
  
  public AbstractAQuery clicked(Object paramObject, String paramString)
  {
    return clicked(new Common().forward(paramObject, paramString, true, ON_CLICK_SIG));
  }
  
  protected AbstractAQuery create(View paramView)
  {
    try
    {
      Constructor localConstructor = getConstructor();
      paramView = localConstructor.newInstance(new Object[] { paramView });
      paramView = (AbstractAQuery)paramView;
      act = act;
      return paramView;
    }
    catch (Exception paramView)
    {
      paramView.printStackTrace();
    }
    return null;
  }
  
  public AbstractAQuery dataChanged()
  {
    if ((view instanceof AdapterView))
    {
      Adapter localAdapter = ((AdapterView)view).getAdapter();
      if ((localAdapter instanceof BaseAdapter)) {
        ((BaseAdapter)localAdapter).notifyDataSetChanged();
      }
    }
    return self();
  }
  
  public AbstractAQuery delete(String paramString, Class paramClass, AjaxCallback paramAjaxCallback)
  {
    ((AjaxCallback)((AjaxCallback)paramAjaxCallback.url(paramString)).type(paramClass)).method(2);
    return ajax(paramAjaxCallback);
  }
  
  public AbstractAQuery delete(String paramString1, Class paramClass, Object paramObject, String paramString2)
  {
    AjaxCallback localAjaxCallback = new AjaxCallback();
    localAjaxCallback.weakHandler(paramObject, paramString2);
    return delete(paramString1, paramClass, localAjaxCallback);
  }
  
  public AbstractAQuery dismiss()
  {
    Iterator localIterator = dialogs.keySet().iterator();
    for (;;)
    {
      if (!localIterator.hasNext()) {
        return self();
      }
      Dialog localDialog = (Dialog)localIterator.next();
      try
      {
        localDialog.dismiss();
        localIterator.remove();
      }
      catch (Exception localException)
      {
        for (;;) {}
      }
    }
  }
  
  public AbstractAQuery dismiss(Dialog paramDialog)
  {
    WeakHashMap localWeakHashMap;
    if (paramDialog != null) {
      localWeakHashMap = dialogs;
    }
    try
    {
      localWeakHashMap.remove(paramDialog);
      paramDialog.dismiss();
      return self();
    }
    catch (Exception paramDialog)
    {
      for (;;) {}
    }
  }
  
  public AbstractAQuery download(String paramString, File paramFile, AjaxCallback paramAjaxCallback)
  {
    ((AjaxCallback)((AjaxCallback)paramAjaxCallback.url(paramString)).type(File.class)).targetFile(paramFile);
    return ajax(paramAjaxCallback);
  }
  
  public AbstractAQuery download(String paramString1, File paramFile, Object paramObject, String paramString2)
  {
    AjaxCallback localAjaxCallback = new AjaxCallback();
    localAjaxCallback.weakHandler(paramObject, paramString2);
    return download(paramString1, paramFile, localAjaxCallback);
  }
  
  public AbstractAQuery enabled(boolean paramBoolean)
  {
    if (view != null) {
      view.setEnabled(paramBoolean);
    }
    return self();
  }
  
  public AbstractAQuery expand(int paramInt, boolean paramBoolean)
  {
    ExpandableListView localExpandableListView;
    if ((view instanceof ExpandableListView))
    {
      localExpandableListView = (ExpandableListView)view;
      if (!paramBoolean) {
        break label33;
      }
      localExpandableListView.expandGroup(paramInt);
    }
    for (;;)
    {
      return self();
      label33:
      localExpandableListView.collapseGroup(paramInt);
    }
  }
  
  public AbstractAQuery expand(boolean paramBoolean)
  {
    ExpandableListView localExpandableListView;
    int i;
    if ((view instanceof ExpandableListView))
    {
      localExpandableListView = (ExpandableListView)view;
      ExpandableListAdapter localExpandableListAdapter = localExpandableListView.getExpandableListAdapter();
      if (localExpandableListAdapter != null)
      {
        int j = localExpandableListAdapter.getGroupCount();
        i = 0;
        if (i < j) {
          break label51;
        }
      }
    }
    return self();
    label51:
    if (paramBoolean) {
      localExpandableListView.expandGroup(i);
    }
    for (;;)
    {
      i += 1;
      break;
      localExpandableListView.collapseGroup(i);
    }
  }
  
  public AbstractAQuery find(int paramInt)
  {
    return create(findView(paramInt));
  }
  
  public Button getButton()
  {
    return (Button)view;
  }
  
  public File getCachedFile(String paramString)
  {
    File localFile2 = AQUtility.getExistedCacheByUrl(AQUtility.getCacheDir(getContext(), 1), paramString);
    File localFile1 = localFile2;
    if (localFile2 == null) {
      localFile1 = AQUtility.getExistedCacheByUrl(AQUtility.getCacheDir(getContext(), 0), paramString);
    }
    return localFile1;
  }
  
  public Bitmap getCachedImage(int paramInt)
  {
    return BitmapAjaxCallback.getMemoryCached(getContext(), paramInt);
  }
  
  public Bitmap getCachedImage(String paramString)
  {
    return getCachedImage(paramString, 0);
  }
  
  public Bitmap getCachedImage(String paramString, int paramInt)
  {
    Bitmap localBitmap2 = BitmapAjaxCallback.getMemoryCached(paramString, paramInt);
    Bitmap localBitmap1 = localBitmap2;
    if (localBitmap2 == null)
    {
      paramString = getCachedFile(paramString);
      localBitmap1 = localBitmap2;
      if (paramString != null) {
        localBitmap1 = BitmapAjaxCallback.getResizedImage(paramString.getAbsolutePath(), null, paramInt, true, 0);
      }
    }
    return localBitmap1;
  }
  
  public CheckBox getCheckBox()
  {
    return (CheckBox)view;
  }
  
  public Context getContext()
  {
    if (act != null) {
      return act;
    }
    if (root != null) {
      return root.getContext();
    }
    return context;
  }
  
  public EditText getEditText()
  {
    return (EditText)view;
  }
  
  public Editable getEditable()
  {
    if ((view instanceof EditText)) {
      return ((EditText)view).getEditableText();
    }
    return null;
  }
  
  public ExpandableListView getExpandableListView()
  {
    return (ExpandableListView)view;
  }
  
  public Gallery getGallery()
  {
    return (Gallery)view;
  }
  
  public GridView getGridView()
  {
    return (GridView)view;
  }
  
  public ImageView getImageView()
  {
    return (ImageView)view;
  }
  
  public ListView getListView()
  {
    return (ListView)view;
  }
  
  public ProgressBar getProgressBar()
  {
    return (ProgressBar)view;
  }
  
  public RatingBar getRatingBar()
  {
    return (RatingBar)view;
  }
  
  public SeekBar getSeekBar()
  {
    return (SeekBar)view;
  }
  
  public Object getSelectedItem()
  {
    if ((view instanceof AdapterView)) {
      return ((AdapterView)view).getSelectedItem();
    }
    return null;
  }
  
  public int getSelectedItemPosition()
  {
    if ((view instanceof AdapterView)) {
      return ((AdapterView)view).getSelectedItemPosition();
    }
    return -1;
  }
  
  public Spinner getSpinner()
  {
    return (Spinner)view;
  }
  
  public Object getTag()
  {
    if (view != null) {
      return view.getTag();
    }
    return null;
  }
  
  public Object getTag(int paramInt)
  {
    if (view != null) {
      return view.getTag(paramInt);
    }
    return null;
  }
  
  public CharSequence getText()
  {
    if ((view instanceof TextView)) {
      return ((TextView)view).getText();
    }
    return null;
  }
  
  public TextView getTextView()
  {
    return (TextView)view;
  }
  
  public View getView()
  {
    return view;
  }
  
  public WebView getWebView()
  {
    return (WebView)view;
  }
  
  public AbstractAQuery gone()
  {
    return visibility(8);
  }
  
  public AbstractAQuery hardwareAccelerated11()
  {
    if (act != null) {
      act.getWindow().setFlags(16777216, 16777216);
    }
    return self();
  }
  
  public AbstractAQuery height(int paramInt)
  {
    size(false, paramInt, true);
    return self();
  }
  
  public AbstractAQuery height(int paramInt, boolean paramBoolean)
  {
    size(false, paramInt, paramBoolean);
    return self();
  }
  
  public AbstractAQuery id(int paramInt)
  {
    return id(findView(paramInt));
  }
  
  public AbstractAQuery id(View paramView)
  {
    view = paramView;
    reset();
    return self();
  }
  
  public AbstractAQuery id(String paramString)
  {
    return id(findView(paramString));
  }
  
  public AbstractAQuery id(int... paramVarArgs)
  {
    return id(findView(paramVarArgs));
  }
  
  public AbstractAQuery image(int paramInt)
  {
    ImageView localImageView;
    if ((view instanceof ImageView))
    {
      localImageView = (ImageView)view;
      localImageView.setTag(1090453505, null);
      if (paramInt != 0) {
        break label40;
      }
      localImageView.setImageBitmap(null);
    }
    for (;;)
    {
      return self();
      label40:
      localImageView.setImageResource(paramInt);
    }
  }
  
  public AbstractAQuery image(Bitmap paramBitmap)
  {
    if ((view instanceof ImageView))
    {
      ImageView localImageView = (ImageView)view;
      localImageView.setTag(1090453505, null);
      localImageView.setImageBitmap(paramBitmap);
    }
    return self();
  }
  
  public AbstractAQuery image(Bitmap paramBitmap, float paramFloat)
  {
    BitmapAjaxCallback localBitmapAjaxCallback = new BitmapAjaxCallback();
    localBitmapAjaxCallback.ratio(paramFloat).bitmap(paramBitmap);
    return image(localBitmapAjaxCallback);
  }
  
  public AbstractAQuery image(Drawable paramDrawable)
  {
    if ((view instanceof ImageView))
    {
      ImageView localImageView = (ImageView)view;
      localImageView.setTag(1090453505, null);
      localImageView.setImageDrawable(paramDrawable);
    }
    return self();
  }
  
  public AbstractAQuery image(BitmapAjaxCallback paramBitmapAjaxCallback)
  {
    if ((view instanceof ImageView))
    {
      paramBitmapAjaxCallback.imageView((ImageView)view);
      invoke(paramBitmapAjaxCallback);
    }
    return self();
  }
  
  public AbstractAQuery image(File paramFile, int paramInt)
  {
    return image(paramFile, true, paramInt, null);
  }
  
  public AbstractAQuery image(File paramFile, boolean paramBoolean, int paramInt, BitmapAjaxCallback paramBitmapAjaxCallback)
  {
    BitmapAjaxCallback localBitmapAjaxCallback = paramBitmapAjaxCallback;
    if (paramBitmapAjaxCallback == null) {
      localBitmapAjaxCallback = new BitmapAjaxCallback();
    }
    localBitmapAjaxCallback.file(paramFile);
    paramBitmapAjaxCallback = null;
    if (paramFile != null) {
      paramBitmapAjaxCallback = paramFile.getAbsolutePath();
    }
    return image(paramBitmapAjaxCallback, paramBoolean, true, paramInt, 0, localBitmapAjaxCallback);
  }
  
  public AbstractAQuery image(String paramString)
  {
    return image(paramString, true, true, 0, 0);
  }
  
  public AbstractAQuery image(String paramString, ImageOptions paramImageOptions)
  {
    return image(paramString, paramImageOptions, null);
  }
  
  protected AbstractAQuery image(String paramString1, ImageOptions paramImageOptions, String paramString2)
  {
    if ((view instanceof ImageView))
    {
      BitmapAjaxCallback.async(act, getContext(), (ImageView)view, paramString1, progress, ah, paramImageOptions, proxy, paramString2);
      reset();
    }
    return self();
  }
  
  public AbstractAQuery image(String paramString, boolean paramBoolean1, boolean paramBoolean2)
  {
    return image(paramString, paramBoolean1, paramBoolean2, 0, 0);
  }
  
  public AbstractAQuery image(String paramString, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2)
  {
    return image(paramString, paramBoolean1, paramBoolean2, paramInt1, paramInt2, null, 0);
  }
  
  public AbstractAQuery image(String paramString, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2, Bitmap paramBitmap, int paramInt3)
  {
    return image(paramString, paramBoolean1, paramBoolean2, paramInt1, paramInt2, paramBitmap, paramInt3, 0.0F);
  }
  
  public AbstractAQuery image(String paramString, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2, Bitmap paramBitmap, int paramInt3, float paramFloat)
  {
    return image(paramString, paramBoolean1, paramBoolean2, paramInt1, paramInt2, paramBitmap, paramInt3, paramFloat, 0, null);
  }
  
  protected AbstractAQuery image(String paramString1, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2, Bitmap paramBitmap, int paramInt3, float paramFloat, int paramInt4, String paramString2)
  {
    if ((view instanceof ImageView))
    {
      BitmapAjaxCallback.async(act, getContext(), (ImageView)view, paramString1, paramBoolean1, paramBoolean2, paramInt1, paramInt2, paramBitmap, paramInt3, paramFloat, Float.MAX_VALUE, progress, ah, policy, paramInt4, proxy, paramString2);
      reset();
    }
    return self();
  }
  
  public AbstractAQuery image(String paramString, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2, BitmapAjaxCallback paramBitmapAjaxCallback)
  {
    ((BitmapAjaxCallback)((BitmapAjaxCallback)paramBitmapAjaxCallback.targetWidth(paramInt1).fallback(paramInt2).url(paramString)).memCache(paramBoolean1)).fileCache(paramBoolean2);
    return image(paramBitmapAjaxCallback);
  }
  
  public View inflate(View paramView, int paramInt, ViewGroup paramViewGroup)
  {
    if (paramView != null)
    {
      Integer localInteger = (Integer)paramView.getTag(1090453507);
      if ((localInteger != null) && (localInteger.intValue() == paramInt)) {
        return paramView;
      }
    }
    if (act != null) {}
    for (paramView = act.getLayoutInflater();; paramView = (LayoutInflater)getContext().getSystemService("layout_inflater"))
    {
      paramView = paramView.inflate(paramInt, paramViewGroup, false);
      paramView.setTag(1090453507, Integer.valueOf(paramInt));
      return paramView;
    }
  }
  
  public AbstractAQuery invalidate(String paramString)
  {
    paramString = getCachedFile(paramString);
    if (paramString != null) {
      paramString.delete();
    }
    return self();
  }
  
  public AbstractAQuery invisible()
  {
    return visibility(4);
  }
  
  protected AbstractAQuery invoke(AbstractAjaxCallback paramAbstractAjaxCallback)
  {
    if (ah != null) {
      paramAbstractAjaxCallback.auth(ah);
    }
    if (progress != null) {
      paramAbstractAjaxCallback.progress(progress);
    }
    if (trans != null) {
      paramAbstractAjaxCallback.transformer(trans);
    }
    paramAbstractAjaxCallback.policy(policy);
    if (proxy != null) {
      paramAbstractAjaxCallback.proxy(proxy.getHostName(), proxy.getPort());
    }
    if (act != null) {
      paramAbstractAjaxCallback.async(act);
    }
    for (;;)
    {
      reset();
      return self();
      paramAbstractAjaxCallback.async(getContext());
    }
  }
  
  public Object invoke(String paramString, Class[] paramArrayOfClass, Object... paramVarArgs)
  {
    View localView = view;
    Object localObject = localView;
    if (localView == null) {
      localObject = act;
    }
    return AQUtility.invokeHandler(localObject, paramString, false, false, paramArrayOfClass, paramVarArgs);
  }
  
  public boolean isChecked()
  {
    if ((view instanceof CompoundButton)) {
      return ((CompoundButton)view).isChecked();
    }
    return false;
  }
  
  public boolean isExist()
  {
    return view != null;
  }
  
  public AbstractAQuery itemClicked(AdapterView.OnItemClickListener paramOnItemClickListener)
  {
    if ((view instanceof AdapterView)) {
      ((AdapterView)view).setOnItemClickListener(paramOnItemClickListener);
    }
    return self();
  }
  
  public AbstractAQuery itemClicked(Object paramObject, String paramString)
  {
    return itemClicked(new Common().forward(paramObject, paramString, true, ON_ITEM_SIG));
  }
  
  public AbstractAQuery itemLongClicked(AdapterView.OnItemLongClickListener paramOnItemLongClickListener)
  {
    if ((view instanceof AdapterView)) {
      ((AdapterView)view).setOnItemLongClickListener(paramOnItemLongClickListener);
    }
    return self();
  }
  
  public AbstractAQuery itemLongClicked(Object paramObject, String paramString)
  {
    return itemLongClicked(new Common().forward(paramObject, paramString, true, ON_ITEM_SIG));
  }
  
  public AbstractAQuery itemSelected(AdapterView.OnItemSelectedListener paramOnItemSelectedListener)
  {
    if ((view instanceof AdapterView)) {
      ((AdapterView)view).setOnItemSelectedListener(paramOnItemSelectedListener);
    }
    return self();
  }
  
  public AbstractAQuery itemSelected(Object paramObject, String paramString)
  {
    return itemSelected(new Common().forward(paramObject, paramString, true, ON_ITEM_SIG));
  }
  
  public AbstractAQuery longClick()
  {
    if (view != null) {
      view.performLongClick();
    }
    return self();
  }
  
  public AbstractAQuery longClicked(View.OnLongClickListener paramOnLongClickListener)
  {
    if (view != null) {
      view.setOnLongClickListener(paramOnLongClickListener);
    }
    return self();
  }
  
  public AbstractAQuery longClicked(Object paramObject, String paramString)
  {
    return longClicked(new Common().forward(paramObject, paramString, true, ON_CLICK_SIG));
  }
  
  public File makeSharedFile(String paramString1, String paramString2)
  {
    FileOutputStream localFileOutputStream = null;
    try
    {
      Object localObject = getCachedFile(paramString1);
      if (localObject == null) {
        break label138;
      }
      paramString1 = AQUtility.getTempDir();
      if (paramString1 == null) {
        break label138;
      }
      paramString1 = new File(paramString1, paramString2);
      try
      {
        paramString1.createNewFile();
        paramString2 = new FileInputStream((File)localObject);
        localFileOutputStream = new FileOutputStream(paramString1);
        localObject = paramString2.getChannel();
        FileChannel localFileChannel = localFileOutputStream.getChannel();
        try
        {
          ((FileChannel)localObject).transferTo(0L, ((FileChannel)localObject).size(), localFileChannel);
          AQUtility.close(paramString2);
          AQUtility.close(localFileOutputStream);
          AQUtility.close((Closeable)localObject);
          AQUtility.close(localFileChannel);
          return paramString1;
        }
        catch (Throwable localThrowable)
        {
          AQUtility.close(paramString2);
          AQUtility.close(localFileOutputStream);
          AQUtility.close((Closeable)localObject);
          AQUtility.close(localFileChannel);
          throw localThrowable;
        }
        AQUtility.debug(paramString2);
      }
      catch (Exception paramString2) {}
    }
    catch (Exception paramString2)
    {
      for (;;)
      {
        paramString1 = localFileOutputStream;
      }
    }
    return paramString1;
    label138:
    return null;
  }
  
  public AbstractAQuery margin(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    if (view != null)
    {
      ViewGroup.LayoutParams localLayoutParams = view.getLayoutParams();
      if ((localLayoutParams instanceof ViewGroup.MarginLayoutParams))
      {
        Context localContext = getContext();
        int i = AQUtility.dip2pixel(localContext, paramFloat1);
        int j = AQUtility.dip2pixel(localContext, paramFloat2);
        int k = AQUtility.dip2pixel(localContext, paramFloat3);
        int m = AQUtility.dip2pixel(localContext, paramFloat4);
        ((ViewGroup.MarginLayoutParams)localLayoutParams).setMargins(i, j, k, m);
        view.setLayoutParams(localLayoutParams);
      }
    }
    return self();
  }
  
  public AbstractAQuery overridePendingTransition5(int paramInt1, int paramInt2)
  {
    if (act != null) {
      AQUtility.invokeHandler(act, "overridePendingTransition", false, false, PENDING_TRANSITION_SIG, new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
    }
    return self();
  }
  
  public AbstractAQuery parent(int paramInt)
  {
    Object localObject1 = view;
    Object localObject2 = null;
    for (;;)
    {
      if (localObject1 == null) {
        localObject1 = localObject2;
      }
      ViewParent localViewParent;
      do
      {
        do
        {
          return create((View)localObject1);
        } while (((View)localObject1).getId() == paramInt);
        localViewParent = ((View)localObject1).getParent();
        localObject1 = localObject2;
      } while (!(localViewParent instanceof View));
      localObject1 = (View)localViewParent;
    }
  }
  
  public AbstractAQuery policy(int paramInt)
  {
    policy = paramInt;
    return self();
  }
  
  public AbstractAQuery post(String paramString1, String paramString2, HttpEntity paramHttpEntity, Class paramClass, AjaxCallback paramAjaxCallback)
  {
    ((AjaxCallback)((AjaxCallback)((AjaxCallback)((AjaxCallback)paramAjaxCallback.url(paramString1)).type(paramClass)).method(1)).header("Content-Type", paramString2)).param("%entity", paramHttpEntity);
    return ajax(paramAjaxCallback);
  }
  
  public AbstractAQuery post(String paramString, JSONObject paramJSONObject, Class paramClass, AjaxCallback paramAjaxCallback)
  {
    try
    {
      paramString = post(paramString, "application/json", new StringEntity(paramJSONObject.toString(), "UTF-8"), paramClass, paramAjaxCallback);
      return paramString;
    }
    catch (UnsupportedEncodingException paramString)
    {
      throw new IllegalArgumentException(paramString);
    }
  }
  
  public AbstractAQuery progress(int paramInt)
  {
    progress = findView(paramInt);
    return self();
  }
  
  public AbstractAQuery progress(Dialog paramDialog)
  {
    progress = paramDialog;
    return self();
  }
  
  public AbstractAQuery progress(Object paramObject)
  {
    progress = paramObject;
    return self();
  }
  
  public AbstractAQuery proxy(String paramString, int paramInt)
  {
    proxy = new HttpHost(paramString, paramInt);
    return self();
  }
  
  public AbstractAQuery put(String paramString1, String paramString2, HttpEntity paramHttpEntity, Class paramClass, AjaxCallback paramAjaxCallback)
  {
    ((AjaxCallback)((AjaxCallback)((AjaxCallback)((AjaxCallback)paramAjaxCallback.url(paramString1)).type(paramClass)).method(3)).header("Content-Type", paramString2)).param("%entity", paramHttpEntity);
    return ajax(paramAjaxCallback);
  }
  
  public AbstractAQuery put(String paramString, JSONObject paramJSONObject, Class paramClass, AjaxCallback paramAjaxCallback)
  {
    try
    {
      paramString = put(paramString, "application/json", new StringEntity(paramJSONObject.toString(), "UTF-8"), paramClass, paramAjaxCallback);
      return paramString;
    }
    catch (UnsupportedEncodingException paramString)
    {
      throw new IllegalArgumentException(paramString);
    }
  }
  
  public AbstractAQuery rating(float paramFloat)
  {
    if ((view instanceof RatingBar)) {
      ((RatingBar)view).setRating(paramFloat);
    }
    return self();
  }
  
  public AbstractAQuery recycle(View paramView)
  {
    root = paramView;
    view = paramView;
    reset();
    context = null;
    return self();
  }
  
  protected void reset()
  {
    ah = null;
    progress = null;
    trans = null;
    policy = 0;
    proxy = null;
  }
  
  public AbstractAQuery scrolled(AbsListView.OnScrollListener paramOnScrollListener)
  {
    if ((view instanceof AbsListView)) {
      setScrollListener().forward(paramOnScrollListener);
    }
    return self();
  }
  
  public AbstractAQuery scrolledBottom(Object paramObject, String paramString)
  {
    if ((view instanceof AbsListView)) {
      setScrollListener().forward(paramObject, paramString, true, ON_SCROLLED_STATE_SIG);
    }
    return self();
  }
  
  protected AbstractAQuery self()
  {
    return this;
  }
  
  public AbstractAQuery setLayerType11(int paramInt, Paint paramPaint)
  {
    if (view != null) {
      AQUtility.invokeHandler(view, "setLayerType", false, false, LAYER_TYPE_SIG, new Object[] { Integer.valueOf(paramInt), paramPaint });
    }
    return self();
  }
  
  public AbstractAQuery setOverScrollMode9(int paramInt)
  {
    if ((view instanceof AbsListView)) {
      AQUtility.invokeHandler(view, "setOverScrollMode", false, false, OVER_SCROLL_SIG, new Object[] { Integer.valueOf(paramInt) });
    }
    return self();
  }
  
  public AbstractAQuery setSelection(int paramInt)
  {
    if ((view instanceof AdapterView)) {
      ((AdapterView)view).setSelection(paramInt);
    }
    return self();
  }
  
  public boolean shouldDelay(int paramInt1, int paramInt2, boolean paramBoolean, View paramView, ViewGroup paramViewGroup, String paramString)
  {
    return Common.shouldDelay(paramInt1, paramInt2, paramView, paramViewGroup, paramString);
  }
  
  public boolean shouldDelay(int paramInt, View paramView, ViewGroup paramViewGroup, String paramString)
  {
    if ((paramViewGroup instanceof ExpandableListView)) {
      throw new IllegalArgumentException("Please use the other shouldDelay methods for expandable list.");
    }
    return Common.shouldDelay(paramInt, paramView, paramViewGroup, paramString);
  }
  
  public boolean shouldDelay(int paramInt, boolean paramBoolean, View paramView, ViewGroup paramViewGroup, String paramString)
  {
    return Common.shouldDelay(paramInt, -1, paramView, paramViewGroup, paramString);
  }
  
  public boolean shouldDelay(View paramView, ViewGroup paramViewGroup, String paramString, float paramFloat)
  {
    return Common.shouldDelay(paramView, paramViewGroup, paramString, paramFloat, true);
  }
  
  public boolean shouldDelay(View paramView, ViewGroup paramViewGroup, String paramString, float paramFloat, boolean paramBoolean)
  {
    return Common.shouldDelay(paramView, paramViewGroup, paramString, paramFloat, paramBoolean);
  }
  
  public AbstractAQuery show(Dialog paramDialog)
  {
    if (paramDialog != null) {}
    try
    {
      paramDialog.show();
      WeakHashMap localWeakHashMap = dialogs;
      localWeakHashMap.put(paramDialog, null);
    }
    catch (Exception paramDialog)
    {
      for (;;) {}
    }
    return self();
  }
  
  public AbstractAQuery sync(AjaxCallback paramAjaxCallback)
  {
    ajax(paramAjaxCallback);
    paramAjaxCallback.block();
    return self();
  }
  
  public AbstractAQuery tag(int paramInt, Object paramObject)
  {
    if (view != null) {
      view.setTag(paramInt, paramObject);
    }
    return self();
  }
  
  public AbstractAQuery tag(Object paramObject)
  {
    if (view != null) {
      view.setTag(paramObject);
    }
    return self();
  }
  
  public AbstractAQuery text(int paramInt)
  {
    if ((view instanceof TextView)) {
      ((TextView)view).setText(paramInt);
    }
    return self();
  }
  
  public AbstractAQuery text(int paramInt, Object... paramVarArgs)
  {
    Context localContext = getContext();
    if (localContext != null) {
      text(localContext.getString(paramInt, paramVarArgs));
    }
    return self();
  }
  
  public AbstractAQuery text(Spanned paramSpanned)
  {
    if ((view instanceof TextView)) {
      ((TextView)view).setText(paramSpanned);
    }
    return self();
  }
  
  public AbstractAQuery text(CharSequence paramCharSequence)
  {
    if ((view instanceof TextView)) {
      ((TextView)view).setText(paramCharSequence);
    }
    return self();
  }
  
  public AbstractAQuery text(CharSequence paramCharSequence, boolean paramBoolean)
  {
    if ((paramBoolean) && ((paramCharSequence == null) || (paramCharSequence.length() == 0))) {
      return gone();
    }
    return text(paramCharSequence);
  }
  
  public AbstractAQuery textChanged(Object paramObject, String paramString)
  {
    if ((view instanceof TextView)) {
      ((TextView)view).addTextChangedListener(new Common().forward(paramObject, paramString, true, TEXT_CHANGE_SIG));
    }
    return self();
  }
  
  public AbstractAQuery textColor(int paramInt)
  {
    if ((view instanceof TextView)) {
      ((TextView)view).setTextColor(paramInt);
    }
    return self();
  }
  
  public AbstractAQuery textColorId(int paramInt)
  {
    return textColor(getContext().getResources().getColor(paramInt));
  }
  
  public AbstractAQuery textSize(float paramFloat)
  {
    if ((view instanceof TextView)) {
      ((TextView)view).setTextSize(paramFloat);
    }
    return self();
  }
  
  public AbstractAQuery transformer(Transformer paramTransformer)
  {
    trans = paramTransformer;
    return self();
  }
  
  public AbstractAQuery transparent(boolean paramBoolean)
  {
    if (view != null) {
      AQUtility.transparent(view, paramBoolean);
    }
    return self();
  }
  
  public AbstractAQuery typeface(Typeface paramTypeface)
  {
    if ((view instanceof TextView)) {
      ((TextView)view).setTypeface(paramTypeface);
    }
    return self();
  }
  
  public AbstractAQuery visibility(int paramInt)
  {
    if ((view != null) && (view.getVisibility() != paramInt)) {
      view.setVisibility(paramInt);
    }
    return self();
  }
  
  public AbstractAQuery visible()
  {
    return visibility(0);
  }
  
  public AbstractAQuery webImage(String paramString)
  {
    return webImage(paramString, true, false, -16777216);
  }
  
  public AbstractAQuery webImage(String paramString, boolean paramBoolean1, boolean paramBoolean2, int paramInt)
  {
    if ((view instanceof WebView))
    {
      setLayerType11(1, null);
      new WebImage((WebView)view, paramString, progress, paramBoolean1, paramBoolean2, paramInt).load();
      progress = null;
    }
    return self();
  }
  
  public AbstractAQuery width(int paramInt)
  {
    size(true, paramInt, true);
    return self();
  }
  
  public AbstractAQuery width(int paramInt, boolean paramBoolean)
  {
    size(true, paramInt, paramBoolean);
    return self();
  }
}
