package com.google.tagmanager;

import android.content.Context;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.containertag.proto.Serving.Supplemental;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import com.google.tagmanager.protobuf.nano.MessageNano;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class Runtime
{
  static final String DEFAULT_RULE_NAME = "Unknown";
  private static final ObjectAndStatic<TypeSystem.Value> DEFAULT_VALUE_AND_STATIC = new ObjectAndStatic(Types.getDefaultValue(), true);
  static final String EXPERIMENT_SUPPLEMENTAL_NAME_PREFIX = "gaExperiment:";
  private static final int MAX_CACHE_SIZE = 1048576;
  private final EventInfoDistributor eventInfoDistributor;
  private volatile String mCurrentEventName;
  private final DataLayer mDataLayer;
  private final Cache<ResourceUtil.ExpandedFunctionCall, ObjectAndStatic<TypeSystem.Value>> mFunctionCallCache;
  private final Cache<String, CachedMacro> mMacroEvaluationCache;
  private final Map<String, MacroInfo> mMacroLookup;
  private final Map<String, FunctionCallImplementation> mMacroMap;
  private final Map<String, FunctionCallImplementation> mPredicateMap;
  private final ResourceUtil.ExpandedResource mResource;
  private final Set<ResourceUtil.ExpandedRule> mRules;
  private final Map<String, FunctionCallImplementation> mTrackingTagMap;
  
  public Runtime(Context paramContext, ResourceUtil.ExpandedResource paramExpandedResource, DataLayer paramDataLayer, CustomFunctionCall.CustomEvaluator paramCustomEvaluator1, CustomFunctionCall.CustomEvaluator paramCustomEvaluator2)
  {
    this(paramContext, paramExpandedResource, paramDataLayer, paramCustomEvaluator1, paramCustomEvaluator2, new NoopEventInfoDistributor());
  }
  
  public Runtime(Context paramContext, ResourceUtil.ExpandedResource paramExpandedResource, DataLayer paramDataLayer, CustomFunctionCall.CustomEvaluator paramCustomEvaluator1, CustomFunctionCall.CustomEvaluator paramCustomEvaluator2, EventInfoDistributor paramEventInfoDistributor)
  {
    if (paramExpandedResource == null) {
      throw new NullPointerException("resource cannot be null");
    }
    mResource = paramExpandedResource;
    mRules = new HashSet(paramExpandedResource.getRules());
    mDataLayer = paramDataLayer;
    eventInfoDistributor = paramEventInfoDistributor;
    paramExpandedResource = new CacheFactory.CacheSizeManager()
    {
      public int sizeOf(ResourceUtil.ExpandedFunctionCall paramAnonymousExpandedFunctionCall, ObjectAndStatic paramAnonymousObjectAndStatic)
      {
        return ((TypeSystem.Value)paramAnonymousObjectAndStatic.getObject()).getCachedSize();
      }
    };
    mFunctionCallCache = new CacheFactory().createCache(1048576, paramExpandedResource);
    paramExpandedResource = new CacheFactory.CacheSizeManager()
    {
      public int sizeOf(String paramAnonymousString, Runtime.CachedMacro paramAnonymousCachedMacro)
      {
        return paramAnonymousString.length() + paramAnonymousCachedMacro.getSize();
      }
    };
    mMacroEvaluationCache = new CacheFactory().createCache(1048576, paramExpandedResource);
    mTrackingTagMap = new HashMap();
    addTrackingTag(new ArbitraryPixelTag(paramContext));
    addTrackingTag(new CustomFunctionCall(paramCustomEvaluator2));
    addTrackingTag(new DataLayerWriteTag(paramDataLayer));
    addTrackingTag(new UniversalAnalyticsTag(paramContext, paramDataLayer));
    mPredicateMap = new HashMap();
    addPredicate(new ContainsPredicate());
    addPredicate(new EndsWithPredicate());
    addPredicate(new EqualsPredicate());
    addPredicate(new GreaterEqualsPredicate());
    addPredicate(new GreaterThanPredicate());
    addPredicate(new LessEqualsPredicate());
    addPredicate(new LessThanPredicate());
    addPredicate(new RegexPredicate());
    addPredicate(new StartsWithPredicate());
    mMacroMap = new HashMap();
    addMacro(new AdvertiserIdMacro(paramContext));
    addMacro(new AdvertisingTrackingEnabledMacro());
    addMacro(new AdwordsClickReferrerMacro(paramContext));
    addMacro(new AppIdMacro(paramContext));
    addMacro(new AppNameMacro(paramContext));
    addMacro(new AppVersionMacro(paramContext));
    addMacro(new ConstantMacro());
    addMacro(new ContainerVersionMacro(this));
    addMacro(new CustomFunctionCall(paramCustomEvaluator1));
    addMacro(new DataLayerMacro(paramDataLayer));
    addMacro(new DeviceIdMacro(paramContext));
    addMacro(new DeviceNameMacro());
    addMacro(new EncodeMacro());
    addMacro(new EventMacro(this));
    addMacro(new GtmVersionMacro());
    addMacro(new HashMacro());
    addMacro(new InstallReferrerMacro(paramContext));
    addMacro(new JoinerMacro());
    addMacro(new LanguageMacro());
    addMacro(new MobileAdwordsUniqueIdMacro(paramContext));
    addMacro(new OsVersionMacro());
    addMacro(new PlatformMacro());
    addMacro(new RandomMacro());
    addMacro(new RegexGroupMacro());
    addMacro(new ResolutionMacro(paramContext));
    addMacro(new RuntimeVersionMacro());
    addMacro(new SdkVersionMacro());
    addMacro(new TimeMacro());
    mMacroLookup = new HashMap();
    paramDataLayer = mRules.iterator();
    while (paramDataLayer.hasNext())
    {
      paramCustomEvaluator1 = (ResourceUtil.ExpandedRule)paramDataLayer.next();
      if (paramEventInfoDistributor.debugMode())
      {
        verifyFunctionAndNameListSizes(paramCustomEvaluator1.getAddMacros(), paramCustomEvaluator1.getAddMacroRuleNames(), "add macro");
        verifyFunctionAndNameListSizes(paramCustomEvaluator1.getRemoveMacros(), paramCustomEvaluator1.getRemoveMacroRuleNames(), "remove macro");
        verifyFunctionAndNameListSizes(paramCustomEvaluator1.getAddTags(), paramCustomEvaluator1.getAddTagRuleNames(), "add tag");
        verifyFunctionAndNameListSizes(paramCustomEvaluator1.getRemoveTags(), paramCustomEvaluator1.getRemoveTagRuleNames(), "remove tag");
      }
      int i = 0;
      while (i < paramCustomEvaluator1.getAddMacros().size())
      {
        paramCustomEvaluator2 = (ResourceUtil.ExpandedFunctionCall)paramCustomEvaluator1.getAddMacros().get(i);
        paramExpandedResource = "Unknown";
        paramContext = paramExpandedResource;
        if (paramEventInfoDistributor.debugMode())
        {
          paramContext = paramExpandedResource;
          if (i < paramCustomEvaluator1.getAddMacroRuleNames().size()) {
            paramContext = (String)paramCustomEvaluator1.getAddMacroRuleNames().get(i);
          }
        }
        paramExpandedResource = getOrAddMacroInfo(mMacroLookup, getFunctionName(paramCustomEvaluator2));
        paramExpandedResource.addRule(paramCustomEvaluator1);
        paramExpandedResource.addAddMacroForRule(paramCustomEvaluator1, paramCustomEvaluator2);
        paramExpandedResource.addAddMacroRuleNameForRule(paramCustomEvaluator1, paramContext);
        i += 1;
      }
      i = 0;
      while (i < paramCustomEvaluator1.getRemoveMacros().size())
      {
        paramCustomEvaluator2 = (ResourceUtil.ExpandedFunctionCall)paramCustomEvaluator1.getRemoveMacros().get(i);
        paramExpandedResource = "Unknown";
        paramContext = paramExpandedResource;
        if (paramEventInfoDistributor.debugMode())
        {
          paramContext = paramExpandedResource;
          if (i < paramCustomEvaluator1.getRemoveMacroRuleNames().size()) {
            paramContext = (String)paramCustomEvaluator1.getRemoveMacroRuleNames().get(i);
          }
        }
        paramExpandedResource = getOrAddMacroInfo(mMacroLookup, getFunctionName(paramCustomEvaluator2));
        paramExpandedResource.addRule(paramCustomEvaluator1);
        paramExpandedResource.addRemoveMacroForRule(paramCustomEvaluator1, paramCustomEvaluator2);
        paramExpandedResource.addRemoveMacroRuleNameForRule(paramCustomEvaluator1, paramContext);
        i += 1;
      }
    }
    paramContext = mResource.getAllMacros().entrySet().iterator();
    while (paramContext.hasNext())
    {
      paramExpandedResource = (Map.Entry)paramContext.next();
      paramDataLayer = ((List)paramExpandedResource.getValue()).iterator();
      while (paramDataLayer.hasNext())
      {
        paramCustomEvaluator1 = (ResourceUtil.ExpandedFunctionCall)paramDataLayer.next();
        if (!Types.valueToBoolean((TypeSystem.Value)paramCustomEvaluator1.getProperties().get(Key.NOT_DEFAULT_MACRO.toString())).booleanValue()) {
          getOrAddMacroInfo(mMacroLookup, (String)paramExpandedResource.getKey()).setDefault(paramCustomEvaluator1);
        }
      }
    }
  }
  
  private static void addFunctionImplToMap(Map paramMap, FunctionCallImplementation paramFunctionCallImplementation)
  {
    if (paramMap.containsKey(paramFunctionCallImplementation.getInstanceFunctionId())) {
      throw new IllegalArgumentException("Duplicate function type name: " + paramFunctionCallImplementation.getInstanceFunctionId());
    }
    paramMap.put(paramFunctionCallImplementation.getInstanceFunctionId(), paramFunctionCallImplementation);
  }
  
  private ObjectAndStatic calculateGenericToRun(Set paramSet1, Set paramSet2, AddRemoveSetPopulator paramAddRemoveSetPopulator, RuleEvaluationStepInfoBuilder paramRuleEvaluationStepInfoBuilder)
  {
    HashSet localHashSet1 = new HashSet();
    HashSet localHashSet2 = new HashSet();
    boolean bool = true;
    paramSet1 = paramSet1.iterator();
    while (paramSet1.hasNext())
    {
      ResourceUtil.ExpandedRule localExpandedRule = (ResourceUtil.ExpandedRule)paramSet1.next();
      ResolvedRuleBuilder localResolvedRuleBuilder = paramRuleEvaluationStepInfoBuilder.createResolvedRuleBuilder();
      ObjectAndStatic localObjectAndStatic = evaluatePredicatesInRule(localExpandedRule, paramSet2, localResolvedRuleBuilder);
      if (((Boolean)localObjectAndStatic.getObject()).booleanValue()) {
        paramAddRemoveSetPopulator.rulePassed(localExpandedRule, localHashSet1, localHashSet2, localResolvedRuleBuilder);
      }
      if ((bool) && (localObjectAndStatic.isStatic())) {
        bool = true;
      } else {
        bool = false;
      }
    }
    localHashSet1.removeAll(localHashSet2);
    paramRuleEvaluationStepInfoBuilder.setEnabledFunctions(localHashSet1);
    return new ObjectAndStatic(localHashSet1, bool);
  }
  
  private ObjectAndStatic evaluateMacroReferenceCycleDetection(String paramString, Set paramSet, MacroEvaluationInfoBuilder paramMacroEvaluationInfoBuilder)
  {
    Object localObject = (CachedMacro)mMacroEvaluationCache.get(paramString);
    if ((localObject != null) && (!eventInfoDistributor.debugMode()))
    {
      pushUnevaluatedValueToDataLayer(((CachedMacro)localObject).getPushAfterEvaluate(), paramSet);
      return ((CachedMacro)localObject).getObjectAndStatic();
    }
    localObject = (MacroInfo)mMacroLookup.get(paramString);
    if (localObject == null)
    {
      Log.e("Invalid macro: " + paramString);
      return DEFAULT_VALUE_AND_STATIC;
    }
    ObjectAndStatic localObjectAndStatic = calculateMacrosToRun(paramString, ((MacroInfo)localObject).getRules(), ((MacroInfo)localObject).getAddMacros(), ((MacroInfo)localObject).getAddMacroRuleNames(), ((MacroInfo)localObject).getRemoveMacros(), ((MacroInfo)localObject).getRemoveMacroRuleNames(), paramSet, paramMacroEvaluationInfoBuilder.createRulesEvaluation());
    if (((Set)localObjectAndStatic.getObject()).isEmpty()) {}
    for (localObject = ((MacroInfo)localObject).getDefault(); localObject == null; localObject = (ResourceUtil.ExpandedFunctionCall)((Set)localObjectAndStatic.getObject()).iterator().next())
    {
      return DEFAULT_VALUE_AND_STATIC;
      if (((Set)localObjectAndStatic.getObject()).size() > 1) {
        Log.w("Multiple macros active for macroName " + paramString);
      }
    }
    paramMacroEvaluationInfoBuilder = executeFunction(mMacroMap, (ResourceUtil.ExpandedFunctionCall)localObject, paramSet, paramMacroEvaluationInfoBuilder.createResult());
    boolean bool;
    if ((localObjectAndStatic.isStatic()) && (paramMacroEvaluationInfoBuilder.isStatic()))
    {
      bool = true;
      if (paramMacroEvaluationInfoBuilder != DEFAULT_VALUE_AND_STATIC) {
        break label328;
      }
    }
    label328:
    for (paramMacroEvaluationInfoBuilder = DEFAULT_VALUE_AND_STATIC;; paramMacroEvaluationInfoBuilder = new ObjectAndStatic(paramMacroEvaluationInfoBuilder.getObject(), bool))
    {
      localObject = ((ResourceUtil.ExpandedFunctionCall)localObject).getPushAfterEvaluate();
      if (paramMacroEvaluationInfoBuilder.isStatic()) {
        mMacroEvaluationCache.put(paramString, new CachedMacro(paramMacroEvaluationInfoBuilder, (TypeSystem.Value)localObject));
      }
      pushUnevaluatedValueToDataLayer((TypeSystem.Value)localObject, paramSet);
      return paramMacroEvaluationInfoBuilder;
      bool = false;
      break;
    }
  }
  
  private ObjectAndStatic executeFunction(Map paramMap, ResourceUtil.ExpandedFunctionCall paramExpandedFunctionCall, Set paramSet, ResolvedFunctionCallBuilder paramResolvedFunctionCallBuilder)
  {
    Object localObject1 = (TypeSystem.Value)paramExpandedFunctionCall.getProperties().get(Key.FUNCTION.toString());
    if (localObject1 == null)
    {
      Log.e("No function id in properties");
      return DEFAULT_VALUE_AND_STATIC;
    }
    localObject1 = functionId;
    paramMap = (FunctionCallImplementation)paramMap.get(localObject1);
    if (paramMap == null)
    {
      Log.e((String)localObject1 + " has no backing implementation.");
      return DEFAULT_VALUE_AND_STATIC;
    }
    Object localObject2 = (ObjectAndStatic)mFunctionCallCache.get(paramExpandedFunctionCall);
    if ((localObject2 == null) || (eventInfoDistributor.debugMode()))
    {
      localObject2 = new HashMap();
      int i = 1;
      Iterator localIterator = paramExpandedFunctionCall.getProperties().entrySet().iterator();
      if (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        Object localObject3 = paramResolvedFunctionCallBuilder.createResolvedPropertyBuilder((String)localEntry.getKey());
        localObject3 = macroExpandValue((TypeSystem.Value)localEntry.getValue(), paramSet, ((ResolvedPropertyBuilder)localObject3).createPropertyValueBuilder((TypeSystem.Value)localEntry.getValue()));
        if (localObject3 == DEFAULT_VALUE_AND_STATIC) {
          return DEFAULT_VALUE_AND_STATIC;
        }
        if (((ObjectAndStatic)localObject3).isStatic()) {
          paramExpandedFunctionCall.updateCacheableProperty((String)localEntry.getKey(), (TypeSystem.Value)((ObjectAndStatic)localObject3).getObject());
        }
        for (;;)
        {
          ((Map)localObject2).put(localEntry.getKey(), ((ObjectAndStatic)localObject3).getObject());
          break;
          i = 0;
        }
      }
      if (!paramMap.hasRequiredKeys(((Map)localObject2).keySet()))
      {
        Log.e("Incorrect keys for function " + (String)localObject1 + " required " + paramMap.getRequiredKeys() + " had " + ((Map)localObject2).keySet());
        return DEFAULT_VALUE_AND_STATIC;
      }
      if ((i != 0) && (paramMap.isCacheable())) {}
      for (boolean bool = true;; bool = false)
      {
        paramMap = new ObjectAndStatic(paramMap.evaluate((Map)localObject2), bool);
        if (bool) {
          mFunctionCallCache.put(paramExpandedFunctionCall, paramMap);
        }
        paramResolvedFunctionCallBuilder.setFunctionResult((TypeSystem.Value)paramMap.getObject());
        return paramMap;
      }
    }
    return localObject2;
  }
  
  private static String getFunctionName(ResourceUtil.ExpandedFunctionCall paramExpandedFunctionCall)
  {
    return Types.valueToString((TypeSystem.Value)paramExpandedFunctionCall.getProperties().get(Key.INSTANCE_NAME.toString()));
  }
  
  private static MacroInfo getOrAddMacroInfo(Map paramMap, String paramString)
  {
    MacroInfo localMacroInfo2 = (MacroInfo)paramMap.get(paramString);
    MacroInfo localMacroInfo1 = localMacroInfo2;
    if (localMacroInfo2 == null)
    {
      localMacroInfo1 = new MacroInfo();
      paramMap.put(paramString, localMacroInfo1);
    }
    return localMacroInfo1;
  }
  
  private ObjectAndStatic macroExpandValue(TypeSystem.Value paramValue, Set paramSet, ValueBuilder paramValueBuilder)
  {
    if (!containsReferences) {
      return new ObjectAndStatic(paramValue, true);
    }
    ObjectAndStatic localObjectAndStatic1;
    switch (type)
    {
    default: 
      break;
    case 5: 
    case 6: 
      Log.e("Unknown type: " + type);
      return DEFAULT_VALUE_AND_STATIC;
    case 2: 
      localValue = ResourceUtil.newValueBasedOnValue(paramValue);
      listItem = new TypeSystem.Value[listItem.length];
      i = 0;
      while (i < listItem.length)
      {
        localObjectAndStatic1 = macroExpandValue(listItem[i], paramSet, paramValueBuilder.getListItem(i));
        if (localObjectAndStatic1 == DEFAULT_VALUE_AND_STATIC) {
          return DEFAULT_VALUE_AND_STATIC;
        }
        listItem[i] = ((TypeSystem.Value)localObjectAndStatic1.getObject());
        i += 1;
      }
      return new ObjectAndStatic(localValue, false);
    case 3: 
      localValue = ResourceUtil.newValueBasedOnValue(paramValue);
      if (mapKey.length != mapValue.length)
      {
        Log.e("Invalid serving value: " + paramValue.toString());
        return DEFAULT_VALUE_AND_STATIC;
      }
      mapKey = new TypeSystem.Value[mapKey.length];
      mapValue = new TypeSystem.Value[mapKey.length];
      i = 0;
      while (i < mapKey.length)
      {
        localObjectAndStatic1 = macroExpandValue(mapKey[i], paramSet, paramValueBuilder.getMapKey(i));
        ObjectAndStatic localObjectAndStatic2 = macroExpandValue(mapValue[i], paramSet, paramValueBuilder.getMapValue(i));
        if ((localObjectAndStatic1 == DEFAULT_VALUE_AND_STATIC) || (localObjectAndStatic2 == DEFAULT_VALUE_AND_STATIC)) {
          return DEFAULT_VALUE_AND_STATIC;
        }
        mapKey[i] = ((TypeSystem.Value)localObjectAndStatic1.getObject());
        mapValue[i] = ((TypeSystem.Value)localObjectAndStatic2.getObject());
        i += 1;
      }
      return new ObjectAndStatic(localValue, false);
    case 4: 
      if (paramSet.contains(macroReference))
      {
        Log.e("Macro cycle detected.  Current macro reference: " + macroReference + "." + "  Previous macro references: " + paramSet.toString() + ".");
        return DEFAULT_VALUE_AND_STATIC;
      }
      paramSet.add(macroReference);
      paramValueBuilder = ValueEscapeUtil.applyEscapings(evaluateMacroReferenceCycleDetection(macroReference, paramSet, paramValueBuilder.createValueMacroEvaluationInfoExtension()), escaping);
      paramSet.remove(macroReference);
      return paramValueBuilder;
    }
    TypeSystem.Value localValue = ResourceUtil.newValueBasedOnValue(paramValue);
    templateToken = new TypeSystem.Value[templateToken.length];
    int i = 0;
    while (i < templateToken.length)
    {
      localObjectAndStatic1 = macroExpandValue(templateToken[i], paramSet, paramValueBuilder.getTemplateToken(i));
      if (localObjectAndStatic1 == DEFAULT_VALUE_AND_STATIC) {
        return DEFAULT_VALUE_AND_STATIC;
      }
      templateToken[i] = ((TypeSystem.Value)localObjectAndStatic1.getObject());
      i += 1;
    }
    return new ObjectAndStatic(localValue, false);
  }
  
  private void pushUnevaluatedValueToDataLayer(TypeSystem.Value paramValue, Set paramSet)
  {
    if (paramValue == null) {
      return;
    }
    paramValue = macroExpandValue(paramValue, paramSet, new NoopValueBuilder());
    if (paramValue != DEFAULT_VALUE_AND_STATIC)
    {
      paramValue = Types.valueToObject((TypeSystem.Value)paramValue.getObject());
      if ((paramValue instanceof Map))
      {
        paramValue = (Map)paramValue;
        mDataLayer.push(paramValue);
        return;
      }
      if ((paramValue instanceof List))
      {
        paramValue = ((List)paramValue).iterator();
        while (paramValue.hasNext())
        {
          paramSet = paramValue.next();
          if ((paramSet instanceof Map))
          {
            paramSet = (Map)paramSet;
            mDataLayer.push(paramSet);
          }
          else
          {
            Log.w("pushAfterEvaluate: value not a Map");
          }
        }
      }
      Log.w("pushAfterEvaluate: value not a Map or List");
    }
  }
  
  private static void verifyFunctionAndNameListSizes(List paramList1, List paramList2, String paramString)
  {
    if (paramList1.size() != paramList2.size()) {
      Log.i("Invalid resource: imbalance of rule names of functions for " + paramString + " operation. Using default rule name instead");
    }
  }
  
  void addMacro(FunctionCallImplementation paramFunctionCallImplementation)
  {
    addFunctionImplToMap(mMacroMap, paramFunctionCallImplementation);
  }
  
  void addPredicate(FunctionCallImplementation paramFunctionCallImplementation)
  {
    addFunctionImplToMap(mPredicateMap, paramFunctionCallImplementation);
  }
  
  void addTrackingTag(FunctionCallImplementation paramFunctionCallImplementation)
  {
    addFunctionImplToMap(mTrackingTagMap, paramFunctionCallImplementation);
  }
  
  ObjectAndStatic calculateMacrosToRun(String paramString, Set paramSet1, final Map paramMap1, final Map paramMap2, final Map paramMap3, final Map paramMap4, Set paramSet2, RuleEvaluationStepInfoBuilder paramRuleEvaluationStepInfoBuilder)
  {
    calculateGenericToRun(paramSet1, paramSet2, new AddRemoveSetPopulator()
    {
      public void rulePassed(ResourceUtil.ExpandedRule paramAnonymousExpandedRule, Set paramAnonymousSet1, Set paramAnonymousSet2, ResolvedRuleBuilder paramAnonymousResolvedRuleBuilder)
      {
        List localList1 = (List)paramMap1.get(paramAnonymousExpandedRule);
        List localList2 = (List)paramMap2.get(paramAnonymousExpandedRule);
        if (localList1 != null)
        {
          paramAnonymousSet1.addAll(localList1);
          paramAnonymousResolvedRuleBuilder.getAddedMacroFunctions().translateAndAddAll(localList1, localList2);
        }
        paramAnonymousSet1 = (List)paramMap3.get(paramAnonymousExpandedRule);
        paramAnonymousExpandedRule = (List)paramMap4.get(paramAnonymousExpandedRule);
        if (paramAnonymousSet1 != null)
        {
          paramAnonymousSet2.addAll(paramAnonymousSet1);
          paramAnonymousResolvedRuleBuilder.getRemovedMacroFunctions().translateAndAddAll(paramAnonymousSet1, paramAnonymousExpandedRule);
        }
      }
    }, paramRuleEvaluationStepInfoBuilder);
  }
  
  ObjectAndStatic calculateTagsToRun(Set paramSet, RuleEvaluationStepInfoBuilder paramRuleEvaluationStepInfoBuilder)
  {
    calculateGenericToRun(paramSet, new HashSet(), new AddRemoveSetPopulator()
    {
      public void rulePassed(ResourceUtil.ExpandedRule paramAnonymousExpandedRule, Set paramAnonymousSet1, Set paramAnonymousSet2, ResolvedRuleBuilder paramAnonymousResolvedRuleBuilder)
      {
        paramAnonymousSet1.addAll(paramAnonymousExpandedRule.getAddTags());
        paramAnonymousSet2.addAll(paramAnonymousExpandedRule.getRemoveTags());
        paramAnonymousResolvedRuleBuilder.getAddedTagFunctions().translateAndAddAll(paramAnonymousExpandedRule.getAddTags(), paramAnonymousExpandedRule.getAddTagRuleNames());
        paramAnonymousResolvedRuleBuilder.getRemovedTagFunctions().translateAndAddAll(paramAnonymousExpandedRule.getRemoveTags(), paramAnonymousExpandedRule.getRemoveTagRuleNames());
      }
    }, paramRuleEvaluationStepInfoBuilder);
  }
  
  public ObjectAndStatic evaluateMacroReference(String paramString)
  {
    EventInfoBuilder localEventInfoBuilder = eventInfoDistributor.createMacroEvalutionEventInfo(paramString);
    paramString = evaluateMacroReferenceCycleDetection(paramString, new HashSet(), localEventInfoBuilder.createMacroEvaluationInfoBuilder());
    localEventInfoBuilder.processEventInfo();
    return paramString;
  }
  
  ObjectAndStatic evaluatePredicate(ResourceUtil.ExpandedFunctionCall paramExpandedFunctionCall, Set paramSet, ResolvedFunctionCallBuilder paramResolvedFunctionCallBuilder)
  {
    paramExpandedFunctionCall = executeFunction(mPredicateMap, paramExpandedFunctionCall, paramSet, paramResolvedFunctionCallBuilder);
    paramSet = Types.valueToBoolean((TypeSystem.Value)paramExpandedFunctionCall.getObject());
    paramResolvedFunctionCallBuilder.setFunctionResult(Types.objectToValue(paramSet));
    return new ObjectAndStatic(paramSet, paramExpandedFunctionCall.isStatic());
  }
  
  ObjectAndStatic evaluatePredicatesInRule(ResourceUtil.ExpandedRule paramExpandedRule, Set paramSet, ResolvedRuleBuilder paramResolvedRuleBuilder)
  {
    boolean bool = true;
    Object localObject = paramExpandedRule.getNegativePredicates().iterator();
    while (((Iterator)localObject).hasNext())
    {
      ObjectAndStatic localObjectAndStatic = evaluatePredicate((ResourceUtil.ExpandedFunctionCall)((Iterator)localObject).next(), paramSet, paramResolvedRuleBuilder.createNegativePredicate());
      if (((Boolean)localObjectAndStatic.getObject()).booleanValue())
      {
        paramResolvedRuleBuilder.setValue(Types.objectToValue(Boolean.valueOf(false)));
        return new ObjectAndStatic(Boolean.valueOf(false), localObjectAndStatic.isStatic());
      }
      if ((bool) && (localObjectAndStatic.isStatic())) {
        bool = true;
      } else {
        bool = false;
      }
    }
    paramExpandedRule = paramExpandedRule.getPositivePredicates().iterator();
    while (paramExpandedRule.hasNext())
    {
      localObject = evaluatePredicate((ResourceUtil.ExpandedFunctionCall)paramExpandedRule.next(), paramSet, paramResolvedRuleBuilder.createPositivePredicate());
      if (!((Boolean)((ObjectAndStatic)localObject).getObject()).booleanValue())
      {
        paramResolvedRuleBuilder.setValue(Types.objectToValue(Boolean.valueOf(false)));
        return new ObjectAndStatic(Boolean.valueOf(false), ((ObjectAndStatic)localObject).isStatic());
      }
      if ((bool) && (((ObjectAndStatic)localObject).isStatic())) {
        bool = true;
      } else {
        bool = false;
      }
    }
    paramResolvedRuleBuilder.setValue(Types.objectToValue(Boolean.valueOf(true)));
    return new ObjectAndStatic(Boolean.valueOf(true), bool);
  }
  
  public void evaluateTags(String paramString)
  {
    try
    {
      setCurrentEventName(paramString);
      paramString = eventInfoDistributor.createDataLayerEventEvaluationEventInfo(paramString);
      DataLayerEventEvaluationInfoBuilder localDataLayerEventEvaluationInfoBuilder = paramString.createDataLayerEventEvaluationInfoBuilder();
      Iterator localIterator = ((Set)calculateTagsToRun(mRules, localDataLayerEventEvaluationInfoBuilder.createRulesEvaluation()).getObject()).iterator();
      while (localIterator.hasNext())
      {
        ResourceUtil.ExpandedFunctionCall localExpandedFunctionCall = (ResourceUtil.ExpandedFunctionCall)localIterator.next();
        executeFunction(mTrackingTagMap, localExpandedFunctionCall, new HashSet(), localDataLayerEventEvaluationInfoBuilder.createAndAddResult());
      }
      paramString.processEventInfo();
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
    setCurrentEventName(null);
  }
  
  String getCurrentEventName()
  {
    try
    {
      String str = mCurrentEventName;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public ResourceUtil.ExpandedResource getResource()
  {
    return mResource;
  }
  
  void setCurrentEventName(String paramString)
  {
    try
    {
      mCurrentEventName = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setSupplementals(List paramList)
  {
    for (;;)
    {
      try
      {
        paramList = paramList.iterator();
        if (!paramList.hasNext()) {
          break;
        }
        Serving.Supplemental localSupplemental = (Serving.Supplemental)paramList.next();
        if ((name == null) || (!name.startsWith("gaExperiment:"))) {
          Log.v("Ignored supplemental: " + localSupplemental);
        } else {
          ExperimentMacroHelper.handleExperimentSupplemental(mDataLayer, localSupplemental);
        }
      }
      catch (Throwable paramList)
      {
        throw paramList;
      }
    }
  }
  
  static abstract interface AddRemoveSetPopulator
  {
    public abstract void rulePassed(ResourceUtil.ExpandedRule paramExpandedRule, Set paramSet1, Set paramSet2, ResolvedRuleBuilder paramResolvedRuleBuilder);
  }
  
  private static class CachedMacro
  {
    private ObjectAndStatic<TypeSystem.Value> mObjectAndStatic;
    private TypeSystem.Value mPushAfterEvaluate;
    
    public CachedMacro(ObjectAndStatic paramObjectAndStatic)
    {
      this(paramObjectAndStatic, null);
    }
    
    public CachedMacro(ObjectAndStatic paramObjectAndStatic, TypeSystem.Value paramValue)
    {
      mObjectAndStatic = paramObjectAndStatic;
      mPushAfterEvaluate = paramValue;
    }
    
    public ObjectAndStatic getObjectAndStatic()
    {
      return mObjectAndStatic;
    }
    
    public TypeSystem.Value getPushAfterEvaluate()
    {
      return mPushAfterEvaluate;
    }
    
    public int getSize()
    {
      int j = ((TypeSystem.Value)mObjectAndStatic.getObject()).getCachedSize();
      if (mPushAfterEvaluate == null) {}
      for (int i = 0;; i = mPushAfterEvaluate.getCachedSize()) {
        return i + j;
      }
    }
  }
  
  private static class MacroInfo
  {
    private final Map<ResourceUtil.ExpandedRule, List<String>> mAddMacroNames = new HashMap();
    private final Map<ResourceUtil.ExpandedRule, List<ResourceUtil.ExpandedFunctionCall>> mAddMacros = new HashMap();
    private ResourceUtil.ExpandedFunctionCall mDefault;
    private final Map<ResourceUtil.ExpandedRule, List<String>> mRemoveMacroNames = new HashMap();
    private final Map<ResourceUtil.ExpandedRule, List<ResourceUtil.ExpandedFunctionCall>> mRemoveMacros = new HashMap();
    private final Set<ResourceUtil.ExpandedRule> mRules = new HashSet();
    
    public MacroInfo() {}
    
    public void addAddMacroForRule(ResourceUtil.ExpandedRule paramExpandedRule, ResourceUtil.ExpandedFunctionCall paramExpandedFunctionCall)
    {
      throw new java.lang.Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a5 = a4\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
    }
    
    public void addAddMacroRuleNameForRule(ResourceUtil.ExpandedRule paramExpandedRule, String paramString)
    {
      throw new java.lang.Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a5 = a4\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
    }
    
    public void addRemoveMacroForRule(ResourceUtil.ExpandedRule paramExpandedRule, ResourceUtil.ExpandedFunctionCall paramExpandedFunctionCall)
    {
      throw new java.lang.Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a5 = a4\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
    }
    
    public void addRemoveMacroRuleNameForRule(ResourceUtil.ExpandedRule paramExpandedRule, String paramString)
    {
      throw new java.lang.Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a5 = a4\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
    }
    
    public void addRule(ResourceUtil.ExpandedRule paramExpandedRule)
    {
      mRules.add(paramExpandedRule);
    }
    
    public Map getAddMacroRuleNames()
    {
      return mAddMacroNames;
    }
    
    public Map getAddMacros()
    {
      return mAddMacros;
    }
    
    public ResourceUtil.ExpandedFunctionCall getDefault()
    {
      return mDefault;
    }
    
    public Map getRemoveMacroRuleNames()
    {
      return mRemoveMacroNames;
    }
    
    public Map getRemoveMacros()
    {
      return mRemoveMacros;
    }
    
    public Set getRules()
    {
      return mRules;
    }
    
    public void setDefault(ResourceUtil.ExpandedFunctionCall paramExpandedFunctionCall)
    {
      mDefault = paramExpandedFunctionCall;
    }
  }
}
