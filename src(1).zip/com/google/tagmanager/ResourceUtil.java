package com.google.tagmanager;

import com.google.analytics.containertag.common.Key;
import com.google.analytics.containertag.proto.Serving.FunctionCall;
import com.google.analytics.containertag.proto.Serving.Property;
import com.google.analytics.containertag.proto.Serving.Resource;
import com.google.analytics.containertag.proto.Serving.Rule;
import com.google.analytics.containertag.proto.Serving.ServingValue;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import com.google.tagmanager.protobuf.nano.ExtendableMessageNano;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

class ResourceUtil
{
  private static final int BUFFER_SIZE = 1024;
  
  private ResourceUtil() {}
  
  public static void copyStream(InputStream paramInputStream, OutputStream paramOutputStream)
    throws IOException
  {
    byte[] arrayOfByte = new byte['?'];
    for (;;)
    {
      int i = paramInputStream.read(arrayOfByte);
      if (i == -1) {
        return;
      }
      paramOutputStream.write(arrayOfByte, 0, i);
    }
  }
  
  private static ExpandedFunctionCall expandFunctionCall(Serving.FunctionCall paramFunctionCall, Serving.Resource paramResource, TypeSystem.Value[] paramArrayOfValue, int paramInt)
    throws ResourceUtil.InvalidResourceException
  {
    ExpandedFunctionCallBuilder localExpandedFunctionCallBuilder = ExpandedFunctionCall.newBuilder();
    paramFunctionCall = property;
    int i = paramFunctionCall.length;
    paramInt = 0;
    if (paramInt < i)
    {
      int j = paramFunctionCall[paramInt];
      Object localObject = (Serving.Property)getWithBoundsCheck(property, Integer.valueOf(j).intValue(), "properties");
      String str = (String)getWithBoundsCheck(key, type, "keys");
      localObject = (TypeSystem.Value)getWithBoundsCheck(paramArrayOfValue, value, "values");
      if (Key.PUSH_AFTER_EVALUATE.toString().equals(str)) {
        localExpandedFunctionCallBuilder.setPushAfterEvaluate((TypeSystem.Value)localObject);
      }
      for (;;)
      {
        paramInt += 1;
        break;
        localExpandedFunctionCallBuilder.addProperty(str, (TypeSystem.Value)localObject);
      }
    }
    return localExpandedFunctionCallBuilder.build();
  }
  
  private static ExpandedRule expandRule(Serving.Rule paramRule, List paramList1, List paramList2, List paramList3, Serving.Resource paramResource)
  {
    ExpandedRuleBuilder localExpandedRuleBuilder = ExpandedRule.newBuilder();
    int[] arrayOfInt = positivePredicate;
    int j = arrayOfInt.length;
    int i = 0;
    while (i < j)
    {
      localExpandedRuleBuilder.addPositivePredicate((ExpandedFunctionCall)paramList3.get(Integer.valueOf(arrayOfInt[i]).intValue()));
      i += 1;
    }
    arrayOfInt = negativePredicate;
    j = arrayOfInt.length;
    i = 0;
    while (i < j)
    {
      localExpandedRuleBuilder.addNegativePredicate((ExpandedFunctionCall)paramList3.get(Integer.valueOf(arrayOfInt[i]).intValue()));
      i += 1;
    }
    paramList3 = addTag;
    j = paramList3.length;
    i = 0;
    while (i < j)
    {
      localExpandedRuleBuilder.addAddTag((ExpandedFunctionCall)paramList1.get(Integer.valueOf(paramList3[i]).intValue()));
      i += 1;
    }
    paramList3 = addTagRuleName;
    j = paramList3.length;
    i = 0;
    int k;
    while (i < j)
    {
      k = paramList3[i];
      localExpandedRuleBuilder.addAddTagRuleName(value[Integer.valueOf(k).intValue()].string);
      i += 1;
    }
    paramList3 = removeTag;
    j = paramList3.length;
    i = 0;
    while (i < j)
    {
      localExpandedRuleBuilder.addRemoveTag((ExpandedFunctionCall)paramList1.get(Integer.valueOf(paramList3[i]).intValue()));
      i += 1;
    }
    paramList1 = removeTagRuleName;
    j = paramList1.length;
    i = 0;
    while (i < j)
    {
      k = paramList1[i];
      localExpandedRuleBuilder.addRemoveTagRuleName(value[Integer.valueOf(k).intValue()].string);
      i += 1;
    }
    paramList1 = addMacro;
    j = paramList1.length;
    i = 0;
    while (i < j)
    {
      localExpandedRuleBuilder.addAddMacro((ExpandedFunctionCall)paramList2.get(Integer.valueOf(paramList1[i]).intValue()));
      i += 1;
    }
    paramList1 = addMacroRuleName;
    j = paramList1.length;
    i = 0;
    while (i < j)
    {
      k = paramList1[i];
      localExpandedRuleBuilder.addAddMacroRuleName(value[Integer.valueOf(k).intValue()].string);
      i += 1;
    }
    paramList1 = removeMacro;
    j = paramList1.length;
    i = 0;
    while (i < j)
    {
      localExpandedRuleBuilder.addRemoveMacro((ExpandedFunctionCall)paramList2.get(Integer.valueOf(paramList1[i]).intValue()));
      i += 1;
    }
    paramRule = removeMacroRuleName;
    j = paramRule.length;
    i = 0;
    while (i < j)
    {
      k = paramRule[i];
      localExpandedRuleBuilder.addRemoveMacroRuleName(value[Integer.valueOf(k).intValue()].string);
      i += 1;
    }
    return localExpandedRuleBuilder.build();
  }
  
  private static TypeSystem.Value expandValue(int paramInt, Serving.Resource paramResource, TypeSystem.Value[] paramArrayOfValue, Set paramSet)
    throws ResourceUtil.InvalidResourceException
  {
    if (paramSet.contains(Integer.valueOf(paramInt))) {
      logAndThrow("Value cycle detected.  Current value reference: " + paramInt + "." + "  Previous value references: " + paramSet + ".");
    }
    TypeSystem.Value localValue2 = (TypeSystem.Value)getWithBoundsCheck(value, paramInt, "values");
    if (paramArrayOfValue[paramInt] != null) {
      return paramArrayOfValue[paramInt];
    }
    Object localObject = null;
    paramSet.add(Integer.valueOf(paramInt));
    switch (type)
    {
    default: 
      break;
    }
    for (;;)
    {
      if (localObject == null) {
        logAndThrow("Invalid value: " + localValue2);
      }
      paramArrayOfValue[paramInt] = localObject;
      paramSet.remove(Integer.valueOf(paramInt));
      return localObject;
      localObject = getServingValue(localValue2);
      TypeSystem.Value localValue3 = newValueBasedOnValue(localValue2);
      TypeSystem.Value localValue1 = localValue3;
      listItem = new TypeSystem.Value[listItem.length];
      int[] arrayOfInt = listItem;
      int k = arrayOfInt.length;
      int j = 0;
      int i = 0;
      int m;
      for (;;)
      {
        localObject = localValue1;
        if (j >= k) {
          break;
        }
        m = arrayOfInt[j];
        listItem[i] = expandValue(m, paramResource, paramArrayOfValue, paramSet);
        j += 1;
        i += 1;
      }
      localValue3 = newValueBasedOnValue(localValue2);
      localValue1 = localValue3;
      localObject = getServingValue(localValue2);
      if (mapKey.length != mapValue.length) {
        logAndThrow("Uneven map keys (" + mapKey.length + ") and map values (" + mapValue.length + ")");
      }
      mapKey = new TypeSystem.Value[mapKey.length];
      mapValue = new TypeSystem.Value[mapKey.length];
      arrayOfInt = mapKey;
      k = arrayOfInt.length;
      j = 0;
      i = 0;
      while (j < k)
      {
        m = arrayOfInt[j];
        mapKey[i] = expandValue(m, paramResource, paramArrayOfValue, paramSet);
        j += 1;
        i += 1;
      }
      arrayOfInt = mapValue;
      k = arrayOfInt.length;
      j = 0;
      i = 0;
      for (;;)
      {
        localObject = localValue1;
        if (j >= k) {
          break;
        }
        m = arrayOfInt[j];
        mapValue[i] = expandValue(m, paramResource, paramArrayOfValue, paramSet);
        j += 1;
        i += 1;
      }
      localValue1 = newValueBasedOnValue(localValue2);
      localObject = localValue1;
      macroReference = Types.valueToString(expandValue(getServingValuemacroNameReference, paramResource, paramArrayOfValue, paramSet));
      continue;
      localValue3 = newValueBasedOnValue(localValue2);
      localValue1 = localValue3;
      localObject = getServingValue(localValue2);
      templateToken = new TypeSystem.Value[templateToken.length];
      arrayOfInt = templateToken;
      k = arrayOfInt.length;
      j = 0;
      i = 0;
      for (;;)
      {
        localObject = localValue1;
        if (j >= k) {
          break;
        }
        m = arrayOfInt[j];
        templateToken[i] = expandValue(m, paramResource, paramArrayOfValue, paramSet);
        j += 1;
        i += 1;
      }
      localObject = localValue2;
    }
  }
  
  public static ExpandedResource getExpandedResource(Serving.Resource paramResource)
    throws ResourceUtil.InvalidResourceException
  {
    Object localObject = new TypeSystem.Value[value.length];
    int i = 0;
    while (i < value.length)
    {
      expandValue(i, paramResource, (TypeSystem.Value[])localObject, new HashSet(0));
      i += 1;
    }
    ExpandedResourceBuilder localExpandedResourceBuilder = ExpandedResource.newBuilder();
    ArrayList localArrayList1 = new ArrayList();
    i = 0;
    while (i < tag.length)
    {
      localArrayList1.add(expandFunctionCall(tag[i], paramResource, (TypeSystem.Value[])localObject, i));
      i += 1;
    }
    ArrayList localArrayList2 = new ArrayList();
    i = 0;
    while (i < predicate.length)
    {
      localArrayList2.add(expandFunctionCall(predicate[i], paramResource, (TypeSystem.Value[])localObject, i));
      i += 1;
    }
    ArrayList localArrayList3 = new ArrayList();
    i = 0;
    while (i < macro.length)
    {
      ExpandedFunctionCall localExpandedFunctionCall = expandFunctionCall(macro[i], paramResource, (TypeSystem.Value[])localObject, i);
      localExpandedResourceBuilder.addMacro(localExpandedFunctionCall);
      localArrayList3.add(localExpandedFunctionCall);
      i += 1;
    }
    localObject = rule;
    int j = localObject.length;
    i = 0;
    while (i < j)
    {
      localExpandedResourceBuilder.addRule(expandRule(localObject[i], localArrayList1, localArrayList3, localArrayList2, paramResource));
      i += 1;
    }
    localExpandedResourceBuilder.setVersion(version);
    localExpandedResourceBuilder.setResourceFormatVersion(resourceFormatVersion);
    return localExpandedResourceBuilder.build();
  }
  
  private static Serving.ServingValue getServingValue(TypeSystem.Value paramValue)
    throws ResourceUtil.InvalidResourceException
  {
    if ((Serving.ServingValue)paramValue.getExtension(Serving.ServingValue.ext) == null) {
      logAndThrow("Expected a ServingValue and didn't get one. Value is: " + paramValue);
    }
    return (Serving.ServingValue)paramValue.getExtension(Serving.ServingValue.ext);
  }
  
  private static Object getWithBoundsCheck(List paramList, int paramInt, String paramString)
    throws ResourceUtil.InvalidResourceException
  {
    if ((paramInt < 0) || (paramInt >= paramList.size())) {
      logAndThrow("Index out of bounds detected: " + paramInt + " in " + paramString);
    }
    return paramList.get(paramInt);
  }
  
  private static Object getWithBoundsCheck(Object[] paramArrayOfObject, int paramInt, String paramString)
    throws ResourceUtil.InvalidResourceException
  {
    if ((paramInt < 0) || (paramInt >= paramArrayOfObject.length)) {
      logAndThrow("Index out of bounds detected: " + paramInt + " in " + paramString);
    }
    return paramArrayOfObject[paramInt];
  }
  
  private static void logAndThrow(String paramString)
    throws ResourceUtil.InvalidResourceException
  {
    Log.e(paramString);
    throw new InvalidResourceException(paramString);
  }
  
  public static TypeSystem.Value newValueBasedOnValue(TypeSystem.Value paramValue)
  {
    TypeSystem.Value localValue = new TypeSystem.Value();
    type = type;
    escaping = ((int[])escaping.clone());
    if (containsReferences) {
      containsReferences = containsReferences;
    }
    return localValue;
  }
  
  public static class ExpandedFunctionCall
  {
    private final Map<String, TypeSystem.Value> mPropertiesMap;
    private final TypeSystem.Value mPushAfterEvaluate;
    
    private ExpandedFunctionCall(Map paramMap, TypeSystem.Value paramValue)
    {
      mPropertiesMap = paramMap;
      mPushAfterEvaluate = paramValue;
    }
    
    public static ResourceUtil.ExpandedFunctionCallBuilder newBuilder()
    {
      return new ResourceUtil.ExpandedFunctionCallBuilder(null);
    }
    
    public Map getProperties()
    {
      return Collections.unmodifiableMap(mPropertiesMap);
    }
    
    public TypeSystem.Value getPushAfterEvaluate()
    {
      return mPushAfterEvaluate;
    }
    
    public String toString()
    {
      return "Properties: " + getProperties() + " pushAfterEvaluate: " + mPushAfterEvaluate;
    }
    
    public void updateCacheableProperty(String paramString, TypeSystem.Value paramValue)
    {
      mPropertiesMap.put(paramString, paramValue);
    }
  }
  
  public static class ExpandedFunctionCallBuilder
  {
    private final Map<String, TypeSystem.Value> mPropertiesMap = new HashMap();
    private TypeSystem.Value mPushAfterEvaluate;
    
    private ExpandedFunctionCallBuilder() {}
    
    public ExpandedFunctionCallBuilder addProperty(String paramString, TypeSystem.Value paramValue)
    {
      mPropertiesMap.put(paramString, paramValue);
      return this;
    }
    
    public ResourceUtil.ExpandedFunctionCall build()
    {
      return new ResourceUtil.ExpandedFunctionCall(mPropertiesMap, mPushAfterEvaluate, null);
    }
    
    public ExpandedFunctionCallBuilder setPushAfterEvaluate(TypeSystem.Value paramValue)
    {
      mPushAfterEvaluate = paramValue;
      return this;
    }
  }
  
  public static class ExpandedResource
  {
    private final Map<String, List<ResourceUtil.ExpandedFunctionCall>> mMacros;
    private final int mResourceFormatVersion;
    private final List<ResourceUtil.ExpandedRule> mRules;
    private final String mVersion;
    
    private ExpandedResource(List paramList, Map paramMap, String paramString, int paramInt)
    {
      mRules = Collections.unmodifiableList(paramList);
      mMacros = Collections.unmodifiableMap(paramMap);
      mVersion = paramString;
      mResourceFormatVersion = paramInt;
    }
    
    public static ResourceUtil.ExpandedResourceBuilder newBuilder()
    {
      return new ResourceUtil.ExpandedResourceBuilder(null);
    }
    
    public Map getAllMacros()
    {
      return mMacros;
    }
    
    public List getMacros(String paramString)
    {
      return (List)mMacros.get(paramString);
    }
    
    public int getResourceFormatVersion()
    {
      return mResourceFormatVersion;
    }
    
    public List getRules()
    {
      return mRules;
    }
    
    public String getVersion()
    {
      return mVersion;
    }
    
    public String toString()
    {
      return "Rules: " + getRules() + "  Macros: " + mMacros;
    }
  }
  
  public static class ExpandedResourceBuilder
  {
    private final Map<String, List<ResourceUtil.ExpandedFunctionCall>> mMacros = new HashMap();
    private int mResourceFormatVersion = 0;
    private final List<ResourceUtil.ExpandedRule> mRules = new ArrayList();
    private String mVersion = "";
    
    private ExpandedResourceBuilder() {}
    
    public ExpandedResourceBuilder addMacro(ResourceUtil.ExpandedFunctionCall paramExpandedFunctionCall)
    {
      throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a5 = a4\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
    }
    
    public ExpandedResourceBuilder addRule(ResourceUtil.ExpandedRule paramExpandedRule)
    {
      mRules.add(paramExpandedRule);
      return this;
    }
    
    public ResourceUtil.ExpandedResource build()
    {
      return new ResourceUtil.ExpandedResource(mRules, mMacros, mVersion, mResourceFormatVersion, null);
    }
    
    public ExpandedResourceBuilder setResourceFormatVersion(int paramInt)
    {
      mResourceFormatVersion = paramInt;
      return this;
    }
    
    public ExpandedResourceBuilder setVersion(String paramString)
    {
      mVersion = paramString;
      return this;
    }
  }
  
  public static class ExpandedRule
  {
    private final List<String> mAddMacroRuleNames;
    private final List<ResourceUtil.ExpandedFunctionCall> mAddMacros;
    private final List<String> mAddTagRuleNames;
    private final List<ResourceUtil.ExpandedFunctionCall> mAddTags;
    private final List<ResourceUtil.ExpandedFunctionCall> mNegativePredicates;
    private final List<ResourceUtil.ExpandedFunctionCall> mPositivePredicates;
    private final List<String> mRemoveMacroRuleNames;
    private final List<ResourceUtil.ExpandedFunctionCall> mRemoveMacros;
    private final List<String> mRemoveTagRuleNames;
    private final List<ResourceUtil.ExpandedFunctionCall> mRemoveTags;
    
    private ExpandedRule(List paramList1, List paramList2, List paramList3, List paramList4, List paramList5, List paramList6, List paramList7, List paramList8, List paramList9, List paramList10)
    {
      mPositivePredicates = Collections.unmodifiableList(paramList1);
      mNegativePredicates = Collections.unmodifiableList(paramList2);
      mAddTags = Collections.unmodifiableList(paramList3);
      mRemoveTags = Collections.unmodifiableList(paramList4);
      mAddMacros = Collections.unmodifiableList(paramList5);
      mRemoveMacros = Collections.unmodifiableList(paramList6);
      mAddMacroRuleNames = Collections.unmodifiableList(paramList7);
      mRemoveMacroRuleNames = Collections.unmodifiableList(paramList8);
      mAddTagRuleNames = Collections.unmodifiableList(paramList9);
      mRemoveTagRuleNames = Collections.unmodifiableList(paramList10);
    }
    
    public static ResourceUtil.ExpandedRuleBuilder newBuilder()
    {
      return new ResourceUtil.ExpandedRuleBuilder(null);
    }
    
    public List getAddMacroRuleNames()
    {
      return mAddMacroRuleNames;
    }
    
    public List getAddMacros()
    {
      return mAddMacros;
    }
    
    public List getAddTagRuleNames()
    {
      return mAddTagRuleNames;
    }
    
    public List getAddTags()
    {
      return mAddTags;
    }
    
    public List getNegativePredicates()
    {
      return mNegativePredicates;
    }
    
    public List getPositivePredicates()
    {
      return mPositivePredicates;
    }
    
    public List getRemoveMacroRuleNames()
    {
      return mRemoveMacroRuleNames;
    }
    
    public List getRemoveMacros()
    {
      return mRemoveMacros;
    }
    
    public List getRemoveTagRuleNames()
    {
      return mRemoveTagRuleNames;
    }
    
    public List getRemoveTags()
    {
      return mRemoveTags;
    }
    
    public String toString()
    {
      return "Positive predicates: " + getPositivePredicates() + "  Negative predicates: " + getNegativePredicates() + "  Add tags: " + getAddTags() + "  Remove tags: " + getRemoveTags() + "  Add macros: " + getAddMacros() + "  Remove macros: " + getRemoveMacros();
    }
  }
  
  public static class ExpandedRuleBuilder
  {
    private final List<String> mAddMacroRuleNames = new ArrayList();
    private final List<ResourceUtil.ExpandedFunctionCall> mAddMacros = new ArrayList();
    private final List<String> mAddTagRuleNames = new ArrayList();
    private final List<ResourceUtil.ExpandedFunctionCall> mAddTags = new ArrayList();
    private final List<ResourceUtil.ExpandedFunctionCall> mNegativePredicates = new ArrayList();
    private final List<ResourceUtil.ExpandedFunctionCall> mPositivePredicates = new ArrayList();
    private final List<String> mRemoveMacroRuleNames = new ArrayList();
    private final List<ResourceUtil.ExpandedFunctionCall> mRemoveMacros = new ArrayList();
    private final List<String> mRemoveTagRuleNames = new ArrayList();
    private final List<ResourceUtil.ExpandedFunctionCall> mRemoveTags = new ArrayList();
    
    private ExpandedRuleBuilder() {}
    
    public ExpandedRuleBuilder addAddMacro(ResourceUtil.ExpandedFunctionCall paramExpandedFunctionCall)
    {
      mAddMacros.add(paramExpandedFunctionCall);
      return this;
    }
    
    public ExpandedRuleBuilder addAddMacroRuleName(String paramString)
    {
      mAddMacroRuleNames.add(paramString);
      return this;
    }
    
    public ExpandedRuleBuilder addAddTag(ResourceUtil.ExpandedFunctionCall paramExpandedFunctionCall)
    {
      mAddTags.add(paramExpandedFunctionCall);
      return this;
    }
    
    public ExpandedRuleBuilder addAddTagRuleName(String paramString)
    {
      mAddTagRuleNames.add(paramString);
      return this;
    }
    
    public ExpandedRuleBuilder addNegativePredicate(ResourceUtil.ExpandedFunctionCall paramExpandedFunctionCall)
    {
      mNegativePredicates.add(paramExpandedFunctionCall);
      return this;
    }
    
    public ExpandedRuleBuilder addPositivePredicate(ResourceUtil.ExpandedFunctionCall paramExpandedFunctionCall)
    {
      mPositivePredicates.add(paramExpandedFunctionCall);
      return this;
    }
    
    public ExpandedRuleBuilder addRemoveMacro(ResourceUtil.ExpandedFunctionCall paramExpandedFunctionCall)
    {
      mRemoveMacros.add(paramExpandedFunctionCall);
      return this;
    }
    
    public ExpandedRuleBuilder addRemoveMacroRuleName(String paramString)
    {
      mRemoveMacroRuleNames.add(paramString);
      return this;
    }
    
    public ExpandedRuleBuilder addRemoveTag(ResourceUtil.ExpandedFunctionCall paramExpandedFunctionCall)
    {
      mRemoveTags.add(paramExpandedFunctionCall);
      return this;
    }
    
    public ExpandedRuleBuilder addRemoveTagRuleName(String paramString)
    {
      mRemoveTagRuleNames.add(paramString);
      return this;
    }
    
    public ResourceUtil.ExpandedRule build()
    {
      return new ResourceUtil.ExpandedRule(mPositivePredicates, mNegativePredicates, mAddTags, mRemoveTags, mAddMacros, mRemoveMacros, mAddMacroRuleNames, mRemoveMacroRuleNames, mAddTagRuleNames, mRemoveTagRuleNames, null);
    }
  }
  
  public static class InvalidResourceException
    extends Exception
  {
    public InvalidResourceException(String paramString)
    {
      super();
    }
  }
}
