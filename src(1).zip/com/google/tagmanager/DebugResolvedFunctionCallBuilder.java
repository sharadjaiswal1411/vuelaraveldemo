package com.google.tagmanager;

import com.google.analytics.containertag.proto.Debug.ResolvedFunctionCall;
import com.google.analytics.containertag.proto.Debug.ResolvedProperty;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;

class DebugResolvedFunctionCallBuilder
  implements ResolvedFunctionCallBuilder
{
  private Debug.ResolvedFunctionCall resolvedFunctionCall;
  
  public DebugResolvedFunctionCallBuilder(Debug.ResolvedFunctionCall paramResolvedFunctionCall)
  {
    resolvedFunctionCall = paramResolvedFunctionCall;
  }
  
  public ResolvedPropertyBuilder createResolvedPropertyBuilder(String paramString)
  {
    Debug.ResolvedProperty localResolvedProperty = new Debug.ResolvedProperty();
    key = paramString;
    resolvedFunctionCall.properties = ArrayUtils.appendToArray(resolvedFunctionCall.properties, localResolvedProperty);
    return new DebugResolvedPropertyBuilder(localResolvedProperty);
  }
  
  public void setFunctionResult(TypeSystem.Value paramValue)
  {
    resolvedFunctionCall.result = DebugValueBuilder.copyImmutableValue(paramValue);
  }
}
