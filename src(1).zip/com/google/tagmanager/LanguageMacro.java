package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Locale;
import java.util.Map;

class LanguageMacro
  extends FunctionCallImplementation
{
  private static final String cachePath = FunctionType.LANGUAGE.toString();
  
  public LanguageMacro()
  {
    super(cachePath, new String[0]);
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    paramMap = Locale.getDefault();
    if (paramMap == null) {
      return Types.getDefaultValue();
    }
    paramMap = paramMap.getLanguage();
    if (paramMap == null) {
      return Types.getDefaultValue();
    }
    return Types.objectToValue(paramMap.toLowerCase());
  }
  
  public boolean isCacheable()
  {
    return false;
  }
}
