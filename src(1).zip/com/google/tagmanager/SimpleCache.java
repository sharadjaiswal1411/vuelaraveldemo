package com.google.tagmanager;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class SimpleCache<K, V>
  implements Cache<K, V>
{
  private final Map<K, V> mHashMap = new HashMap();
  private final int mMaxSize;
  private final CacheFactory.CacheSizeManager<K, V> mSizeManager;
  private int mTotalSize;
  
  SimpleCache(int paramInt, CacheFactory.CacheSizeManager paramCacheSizeManager)
  {
    mMaxSize = paramInt;
    mSizeManager = paramCacheSizeManager;
  }
  
  public Object get(Object paramObject)
  {
    try
    {
      paramObject = mHashMap.get(paramObject);
      return paramObject;
    }
    catch (Throwable paramObject)
    {
      throw paramObject;
    }
  }
  
  public void put(Object paramObject1, Object paramObject2)
  {
    if ((paramObject1 == null) || (paramObject2 == null)) {
      try
      {
        throw new NullPointerException("key == null || value == null");
      }
      catch (Throwable paramObject1)
      {
        throw paramObject1;
      }
    }
    mTotalSize += mSizeManager.sizeOf(paramObject1, paramObject2);
    if (mTotalSize > mMaxSize)
    {
      Iterator localIterator = mHashMap.entrySet().iterator();
      do
      {
        if (!localIterator.hasNext()) {
          break;
        }
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        mTotalSize -= mSizeManager.sizeOf(localEntry.getKey(), localEntry.getValue());
        localIterator.remove();
      } while (mTotalSize > mMaxSize);
    }
    mHashMap.put(paramObject1, paramObject2);
  }
}
