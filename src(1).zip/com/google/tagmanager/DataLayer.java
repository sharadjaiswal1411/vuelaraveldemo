package com.google.tagmanager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataLayer
{
  static final String LIFETIME_KEY = "gtm.lifetime";
  static final String[] LIFETIME_KEY_COMPONENTS = "gtm.lifetime".toString().split("\\.");
  private static final Pattern LIFETIME_PATTERN = Pattern.compile("(\\d+)\\s*([smhd]?)");
  static final int MAX_QUEUE_DEPTH = 500;
  public static final Object OBJECT_NOT_PRESENT = new Object();
  private final ConcurrentHashMap<Listener, Integer> mListeners;
  private final Map<Object, Object> mModel;
  private final PersistentStore mPersistentStore;
  private final CountDownLatch mPersistentStoreLoaded;
  private final ReentrantLock mPushLock;
  private final LinkedList<Map<Object, Object>> mUpdateQueue;
  
  DataLayer()
  {
    this(new PersistentStore()
    {
      public void clearKeysWithPrefix(String paramAnonymousString) {}
      
      public void loadSaved(DataLayer.PersistentStore.Callback paramAnonymousCallback)
      {
        paramAnonymousCallback.onKeyValuesLoaded(new ArrayList());
      }
      
      public void saveKeyValues(List paramAnonymousList, long paramAnonymousLong) {}
    });
  }
  
  DataLayer(PersistentStore paramPersistentStore)
  {
    mPersistentStore = paramPersistentStore;
    mListeners = new ConcurrentHashMap();
    mModel = new HashMap();
    mPushLock = new ReentrantLock();
    mUpdateQueue = new LinkedList();
    mPersistentStoreLoaded = new CountDownLatch(1);
    loadSavedMaps();
  }
  
  private List flattenMap(Map paramMap)
  {
    ArrayList localArrayList = new ArrayList();
    flattenMapHelper(paramMap, "", localArrayList);
    return localArrayList;
  }
  
  private void flattenMapHelper(Map paramMap, String paramString, Collection paramCollection)
  {
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      StringBuilder localStringBuilder = new StringBuilder().append(paramString);
      if (paramString.length() == 0) {}
      for (paramMap = "";; paramMap = ".")
      {
        paramMap = paramMap + localEntry.getKey();
        if (!(localEntry.getValue() instanceof Map)) {
          break label116;
        }
        flattenMapHelper((Map)localEntry.getValue(), paramMap, paramCollection);
        break;
      }
      label116:
      if (!paramMap.equals("gtm.lifetime")) {
        paramCollection.add(new KeyValue(paramMap, localEntry.getValue()));
      }
    }
  }
  
  private Object getLifetimeObject(Map paramMap)
  {
    String[] arrayOfString = LIFETIME_KEY_COMPONENTS;
    int j = arrayOfString.length;
    int i = 0;
    while (i < j)
    {
      String str = arrayOfString[i];
      if (!(paramMap instanceof Map)) {
        return null;
      }
      paramMap = ((Map)paramMap).get(str);
      i += 1;
    }
    return paramMap;
  }
  
  private Long getLifetimeValue(Map paramMap)
  {
    paramMap = getLifetimeObject(paramMap);
    if (paramMap == null) {
      return null;
    }
    return parseLifetime(paramMap.toString());
  }
  
  public static List listOf(Object... paramVarArgs)
  {
    ArrayList localArrayList = new ArrayList();
    int i = 0;
    while (i < paramVarArgs.length)
    {
      localArrayList.add(paramVarArgs[i]);
      i += 1;
    }
    return localArrayList;
  }
  
  private void loadSavedMaps()
  {
    mPersistentStore.loadSaved(new DataLayer.PersistentStore.Callback()
    {
      public void onKeyValuesLoaded(List paramAnonymousList)
      {
        paramAnonymousList = paramAnonymousList.iterator();
        while (paramAnonymousList.hasNext())
        {
          DataLayer.KeyValue localKeyValue = (DataLayer.KeyValue)paramAnonymousList.next();
          DataLayer.this.pushWithoutWaitingForSaved(expandKeyValue(mKey, mValue));
        }
        mPersistentStoreLoaded.countDown();
      }
    });
  }
  
  public static Map mapOf(Object... paramVarArgs)
  {
    if (paramVarArgs.length % 2 != 0) {
      throw new IllegalArgumentException("expected even number of key-value pairs");
    }
    HashMap localHashMap = new HashMap();
    int i = 0;
    while (i < paramVarArgs.length)
    {
      localHashMap.put(paramVarArgs[i], paramVarArgs[(i + 1)]);
      i += 2;
    }
    return localHashMap;
  }
  
  private void notifyListeners(Map paramMap)
  {
    Iterator localIterator = mListeners.keySet().iterator();
    while (localIterator.hasNext()) {
      ((Listener)localIterator.next()).changed(paramMap);
    }
  }
  
  static Long parseLifetime(String paramString)
  {
    Object localObject = LIFETIME_PATTERN.matcher(paramString);
    if (!((Matcher)localObject).matches())
    {
      Log.i("unknown _lifetime: " + paramString);
      return null;
    }
    long l1 = 0L;
    try
    {
      long l2 = Long.parseLong(((Matcher)localObject).group(1));
      l1 = l2;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      for (;;)
      {
        Log.w("illegal number in _lifetime value: " + paramString);
      }
      localObject = ((Matcher)localObject).group(2);
      if (((String)localObject).length() != 0) {
        break label135;
      }
      return Long.valueOf(l1);
      switch (((String)localObject).charAt(0))
      {
      default: 
        Log.w("unknown units in _lifetime: " + paramString);
        return null;
      }
    }
    if (l1 <= 0L)
    {
      Log.i("non-positive _lifetime: " + paramString);
      return null;
    }
    label135:
    return Long.valueOf(l1 * 1000L);
    return Long.valueOf(l1 * 1000L * 60L);
    return Long.valueOf(l1 * 1000L * 60L * 60L);
    return Long.valueOf(l1 * 1000L * 60L * 60L * 24L);
  }
  
  private void processQueuedUpdates()
  {
    int i = 0;
    int j;
    do
    {
      Map localMap = (Map)mUpdateQueue.poll();
      if (localMap == null) {
        break;
      }
      processUpdate(localMap);
      j = i + 1;
      i = j;
    } while (j <= 500);
    mUpdateQueue.clear();
    throw new RuntimeException("Seems like an infinite loop of pushing to the data layer");
  }
  
  private void processUpdate(Map paramMap)
  {
    Map localMap = mModel;
    try
    {
      Iterator localIterator = paramMap.keySet().iterator();
      while (localIterator.hasNext())
      {
        Object localObject = localIterator.next();
        mergeMap(expandKeyValue(localObject, paramMap.get(localObject)), mModel);
      }
    }
    catch (Throwable paramMap)
    {
      throw paramMap;
    }
    notifyListeners(paramMap);
  }
  
  private void pushWithoutWaitingForSaved(Map paramMap)
  {
    mPushLock.lock();
    try
    {
      mUpdateQueue.offer(paramMap);
      int i = mPushLock.getHoldCount();
      if (i == 1) {
        processQueuedUpdates();
      }
      savePersistentlyIfNeeded(paramMap);
      mPushLock.unlock();
      return;
    }
    catch (Throwable paramMap)
    {
      mPushLock.unlock();
      throw paramMap;
    }
  }
  
  private void savePersistentlyIfNeeded(Map paramMap)
  {
    Long localLong = getLifetimeValue(paramMap);
    if (localLong == null) {
      return;
    }
    paramMap = flattenMap(paramMap);
    paramMap.remove("gtm.lifetime");
    mPersistentStore.saveKeyValues(paramMap, localLong.longValue());
  }
  
  void clearPersistentKeysWithPrefix(String paramString)
  {
    push(paramString, null);
    mPersistentStore.clearKeysWithPrefix(paramString);
  }
  
  Map expandKeyValue(Object paramObject1, Object paramObject2)
  {
    HashMap localHashMap = new HashMap();
    Object localObject = localHashMap;
    String[] arrayOfString = paramObject1.toString().split("\\.");
    int i = 0;
    while (i < arrayOfString.length - 1)
    {
      paramObject1 = new HashMap();
      ((Map)localObject).put(arrayOfString[i], paramObject1);
      localObject = paramObject1;
      i += 1;
    }
    ((Map)localObject).put(arrayOfString[(arrayOfString.length - 1)], paramObject2);
    return localHashMap;
  }
  
  public Object get(String paramString)
  {
    Map localMap2 = mModel;
    try
    {
      Map localMap1 = mModel;
      String[] arrayOfString = paramString.split("\\.");
      int j = arrayOfString.length;
      int i = 0;
      paramString = localMap1;
      while (i < j)
      {
        localMap1 = arrayOfString[i];
        if (!(paramString instanceof Map)) {
          return null;
        }
        paramString = ((Map)paramString).get(localMap1);
        if (paramString == null) {
          return null;
        }
        i += 1;
      }
      return paramString;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  void mergeList(List paramList1, List paramList2)
  {
    while (paramList2.size() < paramList1.size()) {
      paramList2.add(null);
    }
    int i = 0;
    if (i < paramList1.size())
    {
      Object localObject = paramList1.get(i);
      if ((localObject instanceof List))
      {
        if (!(paramList2.get(i) instanceof List)) {
          paramList2.set(i, new ArrayList());
        }
        mergeList((List)localObject, (List)paramList2.get(i));
      }
      for (;;)
      {
        i += 1;
        break;
        if ((localObject instanceof Map))
        {
          if (!(paramList2.get(i) instanceof Map)) {
            paramList2.set(i, new HashMap());
          }
          mergeMap((Map)localObject, (Map)paramList2.get(i));
        }
        else if (localObject != OBJECT_NOT_PRESENT)
        {
          paramList2.set(i, localObject);
        }
      }
    }
  }
  
  void mergeMap(Map paramMap1, Map paramMap2)
  {
    Iterator localIterator = paramMap1.keySet().iterator();
    while (localIterator.hasNext())
    {
      Object localObject1 = localIterator.next();
      Object localObject2 = paramMap1.get(localObject1);
      if ((localObject2 instanceof List))
      {
        if (!(paramMap2.get(localObject1) instanceof List)) {
          paramMap2.put(localObject1, new ArrayList());
        }
        mergeList((List)localObject2, (List)paramMap2.get(localObject1));
      }
      else if ((localObject2 instanceof Map))
      {
        if (!(paramMap2.get(localObject1) instanceof Map)) {
          paramMap2.put(localObject1, new HashMap());
        }
        mergeMap((Map)localObject2, (Map)paramMap2.get(localObject1));
      }
      else
      {
        paramMap2.put(localObject1, localObject2);
      }
    }
  }
  
  public void push(Object paramObject1, Object paramObject2)
  {
    push(expandKeyValue(paramObject1, paramObject2));
  }
  
  public void push(Map paramMap)
  {
    CountDownLatch localCountDownLatch = mPersistentStoreLoaded;
    try
    {
      localCountDownLatch.await();
      pushWithoutWaitingForSaved(paramMap);
      return;
    }
    catch (InterruptedException localInterruptedException)
    {
      for (;;)
      {
        Log.w("DataLayer.push: unexpected InterruptedException");
      }
    }
  }
  
  void registerListener(Listener paramListener)
  {
    mListeners.put(paramListener, Integer.valueOf(0));
  }
  
  void unregisterListener(Listener paramListener)
  {
    mListeners.remove(paramListener);
  }
  
  static final class KeyValue
  {
    public final String mKey;
    public final Object mValue;
    
    KeyValue(String paramString, Object paramObject)
    {
      mKey = paramString;
      mValue = paramObject;
    }
    
    public boolean equals(Object paramObject)
    {
      if (!(paramObject instanceof KeyValue)) {
        return false;
      }
      paramObject = (KeyValue)paramObject;
      return (mKey.equals(mKey)) && (mValue.equals(mValue));
    }
    
    public int hashCode()
    {
      return Arrays.hashCode(new Integer[] { Integer.valueOf(mKey.hashCode()), Integer.valueOf(mValue.hashCode()) });
    }
    
    public String toString()
    {
      return "Key: " + mKey + " value: " + mValue.toString();
    }
  }
  
  static abstract interface Listener
  {
    public abstract void changed(Map paramMap);
  }
  
  static abstract interface PersistentStore
  {
    public abstract void clearKeysWithPrefix(String paramString);
    
    public abstract void loadSaved(Callback paramCallback);
    
    public abstract void saveKeyValues(List paramList, long paramLong);
    
    public static abstract interface Callback
    {
      public abstract void onKeyValuesLoaded(List paramList);
    }
  }
}
