package com.google.tagmanager;

abstract interface EventInfoBuilder
{
  public abstract DataLayerEventEvaluationInfoBuilder createDataLayerEventEvaluationInfoBuilder();
  
  public abstract MacroEvaluationInfoBuilder createMacroEvaluationInfoBuilder();
  
  public abstract void processEventInfo();
}
