package com.google.tagmanager;

abstract interface HitSender
{
  public abstract boolean sendHit(String paramString);
  
  public abstract void setUrlWrapModeForTesting(String paramString1, String paramString2);
}
