package com.google.tagmanager;

import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;

abstract interface ResolvedRuleBuilder
{
  public abstract ResolvedFunctionCallBuilder createNegativePredicate();
  
  public abstract ResolvedFunctionCallBuilder createPositivePredicate();
  
  public abstract ResolvedFunctionCallTranslatorList getAddedMacroFunctions();
  
  public abstract ResolvedFunctionCallTranslatorList getAddedTagFunctions();
  
  public abstract ResolvedFunctionCallTranslatorList getRemovedMacroFunctions();
  
  public abstract ResolvedFunctionCallTranslatorList getRemovedTagFunctions();
  
  public abstract void setValue(TypeSystem.Value paramValue);
}
