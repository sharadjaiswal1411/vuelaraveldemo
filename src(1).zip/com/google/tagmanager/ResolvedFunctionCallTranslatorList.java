package com.google.tagmanager;

import java.util.List;

abstract interface ResolvedFunctionCallTranslatorList
{
  public abstract void translateAndAddAll(List paramList1, List paramList2);
}
