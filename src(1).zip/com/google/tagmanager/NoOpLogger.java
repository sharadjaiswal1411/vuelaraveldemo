package com.google.tagmanager;

class NoOpLogger
  implements Logger
{
  NoOpLogger() {}
  
  public void d(String paramString) {}
  
  public void d(String paramString, Throwable paramThrowable) {}
  
  public void e(String paramString) {}
  
  public void e(String paramString, Throwable paramThrowable) {}
  
  public Logger.LogLevel getLogLevel()
  {
    return Logger.LogLevel.NONE;
  }
  
  public void i(String paramString) {}
  
  public void i(String paramString, Throwable paramThrowable) {}
  
  public void setLogLevel(Logger.LogLevel paramLogLevel) {}
  
  public void v(String paramString) {}
  
  public void v(String paramString, Throwable paramThrowable) {}
  
  public void w(String paramString) {}
  
  public void w(String paramString, Throwable paramThrowable) {}
}
