package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class EncodeMacro
  extends FunctionCallImplementation
{
  private static final String ARG0;
  private static final String DEFAULT_INPUT_FORMAT = "text";
  private static final String DEFAULT_OUTPUT_FORMAT = "base16";
  private static final String ID = FunctionType.ENCODE.toString();
  private static final String INPUT_FORMAT = Key.INPUT_FORMAT.toString();
  private static final String NO_PADDING;
  private static final String OUTPUT_FORMAT = Key.OUTPUT_FORMAT.toString();
  
  static
  {
    ARG0 = Key.ARG0.toString();
    NO_PADDING = Key.NO_PADDING.toString();
  }
  
  public EncodeMacro()
  {
    super(ID, new String[] { ARG0 });
  }
  
  public static String getFunctionId()
  {
    return ID;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    Object localObject = (TypeSystem.Value)paramMap.get(ARG0);
    if ((localObject == null) || (localObject == Types.getDefaultValue())) {
      return Types.getDefaultValue();
    }
    String str2 = Types.valueToString((TypeSystem.Value)localObject);
    localObject = (TypeSystem.Value)paramMap.get(INPUT_FORMAT);
    String str1;
    label84:
    int i;
    if (localObject == null)
    {
      str1 = "text";
      localObject = (TypeSystem.Value)paramMap.get(OUTPUT_FORMAT);
      if (localObject != null) {
        break label185;
      }
      localObject = "base16";
      TypeSystem.Value localValue = (TypeSystem.Value)paramMap.get(INPUT_FORMAT);
      int j = 0;
      paramMap = (TypeSystem.Value)paramMap.get(NO_PADDING);
      i = j;
      if (paramMap != null)
      {
        i = j;
        if (Types.valueToBoolean(paramMap).booleanValue()) {
          i = 0x0 | 0x1;
        }
      }
    }
    for (;;)
    {
      try
      {
        boolean bool = "text".equals(str1);
        if (bool)
        {
          paramMap = str2.getBytes();
          if (!"base16".equals(localObject)) {
            break label307;
          }
          paramMap = Base16.encode(paramMap);
          return Types.objectToValue(paramMap);
          str1 = Types.valueToString((TypeSystem.Value)localObject);
          break;
          label185:
          localObject = Types.valueToString((TypeSystem.Value)localObject);
          break label84;
        }
        bool = "base16".equals(str1);
        if (bool)
        {
          paramMap = Base16.decode(str2);
          continue;
        }
        bool = "base64".equals(str1);
        if (bool)
        {
          paramMap = Base64Encoder.decode(str2, i);
          continue;
        }
        bool = "base64url".equals(str1);
        if (bool)
        {
          paramMap = Base64Encoder.decode(str2, i | 0x2);
          continue;
        }
        Log.e("Encode: unknown input format: " + str1);
        paramMap = Types.getDefaultValue();
        return paramMap;
      }
      catch (IllegalArgumentException paramMap)
      {
        Log.e("Encode: invalid input:");
        return Types.getDefaultValue();
      }
      label307:
      if ("base64".equals(localObject))
      {
        paramMap = Base64Encoder.encodeToString(paramMap, i);
      }
      else
      {
        if (!"base64url".equals(localObject)) {
          break label347;
        }
        paramMap = Base64Encoder.encodeToString(paramMap, i | 0x2);
      }
    }
    label347:
    Log.e("Encode: unknown output format: " + (String)localObject);
    return Types.getDefaultValue();
  }
  
  public boolean isCacheable()
  {
    return true;
  }
}
