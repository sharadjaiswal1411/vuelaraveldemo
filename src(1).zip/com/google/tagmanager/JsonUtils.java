package com.google.tagmanager;

import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class JsonUtils
{
  private JsonUtils() {}
  
  public static ResourceUtil.ExpandedResource expandedResourceFromJsonString(String paramString)
    throws JSONException
  {
    paramString = jsonObjectToValue(new JSONObject(paramString));
    ResourceUtil.ExpandedResourceBuilder localExpandedResourceBuilder = ResourceUtil.ExpandedResource.newBuilder();
    int i = 0;
    while (i < mapKey.length)
    {
      localExpandedResourceBuilder.addMacro(ResourceUtil.ExpandedFunctionCall.newBuilder().addProperty(Key.INSTANCE_NAME.toString(), mapKey[i]).addProperty(Key.FUNCTION.toString(), Types.functionIdToValue(ConstantMacro.getFunctionId())).addProperty(ConstantMacro.getValueKey(), mapValue[i]).build());
      i += 1;
    }
    return localExpandedResourceBuilder.build();
  }
  
  static Object jsonObjectToObject(Object paramObject)
    throws JSONException
  {
    if ((paramObject instanceof JSONArray)) {
      throw new RuntimeException("JSONArrays are not supported");
    }
    if (JSONObject.NULL.equals(paramObject)) {
      throw new RuntimeException("JSON nulls are not supported");
    }
    HashMap localHashMap;
    if ((paramObject instanceof JSONObject))
    {
      paramObject = (JSONObject)paramObject;
      localHashMap = new HashMap();
      Iterator localIterator = paramObject.keys();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        localHashMap.put(str, jsonObjectToObject(paramObject.get(str)));
      }
    }
    return paramObject;
    return localHashMap;
  }
  
  private static TypeSystem.Value jsonObjectToValue(Object paramObject)
    throws JSONException
  {
    return Types.objectToValue(jsonObjectToObject(paramObject));
  }
}
