package com.google.tagmanager;

class NoopEventInfoDistributor
  implements EventInfoDistributor
{
  NoopEventInfoDistributor() {}
  
  public EventInfoBuilder createDataLayerEventEvaluationEventInfo(String paramString)
  {
    return new NoopEventInfoBuilder();
  }
  
  public EventInfoBuilder createMacroEvalutionEventInfo(String paramString)
  {
    return new NoopEventInfoBuilder();
  }
  
  public boolean debugMode()
  {
    return false;
  }
}
