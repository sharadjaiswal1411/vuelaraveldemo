package com.google.tagmanager;

import java.util.List;

abstract interface Dispatcher
{
  public abstract void close();
  
  public abstract void dispatchHits(List paramList);
  
  public abstract boolean okToDispatch();
}
