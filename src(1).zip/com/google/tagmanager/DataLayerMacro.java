package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class DataLayerMacro
  extends FunctionCallImplementation
{
  private static final String DEFAULT_VALUE = Key.DEFAULT_VALUE.toString();
  private static final String NAME;
  private static final String PATH = FunctionType.CUSTOM_VAR.toString();
  private final DataLayer mDataLayer;
  
  static
  {
    NAME = Key.NAME.toString();
  }
  
  public DataLayerMacro(DataLayer paramDataLayer)
  {
    super(PATH, new String[] { NAME });
    mDataLayer = paramDataLayer;
  }
  
  public static String getDefaultValueKey()
  {
    return DEFAULT_VALUE;
  }
  
  public static String getFunctionId()
  {
    return PATH;
  }
  
  public static String getNameKey()
  {
    return NAME;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    Object localObject = mDataLayer.get(Types.valueToString((TypeSystem.Value)paramMap.get(NAME)));
    if (localObject == null)
    {
      paramMap = (TypeSystem.Value)paramMap.get(DEFAULT_VALUE);
      if (paramMap != null) {
        return paramMap;
      }
      return Types.getDefaultValue();
    }
    return Types.objectToValue(localObject);
  }
  
  public boolean isCacheable()
  {
    return false;
  }
}
