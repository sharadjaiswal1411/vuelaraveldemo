package com.google.tagmanager;

import android.content.Context;
import android.provider.Settings.Secure;
import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class DeviceIdMacro
  extends FunctionCallImplementation
{
  private static final String cachePath = FunctionType.DEVICE_ID.toString();
  private final Context mContext;
  
  public DeviceIdMacro(Context paramContext)
  {
    super(cachePath, new String[0]);
    mContext = paramContext;
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    paramMap = getAndroidId(mContext);
    if (paramMap == null) {
      return Types.getDefaultValue();
    }
    return Types.objectToValue(paramMap);
  }
  
  protected String getAndroidId(Context paramContext)
  {
    return Settings.Secure.getString(paramContext.getContentResolver(), "android_id");
  }
  
  public boolean isCacheable()
  {
    return true;
  }
}
