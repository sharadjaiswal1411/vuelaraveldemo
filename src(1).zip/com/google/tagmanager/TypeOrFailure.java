package com.google.tagmanager;

class TypeOrFailure<T>
{
  private LoadCallback.Failure mFailure;
  private T mType;
  
  public TypeOrFailure(LoadCallback.Failure paramFailure)
  {
    mFailure = paramFailure;
  }
  
  public TypeOrFailure(Object paramObject)
  {
    mType = paramObject;
  }
  
  public LoadCallback.Failure getFailure()
  {
    return mFailure;
  }
  
  public Object getType()
  {
    return mType;
  }
}
