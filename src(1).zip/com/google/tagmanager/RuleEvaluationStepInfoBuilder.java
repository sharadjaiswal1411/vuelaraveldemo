package com.google.tagmanager;

import java.util.Set;

abstract interface RuleEvaluationStepInfoBuilder
{
  public abstract ResolvedRuleBuilder createResolvedRuleBuilder();
  
  public abstract void setEnabledFunctions(Set paramSet);
}
