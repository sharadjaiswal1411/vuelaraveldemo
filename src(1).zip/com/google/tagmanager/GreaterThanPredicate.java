package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import java.util.Map;

class GreaterThanPredicate
  extends NumberPredicate
{
  private static final String cachePath = FunctionType.GREATER_THAN.toString();
  
  public GreaterThanPredicate()
  {
    super(cachePath);
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  protected boolean evaluateNumber(TypedNumber paramTypedNumber1, TypedNumber paramTypedNumber2, Map paramMap)
  {
    return paramTypedNumber1.compareTo(paramTypedNumber2) > 0;
  }
}
