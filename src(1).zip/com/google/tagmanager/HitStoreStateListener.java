package com.google.tagmanager;

abstract interface HitStoreStateListener
{
  public abstract void reportStoreIsEmpty(boolean paramBoolean);
}
