package com.google.tagmanager;

abstract interface EventInfoDistributor
{
  public abstract EventInfoBuilder createDataLayerEventEvaluationEventInfo(String paramString);
  
  public abstract EventInfoBuilder createMacroEvalutionEventInfo(String paramString);
  
  public abstract boolean debugMode();
}
