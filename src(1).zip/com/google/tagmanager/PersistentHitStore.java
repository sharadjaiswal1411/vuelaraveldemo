package com.google.tagmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build.VERSION;
import android.text.TextUtils;
import com.google.android.gms.common.util.VisibleForTesting;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.http.impl.client.DefaultHttpClient;

class PersistentHitStore
  implements HitStore
{
  private static final String CREATE_HITS_TABLE = String.format("CREATE TABLE IF NOT EXISTS %s ( '%s' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, '%s' INTEGER NOT NULL, '%s' TEXT NOT NULL,'%s' INTEGER NOT NULL);", new Object[] { "gtm_hits", "hit_id", "hit_time", "hit_url", "hit_first_send_time" });
  private static final String DATABASE_FILENAME = "gtm_urls.db";
  @VisibleForTesting
  static final String HITS_TABLE = "gtm_hits";
  static final long HIT_DISPATCH_RETRY_WINDOW = 14400000L;
  @VisibleForTesting
  static final String HIT_FIRST_DISPATCH_TIME = "hit_first_send_time";
  @VisibleForTesting
  static final String HIT_ID = "hit_id";
  private static final String HIT_ID_WHERE_CLAUSE = "hit_id=?";
  @VisibleForTesting
  static final String HIT_TIME = "hit_time";
  @VisibleForTesting
  static final String HIT_URL = "hit_url";
  private Clock mClock;
  private final Context mContext;
  private final String mDatabaseName;
  private final UrlDatabaseHelper mDbHelper;
  private volatile Dispatcher mDispatcher;
  private long mLastDeleteStaleHitsTime;
  private final HitStoreStateListener mListener;
  
  PersistentHitStore(HitStoreStateListener paramHitStoreStateListener, Context paramContext)
  {
    this(paramHitStoreStateListener, paramContext, "gtm_urls.db");
  }
  
  PersistentHitStore(HitStoreStateListener paramHitStoreStateListener, Context paramContext, String paramString)
  {
    mContext = paramContext.getApplicationContext();
    mDatabaseName = paramString;
    mListener = paramHitStoreStateListener;
    mClock = new Clock()
    {
      public long currentTimeMillis()
      {
        return System.currentTimeMillis();
      }
    };
    mDbHelper = new UrlDatabaseHelper(mContext, mDatabaseName);
    mDispatcher = new SimpleNetworkDispatcher(new DefaultHttpClient(), mContext, new StoreDispatchListener());
    mLastDeleteStaleHitsTime = 0L;
  }
  
  private void deleteHit(long paramLong)
  {
    deleteHits(new String[] { String.valueOf(paramLong) });
  }
  
  private SQLiteDatabase getWritableDatabase(String paramString)
  {
    Object localObject = mDbHelper;
    try
    {
      localObject = ((UrlDatabaseHelper)localObject).getWritableDatabase();
      return localObject;
    }
    catch (SQLiteException localSQLiteException)
    {
      Log.w(paramString);
    }
    return null;
  }
  
  private void removeOldHitIfFull()
  {
    int i = getNumStoredHits() - 2000 + 1;
    if (i > 0)
    {
      List localList = peekHitIds(i);
      Log.v("Store full, deleting " + localList.size() + " hits to make room.");
      deleteHits((String[])localList.toArray(new String[0]));
    }
  }
  
  private void setHitFirstDispatchTime(long paramLong1, long paramLong2)
  {
    SQLiteDatabase localSQLiteDatabase = getWritableDatabase("Error opening database for getNumStoredHits.");
    if (localSQLiteDatabase == null) {
      return;
    }
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("hit_first_send_time", Long.valueOf(paramLong2));
    try
    {
      localSQLiteDatabase.update("gtm_hits", localContentValues, "hit_id=?", new String[] { String.valueOf(paramLong1) });
      return;
    }
    catch (SQLiteException localSQLiteException)
    {
      Log.w("Error setting HIT_FIRST_DISPATCH_TIME for hitId: " + paramLong1);
      deleteHit(paramLong1);
    }
  }
  
  private void writeHitToDatabase(long paramLong, String paramString)
  {
    SQLiteDatabase localSQLiteDatabase = getWritableDatabase("Error opening database for putHit");
    if (localSQLiteDatabase == null) {
      return;
    }
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("hit_time", Long.valueOf(paramLong));
    localContentValues.put("hit_url", paramString);
    localContentValues.put("hit_first_send_time", Integer.valueOf(0));
    try
    {
      localSQLiteDatabase.insert("gtm_hits", null, localContentValues);
      paramString = mListener;
      paramString.reportStoreIsEmpty(false);
      return;
    }
    catch (SQLiteException paramString)
    {
      Log.w("Error storing hit");
    }
  }
  
  public void close()
  {
    Object localObject = mDbHelper;
    try
    {
      ((UrlDatabaseHelper)localObject).getWritableDatabase().close();
      localObject = mDispatcher;
      ((Dispatcher)localObject).close();
      return;
    }
    catch (SQLiteException localSQLiteException)
    {
      Log.w("Error opening database for close");
    }
  }
  
  void deleteHits(String[] paramArrayOfString)
  {
    boolean bool = true;
    if (paramArrayOfString != null)
    {
      if (paramArrayOfString.length == 0) {
        return;
      }
      SQLiteDatabase localSQLiteDatabase = getWritableDatabase("Error opening database for deleteHits.");
      if (localSQLiteDatabase != null)
      {
        String str = String.format("HIT_ID in (%s)", new Object[] { TextUtils.join(",", Collections.nCopies(paramArrayOfString.length, "?")) });
        for (;;)
        {
          try
          {
            localSQLiteDatabase.delete("gtm_hits", str, paramArrayOfString);
            paramArrayOfString = mListener;
            int i = getNumStoredHits();
            if (i == 0)
            {
              paramArrayOfString.reportStoreIsEmpty(bool);
              return;
            }
          }
          catch (SQLiteException paramArrayOfString)
          {
            Log.w("Error deleting hits");
            return;
          }
          bool = false;
        }
      }
    }
  }
  
  int deleteStaleHits()
  {
    boolean bool = true;
    long l = mClock.currentTimeMillis();
    if (l <= mLastDeleteStaleHitsTime + 86400000L) {
      return 0;
    }
    mLastDeleteStaleHitsTime = l;
    Object localObject = getWritableDatabase("Error opening database for deleteStaleHits.");
    if (localObject != null)
    {
      int i = ((SQLiteDatabase)localObject).delete("gtm_hits", "HIT_TIME < ?", new String[] { Long.toString(mClock.currentTimeMillis() - 2592000000L) });
      localObject = mListener;
      if (getNumStoredHits() == 0) {}
      for (;;)
      {
        ((HitStoreStateListener)localObject).reportStoreIsEmpty(bool);
        return i;
        bool = false;
      }
    }
    return 0;
  }
  
  public void dispatch()
  {
    Log.v("GTM Dispatch running...");
    if (!mDispatcher.okToDispatch()) {
      return;
    }
    List localList = peekHits(40);
    if (localList.isEmpty())
    {
      Log.v("...nothing to dispatch");
      mListener.reportStoreIsEmpty(true);
      return;
    }
    mDispatcher.dispatchHits(localList);
    if (getNumStoredUntriedHits() > 0) {
      ServiceManagerImpl.getInstance().dispatch();
    }
  }
  
  public UrlDatabaseHelper getDbHelper()
  {
    return mDbHelper;
  }
  
  public Dispatcher getDispatcher()
  {
    return mDispatcher;
  }
  
  UrlDatabaseHelper getHelper()
  {
    return mDbHelper;
  }
  
  int getNumStoredHits()
  {
    int j = 0;
    int i = 0;
    Object localObject4 = getWritableDatabase("Error opening database for getNumStoredHits.");
    if (localObject4 == null) {
      return 0;
    }
    Object localObject2 = null;
    localObject1 = null;
    try
    {
      Cursor localCursor = ((SQLiteDatabase)localObject4).rawQuery("SELECT COUNT(*) from gtm_hits", null);
      localObject4 = localCursor;
      localObject1 = localObject4;
      localObject2 = localObject4;
      boolean bool = localCursor.moveToFirst();
      if (bool)
      {
        localObject1 = localObject4;
        localObject2 = localObject4;
        long l = localCursor.getLong(0);
        i = (int)l;
      }
      j = i;
      if (localCursor != null)
      {
        localCursor.close();
        j = i;
      }
    }
    catch (SQLiteException localSQLiteException)
    {
      do
      {
        localObject3 = localObject1;
        Log.w("Error getting numStoredHits");
      } while (localObject1 == null);
      localObject1.close();
      return 0;
    }
    catch (Throwable localThrowable)
    {
      Object localObject3;
      if (localObject3 == null) {
        break label140;
      }
      localObject3.close();
      throw localThrowable;
    }
    return j;
  }
  
  int getNumStoredUntriedHits()
  {
    int i = 0;
    Object localObject4 = getWritableDatabase("Error opening database for getNumStoredHits.");
    if (localObject4 == null) {
      return 0;
    }
    Object localObject2 = null;
    localObject1 = null;
    try
    {
      localObject4 = ((SQLiteDatabase)localObject4).query("gtm_hits", new String[] { "hit_id", "hit_first_send_time" }, "hit_first_send_time=0", null, null, null, null);
      localObject2 = localObject4;
      localObject1 = localObject2;
      int j = ((Cursor)localObject4).getCount();
      i = j;
      if (localObject4 != null)
      {
        ((Cursor)localObject4).close();
        i = j;
      }
    }
    catch (SQLiteException localSQLiteException)
    {
      do
      {
        localObject3 = localObject1;
        Log.w("Error getting num untried hits");
      } while (localObject1 == null);
      localObject1.close();
      return 0;
    }
    catch (Throwable localThrowable)
    {
      Object localObject3;
      if (localObject3 == null) {
        break label121;
      }
      localObject3.close();
      throw localThrowable;
    }
    return i;
  }
  
  List peekHitIds(int paramInt)
  {
    ArrayList localArrayList = new ArrayList();
    if (paramInt <= 0)
    {
      Log.w("Invalid maxHits specified. Skipping");
      return localArrayList;
    }
    SQLiteDatabase localSQLiteDatabase = getWritableDatabase("Error opening database for peekHitIds.");
    if (localSQLiteDatabase != null)
    {
      Cursor localCursor4 = null;
      Cursor localCursor3 = null;
      Cursor localCursor2 = localCursor3;
      Cursor localCursor1 = localCursor4;
      try
      {
        String str1 = String.format("%s ASC", new Object[] { "hit_id" });
        localCursor2 = localCursor3;
        localCursor1 = localCursor4;
        String str2 = Integer.toString(paramInt);
        localCursor2 = localCursor3;
        localCursor1 = localCursor4;
        localCursor4 = localSQLiteDatabase.query("gtm_hits", new String[] { "hit_id" }, null, null, null, null, str1, str2);
        localCursor3 = localCursor4;
        localCursor2 = localCursor3;
        localCursor1 = localCursor3;
        boolean bool = localCursor4.moveToFirst();
        if (bool) {
          do
          {
            localCursor2 = localCursor3;
            localCursor1 = localCursor3;
            localArrayList.add(String.valueOf(localCursor4.getLong(0)));
            localCursor2 = localCursor3;
            localCursor1 = localCursor3;
            bool = localCursor4.moveToNext();
          } while (bool);
        }
        if (localCursor4 != null)
        {
          localCursor4.close();
          return localArrayList;
        }
      }
      catch (SQLiteException localSQLiteException)
      {
        localCursor1 = localCursor2;
        Log.w("Error in peekHits fetching hitIds: " + localSQLiteException.getMessage());
        if (localCursor2 != null)
        {
          localCursor2.close();
          return localArrayList;
        }
      }
      catch (Throwable localThrowable)
      {
        if (localCursor1 != null) {
          localCursor1.close();
        }
        throw localThrowable;
      }
    }
    return localArrayList;
  }
  
  /* Error */
  public List peekHits(int paramInt)
  {
    // Byte code:
    //   0: new 363	java/util/ArrayList
    //   3: dup
    //   4: invokespecial 364	java/util/ArrayList:<init>	()V
    //   7: astore 10
    //   9: aload_0
    //   10: ldc_w 392
    //   13: invokespecial 194	com/google/tagmanager/PersistentHitStore:getWritableDatabase	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteDatabase;
    //   16: astore 12
    //   18: aload 12
    //   20: ifnonnull +6 -> 26
    //   23: aload 10
    //   25: areturn
    //   26: aconst_null
    //   27: astore 9
    //   29: aconst_null
    //   30: astore 6
    //   32: aload 6
    //   34: astore 8
    //   36: aload 9
    //   38: astore 7
    //   40: ldc_w 370
    //   43: iconst_1
    //   44: anewarray 4	java/lang/Object
    //   47: dup
    //   48: iconst_0
    //   49: ldc 33
    //   51: aastore
    //   52: invokestatic 64	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   55: astore 11
    //   57: aload 6
    //   59: astore 8
    //   61: aload 9
    //   63: astore 7
    //   65: iload_1
    //   66: invokestatic 373	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   69: astore 13
    //   71: aload 6
    //   73: astore 8
    //   75: aload 9
    //   77: astore 7
    //   79: aload 12
    //   81: ldc 22
    //   83: iconst_3
    //   84: anewarray 60	java/lang/String
    //   87: dup
    //   88: iconst_0
    //   89: ldc 33
    //   91: aastore
    //   92: dup
    //   93: iconst_1
    //   94: ldc 39
    //   96: aastore
    //   97: dup
    //   98: iconst_2
    //   99: ldc 30
    //   101: aastore
    //   102: aconst_null
    //   103: aconst_null
    //   104: aconst_null
    //   105: aconst_null
    //   106: aload 11
    //   108: aload 13
    //   110: invokevirtual 376	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   113: astore 11
    //   115: aload 11
    //   117: astore 6
    //   119: aload 6
    //   121: astore 8
    //   123: aload 6
    //   125: astore 7
    //   127: new 363	java/util/ArrayList
    //   130: dup
    //   131: invokespecial 364	java/util/ArrayList:<init>	()V
    //   134: astore 9
    //   136: aload 11
    //   138: invokeinterface 343 1 0
    //   143: istore_3
    //   144: iload_3
    //   145: ifeq +54 -> 199
    //   148: aload 9
    //   150: new 394	com/google/tagmanager/Hit
    //   153: dup
    //   154: aload 11
    //   156: iconst_0
    //   157: invokeinterface 347 2 0
    //   162: aload 11
    //   164: iconst_1
    //   165: invokeinterface 347 2 0
    //   170: aload 11
    //   172: iconst_2
    //   173: invokeinterface 347 2 0
    //   178: invokespecial 397	com/google/tagmanager/Hit:<init>	(JJJ)V
    //   181: invokeinterface 380 2 0
    //   186: pop
    //   187: aload 11
    //   189: invokeinterface 383 1 0
    //   194: istore_3
    //   195: iload_3
    //   196: ifne -48 -> 148
    //   199: aload 11
    //   201: ifnull +10 -> 211
    //   204: aload 11
    //   206: invokeinterface 348 1 0
    //   211: iconst_0
    //   212: istore_2
    //   213: aload 6
    //   215: astore 8
    //   217: aload 6
    //   219: astore 7
    //   221: ldc_w 370
    //   224: iconst_1
    //   225: anewarray 4	java/lang/Object
    //   228: dup
    //   229: iconst_0
    //   230: ldc 33
    //   232: aastore
    //   233: invokestatic 64	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   236: astore 10
    //   238: aload 6
    //   240: astore 8
    //   242: aload 6
    //   244: astore 7
    //   246: iload_1
    //   247: invokestatic 373	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   250: astore 11
    //   252: aload 6
    //   254: astore 8
    //   256: aload 6
    //   258: astore 7
    //   260: aload 12
    //   262: ldc 22
    //   264: iconst_2
    //   265: anewarray 60	java/lang/String
    //   268: dup
    //   269: iconst_0
    //   270: ldc 33
    //   272: aastore
    //   273: dup
    //   274: iconst_1
    //   275: ldc 42
    //   277: aastore
    //   278: aconst_null
    //   279: aconst_null
    //   280: aconst_null
    //   281: aconst_null
    //   282: aload 10
    //   284: aload 11
    //   286: invokevirtual 376	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   289: astore 10
    //   291: aload 10
    //   293: astore 6
    //   295: aload 6
    //   297: astore 8
    //   299: aload 6
    //   301: astore 7
    //   303: aload 10
    //   305: invokeinterface 343 1 0
    //   310: istore_3
    //   311: iload_3
    //   312: ifeq +103 -> 415
    //   315: iload_2
    //   316: istore_1
    //   317: aload 10
    //   319: checkcast 399	android/database/sqlite/SQLiteCursor
    //   322: astore 11
    //   324: aload 6
    //   326: astore 8
    //   328: aload 6
    //   330: astore 7
    //   332: aload 11
    //   334: invokevirtual 405	android/database/AbstractWindowedCursor:getWindow	()Landroid/database/CursorWindow;
    //   337: invokevirtual 410	android/database/CursorWindow:getNumRows	()I
    //   340: istore_2
    //   341: iload_2
    //   342: ifle +165 -> 507
    //   345: aload 6
    //   347: astore 8
    //   349: aload 6
    //   351: astore 7
    //   353: aload 9
    //   355: iload_1
    //   356: invokeinterface 414 2 0
    //   361: astore 11
    //   363: aload 11
    //   365: checkcast 394	com/google/tagmanager/Hit
    //   368: astore 11
    //   370: aload 6
    //   372: astore 8
    //   374: aload 6
    //   376: astore 7
    //   378: aload 11
    //   380: aload 10
    //   382: iconst_1
    //   383: invokeinterface 417 2 0
    //   388: invokevirtual 420	com/google/tagmanager/Hit:setHitUrl	(Ljava/lang/String;)V
    //   391: iload_1
    //   392: iconst_1
    //   393: iadd
    //   394: istore_1
    //   395: aload 6
    //   397: astore 8
    //   399: aload 6
    //   401: astore 7
    //   403: aload 10
    //   405: invokeinterface 383 1 0
    //   410: istore_3
    //   411: iload_3
    //   412: ifne -95 -> 317
    //   415: aload 10
    //   417: ifnull +10 -> 427
    //   420: aload 10
    //   422: invokeinterface 348 1 0
    //   427: aload 9
    //   429: areturn
    //   430: astore 9
    //   432: aload 8
    //   434: astore 6
    //   436: aload 10
    //   438: astore 8
    //   440: aload 6
    //   442: astore 7
    //   444: new 161	java/lang/StringBuilder
    //   447: dup
    //   448: invokespecial 162	java/lang/StringBuilder:<init>	()V
    //   451: ldc_w 385
    //   454: invokevirtual 168	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   457: aload 9
    //   459: invokevirtual 390	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   462: invokevirtual 168	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   465: invokevirtual 181	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   468: invokestatic 150	com/google/tagmanager/Log:w	(Ljava/lang/String;)V
    //   471: aload 6
    //   473: ifnull +10 -> 483
    //   476: aload 6
    //   478: invokeinterface 348 1 0
    //   483: aload 8
    //   485: areturn
    //   486: astore 8
    //   488: aload 7
    //   490: astore 6
    //   492: aload 6
    //   494: ifnull +10 -> 504
    //   497: aload 6
    //   499: invokeinterface 348 1 0
    //   504: aload 8
    //   506: athrow
    //   507: aload 6
    //   509: astore 8
    //   511: aload 6
    //   513: astore 7
    //   515: aload 9
    //   517: iload_1
    //   518: invokeinterface 414 2 0
    //   523: astore 11
    //   525: aload 6
    //   527: astore 7
    //   529: aload 11
    //   531: checkcast 394	com/google/tagmanager/Hit
    //   534: astore 11
    //   536: aload 6
    //   538: astore 8
    //   540: aload 6
    //   542: astore 7
    //   544: aload 11
    //   546: invokevirtual 423	com/google/tagmanager/Hit:getHitId	()J
    //   549: lstore 4
    //   551: aload 6
    //   553: astore 8
    //   555: aload 6
    //   557: astore 7
    //   559: ldc_w 425
    //   562: iconst_1
    //   563: anewarray 4	java/lang/Object
    //   566: dup
    //   567: iconst_0
    //   568: lload 4
    //   570: invokestatic 202	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   573: aastore
    //   574: invokestatic 64	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   577: invokestatic 150	com/google/tagmanager/Log:w	(Ljava/lang/String;)V
    //   580: goto -189 -> 391
    //   583: astore 6
    //   585: aload 8
    //   587: astore 7
    //   589: new 161	java/lang/StringBuilder
    //   592: dup
    //   593: invokespecial 162	java/lang/StringBuilder:<init>	()V
    //   596: ldc_w 427
    //   599: invokevirtual 168	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   602: aload 6
    //   604: invokevirtual 390	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   607: invokevirtual 168	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   610: invokevirtual 181	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   613: invokestatic 150	com/google/tagmanager/Log:w	(Ljava/lang/String;)V
    //   616: aload 8
    //   618: astore 7
    //   620: new 363	java/util/ArrayList
    //   623: dup
    //   624: invokespecial 364	java/util/ArrayList:<init>	()V
    //   627: astore 6
    //   629: iconst_0
    //   630: istore_1
    //   631: aload 8
    //   633: astore 7
    //   635: aload 9
    //   637: invokeinterface 431 1 0
    //   642: astore 9
    //   644: aload 8
    //   646: astore 7
    //   648: aload 9
    //   650: invokeinterface 436 1 0
    //   655: istore_3
    //   656: iload_3
    //   657: ifeq +42 -> 699
    //   660: aload 8
    //   662: astore 7
    //   664: aload 9
    //   666: invokeinterface 440 1 0
    //   671: checkcast 394	com/google/tagmanager/Hit
    //   674: astore 10
    //   676: aload 8
    //   678: astore 7
    //   680: aload 10
    //   682: invokevirtual 443	com/google/tagmanager/Hit:getHitUrl	()Ljava/lang/String;
    //   685: invokestatic 446	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   688: istore_3
    //   689: iload_1
    //   690: istore_2
    //   691: iload_3
    //   692: ifeq +24 -> 716
    //   695: iload_1
    //   696: ifeq +18 -> 714
    //   699: aload 8
    //   701: ifnull +10 -> 711
    //   704: aload 8
    //   706: invokeinterface 348 1 0
    //   711: aload 6
    //   713: areturn
    //   714: iconst_1
    //   715: istore_2
    //   716: aload 8
    //   718: astore 7
    //   720: aload 6
    //   722: aload 10
    //   724: invokeinterface 380 2 0
    //   729: pop
    //   730: iload_2
    //   731: istore_1
    //   732: goto -88 -> 644
    //   735: astore 6
    //   737: aload 7
    //   739: ifnull +10 -> 749
    //   742: aload 7
    //   744: invokeinterface 348 1 0
    //   749: aload 6
    //   751: athrow
    //   752: astore 8
    //   754: goto -262 -> 492
    //   757: astore 7
    //   759: aload 9
    //   761: astore 8
    //   763: aload 7
    //   765: astore 9
    //   767: goto -327 -> 440
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	770	0	this	PersistentHitStore
    //   0	770	1	paramInt	int
    //   212	519	2	i	int
    //   143	549	3	bool	boolean
    //   549	20	4	l	long
    //   30	526	6	localObject1	Object
    //   583	20	6	localSQLiteException1	SQLiteException
    //   627	94	6	localArrayList1	ArrayList
    //   735	15	6	localThrowable1	Throwable
    //   38	705	7	localObject2	Object
    //   757	7	7	localSQLiteException2	SQLiteException
    //   34	450	8	localObject3	Object
    //   486	19	8	localThrowable2	Throwable
    //   509	208	8	localObject4	Object
    //   752	1	8	localThrowable3	Throwable
    //   761	1	8	localObject5	Object
    //   27	401	9	localArrayList2	ArrayList
    //   430	206	9	localSQLiteException3	SQLiteException
    //   642	124	9	localObject6	Object
    //   7	716	10	localObject7	Object
    //   55	490	11	localObject8	Object
    //   16	245	12	localSQLiteDatabase	SQLiteDatabase
    //   69	40	13	str	String
    // Exception table:
    //   from	to	target	type
    //   40	57	430	android/database/sqlite/SQLiteException
    //   65	71	430	android/database/sqlite/SQLiteException
    //   79	115	430	android/database/sqlite/SQLiteException
    //   127	136	430	android/database/sqlite/SQLiteException
    //   40	57	486	java/lang/Throwable
    //   65	71	486	java/lang/Throwable
    //   79	115	486	java/lang/Throwable
    //   127	136	486	java/lang/Throwable
    //   444	471	486	java/lang/Throwable
    //   221	238	583	android/database/sqlite/SQLiteException
    //   246	252	583	android/database/sqlite/SQLiteException
    //   260	291	583	android/database/sqlite/SQLiteException
    //   303	311	583	android/database/sqlite/SQLiteException
    //   332	341	583	android/database/sqlite/SQLiteException
    //   353	363	583	android/database/sqlite/SQLiteException
    //   378	391	583	android/database/sqlite/SQLiteException
    //   403	411	583	android/database/sqlite/SQLiteException
    //   515	525	583	android/database/sqlite/SQLiteException
    //   544	551	583	android/database/sqlite/SQLiteException
    //   559	580	583	android/database/sqlite/SQLiteException
    //   221	238	735	java/lang/Throwable
    //   246	252	735	java/lang/Throwable
    //   260	291	735	java/lang/Throwable
    //   303	311	735	java/lang/Throwable
    //   332	341	735	java/lang/Throwable
    //   353	363	735	java/lang/Throwable
    //   378	391	735	java/lang/Throwable
    //   403	411	735	java/lang/Throwable
    //   515	525	735	java/lang/Throwable
    //   529	536	735	java/lang/Throwable
    //   544	551	735	java/lang/Throwable
    //   559	580	735	java/lang/Throwable
    //   589	616	735	java/lang/Throwable
    //   620	629	735	java/lang/Throwable
    //   635	644	735	java/lang/Throwable
    //   648	656	735	java/lang/Throwable
    //   664	676	735	java/lang/Throwable
    //   680	689	735	java/lang/Throwable
    //   720	730	735	java/lang/Throwable
    //   136	144	752	java/lang/Throwable
    //   148	195	752	java/lang/Throwable
    //   136	144	757	android/database/sqlite/SQLiteException
    //   148	195	757	android/database/sqlite/SQLiteException
  }
  
  public void putHit(long paramLong, String paramString)
  {
    deleteStaleHits();
    removeOldHitIfFull();
    writeHitToDatabase(paramLong, paramString);
  }
  
  public void setClock(Clock paramClock)
  {
    mClock = paramClock;
  }
  
  void setDispatcher(Dispatcher paramDispatcher)
  {
    mDispatcher = paramDispatcher;
  }
  
  void setLastDeleteStaleHitsTime(long paramLong)
  {
    mLastDeleteStaleHitsTime = paramLong;
  }
  
  @VisibleForTesting
  class StoreDispatchListener
    implements SimpleNetworkDispatcher.DispatchListener
  {
    StoreDispatchListener() {}
    
    public void onHitDispatched(Hit paramHit)
    {
      PersistentHitStore.this.deleteHit(paramHit.getHitId());
    }
    
    public void onHitPermanentDispatchFailure(Hit paramHit)
    {
      PersistentHitStore.this.deleteHit(paramHit.getHitId());
      Log.v("Permanent failure dispatching hitId: " + paramHit.getHitId());
    }
    
    public void onHitTransientDispatchFailure(Hit paramHit)
    {
      long l = paramHit.getHitFirstDispatchTime();
      if (l == 0L)
      {
        PersistentHitStore.this.setHitFirstDispatchTime(paramHit.getHitId(), mClock.currentTimeMillis());
        return;
      }
      if (14400000L + l < mClock.currentTimeMillis())
      {
        PersistentHitStore.this.deleteHit(paramHit.getHitId());
        Log.v("Giving up on failed hitId: " + paramHit.getHitId());
      }
    }
  }
  
  @VisibleForTesting
  class UrlDatabaseHelper
    extends SQLiteOpenHelper
  {
    private boolean mBadDatabase;
    private long mLastDatabaseCheckTime = 0L;
    
    UrlDatabaseHelper(Context paramContext, String paramString)
    {
      super(paramString, null, 1);
    }
    
    private boolean tablePresent(String paramString, SQLiteDatabase paramSQLiteDatabase)
    {
      Object localObject2 = null;
      Object localObject1 = null;
      boolean bool;
      try
      {
        paramSQLiteDatabase = paramSQLiteDatabase.query("SQLITE_MASTER", new String[] { "name" }, "name=?", new String[] { paramString }, null, null, null);
        localObject2 = paramSQLiteDatabase;
        localObject1 = localObject2;
        bool = paramSQLiteDatabase.moveToFirst();
        if (paramSQLiteDatabase != null)
        {
          paramSQLiteDatabase.close();
          return bool;
        }
      }
      catch (SQLiteException paramSQLiteDatabase)
      {
        localObject2 = localObject1;
        Log.w("Error querying for table " + paramString);
        if (localObject1 != null) {
          localObject1.close();
        }
        return false;
      }
      catch (Throwable paramString)
      {
        if (localObject2 != null) {
          ((Cursor)localObject2).close();
        }
        throw paramString;
      }
      return bool;
    }
    
    private void validateColumnsPresent(SQLiteDatabase paramSQLiteDatabase)
    {
      paramSQLiteDatabase = paramSQLiteDatabase.rawQuery("SELECT * FROM gtm_hits WHERE 0", null);
      HashSet localHashSet = new HashSet();
      try
      {
        String[] arrayOfString = paramSQLiteDatabase.getColumnNames();
        int i = 0;
        for (;;)
        {
          int j = arrayOfString.length;
          if (i >= j) {
            break;
          }
          localHashSet.add(arrayOfString[i]);
          i += 1;
        }
        paramSQLiteDatabase.close();
        if ((!localHashSet.remove("hit_id")) || (!localHashSet.remove("hit_url")) || (!localHashSet.remove("hit_time")) || (!localHashSet.remove("hit_first_send_time"))) {
          throw new SQLiteException("Database column missing");
        }
      }
      catch (Throwable localThrowable)
      {
        paramSQLiteDatabase.close();
        throw localThrowable;
      }
      if (!localThrowable.isEmpty()) {
        throw new SQLiteException("Database has extra columns");
      }
    }
    
    public SQLiteDatabase getWritableDatabase()
    {
      if ((mBadDatabase) && (mLastDatabaseCheckTime + 3600000L > mClock.currentTimeMillis())) {
        throw new SQLiteException("Database creation failed");
      }
      Object localObject1 = null;
      mBadDatabase = true;
      mLastDatabaseCheckTime = mClock.currentTimeMillis();
      try
      {
        localObject2 = super.getWritableDatabase();
        localObject1 = localObject2;
      }
      catch (SQLiteException localSQLiteException)
      {
        for (;;)
        {
          Object localObject2;
          mContext.getDatabasePath(mDatabaseName).delete();
        }
      }
      localObject2 = localObject1;
      if (localObject1 == null) {
        localObject2 = super.getWritableDatabase();
      }
      mBadDatabase = false;
      return localObject2;
    }
    
    boolean isBadDatabase()
    {
      return mBadDatabase;
    }
    
    public void onCreate(SQLiteDatabase paramSQLiteDatabase)
    {
      FutureApis.setOwnerOnlyReadWrite(paramSQLiteDatabase.getPath());
    }
    
    public void onOpen(SQLiteDatabase paramSQLiteDatabase)
    {
      Cursor localCursor;
      if (Build.VERSION.SDK_INT < 15) {
        localCursor = paramSQLiteDatabase.rawQuery("PRAGMA journal_mode=memory", null);
      }
      try
      {
        localCursor.moveToFirst();
        localCursor.close();
        if (!tablePresent("gtm_hits", paramSQLiteDatabase))
        {
          paramSQLiteDatabase.execSQL(PersistentHitStore.CREATE_HITS_TABLE);
          return;
        }
      }
      catch (Throwable paramSQLiteDatabase)
      {
        localCursor.close();
        throw paramSQLiteDatabase;
      }
      validateColumnsPresent(paramSQLiteDatabase);
    }
    
    public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {}
    
    void setBadDatabase(boolean paramBoolean)
    {
      mBadDatabase = paramBoolean;
    }
  }
}
