package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class CustomFunctionCall
  extends FunctionCallImplementation
{
  private static final String ADDITIONAL_PARAMS = Key.ADDITIONAL_PARAMS.toString();
  private static final String FUNCTION_CALL_NAME;
  private static final String cachePath = FunctionType.FUNCTION_CALL.toString();
  private final CustomEvaluator mFunctionCallEvaluator;
  
  static
  {
    FUNCTION_CALL_NAME = Key.FUNCTION_CALL_NAME.toString();
  }
  
  public CustomFunctionCall(CustomEvaluator paramCustomEvaluator)
  {
    super(cachePath, new String[] { FUNCTION_CALL_NAME });
    mFunctionCallEvaluator = paramCustomEvaluator;
  }
  
  public static String getAdditionalParamsKey()
  {
    return ADDITIONAL_PARAMS;
  }
  
  public static String getFunctionCallNameKey()
  {
    return FUNCTION_CALL_NAME;
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    String str = Types.valueToString((TypeSystem.Value)paramMap.get(FUNCTION_CALL_NAME));
    HashMap localHashMap = new HashMap();
    paramMap = (TypeSystem.Value)paramMap.get(ADDITIONAL_PARAMS);
    if (paramMap != null)
    {
      paramMap = Types.valueToObject(paramMap);
      if (!(paramMap instanceof Map))
      {
        Log.w("FunctionCallMacro: expected ADDITIONAL_PARAMS to be a map.");
        return Types.getDefaultValue();
      }
      paramMap = ((Map)paramMap).entrySet().iterator();
      while (paramMap.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)paramMap.next();
        localHashMap.put(localEntry.getKey().toString(), localEntry.getValue());
      }
    }
    paramMap = mFunctionCallEvaluator;
    try
    {
      paramMap = Types.objectToValue(paramMap.evaluate(str, localHashMap));
      return paramMap;
    }
    catch (Exception paramMap)
    {
      Log.w("Custom macro/tag " + str + " threw exception " + paramMap.getMessage());
    }
    return Types.getDefaultValue();
  }
  
  public boolean isCacheable()
  {
    return false;
  }
  
  public static abstract interface CustomEvaluator
  {
    public abstract Object evaluate(String paramString, Map paramMap);
  }
}
