package com.google.tagmanager;

import com.google.analytics.containertag.proto.Serving.GaExperimentRandom;
import com.google.analytics.containertag.proto.Serving.GaExperimentSupplemental;
import com.google.analytics.containertag.proto.Serving.Supplemental;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

public class ExperimentMacroHelper
{
  public ExperimentMacroHelper() {}
  
  private static void clearKeys(DataLayer paramDataLayer, Serving.GaExperimentSupplemental paramGaExperimentSupplemental)
  {
    paramGaExperimentSupplemental = valueToClear;
    int j = paramGaExperimentSupplemental.length;
    int i = 0;
    while (i < j)
    {
      paramDataLayer.clearPersistentKeysWithPrefix(Types.valueToString(paramGaExperimentSupplemental[i]));
      i += 1;
    }
  }
  
  public static void handleExperimentSupplemental(DataLayer paramDataLayer, Serving.Supplemental paramSupplemental)
  {
    if (experimentSupplemental == null)
    {
      Log.w("supplemental missing experimentSupplemental");
      return;
    }
    clearKeys(paramDataLayer, experimentSupplemental);
    pushValues(paramDataLayer, experimentSupplemental);
    setRandomValues(paramDataLayer, experimentSupplemental);
  }
  
  private static void pushValues(DataLayer paramDataLayer, Serving.GaExperimentSupplemental paramGaExperimentSupplemental)
  {
    paramGaExperimentSupplemental = valueToPush;
    int j = paramGaExperimentSupplemental.length;
    int i = 0;
    while (i < j)
    {
      Map localMap = valueToMap(paramGaExperimentSupplemental[i]);
      if (localMap != null) {
        paramDataLayer.push(localMap);
      }
      i += 1;
    }
  }
  
  private static void setRandomValues(DataLayer paramDataLayer, Serving.GaExperimentSupplemental paramGaExperimentSupplemental)
  {
    Serving.GaExperimentRandom[] arrayOfGaExperimentRandom = experimentRandom;
    int j = arrayOfGaExperimentRandom.length;
    int i = 0;
    while (i < j)
    {
      Serving.GaExperimentRandom localGaExperimentRandom = arrayOfGaExperimentRandom[i];
      if (string == null)
      {
        Log.w("GaExperimentRandom: No key");
        i += 1;
      }
      else
      {
        Object localObject = paramDataLayer.get(string);
        paramGaExperimentSupplemental = (Serving.GaExperimentSupplemental)localObject;
        if (!(localObject instanceof Number))
        {
          localObject = null;
          label68:
          long l1 = minRandom;
          long l2 = maxRandom;
          if ((!retainOriginalValue) || (localObject == null) || (((Long)localObject).longValue() < l1) || (((Long)localObject).longValue() > l2))
          {
            if (l1 > l2) {
              break label243;
            }
            paramGaExperimentSupplemental = Long.valueOf(Math.round(Math.random() * (l2 - l1) + l1));
          }
          paramDataLayer.clearPersistentKeysWithPrefix(string);
          paramGaExperimentSupplemental = paramDataLayer.expandKeyValue(string, paramGaExperimentSupplemental);
          if (lifetimeInMilliseconds > 0L)
          {
            if (paramGaExperimentSupplemental.containsKey("gtm")) {
              break label251;
            }
            paramGaExperimentSupplemental.put("gtm", DataLayer.mapOf(new Object[] { "lifetime", Long.valueOf(lifetimeInMilliseconds) }));
          }
        }
        for (;;)
        {
          paramDataLayer.push(paramGaExperimentSupplemental);
          break;
          localObject = Long.valueOf(((Number)localObject).longValue());
          break label68;
          label243:
          Log.w("GaExperimentRandom: random range invalid");
          break;
          label251:
          localObject = paramGaExperimentSupplemental.get("gtm");
          if ((localObject instanceof Map)) {
            ((Map)localObject).put("lifetime", Long.valueOf(lifetimeInMilliseconds));
          } else {
            Log.w("GaExperimentRandom: gtm not a map");
          }
        }
      }
    }
  }
  
  private static Map valueToMap(TypeSystem.Value paramValue)
  {
    paramValue = Types.valueToObject(paramValue);
    if (!(paramValue instanceof Map))
    {
      Log.w("value: " + paramValue + " is not a map value, ignored.");
      return null;
    }
    return (Map)paramValue;
  }
}
