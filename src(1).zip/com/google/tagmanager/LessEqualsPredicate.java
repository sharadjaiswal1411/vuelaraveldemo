package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import java.util.Map;

class LessEqualsPredicate
  extends NumberPredicate
{
  private static final String cachePath = FunctionType.LESS_EQUALS.toString();
  
  public LessEqualsPredicate()
  {
    super(cachePath);
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  protected boolean evaluateNumber(TypedNumber paramTypedNumber1, TypedNumber paramTypedNumber2, Map paramMap)
  {
    return paramTypedNumber1.compareTo(paramTypedNumber2) <= 0;
  }
}
