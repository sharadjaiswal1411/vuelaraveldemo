package com.google.tagmanager;

import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

class ValueEscapeUtil
{
  private ValueEscapeUtil() {}
  
  private static ObjectAndStatic applyEscaping(ObjectAndStatic paramObjectAndStatic, int paramInt)
  {
    if (!isValidStringType((TypeSystem.Value)paramObjectAndStatic.getObject()))
    {
      Log.e("Escaping can only be applied to strings.");
      return paramObjectAndStatic;
    }
    switch (paramInt)
    {
    default: 
      Log.e("Unsupported Value Escaping: " + paramInt);
      return paramObjectAndStatic;
    }
    return escapeUri(paramObjectAndStatic);
  }
  
  static ObjectAndStatic applyEscapings(ObjectAndStatic paramObjectAndStatic, int... paramVarArgs)
  {
    int j = paramVarArgs.length;
    int i = 0;
    while (i < j)
    {
      paramObjectAndStatic = applyEscaping(paramObjectAndStatic, paramVarArgs[i]);
      i += 1;
    }
    return paramObjectAndStatic;
  }
  
  private static ObjectAndStatic escapeUri(ObjectAndStatic paramObjectAndStatic)
  {
    try
    {
      Object localObject = paramObjectAndStatic.getObject();
      localObject = (TypeSystem.Value)localObject;
      localObject = urlEncode(Types.valueToString((TypeSystem.Value)localObject));
      localObject = new ObjectAndStatic(Types.objectToValue(localObject), paramObjectAndStatic.isStatic());
      return localObject;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      Log.e("Escape URI: unsupported encoding", localUnsupportedEncodingException);
    }
    return paramObjectAndStatic;
  }
  
  private static boolean isValidStringType(TypeSystem.Value paramValue)
  {
    return Types.valueToObject(paramValue) instanceof String;
  }
  
  static String urlEncode(String paramString)
    throws UnsupportedEncodingException
  {
    return URLEncoder.encode(paramString, "UTF-8").replaceAll("\\+", "%20");
  }
}
