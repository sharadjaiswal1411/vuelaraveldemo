package com.google.tagmanager;

import java.io.IOException;
import java.io.InputStream;

abstract interface NetworkClient
{
  public static final int DEFAULT_CONNECTION_TIMEOUT_MILLIS = 20000;
  public static final int DEFAULT_SOCKET_TIMEOUT_MILLIS = 20000;
  
  public abstract void close();
  
  public abstract InputStream getInputStream(String paramString)
    throws IOException;
  
  public abstract void sendPostRequest(String paramString, byte[] paramArrayOfByte)
    throws IOException;
}
