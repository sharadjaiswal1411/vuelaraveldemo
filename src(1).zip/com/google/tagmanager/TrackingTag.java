package com.google.tagmanager;

import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

abstract class TrackingTag
  extends FunctionCallImplementation
{
  public TrackingTag(String paramString, String... paramVarArgs)
  {
    super(paramString, paramVarArgs);
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    evaluateTrackingTag(paramMap);
    return Types.getDefaultValue();
  }
  
  public abstract void evaluateTrackingTag(Map paramMap);
  
  public boolean isCacheable()
  {
    return false;
  }
}
