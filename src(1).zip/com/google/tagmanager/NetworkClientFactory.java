package com.google.tagmanager;

import android.os.Build.VERSION;

class NetworkClientFactory
{
  NetworkClientFactory() {}
  
  public NetworkClient createNetworkClient()
  {
    if (getSdkVersion() < 8) {
      return new HttpNetworkClient();
    }
    return new HttpUrlConnectionNetworkClient();
  }
  
  int getSdkVersion()
  {
    return Build.VERSION.SDK_INT;
  }
}
