package com.google.tagmanager;

import android.content.Context;
import android.content.res.AssetManager;
import com.google.tagmanager.proto.Resource.ResourceWithMetadata;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONException;

class ResourceStorageImpl
  implements Container.ResourceStorage
{
  private static final String SAVED_RESOURCE_FILENAME_PREFIX = "resource_";
  private static final String SAVED_RESOURCE_SUB_DIR = "google_tagmanager";
  private LoadCallback<Resource.ResourceWithMetadata> mCallback;
  private final String mContainerId;
  private final Context mContext;
  private final ExecutorService mExecutor;
  
  ResourceStorageImpl(Context paramContext, String paramString)
  {
    mContext = paramContext;
    mContainerId = paramString;
    mExecutor = Executors.newSingleThreadExecutor();
  }
  
  private String stringFromInputStream(InputStream paramInputStream)
    throws IOException
  {
    StringWriter localStringWriter = new StringWriter();
    char[] arrayOfChar = new char['?'];
    paramInputStream = new BufferedReader(new InputStreamReader(paramInputStream, "UTF-8"));
    for (;;)
    {
      int i = paramInputStream.read(arrayOfChar);
      if (i == -1) {
        break;
      }
      localStringWriter.write(arrayOfChar, 0, i);
    }
    return localStringWriter.toString();
  }
  
  public void close()
  {
    try
    {
      mExecutor.shutdown();
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  File getResourceFile()
  {
    String str = "resource_" + mContainerId;
    return new File(mContext.getDir("google_tagmanager", 0), str);
  }
  
  public ResourceUtil.ExpandedResource loadExpandedResourceFromJsonAsset(String paramString)
  {
    Log.v("loading default container from " + paramString);
    Object localObject5 = mContext.getAssets();
    if (localObject5 == null)
    {
      Log.w("Looking for default JSON container in package, but no assets were found.");
      return null;
    }
    Object localObject4 = null;
    Object localObject1 = null;
    Object localObject3 = null;
    try
    {
      localObject5 = ((AssetManager)localObject5).open(paramString);
      localObject1 = localObject5;
      localObject3 = localObject1;
      localObject4 = localObject1;
      ResourceUtil.ExpandedResource localExpandedResource = JsonUtils.expandedResourceFromJsonString(stringFromInputStream((InputStream)localObject5));
      if (localObject5 != null) {
        try
        {
          ((InputStream)localObject5).close();
          return localExpandedResource;
        }
        catch (IOException paramString)
        {
          return localExpandedResource;
        }
      }
      Object localObject2;
      return localExpandedResource;
    }
    catch (IOException localIOException1)
    {
      localObject2 = localObject3;
      Log.w("No asset file: " + paramString + " found (or errors reading it).");
      if (localObject3 != null) {
        try
        {
          localObject3.close();
          return null;
        }
        catch (IOException paramString)
        {
          return null;
        }
      }
    }
    catch (JSONException localJSONException)
    {
      localObject2 = localObject4;
      Log.w("Error parsing JSON file" + paramString + " : " + localJSONException);
      if (localObject4 != null) {
        try
        {
          localObject4.close();
          return null;
        }
        catch (IOException paramString)
        {
          return null;
        }
      }
    }
    catch (Throwable paramString)
    {
      if (localObject2 != null) {}
      try
      {
        localObject2.close();
        throw paramString;
      }
      catch (IOException localIOException2)
      {
        for (;;) {}
      }
    }
    return null;
  }
  
  /* Error */
  public com.google.analytics.containertag.proto.Serving.Resource loadResourceFromContainerAsset(String paramString)
  {
    // Byte code:
    //   0: new 91	java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial 92	java/lang/StringBuilder:<init>	()V
    //   7: ldc -95
    //   9: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   12: aload_1
    //   13: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   16: invokevirtual 97	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   19: invokestatic 120	com/google/tagmanager/Log:v	(Ljava/lang/String;)V
    //   22: aload_0
    //   23: getfield 32	com/google/tagmanager/ResourceStorageImpl:mContext	Landroid/content/Context;
    //   26: invokevirtual 124	android/content/Context:getAssets	()Landroid/content/res/AssetManager;
    //   29: astore_2
    //   30: aload_2
    //   31: ifnonnull +10 -> 41
    //   34: ldc -93
    //   36: invokestatic 166	com/google/tagmanager/Log:e	(Ljava/lang/String;)V
    //   39: aconst_null
    //   40: areturn
    //   41: aload_2
    //   42: aload_1
    //   43: invokevirtual 135	android/content/res/AssetManager:open	(Ljava/lang/String;)Ljava/io/InputStream;
    //   46: astore_2
    //   47: new 168	java/io/ByteArrayOutputStream
    //   50: dup
    //   51: invokespecial 169	java/io/ByteArrayOutputStream:<init>	()V
    //   54: astore_3
    //   55: aload_2
    //   56: aload_3
    //   57: invokestatic 175	com/google/tagmanager/ResourceUtil:copyStream	(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    //   60: aload_3
    //   61: invokevirtual 179	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   64: invokestatic 185	com/google/analytics/containertag/proto/Serving$Resource:parseFrom	([B)Lcom/google/analytics/containertag/proto/Serving$Resource;
    //   67: astore_3
    //   68: new 91	java/lang/StringBuilder
    //   71: dup
    //   72: invokespecial 92	java/lang/StringBuilder:<init>	()V
    //   75: ldc -69
    //   77: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: aload_3
    //   81: invokevirtual 157	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: invokevirtual 97	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   87: invokestatic 120	com/google/tagmanager/Log:v	(Ljava/lang/String;)V
    //   90: aload_2
    //   91: invokevirtual 146	java/io/InputStream:close	()V
    //   94: aload_3
    //   95: areturn
    //   96: astore_1
    //   97: aload_3
    //   98: areturn
    //   99: astore_2
    //   100: new 91	java/lang/StringBuilder
    //   103: dup
    //   104: invokespecial 92	java/lang/StringBuilder:<init>	()V
    //   107: ldc -108
    //   109: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   112: aload_1
    //   113: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   116: ldc -67
    //   118: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   121: invokevirtual 97	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   124: invokestatic 129	com/google/tagmanager/Log:w	(Ljava/lang/String;)V
    //   127: aconst_null
    //   128: areturn
    //   129: astore_3
    //   130: new 91	java/lang/StringBuilder
    //   133: dup
    //   134: invokespecial 92	java/lang/StringBuilder:<init>	()V
    //   137: ldc -65
    //   139: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   142: aload_1
    //   143: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   146: invokevirtual 97	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   149: invokestatic 129	com/google/tagmanager/Log:w	(Ljava/lang/String;)V
    //   152: aload_2
    //   153: invokevirtual 146	java/io/InputStream:close	()V
    //   156: aconst_null
    //   157: areturn
    //   158: astore_1
    //   159: aload_2
    //   160: invokevirtual 146	java/io/InputStream:close	()V
    //   163: aload_1
    //   164: athrow
    //   165: astore_1
    //   166: goto -10 -> 156
    //   169: astore_2
    //   170: goto -7 -> 163
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	173	0	this	ResourceStorageImpl
    //   0	173	1	paramString	String
    //   29	62	2	localObject1	Object
    //   99	61	2	localIOException1	IOException
    //   169	1	2	localIOException2	IOException
    //   54	44	3	localObject2	Object
    //   129	1	3	localIOException3	IOException
    // Exception table:
    //   from	to	target	type
    //   90	94	96	java/io/IOException
    //   41	47	99	java/io/IOException
    //   47	68	129	java/io/IOException
    //   68	90	129	java/io/IOException
    //   47	68	158	java/lang/Throwable
    //   68	90	158	java/lang/Throwable
    //   130	152	158	java/lang/Throwable
    //   152	156	165	java/io/IOException
    //   159	163	169	java/io/IOException
  }
  
  /* Error */
  void loadResourceFromDisk()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 196	com/google/tagmanager/ResourceStorageImpl:mCallback	Lcom/google/tagmanager/LoadCallback;
    //   4: ifnonnull +13 -> 17
    //   7: new 198	java/lang/IllegalStateException
    //   10: dup
    //   11: ldc -56
    //   13: invokespecial 202	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   16: athrow
    //   17: aload_0
    //   18: getfield 196	com/google/tagmanager/ResourceStorageImpl:mCallback	Lcom/google/tagmanager/LoadCallback;
    //   21: astore_2
    //   22: aload_0
    //   23: astore_1
    //   24: aload_2
    //   25: invokeinterface 207 1 0
    //   30: ldc -47
    //   32: invokestatic 120	com/google/tagmanager/Log:v	(Ljava/lang/String;)V
    //   35: invokestatic 215	com/google/tagmanager/PreviewManager:getInstance	()Lcom/google/tagmanager/PreviewManager;
    //   38: invokevirtual 219	com/google/tagmanager/PreviewManager:getPreviewMode	()Lcom/google/tagmanager/PreviewManager$PreviewMode;
    //   41: getstatic 225	com/google/tagmanager/PreviewManager$PreviewMode:CONTAINER	Lcom/google/tagmanager/PreviewManager$PreviewMode;
    //   44: if_acmpeq +15 -> 59
    //   47: invokestatic 215	com/google/tagmanager/PreviewManager:getInstance	()Lcom/google/tagmanager/PreviewManager;
    //   50: invokevirtual 219	com/google/tagmanager/PreviewManager:getPreviewMode	()Lcom/google/tagmanager/PreviewManager$PreviewMode;
    //   53: getstatic 228	com/google/tagmanager/PreviewManager$PreviewMode:CONTAINER_DEBUG	Lcom/google/tagmanager/PreviewManager$PreviewMode;
    //   56: if_acmpne +32 -> 88
    //   59: aload_1
    //   60: getfield 34	com/google/tagmanager/ResourceStorageImpl:mContainerId	Ljava/lang/String;
    //   63: invokestatic 215	com/google/tagmanager/PreviewManager:getInstance	()Lcom/google/tagmanager/PreviewManager;
    //   66: invokevirtual 231	com/google/tagmanager/PreviewManager:getContainerId	()Ljava/lang/String;
    //   69: invokevirtual 237	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   72: ifeq +16 -> 88
    //   75: aload_1
    //   76: getfield 196	com/google/tagmanager/ResourceStorageImpl:mCallback	Lcom/google/tagmanager/LoadCallback;
    //   79: getstatic 243	com/google/tagmanager/LoadCallback$Failure:NOT_AVAILABLE	Lcom/google/tagmanager/LoadCallback$Failure;
    //   82: invokeinterface 247 2 0
    //   87: return
    //   88: new 249	java/io/FileInputStream
    //   91: dup
    //   92: aload_1
    //   93: invokevirtual 251	com/google/tagmanager/ResourceStorageImpl:getResourceFile	()Ljava/io/File;
    //   96: invokespecial 254	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   99: astore_2
    //   100: new 168	java/io/ByteArrayOutputStream
    //   103: dup
    //   104: invokespecial 169	java/io/ByteArrayOutputStream:<init>	()V
    //   107: astore_3
    //   108: aload_2
    //   109: aload_3
    //   110: invokestatic 175	com/google/tagmanager/ResourceUtil:copyStream	(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    //   113: aload_1
    //   114: getfield 196	com/google/tagmanager/ResourceStorageImpl:mCallback	Lcom/google/tagmanager/LoadCallback;
    //   117: astore_1
    //   118: aload_1
    //   119: aload_3
    //   120: invokevirtual 179	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   123: invokestatic 259	com/google/tagmanager/proto/Resource$ResourceWithMetadata:parseFrom	([B)Lcom/google/tagmanager/proto/Resource$ResourceWithMetadata;
    //   126: invokeinterface 263 2 0
    //   131: aload_2
    //   132: invokevirtual 264	java/io/FileInputStream:close	()V
    //   135: ldc_w 266
    //   138: invokestatic 120	com/google/tagmanager/Log:v	(Ljava/lang/String;)V
    //   141: return
    //   142: astore_2
    //   143: ldc_w 268
    //   146: invokestatic 271	com/google/tagmanager/Log:d	(Ljava/lang/String;)V
    //   149: aload_1
    //   150: getfield 196	com/google/tagmanager/ResourceStorageImpl:mCallback	Lcom/google/tagmanager/LoadCallback;
    //   153: getstatic 243	com/google/tagmanager/LoadCallback$Failure:NOT_AVAILABLE	Lcom/google/tagmanager/LoadCallback$Failure;
    //   156: invokeinterface 247 2 0
    //   161: return
    //   162: astore_1
    //   163: ldc_w 273
    //   166: invokestatic 129	com/google/tagmanager/Log:w	(Ljava/lang/String;)V
    //   169: goto -34 -> 135
    //   172: astore_1
    //   173: ldc_w 275
    //   176: invokestatic 129	com/google/tagmanager/Log:w	(Ljava/lang/String;)V
    //   179: aload_0
    //   180: getfield 196	com/google/tagmanager/ResourceStorageImpl:mCallback	Lcom/google/tagmanager/LoadCallback;
    //   183: getstatic 278	com/google/tagmanager/LoadCallback$Failure:IO_ERROR	Lcom/google/tagmanager/LoadCallback$Failure;
    //   186: invokeinterface 247 2 0
    //   191: aload_2
    //   192: invokevirtual 264	java/io/FileInputStream:close	()V
    //   195: goto -60 -> 135
    //   198: astore_1
    //   199: ldc_w 273
    //   202: invokestatic 129	com/google/tagmanager/Log:w	(Ljava/lang/String;)V
    //   205: goto -70 -> 135
    //   208: astore_1
    //   209: aload_2
    //   210: invokevirtual 264	java/io/FileInputStream:close	()V
    //   213: aload_1
    //   214: athrow
    //   215: astore_2
    //   216: ldc_w 273
    //   219: invokestatic 129	com/google/tagmanager/Log:w	(Ljava/lang/String;)V
    //   222: goto -9 -> 213
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	225	0	this	ResourceStorageImpl
    //   23	127	1	localObject1	Object
    //   162	1	1	localIOException1	IOException
    //   172	1	1	localIOException2	IOException
    //   198	1	1	localIOException3	IOException
    //   208	6	1	localThrowable	Throwable
    //   21	111	2	localObject2	Object
    //   142	68	2	localFileNotFoundException	java.io.FileNotFoundException
    //   215	1	2	localIOException4	IOException
    //   107	13	3	localByteArrayOutputStream	java.io.ByteArrayOutputStream
    // Exception table:
    //   from	to	target	type
    //   88	100	142	java/io/FileNotFoundException
    //   131	135	162	java/io/IOException
    //   100	113	172	java/io/IOException
    //   118	131	172	java/io/IOException
    //   191	195	198	java/io/IOException
    //   100	113	208	java/lang/Throwable
    //   118	131	208	java/lang/Throwable
    //   173	191	208	java/lang/Throwable
    //   209	213	215	java/io/IOException
  }
  
  public void loadResourceFromDiskInBackground()
  {
    mExecutor.execute(new Runnable()
    {
      public void run()
      {
        loadResourceFromDisk();
      }
    });
  }
  
  /* Error */
  boolean saveResourceToDisk(Resource.ResourceWithMetadata paramResourceWithMetadata)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 251	com/google/tagmanager/ResourceStorageImpl:getResourceFile	()Ljava/io/File;
    //   4: astore_3
    //   5: new 290	java/io/FileOutputStream
    //   8: dup
    //   9: aload_3
    //   10: invokespecial 291	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   13: astore_2
    //   14: aload_2
    //   15: aload_1
    //   16: invokestatic 296	com/google/tagmanager/protobuf/nano/MessageNano:toByteArray	(Lcom/google/tagmanager/protobuf/nano/MessageNano;)[B
    //   19: invokevirtual 299	java/io/FileOutputStream:write	([B)V
    //   22: aload_2
    //   23: invokevirtual 300	java/io/FileOutputStream:close	()V
    //   26: iconst_1
    //   27: ireturn
    //   28: astore_1
    //   29: ldc_w 302
    //   32: invokestatic 166	com/google/tagmanager/Log:e	(Ljava/lang/String;)V
    //   35: iconst_0
    //   36: ireturn
    //   37: astore_1
    //   38: ldc_w 304
    //   41: invokestatic 129	com/google/tagmanager/Log:w	(Ljava/lang/String;)V
    //   44: goto -18 -> 26
    //   47: astore_1
    //   48: ldc_w 306
    //   51: invokestatic 129	com/google/tagmanager/Log:w	(Ljava/lang/String;)V
    //   54: aload_3
    //   55: invokevirtual 310	java/io/File:delete	()Z
    //   58: pop
    //   59: aload_2
    //   60: invokevirtual 300	java/io/FileOutputStream:close	()V
    //   63: iconst_0
    //   64: ireturn
    //   65: astore_1
    //   66: ldc_w 304
    //   69: invokestatic 129	com/google/tagmanager/Log:w	(Ljava/lang/String;)V
    //   72: goto -9 -> 63
    //   75: astore_1
    //   76: aload_2
    //   77: invokevirtual 300	java/io/FileOutputStream:close	()V
    //   80: aload_1
    //   81: athrow
    //   82: astore_2
    //   83: ldc_w 304
    //   86: invokestatic 129	com/google/tagmanager/Log:w	(Ljava/lang/String;)V
    //   89: goto -9 -> 80
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	92	0	this	ResourceStorageImpl
    //   0	92	1	paramResourceWithMetadata	Resource.ResourceWithMetadata
    //   13	64	2	localFileOutputStream	java.io.FileOutputStream
    //   82	1	2	localIOException	IOException
    //   4	51	3	localFile	File
    // Exception table:
    //   from	to	target	type
    //   5	14	28	java/io/FileNotFoundException
    //   22	26	37	java/io/IOException
    //   14	22	47	java/io/IOException
    //   59	63	65	java/io/IOException
    //   14	22	75	java/lang/Throwable
    //   48	59	75	java/lang/Throwable
    //   76	80	82	java/io/IOException
  }
  
  public void saveResourceToDiskInBackground(final Resource.ResourceWithMetadata paramResourceWithMetadata)
  {
    mExecutor.execute(new Runnable()
    {
      public void run()
      {
        saveResourceToDisk(paramResourceWithMetadata);
      }
    });
  }
  
  public void setLoadCallback(LoadCallback paramLoadCallback)
  {
    mCallback = paramLoadCallback;
  }
}
