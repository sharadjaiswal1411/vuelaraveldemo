package com.google.tagmanager;

class NoopValueBuilder
  implements ValueBuilder
{
  NoopValueBuilder() {}
  
  public MacroEvaluationInfoBuilder createValueMacroEvaluationInfoExtension()
  {
    return new NoopMacroEvaluationInfoBuilder();
  }
  
  public ValueBuilder getListItem(int paramInt)
  {
    return new NoopValueBuilder();
  }
  
  public ValueBuilder getMapKey(int paramInt)
  {
    return new NoopValueBuilder();
  }
  
  public ValueBuilder getMapValue(int paramInt)
  {
    return new NoopValueBuilder();
  }
  
  public ValueBuilder getTemplateToken(int paramInt)
  {
    return new NoopValueBuilder();
  }
}
