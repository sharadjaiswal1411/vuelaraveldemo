package com.google.tagmanager;

import android.os.Build.VERSION;
import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class SdkVersionMacro
  extends FunctionCallImplementation
{
  private static final String cachePath = FunctionType.SDK_VERSION.toString();
  
  public SdkVersionMacro()
  {
    super(cachePath, new String[0]);
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    return Types.objectToValue(Integer.valueOf(Build.VERSION.SDK_INT));
  }
  
  public boolean isCacheable()
  {
    return true;
  }
}
