package com.google.tagmanager;

abstract interface MacroEvaluationInfoBuilder
{
  public abstract ResolvedFunctionCallBuilder createResult();
  
  public abstract RuleEvaluationStepInfoBuilder createRulesEvaluation();
}
