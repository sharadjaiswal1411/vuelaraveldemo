package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class RuntimeVersionMacro
  extends FunctionCallImplementation
{
  public static final long VERSION_NUMBER = 62676326L;
  private static final String cachePath = FunctionType.RUNTIME_VERSION.toString();
  
  public RuntimeVersionMacro()
  {
    super(cachePath, new String[0]);
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    return Types.objectToValue(Long.valueOf(62676326L));
  }
  
  public boolean isCacheable()
  {
    return true;
  }
}
