package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class ConstantMacro
  extends FunctionCallImplementation
{
  private static final String NAME = FunctionType.CONSTANT.toString();
  private static final String VALUE = Key.VALUE.toString();
  
  public ConstantMacro()
  {
    super(NAME, new String[] { VALUE });
  }
  
  public static String getFunctionId()
  {
    return NAME;
  }
  
  public static String getValueKey()
  {
    return VALUE;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    return (TypeSystem.Value)paramMap.get(VALUE);
  }
  
  public boolean isCacheable()
  {
    return true;
  }
}
