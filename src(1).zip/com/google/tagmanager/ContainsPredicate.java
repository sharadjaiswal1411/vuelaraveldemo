package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import java.util.Map;

class ContainsPredicate
  extends StringPredicate
{
  private static final String cachePath = FunctionType.CONTAINS.toString();
  
  public ContainsPredicate()
  {
    super(cachePath);
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  protected boolean evaluateString(String paramString1, String paramString2, Map paramMap)
  {
    return paramString1.contains(paramString2);
  }
}
