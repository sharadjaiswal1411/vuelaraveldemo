package com.google.tagmanager;

import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import com.google.tagmanager.protobuf.nano.MessageNano;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class Types
{
  private static Boolean DEFAULT_BOOLEAN = new Boolean(false);
  private static Double DEFAULT_DOUBLE;
  private static Long DEFAULT_INT64;
  private static List<Object> DEFAULT_LIST = new ArrayList(0);
  private static Map<Object, Object> DEFAULT_MAP = new HashMap();
  private static TypedNumber DEFAULT_NUMBER;
  private static final Object DEFAULT_OBJECT = null;
  private static String DEFAULT_STRING;
  private static TypeSystem.Value DEFAULT_VALUE = objectToValue(DEFAULT_STRING);
  
  static
  {
    DEFAULT_INT64 = new Long(0L);
    DEFAULT_DOUBLE = new Double(0.0D);
    DEFAULT_NUMBER = TypedNumber.numberWithInt64(0L);
    DEFAULT_STRING = new String("");
  }
  
  private Types() {}
  
  public static TypeSystem.Value functionIdToValue(String paramString)
  {
    TypeSystem.Value localValue = new TypeSystem.Value();
    type = 5;
    functionId = paramString;
    return localValue;
  }
  
  public static Boolean getDefaultBoolean()
  {
    return DEFAULT_BOOLEAN;
  }
  
  public static Double getDefaultDouble()
  {
    return DEFAULT_DOUBLE;
  }
  
  public static Long getDefaultInt64()
  {
    return DEFAULT_INT64;
  }
  
  public static List getDefaultList()
  {
    return DEFAULT_LIST;
  }
  
  public static Map getDefaultMap()
  {
    return DEFAULT_MAP;
  }
  
  public static TypedNumber getDefaultNumber()
  {
    return DEFAULT_NUMBER;
  }
  
  public static Object getDefaultObject()
  {
    return DEFAULT_OBJECT;
  }
  
  public static String getDefaultString()
  {
    return DEFAULT_STRING;
  }
  
  public static TypeSystem.Value getDefaultValue()
  {
    return DEFAULT_VALUE;
  }
  
  private static double getDouble(Object paramObject)
  {
    if ((paramObject instanceof Number)) {
      return ((Number)paramObject).doubleValue();
    }
    Log.e("getDouble received non-Number");
    return 0.0D;
  }
  
  private static long getInt64(Object paramObject)
  {
    if ((paramObject instanceof Number)) {
      return ((Number)paramObject).longValue();
    }
    Log.e("getInt64 received non-Number");
    return 0L;
  }
  
  private static boolean isDoubleableNumber(Object paramObject)
  {
    return ((paramObject instanceof Double)) || ((paramObject instanceof Float)) || (((paramObject instanceof TypedNumber)) && (((TypedNumber)paramObject).isDouble()));
  }
  
  private static boolean isInt64ableNumber(Object paramObject)
  {
    return ((paramObject instanceof Byte)) || ((paramObject instanceof Short)) || ((paramObject instanceof Integer)) || ((paramObject instanceof Long)) || (((paramObject instanceof TypedNumber)) && (((TypedNumber)paramObject).isInt64()));
  }
  
  public static TypeSystem.Value macroReferenceToValue(String paramString, int... paramVarArgs)
  {
    TypeSystem.Value localValue = new TypeSystem.Value();
    type = 4;
    macroReference = paramString;
    containsReferences = true;
    escaping = ((int[])paramVarArgs.clone());
    return localValue;
  }
  
  public static Boolean objectToBoolean(Object paramObject)
  {
    if ((paramObject instanceof Boolean)) {
      return (Boolean)paramObject;
    }
    return parseBoolean(objectToString(paramObject));
  }
  
  public static Double objectToDouble(Object paramObject)
  {
    if (isDoubleableNumber(paramObject)) {
      return Double.valueOf(getDouble(paramObject));
    }
    return parseDouble(objectToString(paramObject));
  }
  
  public static Long objectToInt64(Object paramObject)
  {
    if (isInt64ableNumber(paramObject)) {
      return Long.valueOf(getInt64(paramObject));
    }
    return parseInt64(objectToString(paramObject));
  }
  
  public static TypedNumber objectToNumber(Object paramObject)
  {
    if ((paramObject instanceof TypedNumber)) {
      return (TypedNumber)paramObject;
    }
    if (isInt64ableNumber(paramObject)) {
      return TypedNumber.numberWithInt64(getInt64(paramObject));
    }
    if (isDoubleableNumber(paramObject)) {
      return TypedNumber.numberWithDouble(Double.valueOf(getDouble(paramObject)));
    }
    return parseNumber(objectToString(paramObject));
  }
  
  public static String objectToString(Object paramObject)
  {
    if (paramObject == null) {
      return DEFAULT_STRING;
    }
    return paramObject.toString();
  }
  
  public static TypeSystem.Value objectToValue(Object paramObject)
  {
    Object localObject1 = new TypeSystem.Value();
    boolean bool2 = false;
    boolean bool3 = false;
    boolean bool1 = false;
    if ((paramObject instanceof TypeSystem.Value)) {
      return (TypeSystem.Value)paramObject;
    }
    if ((paramObject instanceof String))
    {
      type = 1;
      string = ((String)paramObject);
    }
    for (;;)
    {
      containsReferences = bool1;
      return localObject1;
      Object localObject2;
      Object localObject3;
      if ((paramObject instanceof List))
      {
        type = 2;
        localObject2 = (List)paramObject;
        paramObject = new ArrayList(((List)localObject2).size());
        localObject2 = ((List)localObject2).iterator();
        bool1 = bool2;
        if (((Iterator)localObject2).hasNext())
        {
          localObject3 = objectToValue(((Iterator)localObject2).next());
          if (localObject3 == DEFAULT_VALUE) {
            return DEFAULT_VALUE;
          }
          if ((bool1) || (containsReferences)) {}
          for (bool1 = true;; bool1 = false)
          {
            paramObject.add(localObject3);
            break;
          }
        }
        listItem = ((TypeSystem.Value[])paramObject.toArray(new TypeSystem.Value[0]));
      }
      else if ((paramObject instanceof Map))
      {
        type = 3;
        localObject3 = ((Map)paramObject).entrySet();
        paramObject = new ArrayList(((Set)localObject3).size());
        localObject2 = new ArrayList(((Set)localObject3).size());
        localObject3 = ((Set)localObject3).iterator();
        bool1 = bool3;
        if (((Iterator)localObject3).hasNext())
        {
          Object localObject4 = (Map.Entry)((Iterator)localObject3).next();
          TypeSystem.Value localValue = objectToValue(((Map.Entry)localObject4).getKey());
          localObject4 = objectToValue(((Map.Entry)localObject4).getValue());
          if ((localValue == DEFAULT_VALUE) || (localObject4 == DEFAULT_VALUE)) {
            return DEFAULT_VALUE;
          }
          if ((bool1) || (containsReferences) || (containsReferences)) {}
          for (bool1 = true;; bool1 = false)
          {
            paramObject.add(localValue);
            ((List)localObject2).add(localObject4);
            break;
          }
        }
        mapKey = ((TypeSystem.Value[])paramObject.toArray(new TypeSystem.Value[0]));
        mapValue = ((TypeSystem.Value[])((List)localObject2).toArray(new TypeSystem.Value[0]));
      }
      else if (isDoubleableNumber(paramObject))
      {
        type = 1;
        string = paramObject.toString();
      }
      else if (isInt64ableNumber(paramObject))
      {
        type = 6;
        integer = getInt64(paramObject);
      }
      else
      {
        if (!(paramObject instanceof Boolean)) {
          break;
        }
        type = 8;
        boolean_ = ((Boolean)paramObject).booleanValue();
      }
    }
    localObject1 = new StringBuilder().append("Converting to Value from unknown object type: ");
    if (paramObject == null) {}
    for (paramObject = "null";; paramObject = paramObject.getClass().toString())
    {
      Log.e(paramObject);
      return DEFAULT_VALUE;
    }
  }
  
  private static Boolean parseBoolean(String paramString)
  {
    if ("true".equalsIgnoreCase(paramString)) {
      return Boolean.TRUE;
    }
    if ("false".equalsIgnoreCase(paramString)) {
      return Boolean.FALSE;
    }
    return DEFAULT_BOOLEAN;
  }
  
  private static Double parseDouble(String paramString)
  {
    paramString = parseNumber(paramString);
    if (paramString == DEFAULT_NUMBER) {
      return DEFAULT_DOUBLE;
    }
    return Double.valueOf(paramString.doubleValue());
  }
  
  private static Long parseInt64(String paramString)
  {
    paramString = parseNumber(paramString);
    if (paramString == DEFAULT_NUMBER) {
      return DEFAULT_INT64;
    }
    return Long.valueOf(paramString.longValue());
  }
  
  private static TypedNumber parseNumber(String paramString)
  {
    try
    {
      TypedNumber localTypedNumber = TypedNumber.numberWithString(paramString);
      return localTypedNumber;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      Log.e("Failed to convert '" + paramString + "' to a number.");
    }
    return DEFAULT_NUMBER;
  }
  
  public static TypeSystem.Value templateToValue(TypeSystem.Value... paramVarArgs)
  {
    TypeSystem.Value localValue = new TypeSystem.Value();
    type = 7;
    boolean bool = false;
    templateToken = new TypeSystem.Value[paramVarArgs.length];
    int i = 0;
    if (i < paramVarArgs.length)
    {
      templateToken[i] = paramVarArgs[i];
      if ((bool) || (containsReferences)) {}
      for (bool = true;; bool = false)
      {
        i += 1;
        break;
      }
    }
    containsReferences = bool;
    return localValue;
  }
  
  public static Boolean valueToBoolean(TypeSystem.Value paramValue)
  {
    return objectToBoolean(valueToObject(paramValue));
  }
  
  public static Double valueToDouble(TypeSystem.Value paramValue)
  {
    return objectToDouble(valueToObject(paramValue));
  }
  
  public static Long valueToInt64(TypeSystem.Value paramValue)
  {
    return objectToInt64(valueToObject(paramValue));
  }
  
  public static TypedNumber valueToNumber(TypeSystem.Value paramValue)
  {
    return objectToNumber(valueToObject(paramValue));
  }
  
  public static Object valueToObject(TypeSystem.Value paramValue)
  {
    if (paramValue == null) {
      return DEFAULT_OBJECT;
    }
    Object localObject1;
    int j;
    int i;
    switch (type)
    {
    default: 
      Log.e("Failed to convert a value of type: " + type);
      return DEFAULT_OBJECT;
    case 1: 
      return string;
    case 2: 
      localObject1 = new ArrayList(listItem.length);
      paramValue = listItem;
      j = paramValue.length;
      i = 0;
    }
    while (i < j)
    {
      Object localObject2 = valueToObject(paramValue[i]);
      if (localObject2 == DEFAULT_OBJECT) {
        return DEFAULT_OBJECT;
      }
      ((ArrayList)localObject1).add(localObject2);
      i += 1;
      continue;
      if (mapKey.length != mapValue.length)
      {
        Log.e("Converting an invalid value to object: " + paramValue.toString());
        return DEFAULT_OBJECT;
      }
      localObject1 = new LinkedHashMap(mapValue.length);
      i = 0;
      while (i < mapKey.length)
      {
        localObject2 = valueToObject(mapKey[i]);
        Object localObject3 = valueToObject(mapValue[i]);
        if ((localObject2 == DEFAULT_OBJECT) || (localObject3 == DEFAULT_OBJECT)) {
          return DEFAULT_OBJECT;
        }
        ((Map)localObject1).put(localObject2, localObject3);
        i += 1;
      }
      return localObject1;
      Log.e("Trying to convert a macro reference to object");
      return DEFAULT_OBJECT;
      Log.e("Trying to convert a function id to object");
      return DEFAULT_OBJECT;
      return Long.valueOf(integer);
      localObject1 = new StringBuffer();
      paramValue = templateToken;
      j = paramValue.length;
      i = 0;
      while (i < j)
      {
        localObject2 = valueToString(paramValue[i]);
        if (localObject2 == DEFAULT_STRING) {
          return DEFAULT_OBJECT;
        }
        ((StringBuffer)localObject1).append((String)localObject2);
        i += 1;
      }
      return ((StringBuffer)localObject1).toString();
      return Boolean.valueOf(boolean_);
    }
    return localObject1;
  }
  
  public static String valueToString(TypeSystem.Value paramValue)
  {
    return objectToString(valueToObject(paramValue));
  }
}
