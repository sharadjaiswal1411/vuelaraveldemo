package com.google.tagmanager;

import android.content.Context;
import com.google.analytics.containertag.proto.Serving.SupplementedResource;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

class ResourceLoaderSchedulerImpl
  implements Container.ResourceLoaderScheduler
{
  private static final boolean MAY_INTERRUPT_IF_RUNNING = true;
  private LoadCallback<Serving.SupplementedResource> mCallback;
  private boolean mClosed;
  private final String mContainerId;
  private final Context mContext;
  private CtfeHost mCtfeHost;
  private String mCtfeUrlPathAndQuery;
  private final ScheduledExecutorService mExecutor;
  private ScheduledFuture<?> mFuture;
  private final ResourceLoaderFactory mResourceLoaderFactory;
  
  public ResourceLoaderSchedulerImpl(Context paramContext, String paramString, CtfeHost paramCtfeHost)
  {
    this(paramContext, paramString, paramCtfeHost, null, null);
  }
  
  ResourceLoaderSchedulerImpl(Context paramContext, String paramString, CtfeHost paramCtfeHost, ScheduledExecutorServiceFactory paramScheduledExecutorServiceFactory, ResourceLoaderFactory paramResourceLoaderFactory) {}
  
  private ResourceLoader createResourceLoader(String paramString)
  {
    ResourceLoader localResourceLoader = mResourceLoaderFactory.createResourceLoader(mCtfeHost);
    localResourceLoader.setLoadCallback(mCallback);
    localResourceLoader.setCtfeURLPathAndQuery(mCtfeUrlPathAndQuery);
    localResourceLoader.setPreviousVersion(paramString);
    return localResourceLoader;
  }
  
  private void ensureNotClosed()
  {
    try
    {
      if (mClosed) {
        throw new IllegalStateException("called method after closed");
      }
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public void close()
  {
    try
    {
      ensureNotClosed();
      if (mFuture != null) {
        mFuture.cancel(false);
      }
      mExecutor.shutdown();
      mClosed = true;
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public void loadAfterDelay(long paramLong, String paramString)
  {
    try
    {
      Log.v("loadAfterDelay: containerId=" + mContainerId + " delay=" + paramLong);
      ensureNotClosed();
      if (mCallback == null) {
        throw new IllegalStateException("callback must be set before loadAfterDelay() is called.");
      }
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
    if (mFuture != null) {
      mFuture.cancel(false);
    }
    mFuture = mExecutor.schedule(createResourceLoader(paramString), paramLong, TimeUnit.MILLISECONDS);
  }
  
  public void setCtfeURLPathAndQuery(String paramString)
  {
    try
    {
      ensureNotClosed();
      mCtfeUrlPathAndQuery = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setLoadCallback(LoadCallback paramLoadCallback)
  {
    try
    {
      ensureNotClosed();
      mCallback = paramLoadCallback;
      return;
    }
    catch (Throwable paramLoadCallback)
    {
      throw paramLoadCallback;
    }
  }
  
  static abstract interface ResourceLoaderFactory
  {
    public abstract ResourceLoader createResourceLoader(CtfeHost paramCtfeHost);
  }
  
  static abstract interface ScheduledExecutorServiceFactory
  {
    public abstract ScheduledExecutorService createExecutorService();
  }
}
