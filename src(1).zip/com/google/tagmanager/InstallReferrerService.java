package com.google.tagmanager;

import android.app.IntentService;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import com.google.analytics.tracking.android.CampaignTrackingService;
import com.google.android.gms.common.util.VisibleForTesting;

public final class InstallReferrerService
  extends IntentService
{
  @VisibleForTesting
  Context contextOverride;
  @VisibleForTesting
  CampaignTrackingService gaService;
  
  public InstallReferrerService()
  {
    super("InstallReferrerService");
  }
  
  public InstallReferrerService(String paramString)
  {
    super(paramString);
  }
  
  private void forwardToGoogleAnalytics(Context paramContext, Intent paramIntent)
  {
    if (gaService == null) {
      gaService = new CampaignTrackingService();
    }
    gaService.processIntent(paramContext, paramIntent);
  }
  
  protected void onHandleIntent(Intent paramIntent)
  {
    String str = paramIntent.getStringExtra("referrer");
    if (contextOverride != null) {}
    for (Context localContext = contextOverride;; localContext = getApplicationContext())
    {
      InstallReferrerUtil.saveInstallReferrer(localContext, str);
      forwardToGoogleAnalytics(localContext, paramIntent);
      return;
    }
  }
}
