package com.google.tagmanager;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.google.analytics.containertag.proto.Serving.SupplementedResource;
import com.google.android.gms.common.util.VisibleForTesting;

class ResourceLoader
  implements Runnable
{
  private static final String CTFE_URL_PREFIX = "/r?id=";
  private static final String CTFE_URL_SUFFIX = "&v=a62676326";
  private static final String PREVIOUS_CONTAINER_VERSION_QUERY_NAME = "pv";
  @VisibleForTesting
  static final String SDK_VERSION = "a62676326";
  private LoadCallback<Serving.SupplementedResource> mCallback;
  private final NetworkClientFactory mClientFactory;
  private final String mContainerId;
  private final Context mContext;
  private volatile CtfeHost mCtfeHost;
  private volatile String mCtfeUrlPathAndQuery;
  private final String mDefaultCtfeUrlPathAndQuery;
  private volatile String mPreviousVersion;
  
  public ResourceLoader(Context paramContext, String paramString, CtfeHost paramCtfeHost)
  {
    this(paramContext, paramString, new NetworkClientFactory(), paramCtfeHost);
  }
  
  ResourceLoader(Context paramContext, String paramString, NetworkClientFactory paramNetworkClientFactory, CtfeHost paramCtfeHost)
  {
    mContext = paramContext;
    mClientFactory = paramNetworkClientFactory;
    mContainerId = paramString;
    mCtfeHost = paramCtfeHost;
    mDefaultCtfeUrlPathAndQuery = ("/r?id=" + paramString);
    mCtfeUrlPathAndQuery = mDefaultCtfeUrlPathAndQuery;
    mPreviousVersion = null;
  }
  
  /* Error */
  private void loadResource()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 81	com/google/tagmanager/ResourceLoader:okToLoad	()Z
    //   4: ifne +16 -> 20
    //   7: aload_0
    //   8: getfield 83	com/google/tagmanager/ResourceLoader:mCallback	Lcom/google/tagmanager/LoadCallback;
    //   11: getstatic 89	com/google/tagmanager/LoadCallback$Failure:NOT_AVAILABLE	Lcom/google/tagmanager/LoadCallback$Failure;
    //   14: invokeinterface 95 2 0
    //   19: return
    //   20: ldc 97
    //   22: invokestatic 103	com/google/tagmanager/Log:v	(Ljava/lang/String;)V
    //   25: aload_0
    //   26: invokevirtual 106	com/google/tagmanager/ResourceLoader:getCtfeUrl	()Ljava/lang/String;
    //   29: astore_2
    //   30: aload_0
    //   31: getfield 49	com/google/tagmanager/ResourceLoader:mClientFactory	Lcom/google/tagmanager/NetworkClientFactory;
    //   34: invokevirtual 110	com/google/tagmanager/NetworkClientFactory:createNetworkClient	()Lcom/google/tagmanager/NetworkClient;
    //   37: astore_1
    //   38: aload_1
    //   39: aload_2
    //   40: invokeinterface 116 2 0
    //   45: astore_3
    //   46: new 118	java/io/ByteArrayOutputStream
    //   49: dup
    //   50: invokespecial 119	java/io/ByteArrayOutputStream:<init>	()V
    //   53: astore 4
    //   55: aload_3
    //   56: aload 4
    //   58: invokestatic 125	com/google/tagmanager/ResourceUtil:copyStream	(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    //   61: aload 4
    //   63: invokevirtual 129	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   66: invokestatic 135	com/google/analytics/containertag/proto/Serving$SupplementedResource:parseFrom	([B)Lcom/google/analytics/containertag/proto/Serving$SupplementedResource;
    //   69: astore_3
    //   70: new 55	java/lang/StringBuilder
    //   73: dup
    //   74: invokespecial 56	java/lang/StringBuilder:<init>	()V
    //   77: ldc -119
    //   79: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   82: aload_3
    //   83: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   86: invokevirtual 64	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   89: invokestatic 103	com/google/tagmanager/Log:v	(Ljava/lang/String;)V
    //   92: aload_3
    //   93: getfield 144	com/google/analytics/containertag/proto/Serving$SupplementedResource:resource	Lcom/google/analytics/containertag/proto/Serving$Resource;
    //   96: astore 4
    //   98: aload 4
    //   100: ifnonnull +36 -> 136
    //   103: new 55	java/lang/StringBuilder
    //   106: dup
    //   107: invokespecial 56	java/lang/StringBuilder:<init>	()V
    //   110: ldc -110
    //   112: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   115: astore 4
    //   117: aload_0
    //   118: getfield 51	com/google/tagmanager/ResourceLoader:mContainerId	Ljava/lang/String;
    //   121: astore 5
    //   123: aload 4
    //   125: aload 5
    //   127: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   130: invokevirtual 64	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   133: invokestatic 103	com/google/tagmanager/Log:v	(Ljava/lang/String;)V
    //   136: aload_0
    //   137: getfield 83	com/google/tagmanager/ResourceLoader:mCallback	Lcom/google/tagmanager/LoadCallback;
    //   140: astore 4
    //   142: aload 4
    //   144: aload_3
    //   145: invokeinterface 150 2 0
    //   150: aload_1
    //   151: invokeinterface 153 1 0
    //   156: ldc -101
    //   158: invokestatic 103	com/google/tagmanager/Log:v	(Ljava/lang/String;)V
    //   161: return
    //   162: astore_3
    //   163: new 55	java/lang/StringBuilder
    //   166: dup
    //   167: invokespecial 56	java/lang/StringBuilder:<init>	()V
    //   170: ldc -99
    //   172: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   175: aload_2
    //   176: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   179: ldc -97
    //   181: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   184: aload_0
    //   185: getfield 51	com/google/tagmanager/ResourceLoader:mContainerId	Ljava/lang/String;
    //   188: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   191: ldc -95
    //   193: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   196: invokevirtual 64	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   199: invokestatic 164	com/google/tagmanager/Log:w	(Ljava/lang/String;)V
    //   202: aload_0
    //   203: getfield 83	com/google/tagmanager/ResourceLoader:mCallback	Lcom/google/tagmanager/LoadCallback;
    //   206: getstatic 167	com/google/tagmanager/LoadCallback$Failure:SERVER_ERROR	Lcom/google/tagmanager/LoadCallback$Failure;
    //   209: invokeinterface 95 2 0
    //   214: aload_1
    //   215: invokeinterface 153 1 0
    //   220: return
    //   221: astore_3
    //   222: new 55	java/lang/StringBuilder
    //   225: dup
    //   226: invokespecial 56	java/lang/StringBuilder:<init>	()V
    //   229: ldc -87
    //   231: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   234: aload_2
    //   235: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   238: ldc -85
    //   240: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   243: aload_3
    //   244: invokevirtual 174	java/io/IOException:getMessage	()Ljava/lang/String;
    //   247: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   250: invokevirtual 64	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   253: aload_3
    //   254: invokestatic 177	com/google/tagmanager/Log:w	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   257: aload_0
    //   258: getfield 83	com/google/tagmanager/ResourceLoader:mCallback	Lcom/google/tagmanager/LoadCallback;
    //   261: getstatic 180	com/google/tagmanager/LoadCallback$Failure:IO_ERROR	Lcom/google/tagmanager/LoadCallback$Failure;
    //   264: invokeinterface 95 2 0
    //   269: aload_1
    //   270: invokeinterface 153 1 0
    //   275: return
    //   276: astore_3
    //   277: new 55	java/lang/StringBuilder
    //   280: dup
    //   281: invokespecial 56	java/lang/StringBuilder:<init>	()V
    //   284: ldc -74
    //   286: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   289: aload_2
    //   290: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   293: ldc -85
    //   295: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   298: aload_3
    //   299: invokevirtual 174	java/io/IOException:getMessage	()Ljava/lang/String;
    //   302: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   305: invokevirtual 64	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   308: aload_3
    //   309: invokestatic 177	com/google/tagmanager/Log:w	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   312: aload_0
    //   313: getfield 83	com/google/tagmanager/ResourceLoader:mCallback	Lcom/google/tagmanager/LoadCallback;
    //   316: getstatic 167	com/google/tagmanager/LoadCallback$Failure:SERVER_ERROR	Lcom/google/tagmanager/LoadCallback$Failure;
    //   319: invokeinterface 95 2 0
    //   324: aload_1
    //   325: invokeinterface 153 1 0
    //   330: return
    //   331: astore_2
    //   332: aload_1
    //   333: invokeinterface 153 1 0
    //   338: aload_2
    //   339: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	340	0	this	ResourceLoader
    //   37	296	1	localNetworkClient	NetworkClient
    //   29	261	2	str1	String
    //   331	8	2	localThrowable	Throwable
    //   45	100	3	localObject1	Object
    //   162	1	3	localFileNotFoundException	java.io.FileNotFoundException
    //   221	33	3	localIOException1	java.io.IOException
    //   276	33	3	localIOException2	java.io.IOException
    //   53	90	4	localObject2	Object
    //   121	5	5	str2	String
    // Exception table:
    //   from	to	target	type
    //   38	46	162	java/io/FileNotFoundException
    //   38	46	221	java/io/IOException
    //   46	70	276	java/io/IOException
    //   70	92	276	java/io/IOException
    //   103	117	276	java/io/IOException
    //   123	136	276	java/io/IOException
    //   142	150	276	java/io/IOException
    //   38	46	331	java/lang/Throwable
    //   46	70	331	java/lang/Throwable
    //   70	92	331	java/lang/Throwable
    //   92	98	331	java/lang/Throwable
    //   103	117	331	java/lang/Throwable
    //   117	123	331	java/lang/Throwable
    //   123	136	331	java/lang/Throwable
    //   142	150	331	java/lang/Throwable
    //   163	214	331	java/lang/Throwable
    //   222	269	331	java/lang/Throwable
    //   277	324	331	java/lang/Throwable
  }
  
  private boolean okToLoad()
  {
    NetworkInfo localNetworkInfo = ((ConnectivityManager)mContext.getSystemService("connectivity")).getActiveNetworkInfo();
    if ((localNetworkInfo == null) || (!localNetworkInfo.isConnected()))
    {
      Log.v("...no network connectivity");
      return false;
    }
    return true;
  }
  
  String getCtfeUrl()
  {
    String str3 = mCtfeHost.getCtfeServerAddress() + mCtfeUrlPathAndQuery + "&v=a62676326";
    String str1 = str3;
    String str2 = str1;
    if (mPreviousVersion != null)
    {
      str2 = str1;
      if (!mPreviousVersion.trim().equals("")) {
        str2 = str3 + "&pv=" + mPreviousVersion;
      }
    }
    if (PreviewManager.getInstance().getPreviewMode().equals(PreviewManager.PreviewMode.CONTAINER_DEBUG)) {
      return str2 + "&gtm_debug=x";
    }
    return str2;
  }
  
  public void run()
  {
    if (mCallback == null) {
      throw new IllegalStateException("callback must be set before execute");
    }
    mCallback.startLoad();
    loadResource();
  }
  
  void setCtfeURLPathAndQuery(String paramString)
  {
    if (paramString == null)
    {
      mCtfeUrlPathAndQuery = mDefaultCtfeUrlPathAndQuery;
      return;
    }
    Log.d("Setting CTFE URL path: " + paramString);
    mCtfeUrlPathAndQuery = paramString;
  }
  
  void setLoadCallback(LoadCallback paramLoadCallback)
  {
    mCallback = paramLoadCallback;
  }
  
  void setPreviousVersion(String paramString)
  {
    Log.d("Setting previous container version: " + paramString);
    mPreviousVersion = paramString;
  }
}
