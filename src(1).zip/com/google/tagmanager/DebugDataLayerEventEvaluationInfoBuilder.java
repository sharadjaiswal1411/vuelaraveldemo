package com.google.tagmanager;

import com.google.analytics.containertag.proto.Debug.DataLayerEventEvaluationInfo;
import com.google.analytics.containertag.proto.Debug.ResolvedFunctionCall;
import com.google.analytics.containertag.proto.Debug.RuleEvaluationStepInfo;

class DebugDataLayerEventEvaluationInfoBuilder
  implements DataLayerEventEvaluationInfoBuilder
{
  private Debug.DataLayerEventEvaluationInfo dataLayerEvent;
  
  public DebugDataLayerEventEvaluationInfoBuilder(Debug.DataLayerEventEvaluationInfo paramDataLayerEventEvaluationInfo)
  {
    dataLayerEvent = paramDataLayerEventEvaluationInfo;
  }
  
  public ResolvedFunctionCallBuilder createAndAddResult()
  {
    Debug.ResolvedFunctionCall localResolvedFunctionCall = new Debug.ResolvedFunctionCall();
    dataLayerEvent.results = ArrayUtils.appendToArray(dataLayerEvent.results, localResolvedFunctionCall);
    return new DebugResolvedFunctionCallBuilder(localResolvedFunctionCall);
  }
  
  public RuleEvaluationStepInfoBuilder createRulesEvaluation()
  {
    dataLayerEvent.rulesEvaluation = new Debug.RuleEvaluationStepInfo();
    return new DebugRuleEvaluationStepInfoBuilder(dataLayerEvent.rulesEvaluation);
  }
}
