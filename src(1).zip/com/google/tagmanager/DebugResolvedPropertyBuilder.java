package com.google.tagmanager;

import com.google.analytics.containertag.proto.Debug.ResolvedProperty;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;

class DebugResolvedPropertyBuilder
  implements ResolvedPropertyBuilder
{
  private Debug.ResolvedProperty resolvedProperty;
  
  public DebugResolvedPropertyBuilder(Debug.ResolvedProperty paramResolvedProperty)
  {
    resolvedProperty = paramResolvedProperty;
  }
  
  public ValueBuilder createPropertyValueBuilder(TypeSystem.Value paramValue)
  {
    paramValue = DebugValueBuilder.copyImmutableValue(paramValue);
    resolvedProperty.value = paramValue;
    return new DebugValueBuilder(paramValue);
  }
}
