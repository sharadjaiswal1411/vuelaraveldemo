package com.google.tagmanager;

import com.google.analytics.containertag.proto.Debug.ResolvedRule;
import com.google.analytics.containertag.proto.Debug.RuleEvaluationStepInfo;
import java.util.Iterator;
import java.util.Set;

class DebugRuleEvaluationStepInfoBuilder
  implements RuleEvaluationStepInfoBuilder
{
  private Debug.RuleEvaluationStepInfo ruleEvaluationStepInfo;
  
  public DebugRuleEvaluationStepInfoBuilder(Debug.RuleEvaluationStepInfo paramRuleEvaluationStepInfo)
  {
    ruleEvaluationStepInfo = paramRuleEvaluationStepInfo;
  }
  
  public ResolvedRuleBuilder createResolvedRuleBuilder()
  {
    Debug.ResolvedRule localResolvedRule = new Debug.ResolvedRule();
    ruleEvaluationStepInfo.rules = ArrayUtils.appendToArray(ruleEvaluationStepInfo.rules, localResolvedRule);
    return new DebugResolvedRuleBuilder(localResolvedRule);
  }
  
  public void setEnabledFunctions(Set paramSet)
  {
    paramSet = paramSet.iterator();
    while (paramSet.hasNext())
    {
      ResourceUtil.ExpandedFunctionCall localExpandedFunctionCall = (ResourceUtil.ExpandedFunctionCall)paramSet.next();
      ruleEvaluationStepInfo.enabledFunctions = ArrayUtils.appendToArray(ruleEvaluationStepInfo.enabledFunctions, DebugResolvedRuleBuilder.translateExpandedFunctionCall(localExpandedFunctionCall));
    }
  }
}
