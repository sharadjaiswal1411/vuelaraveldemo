package com.google.tagmanager;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.concurrent.LinkedBlockingQueue;

class HitSendingThreadImpl
  extends Thread
  implements HitSendingThread
{
  private static HitSendingThreadImpl sInstance;
  private volatile boolean mClosed = false;
  private final Context mContext;
  private volatile boolean mDisabled = false;
  private volatile HitStore mUrlStore;
  private final LinkedBlockingQueue<Runnable> queue = new LinkedBlockingQueue();
  
  private HitSendingThreadImpl(Context paramContext)
  {
    super("GAThread");
    if (paramContext != null) {}
    for (mContext = paramContext.getApplicationContext();; mContext = paramContext)
    {
      start();
      return;
    }
  }
  
  HitSendingThreadImpl(Context paramContext, HitStore paramHitStore)
  {
    super("GAThread");
    if (paramContext != null) {}
    for (mContext = paramContext.getApplicationContext();; mContext = paramContext)
    {
      mUrlStore = paramHitStore;
      start();
      return;
    }
  }
  
  static HitSendingThreadImpl getInstance(Context paramContext)
  {
    if (sInstance == null) {
      sInstance = new HitSendingThreadImpl(paramContext);
    }
    return sInstance;
  }
  
  private String printStackTrace(Throwable paramThrowable)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    PrintStream localPrintStream = new PrintStream(localByteArrayOutputStream);
    paramThrowable.printStackTrace(localPrintStream);
    localPrintStream.flush();
    return new String(localByteArrayOutputStream.toByteArray());
  }
  
  void close()
  {
    mClosed = true;
    interrupt();
  }
  
  int getQueueSize()
  {
    return queue.size();
  }
  
  HitStore getStore()
  {
    return mUrlStore;
  }
  
  boolean isDisabled()
  {
    return mDisabled;
  }
  
  public void queueToThread(Runnable paramRunnable)
  {
    queue.add(paramRunnable);
  }
  
  public void run()
  {
    while (!mClosed) {
      try
      {
        Object localObject = queue;
        try
        {
          localObject = ((LinkedBlockingQueue)localObject).take();
          localObject = (Runnable)localObject;
          boolean bool = mDisabled;
          if (!bool) {
            ((Runnable)localObject).run();
          }
        }
        catch (InterruptedException localInterruptedException)
        {
          Log.i(localInterruptedException.toString());
        }
      }
      catch (Throwable localThrowable)
      {
        Log.e("Error on GAThread: " + printStackTrace(localThrowable));
        Log.e("Google Analytics is shutting down.");
        mDisabled = true;
      }
    }
  }
  
  public void sendHit(String paramString)
  {
    sendHit(paramString, System.currentTimeMillis());
  }
  
  void sendHit(String paramString, final long paramLong)
  {
    queueToThread(new Runnable()
    {
      public void run()
      {
        if (mUrlStore == null)
        {
          ServiceManagerImpl localServiceManagerImpl = ServiceManagerImpl.getInstance();
          localServiceManagerImpl.initialize(mContext, jdField_this);
          HitSendingThreadImpl.access$002(HitSendingThreadImpl.this, localServiceManagerImpl.getStore());
        }
        mUrlStore.putHit(paramLong, val$url);
      }
    });
  }
}
