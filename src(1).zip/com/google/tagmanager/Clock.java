package com.google.tagmanager;

abstract interface Clock
{
  public abstract long currentTimeMillis();
}
