package com.google.tagmanager;

import android.content.Context;
import com.google.analytics.tracking.android.GoogleAnalytics;
import com.google.analytics.tracking.android.Logger;
import com.google.analytics.tracking.android.Tracker;

class TrackerProvider
{
  private Context mContext;
  private GoogleAnalytics mGoogleAnalytics;
  
  TrackerProvider(Context paramContext)
  {
    mContext = paramContext;
  }
  
  TrackerProvider(GoogleAnalytics paramGoogleAnalytics)
  {
    mGoogleAnalytics = paramGoogleAnalytics;
    mGoogleAnalytics.setLogger(new LoggerImpl());
  }
  
  private void initTrackProviderIfNecessary()
  {
    try
    {
      if (mGoogleAnalytics == null)
      {
        mGoogleAnalytics = GoogleAnalytics.getInstance(mContext);
        mGoogleAnalytics.setLogger(new LoggerImpl());
      }
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public void close(Tracker paramTracker)
  {
    mGoogleAnalytics.closeTracker(paramTracker.getName());
  }
  
  public Tracker getTracker(String paramString)
  {
    initTrackProviderIfNecessary();
    return mGoogleAnalytics.getTracker(paramString);
  }
  
  static class LoggerImpl
    implements Logger
  {
    LoggerImpl() {}
    
    private static com.google.analytics.tracking.android.Logger.LogLevel toAnalyticsLogLevel(Logger.LogLevel paramLogLevel)
    {
      switch (TrackerProvider.1.$SwitchMap$com$google$tagmanager$Logger$LogLevel[paramLogLevel.ordinal()])
      {
      default: 
        return com.google.analytics.tracking.android.Logger.LogLevel.ERROR;
      case 1: 
      case 2: 
        return com.google.analytics.tracking.android.Logger.LogLevel.ERROR;
      case 3: 
        return com.google.analytics.tracking.android.Logger.LogLevel.WARNING;
      case 4: 
      case 5: 
        return com.google.analytics.tracking.android.Logger.LogLevel.INFO;
      }
      return com.google.analytics.tracking.android.Logger.LogLevel.VERBOSE;
    }
    
    public void error(Exception paramException)
    {
      Log.e("", paramException);
    }
    
    public void error(String paramString)
    {
      Log.e(paramString);
    }
    
    public com.google.analytics.tracking.android.Logger.LogLevel getLogLevel()
    {
      Logger.LogLevel localLogLevel = Log.getLogLevel();
      if (localLogLevel == null) {
        return com.google.analytics.tracking.android.Logger.LogLevel.ERROR;
      }
      return toAnalyticsLogLevel(localLogLevel);
    }
    
    public void info(String paramString)
    {
      Log.i(paramString);
    }
    
    public void setLogLevel(com.google.analytics.tracking.android.Logger.LogLevel paramLogLevel)
    {
      Log.w("GA uses GTM logger. Please use TagManager.getLogger().setLogLevel(LogLevel) instead.");
    }
    
    public void verbose(String paramString)
    {
      Log.v(paramString);
    }
    
    public void warn(String paramString)
    {
      Log.w(paramString);
    }
  }
}
