package com.google.tagmanager;

abstract interface HitSendingThread
{
  public abstract void queueToThread(Runnable paramRunnable);
  
  public abstract void sendHit(String paramString);
}
