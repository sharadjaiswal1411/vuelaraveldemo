package com.google.tagmanager;

class DebugEventInfoDistributor
  implements EventInfoDistributor
{
  private String containerId;
  private String containerVersion;
  private DebugInformationHandler handler;
  
  public DebugEventInfoDistributor(DebugInformationHandler paramDebugInformationHandler, String paramString1, String paramString2)
  {
    handler = paramDebugInformationHandler;
    containerVersion = paramString1;
    containerId = paramString2;
  }
  
  public EventInfoBuilder createDataLayerEventEvaluationEventInfo(String paramString)
  {
    return new DebugEventInfoBuilder(1, containerVersion, containerId, paramString, handler);
  }
  
  public EventInfoBuilder createMacroEvalutionEventInfo(String paramString)
  {
    return new DebugEventInfoBuilder(2, containerVersion, containerId, paramString, handler);
  }
  
  public boolean debugMode()
  {
    return true;
  }
}
