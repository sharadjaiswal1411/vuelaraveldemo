package com.google.tagmanager;

abstract interface DataLayerEventEvaluationInfoBuilder
{
  public abstract ResolvedFunctionCallBuilder createAndAddResult();
  
  public abstract RuleEvaluationStepInfoBuilder createRulesEvaluation();
}
