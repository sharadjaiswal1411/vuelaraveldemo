package com.google.tagmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build.VERSION;
import android.text.TextUtils;
import com.google.android.gms.common.util.VisibleForTesting;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

class DataLayerPersistentStoreImpl
  implements DataLayer.PersistentStore
{
  private static final String CREATE_MAPS_TABLE = String.format("CREATE TABLE IF NOT EXISTS %s ( '%s' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, '%s' STRING NOT NULL, '%s' BLOB NOT NULL, '%s' INTEGER NOT NULL);", new Object[] { "datalayer", "ID", "key", "value", "expires" });
  private static final String DATABASE_NAME = "google_tagmanager.db";
  private static final String EXPIRE_FIELD = "expires";
  private static final String ID_FIELD = "ID";
  private static final String KEY_FIELD = "key";
  private static final String MAPS_TABLE = "datalayer";
  private static final int MAX_NUM_STORED_ITEMS = 2000;
  private static final String VALUE_FIELD = "value";
  private Clock mClock;
  private final Context mContext;
  private DatabaseHelper mDbHelper;
  private final Executor mExecutor;
  private int mMaxNumStoredItems;
  
  public DataLayerPersistentStoreImpl(Context paramContext)
  {
    this(paramContext, new Clock()
    {
      public long currentTimeMillis()
      {
        return System.currentTimeMillis();
      }
    }, "google_tagmanager.db", 2000, Executors.newSingleThreadExecutor());
  }
  
  DataLayerPersistentStoreImpl(Context paramContext, Clock paramClock, String paramString, int paramInt, Executor paramExecutor)
  {
    mContext = paramContext;
    mClock = paramClock;
    mMaxNumStoredItems = paramInt;
    mExecutor = paramExecutor;
    mDbHelper = new DatabaseHelper(mContext, paramString);
  }
  
  private void clearKeysWithPrefixSingleThreaded(String paramString)
  {
    SQLiteDatabase localSQLiteDatabase = getWritableDatabase("Error opening database for clearKeysWithPrefix.");
    if (localSQLiteDatabase == null) {
      return;
    }
    try
    {
      String str = paramString + ".%";
      int i = localSQLiteDatabase.delete("datalayer", "key = ? OR key LIKE ?", new String[] { paramString, str });
      Log.v("Cleared " + i + " items");
      closeDatabaseConnection();
      return;
    }
    catch (SQLiteException localSQLiteException)
    {
      Log.w("Error deleting entries with key prefix: " + paramString + " (" + localSQLiteException + ").");
      closeDatabaseConnection();
      return;
    }
    catch (Throwable paramString)
    {
      closeDatabaseConnection();
      throw paramString;
    }
  }
  
  private void closeDatabaseConnection()
  {
    DatabaseHelper localDatabaseHelper = mDbHelper;
    try
    {
      localDatabaseHelper.close();
      return;
    }
    catch (SQLiteException localSQLiteException) {}
  }
  
  private void deleteEntries(String[] paramArrayOfString)
  {
    if (paramArrayOfString != null)
    {
      if (paramArrayOfString.length == 0) {
        return;
      }
      SQLiteDatabase localSQLiteDatabase = getWritableDatabase("Error opening database for deleteEntries.");
      if (localSQLiteDatabase != null)
      {
        String str = String.format("%s in (%s)", new Object[] { "ID", TextUtils.join(",", Collections.nCopies(paramArrayOfString.length, "?")) });
        try
        {
          localSQLiteDatabase.delete("datalayer", str, paramArrayOfString);
          return;
        }
        catch (SQLiteException localSQLiteException)
        {
          Log.w("Error deleting entries " + Arrays.toString(paramArrayOfString));
        }
      }
    }
  }
  
  private void deleteEntriesOlderThan(long paramLong)
  {
    SQLiteDatabase localSQLiteDatabase = getWritableDatabase("Error opening database for deleteOlderThan.");
    if (localSQLiteDatabase == null) {
      return;
    }
    try
    {
      String str = Long.toString(paramLong);
      int i = localSQLiteDatabase.delete("datalayer", "expires <= ?", new String[] { str });
      Log.v("Deleted " + i + " expired items");
      return;
    }
    catch (SQLiteException localSQLiteException)
    {
      Log.w("Error deleting old entries.");
    }
  }
  
  private int getNumStoredEntries()
  {
    int j = 0;
    int i = 0;
    Object localObject4 = getWritableDatabase("Error opening database for getNumStoredEntries.");
    if (localObject4 == null) {
      return 0;
    }
    Object localObject2 = null;
    localObject1 = null;
    try
    {
      Cursor localCursor = ((SQLiteDatabase)localObject4).rawQuery("SELECT COUNT(*) from datalayer", null);
      localObject4 = localCursor;
      localObject1 = localObject4;
      localObject2 = localObject4;
      boolean bool = localCursor.moveToFirst();
      if (bool)
      {
        localObject1 = localObject4;
        localObject2 = localObject4;
        long l = localCursor.getLong(0);
        i = (int)l;
      }
      j = i;
      if (localCursor != null)
      {
        localCursor.close();
        j = i;
      }
    }
    catch (SQLiteException localSQLiteException)
    {
      do
      {
        localObject3 = localObject1;
        Log.w("Error getting numStoredEntries");
      } while (localObject1 == null);
      localObject1.close();
      return 0;
    }
    catch (Throwable localThrowable)
    {
      Object localObject3;
      if (localObject3 == null) {
        break label138;
      }
      localObject3.close();
      throw localThrowable;
    }
    return j;
  }
  
  private SQLiteDatabase getWritableDatabase(String paramString)
  {
    Object localObject = mDbHelper;
    try
    {
      localObject = ((DatabaseHelper)localObject).getWritableDatabase();
      return localObject;
    }
    catch (SQLiteException localSQLiteException)
    {
      Log.w(paramString);
    }
    return null;
  }
  
  private List loadSerialized()
  {
    Object localObject = getWritableDatabase("Error opening database for loadSerialized.");
    ArrayList localArrayList = new ArrayList();
    if (localObject == null) {
      return localArrayList;
    }
    localObject = ((SQLiteDatabase)localObject).query("datalayer", new String[] { "key", "value" }, null, null, null, null, "ID", null);
    try
    {
      for (;;)
      {
        boolean bool = ((Cursor)localObject).moveToNext();
        if (!bool) {
          break;
        }
        localArrayList.add(new KeyAndSerialized(((Cursor)localObject).getString(0), ((Cursor)localObject).getBlob(1)));
      }
      ((Cursor)localObject).close();
    }
    catch (Throwable localThrowable)
    {
      ((Cursor)localObject).close();
      throw localThrowable;
    }
    return localThrowable;
  }
  
  private List loadSingleThreaded()
  {
    try
    {
      deleteEntriesOlderThan(mClock.currentTimeMillis());
      List localList = unserializeValues(loadSerialized());
      closeDatabaseConnection();
      return localList;
    }
    catch (Throwable localThrowable)
    {
      closeDatabaseConnection();
      throw localThrowable;
    }
  }
  
  private void makeRoomForEntries(int paramInt)
  {
    paramInt = getNumStoredEntries() - mMaxNumStoredItems + paramInt;
    if (paramInt > 0)
    {
      List localList = peekEntryIds(paramInt);
      Log.i("DataLayer store full, deleting " + localList.size() + " entries to make room.");
      deleteEntries((String[])localList.toArray(new String[0]));
    }
  }
  
  private List peekEntryIds(int paramInt)
  {
    ArrayList localArrayList = new ArrayList();
    if (paramInt <= 0)
    {
      Log.w("Invalid maxEntries specified. Skipping.");
      return localArrayList;
    }
    SQLiteDatabase localSQLiteDatabase = getWritableDatabase("Error opening database for peekEntryIds.");
    if (localSQLiteDatabase != null)
    {
      Cursor localCursor4 = null;
      Cursor localCursor3 = null;
      Cursor localCursor2 = localCursor3;
      Cursor localCursor1 = localCursor4;
      try
      {
        String str1 = String.format("%s ASC", new Object[] { "ID" });
        localCursor2 = localCursor3;
        localCursor1 = localCursor4;
        String str2 = Integer.toString(paramInt);
        localCursor2 = localCursor3;
        localCursor1 = localCursor4;
        localCursor4 = localSQLiteDatabase.query("datalayer", new String[] { "ID" }, null, null, null, null, str1, str2);
        localCursor3 = localCursor4;
        localCursor2 = localCursor3;
        localCursor1 = localCursor3;
        boolean bool = localCursor4.moveToFirst();
        if (bool) {
          do
          {
            localCursor2 = localCursor3;
            localCursor1 = localCursor3;
            localArrayList.add(String.valueOf(localCursor4.getLong(0)));
            localCursor2 = localCursor3;
            localCursor1 = localCursor3;
            bool = localCursor4.moveToNext();
          } while (bool);
        }
        if (localCursor4 != null)
        {
          localCursor4.close();
          return localArrayList;
        }
      }
      catch (SQLiteException localSQLiteException)
      {
        localCursor1 = localCursor2;
        Log.w("Error in peekEntries fetching entryIds: " + localSQLiteException.getMessage());
        if (localCursor2 != null)
        {
          localCursor2.close();
          return localArrayList;
        }
      }
      catch (Throwable localThrowable)
      {
        if (localCursor1 != null) {
          localCursor1.close();
        }
        throw localThrowable;
      }
    }
    return localArrayList;
  }
  
  /* Error */
  private void saveSingleThreaded(List paramList, long paramLong)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 83	com/google/tagmanager/DataLayerPersistentStoreImpl:mClock	Lcom/google/tagmanager/Clock;
    //   6: invokeinterface 284 1 0
    //   11: lstore 4
    //   13: aload_0
    //   14: lload 4
    //   16: invokespecial 286	com/google/tagmanager/DataLayerPersistentStoreImpl:deleteEntriesOlderThan	(J)V
    //   19: aload_0
    //   20: aload_1
    //   21: invokeinterface 305 1 0
    //   26: invokespecial 340	com/google/tagmanager/DataLayerPersistentStoreImpl:makeRoomForEntries	(I)V
    //   29: aload_0
    //   30: aload_1
    //   31: lload 4
    //   33: lload_2
    //   34: ladd
    //   35: invokespecial 343	com/google/tagmanager/DataLayerPersistentStoreImpl:writeEntriesToDatabase	(Ljava/util/List;J)V
    //   38: aload_0
    //   39: invokespecial 159	com/google/tagmanager/DataLayerPersistentStoreImpl:closeDatabaseConnection	()V
    //   42: aload_0
    //   43: monitorexit
    //   44: return
    //   45: astore_1
    //   46: aload_0
    //   47: invokespecial 159	com/google/tagmanager/DataLayerPersistentStoreImpl:closeDatabaseConnection	()V
    //   50: aload_1
    //   51: athrow
    //   52: astore_1
    //   53: aload_0
    //   54: monitorexit
    //   55: aload_1
    //   56: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	57	0	this	DataLayerPersistentStoreImpl
    //   0	57	1	paramList	List
    //   0	57	2	paramLong	long
    //   11	21	4	l	long
    // Exception table:
    //   from	to	target	type
    //   2	38	45	java/lang/Throwable
    //   38	42	52	java/lang/Throwable
    //   46	52	52	java/lang/Throwable
  }
  
  private byte[] serialize(Object paramObject)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    Object localObject2 = null;
    Object localObject3 = null;
    try
    {
      Object localObject1 = new ObjectOutputStream(localByteArrayOutputStream);
      return paramObject;
    }
    catch (IOException paramObject)
    {
      try
      {
        ((ObjectOutputStream)localObject1).writeObject(paramObject);
        paramObject = localByteArrayOutputStream.toByteArray();
        if (localObject1 == null) {}
      }
      catch (Throwable paramObject)
      {
        for (;;) {}
      }
      catch (IOException paramObject)
      {
        for (;;)
        {
          paramObject = localIOException1;
        }
      }
      try
      {
        ((ObjectOutputStream)localObject1).close();
        localByteArrayOutputStream.close();
        return paramObject;
      }
      catch (IOException localIOException2) {}
      paramObject = paramObject;
      paramObject = localObject3;
      if (paramObject != null) {}
      try
      {
        paramObject.close();
        localByteArrayOutputStream.close();
        return null;
      }
      catch (IOException paramObject)
      {
        return null;
      }
    }
    catch (Throwable paramObject)
    {
      localObject1 = localObject2;
      if (localObject1 != null) {}
      try
      {
        ((ObjectOutputStream)localObject1).close();
        localByteArrayOutputStream.close();
      }
      catch (IOException localIOException1)
      {
        for (;;) {}
      }
      throw paramObject;
    }
  }
  
  private List serializeValues(List paramList)
  {
    ArrayList localArrayList = new ArrayList();
    paramList = paramList.iterator();
    while (paramList.hasNext())
    {
      DataLayer.KeyValue localKeyValue = (DataLayer.KeyValue)paramList.next();
      localArrayList.add(new KeyAndSerialized(mKey, serialize(mValue)));
    }
    return localArrayList;
  }
  
  /* Error */
  private Object unserialize(byte[] paramArrayOfByte)
  {
    // Byte code:
    //   0: new 396	java/io/ByteArrayInputStream
    //   3: dup
    //   4: aload_1
    //   5: invokespecial 399	java/io/ByteArrayInputStream:<init>	([B)V
    //   8: astore 5
    //   10: aconst_null
    //   11: astore 4
    //   13: aconst_null
    //   14: astore_2
    //   15: aconst_null
    //   16: astore_3
    //   17: new 401	java/io/ObjectInputStream
    //   20: dup
    //   21: aload 5
    //   23: invokespecial 404	java/io/ObjectInputStream:<init>	(Ljava/io/InputStream;)V
    //   26: astore_1
    //   27: aload_1
    //   28: invokevirtual 407	java/io/ObjectInputStream:readObject	()Ljava/lang/Object;
    //   31: astore_2
    //   32: aload_1
    //   33: ifnull +7 -> 40
    //   36: aload_1
    //   37: invokevirtual 408	java/io/ObjectInputStream:close	()V
    //   40: aload 5
    //   42: invokevirtual 409	java/io/ByteArrayInputStream:close	()V
    //   45: aload_2
    //   46: areturn
    //   47: astore_1
    //   48: aload_3
    //   49: astore_1
    //   50: aload_1
    //   51: ifnull +7 -> 58
    //   54: aload_1
    //   55: invokevirtual 408	java/io/ObjectInputStream:close	()V
    //   58: aload 5
    //   60: invokevirtual 409	java/io/ByteArrayInputStream:close	()V
    //   63: aconst_null
    //   64: areturn
    //   65: astore_1
    //   66: aconst_null
    //   67: areturn
    //   68: astore_1
    //   69: aload 4
    //   71: astore_1
    //   72: aload_1
    //   73: ifnull +7 -> 80
    //   76: aload_1
    //   77: invokevirtual 408	java/io/ObjectInputStream:close	()V
    //   80: aload 5
    //   82: invokevirtual 409	java/io/ByteArrayInputStream:close	()V
    //   85: aconst_null
    //   86: areturn
    //   87: astore_1
    //   88: aconst_null
    //   89: areturn
    //   90: astore_1
    //   91: aload_2
    //   92: ifnull +7 -> 99
    //   95: aload_2
    //   96: invokevirtual 408	java/io/ObjectInputStream:close	()V
    //   99: aload 5
    //   101: invokevirtual 409	java/io/ByteArrayInputStream:close	()V
    //   104: aload_1
    //   105: athrow
    //   106: astore_2
    //   107: goto -3 -> 104
    //   110: astore_3
    //   111: aload_1
    //   112: astore_2
    //   113: aload_3
    //   114: astore_1
    //   115: goto -24 -> 91
    //   118: astore_2
    //   119: goto -47 -> 72
    //   122: astore_2
    //   123: goto -73 -> 50
    //   126: astore_1
    //   127: aload_2
    //   128: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	129	0	this	DataLayerPersistentStoreImpl
    //   0	129	1	paramArrayOfByte	byte[]
    //   14	82	2	localObject1	Object
    //   106	1	2	localIOException1	IOException
    //   112	1	2	arrayOfByte	byte[]
    //   118	1	2	localClassNotFoundException	ClassNotFoundException
    //   122	6	2	localIOException2	IOException
    //   16	33	3	localObject2	Object
    //   110	4	3	localThrowable	Throwable
    //   11	59	4	localObject3	Object
    //   8	92	5	localByteArrayInputStream	java.io.ByteArrayInputStream
    // Exception table:
    //   from	to	target	type
    //   17	27	47	java/io/IOException
    //   54	58	65	java/io/IOException
    //   58	63	65	java/io/IOException
    //   17	27	68	java/lang/ClassNotFoundException
    //   76	80	87	java/io/IOException
    //   80	85	87	java/io/IOException
    //   17	27	90	java/lang/Throwable
    //   95	99	106	java/io/IOException
    //   99	104	106	java/io/IOException
    //   27	32	110	java/lang/Throwable
    //   27	32	118	java/lang/ClassNotFoundException
    //   27	32	122	java/io/IOException
    //   36	40	126	java/io/IOException
    //   40	45	126	java/io/IOException
  }
  
  private List unserializeValues(List paramList)
  {
    ArrayList localArrayList = new ArrayList();
    paramList = paramList.iterator();
    while (paramList.hasNext())
    {
      KeyAndSerialized localKeyAndSerialized = (KeyAndSerialized)paramList.next();
      localArrayList.add(new DataLayer.KeyValue(mKey, unserialize(mSerialized)));
    }
    return localArrayList;
  }
  
  private void writeEntriesToDatabase(List paramList, long paramLong)
  {
    SQLiteDatabase localSQLiteDatabase = getWritableDatabase("Error opening database for writeEntryToDatabase.");
    if (localSQLiteDatabase == null) {
      return;
    }
    paramList = paramList.iterator();
    while (paramList.hasNext())
    {
      KeyAndSerialized localKeyAndSerialized = (KeyAndSerialized)paramList.next();
      ContentValues localContentValues = new ContentValues();
      localContentValues.put("expires", Long.valueOf(paramLong));
      localContentValues.put("key", mKey);
      localContentValues.put("value", mSerialized);
      localSQLiteDatabase.insert("datalayer", null, localContentValues);
    }
  }
  
  public void clearKeysWithPrefix(final String paramString)
  {
    mExecutor.execute(new Runnable()
    {
      public void run()
      {
        DataLayerPersistentStoreImpl.this.clearKeysWithPrefixSingleThreaded(paramString);
      }
    });
  }
  
  public void loadSaved(final DataLayer.PersistentStore.Callback paramCallback)
  {
    mExecutor.execute(new Runnable()
    {
      public void run()
      {
        paramCallback.onKeyValuesLoaded(DataLayerPersistentStoreImpl.this.loadSingleThreaded());
      }
    });
  }
  
  public void saveKeyValues(final List paramList, final long paramLong)
  {
    paramList = serializeValues(paramList);
    mExecutor.execute(new Runnable()
    {
      public void run()
      {
        DataLayerPersistentStoreImpl.this.saveSingleThreaded(paramList, paramLong);
      }
    });
  }
  
  @VisibleForTesting
  class DatabaseHelper
    extends SQLiteOpenHelper
  {
    DatabaseHelper(Context paramContext, String paramString)
    {
      super(paramString, null, 1);
    }
    
    private boolean tablePresent(String paramString, SQLiteDatabase paramSQLiteDatabase)
    {
      Object localObject2 = null;
      Object localObject1 = null;
      boolean bool;
      try
      {
        paramSQLiteDatabase = paramSQLiteDatabase.query("SQLITE_MASTER", new String[] { "name" }, "name=?", new String[] { paramString }, null, null, null);
        localObject2 = paramSQLiteDatabase;
        localObject1 = localObject2;
        bool = paramSQLiteDatabase.moveToFirst();
        if (paramSQLiteDatabase != null)
        {
          paramSQLiteDatabase.close();
          return bool;
        }
      }
      catch (SQLiteException paramSQLiteDatabase)
      {
        localObject2 = localObject1;
        Log.w("Error querying for table " + paramString);
        if (localObject1 != null) {
          localObject1.close();
        }
        return false;
      }
      catch (Throwable paramString)
      {
        if (localObject2 != null) {
          ((Cursor)localObject2).close();
        }
        throw paramString;
      }
      return bool;
    }
    
    private void validateColumnsPresent(SQLiteDatabase paramSQLiteDatabase)
    {
      paramSQLiteDatabase = paramSQLiteDatabase.rawQuery("SELECT * FROM datalayer WHERE 0", null);
      HashSet localHashSet = new HashSet();
      try
      {
        String[] arrayOfString = paramSQLiteDatabase.getColumnNames();
        int i = 0;
        for (;;)
        {
          int j = arrayOfString.length;
          if (i >= j) {
            break;
          }
          localHashSet.add(arrayOfString[i]);
          i += 1;
        }
        paramSQLiteDatabase.close();
        if ((!localHashSet.remove("key")) || (!localHashSet.remove("value")) || (!localHashSet.remove("ID")) || (!localHashSet.remove("expires"))) {
          throw new SQLiteException("Database column missing");
        }
      }
      catch (Throwable localThrowable)
      {
        paramSQLiteDatabase.close();
        throw localThrowable;
      }
      if (!localThrowable.isEmpty()) {
        throw new SQLiteException("Database has extra columns");
      }
    }
    
    public SQLiteDatabase getWritableDatabase()
    {
      Object localObject = null;
      try
      {
        SQLiteDatabase localSQLiteDatabase = super.getWritableDatabase();
        localObject = localSQLiteDatabase;
      }
      catch (SQLiteException localSQLiteException)
      {
        for (;;)
        {
          mContext.getDatabasePath("google_tagmanager.db").delete();
        }
      }
      if (localObject == null) {
        return super.getWritableDatabase();
      }
      return localObject;
    }
    
    public void onCreate(SQLiteDatabase paramSQLiteDatabase)
    {
      FutureApis.setOwnerOnlyReadWrite(paramSQLiteDatabase.getPath());
    }
    
    public void onOpen(SQLiteDatabase paramSQLiteDatabase)
    {
      Cursor localCursor;
      if (Build.VERSION.SDK_INT < 15) {
        localCursor = paramSQLiteDatabase.rawQuery("PRAGMA journal_mode=memory", null);
      }
      try
      {
        localCursor.moveToFirst();
        localCursor.close();
        if (!tablePresent("datalayer", paramSQLiteDatabase))
        {
          paramSQLiteDatabase.execSQL(DataLayerPersistentStoreImpl.CREATE_MAPS_TABLE);
          return;
        }
      }
      catch (Throwable paramSQLiteDatabase)
      {
        localCursor.close();
        throw paramSQLiteDatabase;
      }
      validateColumnsPresent(paramSQLiteDatabase);
    }
    
    public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {}
  }
  
  private static class KeyAndSerialized
  {
    final String mKey;
    final byte[] mSerialized;
    
    KeyAndSerialized(String paramString, byte[] paramArrayOfByte)
    {
      mKey = paramString;
      mSerialized = paramArrayOfByte;
    }
    
    public String toString()
    {
      return "KeyAndSerialized: key = " + mKey + " serialized hash = " + Arrays.hashCode(mSerialized);
    }
  }
}
