package com.google.tagmanager;

abstract interface HitStore
{
  public abstract void close();
  
  public abstract void dispatch();
  
  public abstract Dispatcher getDispatcher();
  
  public abstract void putHit(long paramLong, String paramString);
}
