package com.google.tagmanager;

import android.content.Context;
import android.provider.Settings.Secure;
import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class MobileAdwordsUniqueIdMacro
  extends FunctionCallImplementation
{
  private static final String cachePath = FunctionType.MOBILE_ADWORDS_UNIQUE_ID.toString();
  private final Context mContext;
  
  public MobileAdwordsUniqueIdMacro(Context paramContext)
  {
    super(cachePath, new String[0]);
    mContext = paramContext;
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    paramMap = getAndroidId(mContext);
    if (paramMap == null) {
      return Types.getDefaultValue();
    }
    return Types.objectToValue(paramMap);
  }
  
  protected String getAndroidId(Context paramContext)
  {
    return Settings.Secure.getString(paramContext.getContentResolver(), "android_id");
  }
  
  public boolean isCacheable()
  {
    return true;
  }
}
