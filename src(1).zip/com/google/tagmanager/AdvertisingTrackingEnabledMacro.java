package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class AdvertisingTrackingEnabledMacro
  extends FunctionCallImplementation
{
  private static final String cachePath = FunctionType.ADVERTISING_TRACKING_ENABLED.toString();
  
  public AdvertisingTrackingEnabledMacro()
  {
    super(cachePath, new String[0]);
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    return Types.objectToValue(Boolean.valueOf(true));
  }
  
  public boolean isCacheable()
  {
    return true;
  }
}
