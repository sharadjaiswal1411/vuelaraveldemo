package com.google.tagmanager;

import android.content.Context;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

class DelayedHitSender
  implements HitSender
{
  private static DelayedHitSender sInstance;
  private static final Object sInstanceLock = new Object();
  private RateLimiter mRateLimiter;
  private HitSendingThread mSendingThread;
  private String mWrapperQueryParameter;
  private String mWrapperUrl;
  
  private DelayedHitSender(Context paramContext)
  {
    this(HitSendingThreadImpl.getInstance(paramContext), new SendHitRateLimiter());
  }
  
  DelayedHitSender(HitSendingThread paramHitSendingThread, RateLimiter paramRateLimiter)
  {
    mSendingThread = paramHitSendingThread;
    mRateLimiter = paramRateLimiter;
  }
  
  public static HitSender getInstance(Context paramContext)
  {
    Object localObject = sInstanceLock;
    try
    {
      if (sInstance == null) {
        sInstance = new DelayedHitSender(paramContext);
      }
      paramContext = sInstance;
      return paramContext;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public boolean sendHit(String paramString)
  {
    if (!mRateLimiter.tokenAvailable())
    {
      Log.w("Too many urls sent too quickly with the TagManagerSender, rate limiting invoked.");
      return false;
    }
    Object localObject = paramString;
    if (mWrapperUrl != null)
    {
      localObject = paramString;
      if (mWrapperQueryParameter == null) {}
    }
    try
    {
      localObject = new StringBuilder();
      String str = mWrapperUrl;
      localObject = ((StringBuilder)localObject).append(str).append("?");
      str = mWrapperQueryParameter;
      localObject = str + "=" + URLEncoder.encode(paramString, "UTF-8");
      paramString = (String)localObject;
      Log.v("Sending wrapped url hit: " + (String)localObject);
      localObject = paramString;
      mSendingThread.sendHit((String)localObject);
      return true;
    }
    catch (UnsupportedEncodingException paramString)
    {
      Log.w("Error wrapping URL for testing.", paramString);
    }
    return false;
  }
  
  public void setUrlWrapModeForTesting(String paramString1, String paramString2)
  {
    mWrapperUrl = paramString1;
    mWrapperQueryParameter = paramString2;
  }
}
