package com.google.tagmanager;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class AppVersionMacro
  extends FunctionCallImplementation
{
  private static final String cachePath = FunctionType.APP_VERSION.toString();
  private final Context mContext;
  
  public AppVersionMacro(Context paramContext)
  {
    super(cachePath, new String[0]);
    mContext = paramContext;
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    paramMap = mContext;
    try
    {
      paramMap = paramMap.getPackageManager();
      Context localContext = mContext;
      paramMap = paramMap.getPackageInfo(localContext.getPackageName(), 0);
      int i = versionCode;
      paramMap = Types.objectToValue(Integer.valueOf(i));
      return paramMap;
    }
    catch (PackageManager.NameNotFoundException paramMap)
    {
      Log.e("Package name " + mContext.getPackageName() + " not found. " + paramMap.getMessage());
    }
    return Types.getDefaultValue();
  }
  
  public boolean isCacheable()
  {
    return true;
  }
}
