package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class TimeMacro
  extends FunctionCallImplementation
{
  private static final String cachePath = FunctionType.TIME.toString();
  
  public TimeMacro()
  {
    super(cachePath, new String[0]);
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    return Types.objectToValue(Long.valueOf(System.currentTimeMillis()));
  }
  
  public boolean isCacheable()
  {
    return false;
  }
}
