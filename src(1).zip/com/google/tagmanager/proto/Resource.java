package com.google.tagmanager.proto;

import com.google.analytics.containertag.proto.Serving.Resource;
import com.google.analytics.containertag.proto.Serving.SupplementedResource;
import com.google.tagmanager.protobuf.nano.CodedInputByteBufferNano;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import com.google.tagmanager.protobuf.nano.ExtendableMessageNano;
import com.google.tagmanager.protobuf.nano.InvalidProtocolBufferNanoException;
import com.google.tagmanager.protobuf.nano.MessageNano;
import com.google.tagmanager.protobuf.nano.WireFormatNano;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public abstract interface Resource
{
  public static final class ResourceWithMetadata
    extends ExtendableMessageNano
  {
    public static final ResourceWithMetadata[] EMPTY_ARRAY = new ResourceWithMetadata[0];
    public Serving.Resource resource = null;
    public Serving.SupplementedResource supplementedResource = null;
    public long timeStamp = 0L;
    
    public ResourceWithMetadata() {}
    
    public static ResourceWithMetadata parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new ResourceWithMetadata().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static ResourceWithMetadata parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (ResourceWithMetadata)MessageNano.mergeFrom(new ResourceWithMetadata(), paramArrayOfByte);
    }
    
    public final ResourceWithMetadata clear()
    {
      timeStamp = 0L;
      resource = null;
      supplementedResource = null;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof ResourceWithMetadata)) {
        return false;
      }
      paramObject = (ResourceWithMetadata)paramObject;
      if (timeStamp == timeStamp)
      {
        if (resource != null) {
          break label77;
        }
        if (resource == null)
        {
          if (supplementedResource != null) {
            break label94;
          }
          if (supplementedResource == null)
          {
            label61:
            if (unknownFieldData != null) {
              break label111;
            }
            if (unknownFieldData == null) {
              break label127;
            }
          }
        }
      }
      label77:
      label94:
      label111:
      while (!unknownFieldData.equals(unknownFieldData))
      {
        do
        {
          do
          {
            return false;
          } while (!resource.equals(resource));
          break;
        } while (!supplementedResource.equals(supplementedResource));
        break label61;
      }
      label127:
      return true;
    }
    
    public int getSerializedSize()
    {
      int j = 0 + CodedOutputByteBufferNano.computeInt64Size(1, timeStamp);
      int i = j;
      if (resource != null) {
        i = j + CodedOutputByteBufferNano.computeMessageSize(2, resource);
      }
      j = i;
      if (supplementedResource != null) {
        j = i + CodedOutputByteBufferNano.computeMessageSize(3, supplementedResource);
      }
      i = j + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int k = 0;
      int m = (int)(timeStamp ^ timeStamp >>> 32);
      int i;
      int j;
      if (resource == null)
      {
        i = 0;
        if (supplementedResource != null) {
          break label75;
        }
        j = 0;
        label35:
        if (unknownFieldData != null) {
          break label86;
        }
      }
      for (;;)
      {
        return (((m + 527) * 31 + i) * 31 + j) * 31 + k;
        i = resource.hashCode();
        break;
        label75:
        j = supplementedResource.hashCode();
        break label35;
        label86:
        k = unknownFieldData.hashCode();
      }
    }
    
    public ResourceWithMetadata mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 8: 
          timeStamp = paramCodedInputByteBufferNano.readInt64();
          break;
        case 18: 
          resource = new Serving.Resource();
          paramCodedInputByteBufferNano.readMessage(resource);
          break;
        case 26: 
          supplementedResource = new Serving.SupplementedResource();
          paramCodedInputByteBufferNano.readMessage(supplementedResource);
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      paramCodedOutputByteBufferNano.writeInt64(1, timeStamp);
      if (resource != null) {
        paramCodedOutputByteBufferNano.writeMessage(2, resource);
      }
      if (supplementedResource != null) {
        paramCodedOutputByteBufferNano.writeMessage(3, supplementedResource);
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
}
