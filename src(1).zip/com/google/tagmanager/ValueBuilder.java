package com.google.tagmanager;

abstract interface ValueBuilder
{
  public abstract MacroEvaluationInfoBuilder createValueMacroEvaluationInfoExtension();
  
  public abstract ValueBuilder getListItem(int paramInt);
  
  public abstract ValueBuilder getMapKey(int paramInt);
  
  public abstract ValueBuilder getMapValue(int paramInt);
  
  public abstract ValueBuilder getTemplateToken(int paramInt);
}
