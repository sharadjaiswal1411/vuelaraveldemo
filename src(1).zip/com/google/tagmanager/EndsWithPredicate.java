package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import java.util.Map;

class EndsWithPredicate
  extends StringPredicate
{
  private static final String cachePath = FunctionType.ENDS_WITH.toString();
  
  public EndsWithPredicate()
  {
    super(cachePath);
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  protected boolean evaluateString(String paramString1, String paramString2, Map paramMap)
  {
    return paramString1.endsWith(paramString2);
  }
}
