package com.google.tagmanager;

import android.content.Context;
import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class AdvertiserIdMacro
  extends FunctionCallImplementation
{
  private static final String cachePath = FunctionType.ADVERTISER_ID.toString();
  private final Context mContext;
  
  public AdvertiserIdMacro(Context paramContext)
  {
    super(cachePath, new String[0]);
    mContext = paramContext;
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    return Types.getDefaultValue();
  }
  
  public boolean isCacheable()
  {
    return true;
  }
}
