package com.google.tagmanager;

import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;

abstract interface ResolvedPropertyBuilder
{
  public abstract ValueBuilder createPropertyValueBuilder(TypeSystem.Value paramValue);
}
