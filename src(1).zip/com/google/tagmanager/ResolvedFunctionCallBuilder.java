package com.google.tagmanager;

import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;

abstract interface ResolvedFunctionCallBuilder
{
  public abstract ResolvedPropertyBuilder createResolvedPropertyBuilder(String paramString);
  
  public abstract void setFunctionResult(TypeSystem.Value paramValue);
}
