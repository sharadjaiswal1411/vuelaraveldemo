package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class RandomMacro
  extends FunctionCallImplementation
{
  private static final String IGNORE_CASE = Key.MAX.toString();
  private static final String REGEX;
  private static final String cachePath = FunctionType.RANDOM.toString();
  
  static
  {
    REGEX = Key.MIN.toString();
  }
  
  public RandomMacro()
  {
    super(cachePath, new String[0]);
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    double d4 = 0.0D;
    double d5 = 2.147483647E9D;
    Object localObject = (TypeSystem.Value)paramMap.get(REGEX);
    paramMap = (TypeSystem.Value)paramMap.get(IGNORE_CASE);
    double d2 = d4;
    double d1 = d5;
    if (localObject != null)
    {
      d2 = d4;
      d1 = d5;
      if (localObject != Types.getDefaultValue())
      {
        d2 = d4;
        d1 = d5;
        if (paramMap != null)
        {
          d2 = d4;
          d1 = d5;
          if (paramMap != Types.getDefaultValue())
          {
            localObject = Types.valueToNumber((TypeSystem.Value)localObject);
            paramMap = Types.valueToNumber(paramMap);
            d2 = d4;
            d1 = d5;
            if (localObject != Types.getDefaultNumber())
            {
              d2 = d4;
              d1 = d5;
              if (paramMap != Types.getDefaultNumber())
              {
                double d6 = ((TypedNumber)localObject).doubleValue();
                double d3 = paramMap.doubleValue();
                d2 = d4;
                d1 = d5;
                if (d6 <= d3)
                {
                  d2 = d6;
                  d1 = d3;
                }
              }
            }
          }
        }
      }
    }
    return Types.objectToValue(Long.valueOf(Math.round(Math.random() * (d1 - d2) + d2)));
  }
  
  public boolean isCacheable()
  {
    return false;
  }
}
