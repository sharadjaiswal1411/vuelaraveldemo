package com.google.tagmanager;

import android.content.Context;
import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.containertag.common.Key;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import com.google.analytics.tracking.android.Tracker;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class UniversalAnalyticsTag
  extends TrackingTag
{
  private static final String ACCOUNT;
  private static final String ANALYTICS_FIELDS = Key.ANALYTICS_FIELDS.toString();
  private static final String ANALYTICS_PASS_THROUGH;
  private static final String DEFAULT_TRACKING_ID = "_GTM_DEFAULT_TRACKER_";
  private static final String TRACK_TRANSACTION = Key.TRACK_TRANSACTION.toString();
  private static final String TRANSACTION_DATALAYER_MAP = Key.TRANSACTION_DATALAYER_MAP.toString();
  private static final String TRANSACTION_ITEM_DATALAYER_MAP = Key.TRANSACTION_ITEM_DATALAYER_MAP.toString();
  private static final String cachePath = FunctionType.UNIVERSAL_ANALYTICS.toString();
  private static Map<String, String> defaultItemMap;
  private static Map<String, String> defaultTransactionMap;
  private final DataLayer mDataLayer;
  private final TrackerProvider mTrackerProvider;
  private final Set<String> mTurnOffAnonymizeIpValues;
  
  static
  {
    ACCOUNT = Key.ACCOUNT.toString();
    ANALYTICS_PASS_THROUGH = Key.ANALYTICS_PASS_THROUGH.toString();
  }
  
  public UniversalAnalyticsTag(Context paramContext, DataLayer paramDataLayer)
  {
    this(paramContext, paramDataLayer, new TrackerProvider(paramContext));
  }
  
  UniversalAnalyticsTag(Context paramContext, DataLayer paramDataLayer, TrackerProvider paramTrackerProvider)
  {
    super(cachePath, new String[0]);
    mDataLayer = paramDataLayer;
    mTrackerProvider = paramTrackerProvider;
    mTurnOffAnonymizeIpValues = new HashSet();
    mTurnOffAnonymizeIpValues.add("");
    mTurnOffAnonymizeIpValues.add("0");
    mTurnOffAnonymizeIpValues.add("false");
  }
  
  private void addParam(Map paramMap, String paramString1, String paramString2)
  {
    if (paramString2 != null) {
      paramMap.put(paramString1, paramString2);
    }
  }
  
  private boolean checkBooleanProperty(Map paramMap, String paramString)
  {
    paramMap = (TypeSystem.Value)paramMap.get(paramString);
    if (paramMap == null) {
      return false;
    }
    return Types.valueToBoolean(paramMap).booleanValue();
  }
  
  private Map convertToGaFields(TypeSystem.Value paramValue)
  {
    if (paramValue == null) {
      return new HashMap();
    }
    paramValue = valueToMap(paramValue);
    if (paramValue == null) {
      return new HashMap();
    }
    String str = (String)paramValue.get("&aip");
    if ((str != null) && (mTurnOffAnonymizeIpValues.contains(str.toLowerCase()))) {
      paramValue.remove("&aip");
    }
    return paramValue;
  }
  
  private String getDataLayerString(String paramString)
  {
    paramString = mDataLayer.get(paramString);
    if (paramString == null) {
      return null;
    }
    return paramString.toString();
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  private Map getTransactionFields(Map paramMap)
  {
    paramMap = (TypeSystem.Value)paramMap.get(TRANSACTION_DATALAYER_MAP);
    if (paramMap != null) {
      return valueToMap(paramMap);
    }
    if (defaultTransactionMap == null)
    {
      paramMap = new HashMap();
      paramMap.put("transactionId", "&ti");
      paramMap.put("transactionAffiliation", "&ta");
      paramMap.put("transactionTax", "&tt");
      paramMap.put("transactionShipping", "&ts");
      paramMap.put("transactionTotal", "&tr");
      paramMap.put("transactionCurrency", "&cu");
      defaultTransactionMap = paramMap;
    }
    return defaultTransactionMap;
  }
  
  private Map getTransactionItemFields(Map paramMap)
  {
    paramMap = (TypeSystem.Value)paramMap.get(TRANSACTION_ITEM_DATALAYER_MAP);
    if (paramMap != null) {
      return valueToMap(paramMap);
    }
    if (defaultItemMap == null)
    {
      paramMap = new HashMap();
      paramMap.put("name", "&in");
      paramMap.put("sku", "&ic");
      paramMap.put("category", "&iv");
      paramMap.put("price", "&ip");
      paramMap.put("quantity", "&iq");
      paramMap.put("currency", "&cu");
      defaultItemMap = paramMap;
    }
    return defaultItemMap;
  }
  
  private List getTransactionItems()
  {
    Object localObject = mDataLayer.get("transactionProducts");
    if (localObject == null) {
      return null;
    }
    if (!(localObject instanceof List)) {
      throw new IllegalArgumentException("transactionProducts should be of type List.");
    }
    Iterator localIterator = ((List)localObject).iterator();
    while (localIterator.hasNext()) {
      if (!(localIterator.next() instanceof Map)) {
        throw new IllegalArgumentException("Each element of transactionProducts should be of type Map.");
      }
    }
    return (List)localObject;
  }
  
  private void sendTransaction(Tracker paramTracker, Map paramMap)
  {
    Object localObject1 = getDataLayerString("transactionId");
    if (localObject1 == null)
    {
      Log.e("Cannot find transactionId in data layer.");
      return;
    }
    LinkedList localLinkedList = new LinkedList();
    Object localObject2 = ANALYTICS_FIELDS;
    Object localObject3;
    boolean bool;
    Object localObject4;
    Object localObject5;
    try
    {
      localObject2 = paramMap.get(localObject2);
      localObject2 = (TypeSystem.Value)localObject2;
      localObject2 = convertToGaFields((TypeSystem.Value)localObject2);
      ((Map)localObject2).put("&t", "transaction");
      localObject3 = getTransactionFields(paramMap).entrySet().iterator();
      for (;;)
      {
        bool = ((Iterator)localObject3).hasNext();
        if (!bool) {
          break;
        }
        localObject4 = ((Iterator)localObject3).next();
        localObject5 = (Map.Entry)localObject4;
        localObject4 = ((Map.Entry)localObject5).getValue();
        localObject4 = (String)localObject4;
        localObject5 = ((Map.Entry)localObject5).getKey();
        localObject5 = (String)localObject5;
        addParam((Map)localObject2, (String)localObject4, getDataLayerString((String)localObject5));
      }
      localLinkedList.add(localObject2);
    }
    catch (IllegalArgumentException paramTracker)
    {
      Log.e("Unable to send transaction", paramTracker);
      return;
    }
    localObject2 = getTransactionItems();
    if (localObject2 != null)
    {
      localObject2 = ((List)localObject2).iterator();
      for (;;)
      {
        bool = ((Iterator)localObject2).hasNext();
        if (!bool) {
          break;
        }
        localObject3 = ((Iterator)localObject2).next();
        localObject3 = (Map)localObject3;
        localObject4 = ((Map)localObject3).get("name");
        if (localObject4 == null)
        {
          Log.e("Unable to send transaction item hit due to missing 'name' field.");
          return;
        }
        localObject4 = ANALYTICS_FIELDS;
        localObject4 = paramMap.get(localObject4);
        localObject4 = (TypeSystem.Value)localObject4;
        localObject4 = convertToGaFields((TypeSystem.Value)localObject4);
        ((Map)localObject4).put("&t", "item");
        ((Map)localObject4).put("&ti", localObject1);
        localObject5 = getTransactionItemFields(paramMap).entrySet().iterator();
        for (;;)
        {
          bool = ((Iterator)localObject5).hasNext();
          if (!bool) {
            break;
          }
          Object localObject6 = ((Iterator)localObject5).next();
          Object localObject7 = (Map.Entry)localObject6;
          localObject6 = ((Map.Entry)localObject7).getValue();
          localObject6 = (String)localObject6;
          localObject7 = ((Map)localObject3).get(((Map.Entry)localObject7).getKey());
          localObject7 = (String)localObject7;
          addParam((Map)localObject4, (String)localObject6, (String)localObject7);
        }
        localLinkedList.add(localObject4);
      }
    }
    paramMap = localLinkedList.iterator();
    for (;;)
    {
      bool = paramMap.hasNext();
      if (!bool) {
        break;
      }
      localObject1 = paramMap.next();
      localObject1 = (Map)localObject1;
      paramTracker.send((Map)localObject1);
    }
  }
  
  private Map valueToMap(TypeSystem.Value paramValue)
  {
    paramValue = Types.valueToObject(paramValue);
    if (!(paramValue instanceof Map)) {
      return null;
    }
    Object localObject = (Map)paramValue;
    paramValue = new LinkedHashMap();
    localObject = ((Map)localObject).entrySet().iterator();
    while (((Iterator)localObject).hasNext())
    {
      Map.Entry localEntry = (Map.Entry)((Iterator)localObject).next();
      paramValue.put(localEntry.getKey().toString(), localEntry.getValue().toString());
    }
    return paramValue;
  }
  
  public void evaluateTrackingTag(Map paramMap)
  {
    Tracker localTracker = mTrackerProvider.getTracker("_GTM_DEFAULT_TRACKER_");
    if (checkBooleanProperty(paramMap, ANALYTICS_PASS_THROUGH)) {
      localTracker.send(convertToGaFields((TypeSystem.Value)paramMap.get(ANALYTICS_FIELDS)));
    }
    for (;;)
    {
      mTrackerProvider.close(localTracker);
      return;
      if (checkBooleanProperty(paramMap, TRACK_TRANSACTION)) {
        sendTransaction(localTracker, paramMap);
      } else {
        Log.w("Ignoring unknown tag.");
      }
    }
  }
}
