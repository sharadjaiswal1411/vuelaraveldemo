package com.google.tagmanager;

class ObjectAndStatic<T>
{
  private final boolean mIsStatic;
  private final T mObject;
  
  ObjectAndStatic(Object paramObject, boolean paramBoolean)
  {
    mObject = paramObject;
    mIsStatic = paramBoolean;
  }
  
  public Object getObject()
  {
    return mObject;
  }
  
  public boolean isStatic()
  {
    return mIsStatic;
  }
}
