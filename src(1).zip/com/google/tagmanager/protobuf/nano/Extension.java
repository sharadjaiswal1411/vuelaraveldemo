package com.google.tagmanager.protobuf.nano;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public class Extension<T>
{
  public final int fieldNumber;
  public Class<T> fieldType;
  public boolean isRepeatedField;
  public Class<T> listType;
  
  private Extension(int paramInt, TypeLiteral paramTypeLiteral)
  {
    fieldNumber = paramInt;
    isRepeatedField = paramTypeLiteral.isList();
    fieldType = paramTypeLiteral.getTargetClass();
    if (isRepeatedField) {}
    for (paramTypeLiteral = paramTypeLiteral.getListType();; paramTypeLiteral = null)
    {
      listType = paramTypeLiteral;
      return;
    }
  }
  
  public static Extension create(int paramInt, TypeLiteral paramTypeLiteral)
  {
    return new Extension(paramInt, paramTypeLiteral);
  }
  
  public static Extension createRepeated(int paramInt, TypeLiteral paramTypeLiteral)
  {
    return new Extension(paramInt, paramTypeLiteral);
  }
  
  public static abstract class TypeLiteral<T>
  {
    private final Type type;
    
    protected TypeLiteral()
    {
      Type localType = getClass().getGenericSuperclass();
      if ((localType instanceof Class)) {
        throw new RuntimeException("Missing type parameter");
      }
      type = ((ParameterizedType)localType).getActualTypeArguments()[0];
    }
    
    private Class getListType()
    {
      return (Class)((ParameterizedType)type).getRawType();
    }
    
    private Class getTargetClass()
    {
      if (isList()) {
        return (Class)((ParameterizedType)type).getActualTypeArguments()[0];
      }
      return (Class)type;
    }
    
    private boolean isList()
    {
      return type instanceof ParameterizedType;
    }
  }
}
