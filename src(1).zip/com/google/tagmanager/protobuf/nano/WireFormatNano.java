package com.google.tagmanager.protobuf.nano;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class WireFormatNano
{
  public static final boolean[] EMPTY_BOOLEAN_ARRAY;
  public static final Boolean[] EMPTY_BOOLEAN_REF_ARRAY = new Boolean[0];
  public static final byte[] EMPTY_BYTES;
  public static final byte[][] EMPTY_BYTES_ARRAY;
  public static final double[] EMPTY_DOUBLE_ARRAY;
  public static final Double[] EMPTY_DOUBLE_REF_ARRAY;
  public static final float[] EMPTY_FLOAT_ARRAY;
  public static final Float[] EMPTY_FLOAT_REF_ARRAY;
  public static final int[] EMPTY_INT_ARRAY;
  public static final Integer[] EMPTY_INT_REF_ARRAY;
  public static final long[] EMPTY_LONG_ARRAY;
  public static final Long[] EMPTY_LONG_REF_ARRAY;
  public static final String[] EMPTY_STRING_ARRAY;
  static final int MESSAGE_SET_ITEM = 1;
  static final int MESSAGE_SET_ITEM_END_TAG;
  static final int MESSAGE_SET_ITEM_TAG = makeTag(1, 3);
  static final int MESSAGE_SET_MESSAGE = 3;
  static final int MESSAGE_SET_MESSAGE_TAG;
  static final int MESSAGE_SET_TYPE_ID = 2;
  static final int MESSAGE_SET_TYPE_ID_TAG;
  static final int TAG_TYPE_BITS = 3;
  static final int TAG_TYPE_MASK = 7;
  static final int WIRETYPE_END_GROUP = 4;
  static final int WIRETYPE_FIXED32 = 5;
  static final int WIRETYPE_FIXED64 = 1;
  static final int WIRETYPE_LENGTH_DELIMITED = 2;
  static final int WIRETYPE_START_GROUP = 3;
  static final int WIRETYPE_VARINT = 0;
  
  static
  {
    MESSAGE_SET_ITEM_END_TAG = makeTag(1, 4);
    MESSAGE_SET_TYPE_ID_TAG = makeTag(2, 0);
    MESSAGE_SET_MESSAGE_TAG = makeTag(3, 2);
    EMPTY_INT_ARRAY = new int[0];
    EMPTY_LONG_ARRAY = new long[0];
    EMPTY_FLOAT_ARRAY = new float[0];
    EMPTY_DOUBLE_ARRAY = new double[0];
    EMPTY_BOOLEAN_ARRAY = new boolean[0];
    EMPTY_STRING_ARRAY = new String[0];
    EMPTY_BYTES_ARRAY = new byte[0][];
    EMPTY_BYTES = new byte[0];
    EMPTY_INT_REF_ARRAY = new Integer[0];
    EMPTY_LONG_REF_ARRAY = new Long[0];
    EMPTY_FLOAT_REF_ARRAY = new Float[0];
    EMPTY_DOUBLE_REF_ARRAY = new Double[0];
  }
  
  private WireFormatNano() {}
  
  public static int computeWireSize(List paramList)
  {
    if (paramList == null) {
      return 0;
    }
    int i = 0;
    paramList = paramList.iterator();
    while (paramList.hasNext())
    {
      UnknownFieldData localUnknownFieldData = (UnknownFieldData)paramList.next();
      i = i + CodedOutputByteBufferNano.computeRawVarint32Size(tag) + bytes.length;
    }
    return i;
  }
  
  public static Object getExtension(Extension paramExtension, List paramList)
  {
    if (paramList == null) {
      return null;
    }
    Object localObject = new ArrayList();
    paramList = paramList.iterator();
    UnknownFieldData localUnknownFieldData;
    while (paramList.hasNext())
    {
      localUnknownFieldData = (UnknownFieldData)paramList.next();
      if (getTagFieldNumber(tag) == fieldNumber) {
        ((List)localObject).add(localUnknownFieldData);
      }
    }
    if (!((List)localObject).isEmpty())
    {
      if (isRepeatedField)
      {
        paramList = new ArrayList(((List)localObject).size());
        localObject = ((List)localObject).iterator();
        while (((Iterator)localObject).hasNext())
        {
          localUnknownFieldData = (UnknownFieldData)((Iterator)localObject).next();
          paramList.add(readData(fieldType, bytes));
        }
        return listType.cast(paramList);
      }
      paramList = (UnknownFieldData)((List)localObject).get(((List)localObject).size() - 1);
      return readData(fieldType, bytes);
    }
    return null;
  }
  
  public static final int getRepeatedFieldArrayLength(CodedInputByteBufferNano paramCodedInputByteBufferNano, int paramInt)
    throws IOException
  {
    int i = 1;
    int j = paramCodedInputByteBufferNano.getPosition();
    paramCodedInputByteBufferNano.skipField(paramInt);
    for (;;)
    {
      if ((paramCodedInputByteBufferNano.getBytesUntilLimit() <= 0) || (paramCodedInputByteBufferNano.readTag() != paramInt))
      {
        paramCodedInputByteBufferNano.rewindToPosition(j);
        return i;
      }
      paramCodedInputByteBufferNano.skipField(paramInt);
      i += 1;
    }
  }
  
  public static int getTagFieldNumber(int paramInt)
  {
    return paramInt >>> 3;
  }
  
  static int getTagWireType(int paramInt)
  {
    return paramInt & 0x7;
  }
  
  static int makeTag(int paramInt1, int paramInt2)
  {
    return paramInt1 << 3 | paramInt2;
  }
  
  public static boolean parseUnknownField(CodedInputByteBufferNano paramCodedInputByteBufferNano, int paramInt)
    throws IOException
  {
    return paramCodedInputByteBufferNano.skipField(paramInt);
  }
  
  /* Error */
  private static Object readData(Class paramClass, byte[] paramArrayOfByte)
  {
    // Byte code:
    //   0: aload_1
    //   1: arraylength
    //   2: ifne +5 -> 7
    //   5: aconst_null
    //   6: areturn
    //   7: aload_1
    //   8: invokestatic 228	com/google/tagmanager/protobuf/nano/CodedInputByteBufferNano:newInstance	([B)Lcom/google/tagmanager/protobuf/nano/CodedInputByteBufferNano;
    //   11: astore_1
    //   12: aload_0
    //   13: ldc 79
    //   15: if_acmpne +14 -> 29
    //   18: aload_0
    //   19: aload_1
    //   20: invokevirtual 232	com/google/tagmanager/protobuf/nano/CodedInputByteBufferNano:readString	()Ljava/lang/String;
    //   23: invokevirtual 190	java/lang/Class:cast	(Ljava/lang/Object;)Ljava/lang/Object;
    //   26: astore_0
    //   27: aload_0
    //   28: areturn
    //   29: aload_0
    //   30: ldc 88
    //   32: if_acmpne +17 -> 49
    //   35: aload_0
    //   36: aload_1
    //   37: invokevirtual 235	com/google/tagmanager/protobuf/nano/CodedInputByteBufferNano:readInt32	()I
    //   40: invokestatic 239	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   43: invokevirtual 190	java/lang/Class:cast	(Ljava/lang/Object;)Ljava/lang/Object;
    //   46: astore_0
    //   47: aload_0
    //   48: areturn
    //   49: aload_0
    //   50: ldc 92
    //   52: if_acmpne +17 -> 69
    //   55: aload_0
    //   56: aload_1
    //   57: invokevirtual 243	com/google/tagmanager/protobuf/nano/CodedInputByteBufferNano:readInt64	()J
    //   60: invokestatic 246	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   63: invokevirtual 190	java/lang/Class:cast	(Ljava/lang/Object;)Ljava/lang/Object;
    //   66: astore_0
    //   67: aload_0
    //   68: areturn
    //   69: aload_0
    //   70: ldc 104
    //   72: if_acmpne +17 -> 89
    //   75: aload_0
    //   76: aload_1
    //   77: invokevirtual 249	com/google/tagmanager/protobuf/nano/CodedInputByteBufferNano:readBool	()Z
    //   80: invokestatic 252	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
    //   83: invokevirtual 190	java/lang/Class:cast	(Ljava/lang/Object;)Ljava/lang/Object;
    //   86: astore_0
    //   87: aload_0
    //   88: areturn
    //   89: aload_0
    //   90: ldc 96
    //   92: if_acmpne +17 -> 109
    //   95: aload_0
    //   96: aload_1
    //   97: invokevirtual 256	com/google/tagmanager/protobuf/nano/CodedInputByteBufferNano:readFloat	()F
    //   100: invokestatic 259	java/lang/Float:valueOf	(F)Ljava/lang/Float;
    //   103: invokevirtual 190	java/lang/Class:cast	(Ljava/lang/Object;)Ljava/lang/Object;
    //   106: astore_0
    //   107: aload_0
    //   108: areturn
    //   109: aload_0
    //   110: ldc 100
    //   112: if_acmpne +17 -> 129
    //   115: aload_0
    //   116: aload_1
    //   117: invokevirtual 263	com/google/tagmanager/protobuf/nano/CodedInputByteBufferNano:readDouble	()D
    //   120: invokestatic 266	java/lang/Double:valueOf	(D)Ljava/lang/Double;
    //   123: invokevirtual 190	java/lang/Class:cast	(Ljava/lang/Object;)Ljava/lang/Object;
    //   126: astore_0
    //   127: aload_0
    //   128: areturn
    //   129: aload_0
    //   130: ldc 82
    //   132: if_acmpne +14 -> 146
    //   135: aload_0
    //   136: aload_1
    //   137: invokevirtual 270	com/google/tagmanager/protobuf/nano/CodedInputByteBufferNano:readBytes	()[B
    //   140: invokevirtual 190	java/lang/Class:cast	(Ljava/lang/Object;)Ljava/lang/Object;
    //   143: astore_0
    //   144: aload_0
    //   145: areturn
    //   146: ldc_w 272
    //   149: aload_0
    //   150: invokevirtual 276	java/lang/Class:isAssignableFrom	(Ljava/lang/Class;)Z
    //   153: istore_2
    //   154: iload_2
    //   155: ifeq +103 -> 258
    //   158: aload_0
    //   159: invokevirtual 278	java/lang/Class:newInstance	()Ljava/lang/Object;
    //   162: astore_3
    //   163: aload_3
    //   164: checkcast 272	com/google/tagmanager/protobuf/nano/MessageNano
    //   167: astore_3
    //   168: aload_1
    //   169: aload_3
    //   170: invokevirtual 282	com/google/tagmanager/protobuf/nano/CodedInputByteBufferNano:readMessage	(Lcom/google/tagmanager/protobuf/nano/MessageNano;)V
    //   173: aload_0
    //   174: aload_3
    //   175: invokevirtual 190	java/lang/Class:cast	(Ljava/lang/Object;)Ljava/lang/Object;
    //   178: astore_1
    //   179: aload_1
    //   180: areturn
    //   181: astore_1
    //   182: new 284	java/lang/IllegalArgumentException
    //   185: dup
    //   186: new 286	java/lang/StringBuilder
    //   189: dup
    //   190: invokespecial 287	java/lang/StringBuilder:<init>	()V
    //   193: ldc_w 289
    //   196: invokevirtual 293	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   199: aload_0
    //   200: invokevirtual 296	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   203: invokevirtual 299	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   206: aload_1
    //   207: invokespecial 302	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   210: astore_0
    //   211: aload_0
    //   212: athrow
    //   213: astore_0
    //   214: new 284	java/lang/IllegalArgumentException
    //   217: dup
    //   218: ldc_w 304
    //   221: aload_0
    //   222: invokespecial 302	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   225: athrow
    //   226: astore_1
    //   227: new 284	java/lang/IllegalArgumentException
    //   230: dup
    //   231: new 286	java/lang/StringBuilder
    //   234: dup
    //   235: invokespecial 287	java/lang/StringBuilder:<init>	()V
    //   238: ldc_w 289
    //   241: invokevirtual 293	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   244: aload_0
    //   245: invokevirtual 296	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   248: invokevirtual 299	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   251: aload_1
    //   252: invokespecial 302	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   255: astore_0
    //   256: aload_0
    //   257: athrow
    //   258: new 284	java/lang/IllegalArgumentException
    //   261: dup
    //   262: new 286	java/lang/StringBuilder
    //   265: dup
    //   266: invokespecial 287	java/lang/StringBuilder:<init>	()V
    //   269: ldc_w 306
    //   272: invokevirtual 293	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   275: aload_0
    //   276: invokevirtual 296	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   279: invokevirtual 299	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   282: invokespecial 309	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   285: astore_0
    //   286: aload_0
    //   287: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	288	0	paramClass	Class
    //   0	288	1	paramArrayOfByte	byte[]
    //   153	2	2	bool	boolean
    //   162	13	3	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   158	163	181	java/lang/IllegalAccessException
    //   168	179	181	java/lang/IllegalAccessException
    //   18	27	213	java/io/IOException
    //   35	47	213	java/io/IOException
    //   55	67	213	java/io/IOException
    //   75	87	213	java/io/IOException
    //   95	107	213	java/io/IOException
    //   115	127	213	java/io/IOException
    //   135	144	213	java/io/IOException
    //   146	154	213	java/io/IOException
    //   158	163	213	java/io/IOException
    //   168	179	213	java/io/IOException
    //   182	211	213	java/io/IOException
    //   227	256	213	java/io/IOException
    //   258	286	213	java/io/IOException
    //   158	163	226	java/lang/InstantiationException
    //   168	179	226	java/lang/InstantiationException
  }
  
  public static void setExtension(Extension paramExtension, Object paramObject, List paramList)
  {
    Object localObject = paramList.iterator();
    while (((Iterator)localObject).hasNext())
    {
      UnknownFieldData localUnknownFieldData = (UnknownFieldData)((Iterator)localObject).next();
      if (fieldNumber == getTagFieldNumber(tag)) {
        ((Iterator)localObject).remove();
      }
    }
    if (paramObject == null) {
      return;
    }
    if ((paramObject instanceof List))
    {
      paramObject = ((List)paramObject).iterator();
      while (paramObject.hasNext())
      {
        localObject = paramObject.next();
        paramList.add(write(fieldNumber, localObject));
      }
    }
    paramList.add(write(fieldNumber, paramObject));
  }
  
  public static boolean storeUnknownField(List paramList, CodedInputByteBufferNano paramCodedInputByteBufferNano, int paramInt)
    throws IOException
  {
    int i = paramCodedInputByteBufferNano.getPosition();
    boolean bool = paramCodedInputByteBufferNano.skipField(paramInt);
    paramList.add(new UnknownFieldData(paramInt, paramCodedInputByteBufferNano.getData(i, paramCodedInputByteBufferNano.getPosition() - i)));
    return bool;
  }
  
  private static UnknownFieldData write(int paramInt, Object paramObject)
  {
    Object localObject = paramObject.getClass();
    if (localObject == String.class) {
      localObject = (String)paramObject;
    }
    for (;;)
    {
      try
      {
        i = CodedOutputByteBufferNano.computeStringSizeNoTag((String)localObject);
        paramObject = new byte[i];
        CodedOutputByteBufferNano.newInstance(paramObject).writeStringNoTag((String)localObject);
        paramInt = makeTag(paramInt, 2);
        return new UnknownFieldData(paramInt, paramObject);
      }
      catch (IOException paramObject)
      {
        int i;
        boolean bool;
        int j;
        CodedOutputByteBufferNano localCodedOutputByteBufferNano;
        throw new IllegalArgumentException(paramObject);
      }
      if (localObject == Integer.class)
      {
        localObject = (Integer)paramObject;
        i = CodedOutputByteBufferNano.computeInt32SizeNoTag(((Integer)localObject).intValue());
        paramObject = new byte[i];
        CodedOutputByteBufferNano.newInstance(paramObject).writeInt32NoTag(((Integer)localObject).intValue());
        paramInt = makeTag(paramInt, 0);
      }
      else if (localObject == Long.class)
      {
        localObject = (Long)paramObject;
        i = CodedOutputByteBufferNano.computeInt64SizeNoTag(((Long)localObject).longValue());
        paramObject = new byte[i];
        CodedOutputByteBufferNano.newInstance(paramObject).writeInt64NoTag(((Long)localObject).longValue());
        paramInt = makeTag(paramInt, 0);
      }
      else if (localObject == Boolean.class)
      {
        localObject = (Boolean)paramObject;
        i = CodedOutputByteBufferNano.computeBoolSizeNoTag(((Boolean)localObject).booleanValue());
        paramObject = new byte[i];
        CodedOutputByteBufferNano.newInstance(paramObject).writeBoolNoTag(((Boolean)localObject).booleanValue());
        paramInt = makeTag(paramInt, 0);
      }
      else if (localObject == Float.class)
      {
        localObject = (Float)paramObject;
        i = CodedOutputByteBufferNano.computeFloatSizeNoTag(((Float)localObject).floatValue());
        paramObject = new byte[i];
        CodedOutputByteBufferNano.newInstance(paramObject).writeFloatNoTag(((Float)localObject).floatValue());
        paramInt = makeTag(paramInt, 5);
      }
      else if (localObject == Double.class)
      {
        localObject = (Double)paramObject;
        i = CodedOutputByteBufferNano.computeDoubleSizeNoTag(((Double)localObject).doubleValue());
        paramObject = new byte[i];
        CodedOutputByteBufferNano.newInstance(paramObject).writeDoubleNoTag(((Double)localObject).doubleValue());
        paramInt = makeTag(paramInt, 1);
      }
      else if (localObject == [B.class)
      {
        localObject = (byte[])paramObject;
        i = CodedOutputByteBufferNano.computeByteArraySizeNoTag((byte[])localObject);
        paramObject = new byte[i];
        CodedOutputByteBufferNano.newInstance(paramObject).writeByteArrayNoTag((byte[])localObject);
        paramInt = makeTag(paramInt, 2);
      }
      else
      {
        bool = MessageNano.class.isAssignableFrom((Class)localObject);
        if (!bool) {
          continue;
        }
        localObject = (MessageNano)paramObject;
        i = ((MessageNano)localObject).getSerializedSize();
        j = CodedOutputByteBufferNano.computeRawVarint32Size(i);
        paramObject = new byte[i + j];
        localCodedOutputByteBufferNano = CodedOutputByteBufferNano.newInstance(paramObject);
        localCodedOutputByteBufferNano.writeRawVarint32(i);
        localCodedOutputByteBufferNano.writeRawBytes(MessageNano.toByteArray((MessageNano)localObject));
        paramInt = makeTag(paramInt, 2);
      }
    }
    paramObject = new IllegalArgumentException("Unhandled extension field type: " + localObject);
    throw paramObject;
  }
  
  public static void writeUnknownFields(List paramList, CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
    throws IOException
  {
    if (paramList == null) {
      return;
    }
    paramList = paramList.iterator();
    while (paramList.hasNext())
    {
      UnknownFieldData localUnknownFieldData = (UnknownFieldData)paramList.next();
      paramCodedOutputByteBufferNano.writeTag(getTagFieldNumber(tag), getTagWireType(tag));
      paramCodedOutputByteBufferNano.writeRawBytes(bytes);
    }
  }
}
