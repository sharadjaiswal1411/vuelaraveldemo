package com.google.tagmanager.protobuf.nano;

import java.io.IOException;

public final class CodedInputByteBufferNano
{
  private static final int DEFAULT_RECURSION_LIMIT = 64;
  private static final int DEFAULT_SIZE_LIMIT = 67108864;
  private final byte[] buffer;
  private int bufferPos;
  private int bufferSize;
  private int bufferSizeAfterLimit;
  private int bufferStart;
  private int currentLimit = Integer.MAX_VALUE;
  private int lastTag;
  private int recursionDepth;
  private int recursionLimit = 64;
  private int sizeLimit = 67108864;
  
  private CodedInputByteBufferNano(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    buffer = paramArrayOfByte;
    bufferStart = paramInt1;
    bufferSize = (paramInt1 + paramInt2);
    bufferPos = paramInt1;
  }
  
  public static int decodeZigZag32(int paramInt)
  {
    return paramInt >>> 1 ^ -(paramInt & 0x1);
  }
  
  public static long decodeZigZag64(long paramLong)
  {
    return paramLong >>> 1 ^ -(1L & paramLong);
  }
  
  public static CodedInputByteBufferNano newInstance(byte[] paramArrayOfByte)
  {
    return newInstance(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public static CodedInputByteBufferNano newInstance(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    return new CodedInputByteBufferNano(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  private void recomputeBufferSizeAfterLimit()
  {
    bufferSize += bufferSizeAfterLimit;
    int i = bufferSize;
    if (i > currentLimit)
    {
      bufferSizeAfterLimit = (i - currentLimit);
      bufferSize -= bufferSizeAfterLimit;
      return;
    }
    bufferSizeAfterLimit = 0;
  }
  
  public void checkLastTagWas(int paramInt)
    throws InvalidProtocolBufferNanoException
  {
    if (lastTag != paramInt) {
      throw InvalidProtocolBufferNanoException.invalidEndTag();
    }
  }
  
  public int getBytesUntilLimit()
  {
    if (currentLimit == Integer.MAX_VALUE) {
      return -1;
    }
    int i = bufferPos;
    return currentLimit - i;
  }
  
  public byte[] getData(int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0) {
      return WireFormatNano.EMPTY_BYTES;
    }
    byte[] arrayOfByte = new byte[paramInt2];
    int i = bufferStart;
    System.arraycopy(buffer, i + paramInt1, arrayOfByte, 0, paramInt2);
    return arrayOfByte;
  }
  
  public int getPosition()
  {
    return bufferPos - bufferStart;
  }
  
  public boolean isAtEnd()
  {
    return bufferPos == bufferSize;
  }
  
  public void popLimit(int paramInt)
  {
    currentLimit = paramInt;
    recomputeBufferSizeAfterLimit();
  }
  
  public int pushLimit(int paramInt)
    throws InvalidProtocolBufferNanoException
  {
    if (paramInt < 0) {
      throw InvalidProtocolBufferNanoException.negativeSize();
    }
    paramInt += bufferPos;
    int i = currentLimit;
    if (paramInt > i) {
      throw InvalidProtocolBufferNanoException.truncatedMessage();
    }
    currentLimit = paramInt;
    recomputeBufferSizeAfterLimit();
    return i;
  }
  
  public boolean readBool()
    throws IOException
  {
    return readRawVarint32() != 0;
  }
  
  public byte[] readBytes()
    throws IOException
  {
    int i = readRawVarint32();
    if ((i <= bufferSize - bufferPos) && (i > 0))
    {
      byte[] arrayOfByte = new byte[i];
      System.arraycopy(buffer, bufferPos, arrayOfByte, 0, i);
      bufferPos += i;
      return arrayOfByte;
    }
    return readRawBytes(i);
  }
  
  public double readDouble()
    throws IOException
  {
    return Double.longBitsToDouble(readRawLittleEndian64());
  }
  
  public int readEnum()
    throws IOException
  {
    return readRawVarint32();
  }
  
  public int readFixed32()
    throws IOException
  {
    return readRawLittleEndian32();
  }
  
  public long readFixed64()
    throws IOException
  {
    return readRawLittleEndian64();
  }
  
  public float readFloat()
    throws IOException
  {
    return Float.intBitsToFloat(readRawLittleEndian32());
  }
  
  public void readGroup(MessageNano paramMessageNano, int paramInt)
    throws IOException
  {
    if (recursionDepth >= recursionLimit) {
      throw InvalidProtocolBufferNanoException.recursionLimitExceeded();
    }
    recursionDepth += 1;
    paramMessageNano.mergeFrom(this);
    checkLastTagWas(WireFormatNano.makeTag(paramInt, 4));
    recursionDepth -= 1;
  }
  
  public int readInt32()
    throws IOException
  {
    return readRawVarint32();
  }
  
  public long readInt64()
    throws IOException
  {
    return readRawVarint64();
  }
  
  public void readMessage(MessageNano paramMessageNano)
    throws IOException
  {
    int i = readRawVarint32();
    if (recursionDepth >= recursionLimit) {
      throw InvalidProtocolBufferNanoException.recursionLimitExceeded();
    }
    i = pushLimit(i);
    recursionDepth += 1;
    paramMessageNano.mergeFrom(this);
    checkLastTagWas(0);
    recursionDepth -= 1;
    popLimit(i);
  }
  
  public byte readRawByte()
    throws IOException
  {
    if (bufferPos == bufferSize) {
      throw InvalidProtocolBufferNanoException.truncatedMessage();
    }
    byte[] arrayOfByte = buffer;
    int i = bufferPos;
    bufferPos = (i + 1);
    return arrayOfByte[i];
  }
  
  public byte[] readRawBytes(int paramInt)
    throws IOException
  {
    if (paramInt < 0) {
      throw InvalidProtocolBufferNanoException.negativeSize();
    }
    if (bufferPos + paramInt > currentLimit)
    {
      skipRawBytes(currentLimit - bufferPos);
      throw InvalidProtocolBufferNanoException.truncatedMessage();
    }
    if (paramInt <= bufferSize - bufferPos)
    {
      byte[] arrayOfByte = new byte[paramInt];
      System.arraycopy(buffer, bufferPos, arrayOfByte, 0, paramInt);
      bufferPos += paramInt;
      return arrayOfByte;
    }
    throw InvalidProtocolBufferNanoException.truncatedMessage();
  }
  
  public int readRawLittleEndian32()
    throws IOException
  {
    return readRawByte() & 0xFF | (readRawByte() & 0xFF) << 8 | (readRawByte() & 0xFF) << 16 | (readRawByte() & 0xFF) << 24;
  }
  
  public long readRawLittleEndian64()
    throws IOException
  {
    int i = readRawByte();
    int j = readRawByte();
    int k = readRawByte();
    int m = readRawByte();
    int n = readRawByte();
    int i1 = readRawByte();
    int i2 = readRawByte();
    int i3 = readRawByte();
    return i & 0xFF | (j & 0xFF) << 8 | (k & 0xFF) << 16 | (m & 0xFF) << 24 | (n & 0xFF) << 32 | (i1 & 0xFF) << 40 | (i2 & 0xFF) << 48 | (i3 & 0xFF) << 56;
  }
  
  public int readRawVarint32()
    throws IOException
  {
    int i = readRawByte();
    if (i >= 0) {
      return i;
    }
    i &= 0x7F;
    int j = readRawByte();
    if (j >= 0) {
      return i | j << 7;
    }
    i |= (j & 0x7F) << 7;
    j = readRawByte();
    if (j >= 0) {
      return i | j << 14;
    }
    j = i | (j & 0x7F) << 14;
    int k = readRawByte();
    if (k >= 0) {
      return j | k << 21;
    }
    int m = readRawByte();
    if (m < 0)
    {
      i = 0;
      while (i < 5)
      {
        if (readRawByte() >= 0) {
          break label120;
        }
        i += 1;
      }
      throw InvalidProtocolBufferNanoException.malformedVarint();
    }
    label120:
    return j | (k & 0x7F) << 21 | m << 28;
  }
  
  public long readRawVarint64()
    throws IOException
  {
    int i = 0;
    long l = 0L;
    while (i < 64)
    {
      int j = readRawByte();
      l |= (j & 0x7F) << i;
      if ((j & 0x80) == 0) {
        return l;
      }
      i += 7;
    }
    throw InvalidProtocolBufferNanoException.malformedVarint();
  }
  
  public int readSFixed32()
    throws IOException
  {
    return readRawLittleEndian32();
  }
  
  public long readSFixed64()
    throws IOException
  {
    return readRawLittleEndian64();
  }
  
  public int readSInt32()
    throws IOException
  {
    return decodeZigZag32(readRawVarint32());
  }
  
  public long readSInt64()
    throws IOException
  {
    return decodeZigZag64(readRawVarint64());
  }
  
  public String readString()
    throws IOException
  {
    int i = readRawVarint32();
    if ((i <= bufferSize - bufferPos) && (i > 0))
    {
      String str = new String(buffer, bufferPos, i, "UTF-8");
      bufferPos += i;
      return str;
    }
    return new String(readRawBytes(i), "UTF-8");
  }
  
  public int readTag()
    throws IOException
  {
    if (isAtEnd())
    {
      lastTag = 0;
      return 0;
    }
    lastTag = readRawVarint32();
    if (lastTag == 0) {
      throw InvalidProtocolBufferNanoException.invalidTag();
    }
    return lastTag;
  }
  
  public int readUInt32()
    throws IOException
  {
    return readRawVarint32();
  }
  
  public long readUInt64()
    throws IOException
  {
    return readRawVarint64();
  }
  
  public void resetSizeCounter() {}
  
  public void rewindToPosition(int paramInt)
  {
    if (paramInt > bufferPos - bufferStart) {
      throw new IllegalArgumentException("Position " + paramInt + " is beyond current " + (bufferPos - bufferStart));
    }
    if (paramInt < 0) {
      throw new IllegalArgumentException("Bad position " + paramInt);
    }
    bufferPos = (bufferStart + paramInt);
  }
  
  public int setRecursionLimit(int paramInt)
  {
    if (paramInt < 0) {
      throw new IllegalArgumentException("Recursion limit cannot be negative: " + paramInt);
    }
    int i = recursionLimit;
    recursionLimit = paramInt;
    return i;
  }
  
  public int setSizeLimit(int paramInt)
  {
    if (paramInt < 0) {
      throw new IllegalArgumentException("Size limit cannot be negative: " + paramInt);
    }
    int i = sizeLimit;
    sizeLimit = paramInt;
    return i;
  }
  
  public boolean skipField(int paramInt)
    throws IOException
  {
    switch (WireFormatNano.getTagWireType(paramInt))
    {
    default: 
      throw InvalidProtocolBufferNanoException.invalidWireType();
    case 0: 
      readInt32();
      return true;
    case 1: 
      readRawLittleEndian64();
      return true;
    case 2: 
      skipRawBytes(readRawVarint32());
      return true;
    case 3: 
      skipMessage();
      checkLastTagWas(WireFormatNano.makeTag(WireFormatNano.getTagFieldNumber(paramInt), 4));
      return true;
    case 4: 
      return false;
    }
    readRawLittleEndian32();
    return true;
  }
  
  public void skipMessage()
    throws IOException
  {
    int i;
    do
    {
      i = readTag();
    } while ((i != 0) && (skipField(i)));
  }
  
  public void skipRawBytes(int paramInt)
    throws IOException
  {
    if (paramInt < 0) {
      throw InvalidProtocolBufferNanoException.negativeSize();
    }
    if (bufferPos + paramInt > currentLimit)
    {
      skipRawBytes(currentLimit - bufferPos);
      throw InvalidProtocolBufferNanoException.truncatedMessage();
    }
    if (paramInt <= bufferSize - bufferPos)
    {
      bufferPos += paramInt;
      return;
    }
    throw InvalidProtocolBufferNanoException.truncatedMessage();
  }
}
