package com.google.tagmanager.protobuf.nano;

import java.util.ArrayList;
import java.util.List;

public abstract class ExtendableMessageNano
  extends MessageNano
{
  protected List<UnknownFieldData> unknownFieldData;
  
  public ExtendableMessageNano() {}
  
  public Object getExtension(Extension paramExtension)
  {
    return WireFormatNano.getExtension(paramExtension, unknownFieldData);
  }
  
  public int getSerializedSize()
  {
    int i = WireFormatNano.computeWireSize(unknownFieldData);
    cachedSize = i;
    return i;
  }
  
  public void setExtension(Extension paramExtension, Object paramObject)
  {
    if (unknownFieldData == null) {
      unknownFieldData = new ArrayList();
    }
    WireFormatNano.setExtension(paramExtension, paramObject, unknownFieldData);
  }
}
