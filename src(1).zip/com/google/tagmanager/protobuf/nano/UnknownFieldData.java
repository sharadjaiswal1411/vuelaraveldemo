package com.google.tagmanager.protobuf.nano;

import java.util.Arrays;

public final class UnknownFieldData
{
  final byte[] bytes;
  final int tag;
  
  UnknownFieldData(int paramInt, byte[] paramArrayOfByte)
  {
    tag = paramInt;
    bytes = paramArrayOfByte;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof UnknownFieldData)) {
      return false;
    }
    paramObject = (UnknownFieldData)paramObject;
    return (tag == tag) && (Arrays.equals(bytes, bytes));
  }
  
  public int hashCode()
  {
    int j = tag + 527;
    int i = 0;
    while (i < bytes.length)
    {
      j = j * 31 + bytes[i];
      i += 1;
    }
    return j;
  }
}
