package com.google.tagmanager;

import android.os.Build.VERSION;
import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class OsVersionMacro
  extends FunctionCallImplementation
{
  private static final String cachePath = FunctionType.OS_VERSION.toString();
  
  public OsVersionMacro()
  {
    super(cachePath, new String[0]);
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    return Types.objectToValue(Build.VERSION.RELEASE);
  }
  
  public boolean isCacheable()
  {
    return true;
  }
}
