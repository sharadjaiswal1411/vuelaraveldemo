package com.google.tagmanager;

import android.text.TextUtils;

class Hit
{
  private final long mHitFirstDispatchTime;
  private final long mHitId;
  private final long mHitTime;
  private String mHitUrl;
  
  Hit(long paramLong1, long paramLong2)
  {
    mHitId = paramLong1;
    mHitTime = paramLong2;
    mHitFirstDispatchTime = 0L;
  }
  
  Hit(long paramLong1, long paramLong2, long paramLong3)
  {
    mHitId = paramLong1;
    mHitTime = paramLong2;
    mHitFirstDispatchTime = paramLong3;
  }
  
  long getHitFirstDispatchTime()
  {
    return mHitFirstDispatchTime;
  }
  
  long getHitId()
  {
    return mHitId;
  }
  
  long getHitTime()
  {
    return mHitTime;
  }
  
  String getHitUrl()
  {
    return mHitUrl;
  }
  
  void setHitUrl(String paramString)
  {
    if (paramString != null)
    {
      if (TextUtils.isEmpty(paramString.trim())) {
        return;
      }
      mHitUrl = paramString;
    }
  }
}
