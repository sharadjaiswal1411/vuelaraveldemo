package com.google.tagmanager;

import android.content.Context;
import android.net.Uri;
import java.util.Map;

class AdwordsClickReferrerListener
  implements DataLayer.Listener
{
  private final Context context;
  
  public AdwordsClickReferrerListener(Context paramContext)
  {
    context = paramContext;
  }
  
  public void changed(Map paramMap)
  {
    Object localObject3 = paramMap.get("gtm.url");
    Object localObject1 = localObject3;
    Object localObject2 = localObject1;
    if (localObject3 == null)
    {
      paramMap = paramMap.get("gtm");
      localObject2 = localObject1;
      if (paramMap != null)
      {
        localObject2 = localObject1;
        if ((paramMap instanceof Map)) {
          localObject2 = ((Map)paramMap).get("url");
        }
      }
    }
    if (localObject2 != null)
    {
      if (!(localObject2 instanceof String)) {
        return;
      }
      paramMap = Uri.parse((String)localObject2).getQueryParameter("referrer");
      if (paramMap != null) {
        InstallReferrerUtil.addClickReferrer(context, paramMap);
      }
    }
  }
}
