package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class EventMacro
  extends FunctionCallImplementation
{
  private static final String cachePath = FunctionType.EVENT.toString();
  private final Runtime mRuntime;
  
  public EventMacro(Runtime paramRuntime)
  {
    super(cachePath, new String[0]);
    mRuntime = paramRuntime;
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    paramMap = mRuntime.getCurrentEventName();
    if (paramMap == null) {
      return Types.getDefaultValue();
    }
    return Types.objectToValue(paramMap);
  }
  
  public boolean isCacheable()
  {
    return false;
  }
}
