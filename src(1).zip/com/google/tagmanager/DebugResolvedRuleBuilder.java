package com.google.tagmanager;

import com.google.analytics.containertag.proto.Debug.ResolvedFunctionCall;
import com.google.analytics.containertag.proto.Debug.ResolvedProperty;
import com.google.analytics.containertag.proto.Debug.ResolvedRule;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class DebugResolvedRuleBuilder
  implements ResolvedRuleBuilder
{
  ResolvedFunctionCallTranslatorList addMacrosHolder;
  ResolvedFunctionCallTranslatorList addTagsHolder;
  ResolvedFunctionCallTranslatorList removeMacrosHolder;
  ResolvedFunctionCallTranslatorList removeTagsHolder;
  Debug.ResolvedRule resolvedRule;
  
  public DebugResolvedRuleBuilder(Debug.ResolvedRule paramResolvedRule)
  {
    resolvedRule = paramResolvedRule;
    addMacrosHolder = new DebugResolvedFunctionCallListTranslator(1);
    removeMacrosHolder = new DebugResolvedFunctionCallListTranslator(2);
    addTagsHolder = new DebugResolvedFunctionCallListTranslator(3);
    removeTagsHolder = new DebugResolvedFunctionCallListTranslator(4);
  }
  
  public static Debug.ResolvedFunctionCall translateExpandedFunctionCall(ResourceUtil.ExpandedFunctionCall paramExpandedFunctionCall)
  {
    Debug.ResolvedFunctionCall localResolvedFunctionCall = new Debug.ResolvedFunctionCall();
    paramExpandedFunctionCall = paramExpandedFunctionCall.getProperties().entrySet().iterator();
    while (paramExpandedFunctionCall.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)paramExpandedFunctionCall.next();
      Debug.ResolvedProperty localResolvedProperty = new Debug.ResolvedProperty();
      key = ((String)localEntry.getKey());
      value = DebugValueBuilder.copyImmutableValue((TypeSystem.Value)localEntry.getValue());
      properties = ArrayUtils.appendToArray(properties, localResolvedProperty);
    }
    return localResolvedFunctionCall;
  }
  
  public ResolvedFunctionCallBuilder createNegativePredicate()
  {
    Debug.ResolvedFunctionCall localResolvedFunctionCall = new Debug.ResolvedFunctionCall();
    resolvedRule.negativePredicates = ArrayUtils.appendToArray(resolvedRule.negativePredicates, localResolvedFunctionCall);
    return new DebugResolvedFunctionCallBuilder(localResolvedFunctionCall);
  }
  
  public ResolvedFunctionCallBuilder createPositivePredicate()
  {
    Debug.ResolvedFunctionCall localResolvedFunctionCall = new Debug.ResolvedFunctionCall();
    resolvedRule.positivePredicates = ArrayUtils.appendToArray(resolvedRule.positivePredicates, localResolvedFunctionCall);
    return new DebugResolvedFunctionCallBuilder(localResolvedFunctionCall);
  }
  
  public ResolvedFunctionCallTranslatorList getAddedMacroFunctions()
  {
    return addMacrosHolder;
  }
  
  public ResolvedFunctionCallTranslatorList getAddedTagFunctions()
  {
    return addTagsHolder;
  }
  
  public ResolvedFunctionCallTranslatorList getRemovedMacroFunctions()
  {
    return removeMacrosHolder;
  }
  
  public ResolvedFunctionCallTranslatorList getRemovedTagFunctions()
  {
    return removeTagsHolder;
  }
  
  public void setValue(TypeSystem.Value paramValue)
  {
    resolvedRule.result = DebugValueBuilder.copyImmutableValue(paramValue);
  }
  
  class DebugResolvedFunctionCallListTranslator
    implements ResolvedFunctionCallTranslatorList
  {
    private final int type;
    
    DebugResolvedFunctionCallListTranslator(int paramInt)
    {
      type = paramInt;
    }
    
    public void translateAndAddAll(List paramList1, List paramList2)
    {
      ArrayList localArrayList = new ArrayList(paramList1.size());
      int i = 0;
      if (i < paramList1.size())
      {
        localArrayList.add(DebugResolvedRuleBuilder.translateExpandedFunctionCall((ResourceUtil.ExpandedFunctionCall)paramList1.get(i)));
        if (i < paramList2.size()) {}
        for (getassociatedRuleName = ((String)paramList2.get(i));; getassociatedRuleName = "Unknown")
        {
          i += 1;
          break;
        }
      }
      paramList1 = (Debug.ResolvedFunctionCall[])localArrayList.toArray(new Debug.ResolvedFunctionCall[0]);
      switch (type)
      {
      default: 
        Log.e("unknown type in translateAndAddAll: " + type);
        return;
      case 1: 
        resolvedRule.addMacros = paramList1;
        return;
      case 2: 
        resolvedRule.removeMacros = paramList1;
        return;
      case 3: 
        resolvedRule.addTags = paramList1;
        return;
      }
      resolvedRule.removeTags = paramList1;
    }
    
    class Type
    {
      static final int ADD_MACROS = 1;
      static final int ADD_TAGS = 3;
      static final int REMOVE_MACROS = 2;
      static final int REMOVE_TAGS = 4;
      
      Type() {}
    }
  }
}
