package com.google.tagmanager;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;

class HttpNetworkClient
  implements NetworkClient
{
  private HttpClient mClient;
  
  HttpNetworkClient() {}
  
  private void closeWithClient(HttpClient paramHttpClient)
  {
    if ((paramHttpClient != null) && (paramHttpClient.getConnectionManager() != null)) {
      paramHttpClient.getConnectionManager().shutdown();
    }
  }
  
  private InputStream handleServerResponse(HttpClient paramHttpClient, HttpResponse paramHttpResponse)
    throws IOException
  {
    int i = paramHttpResponse.getStatusLine().getStatusCode();
    if (i == 200)
    {
      Log.v("Success response");
      return paramHttpResponse.getEntity().getContent();
    }
    paramHttpClient = "Bad response: " + i;
    if (i == 404) {
      throw new FileNotFoundException(paramHttpClient);
    }
    throw new IOException(paramHttpClient);
  }
  
  public void close()
  {
    closeWithClient(mClient);
  }
  
  HttpClient createNewHttpClient()
  {
    BasicHttpParams localBasicHttpParams = new BasicHttpParams();
    HttpConnectionParams.setConnectionTimeout(localBasicHttpParams, 20000);
    HttpConnectionParams.setSoTimeout(localBasicHttpParams, 20000);
    return new DefaultHttpClient(localBasicHttpParams);
  }
  
  HttpPost createPostRequest(String paramString, byte[] paramArrayOfByte)
  {
    paramString = new HttpPost(paramString);
    paramString.setEntity(new ByteArrayEntity(paramArrayOfByte));
    return paramString;
  }
  
  public InputStream getInputStream(String paramString)
    throws IOException
  {
    mClient = createNewHttpClient();
    paramString = mClient.execute(new HttpGet(paramString));
    return handleServerResponse(mClient, paramString);
  }
  
  public void sendPostRequest(String paramString, byte[] paramArrayOfByte)
    throws IOException
  {
    HttpClient localHttpClient = createNewHttpClient();
    handleServerResponse(localHttpClient, localHttpClient.execute(createPostRequest(paramString, paramArrayOfByte)));
    closeWithClient(localHttpClient);
  }
}
