package com.google.tagmanager;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import com.google.analytics.containertag.common.FunctionType;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import java.util.Map;

class AppNameMacro
  extends FunctionCallImplementation
{
  private static final String cachePath = FunctionType.APP_NAME.toString();
  private final Context mContext;
  
  public AppNameMacro(Context paramContext)
  {
    super(cachePath, new String[0]);
    mContext = paramContext;
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  public TypeSystem.Value evaluate(Map paramMap)
  {
    paramMap = mContext;
    try
    {
      paramMap = paramMap.getPackageManager();
      Context localContext = mContext;
      paramMap = Types.objectToValue(paramMap.getApplicationLabel(paramMap.getApplicationInfo(localContext.getPackageName(), 0)).toString());
      return paramMap;
    }
    catch (PackageManager.NameNotFoundException paramMap)
    {
      Log.e("App name is not found.", paramMap);
    }
    return Types.getDefaultValue();
  }
  
  public boolean isCacheable()
  {
    return true;
  }
}
