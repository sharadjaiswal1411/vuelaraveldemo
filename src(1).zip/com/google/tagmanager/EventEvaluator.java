package com.google.tagmanager;

class EventEvaluator
{
  private final ResourceUtil.ExpandedResource mResource;
  private final Runtime mRuntime;
  
  public EventEvaluator(Runtime paramRuntime, ResourceUtil.ExpandedResource paramExpandedResource)
  {
    if (paramRuntime == null) {
      throw new NullPointerException("runtime cannot be null");
    }
    mRuntime = paramRuntime;
    if (paramExpandedResource != paramRuntime.getResource()) {
      throw new IllegalArgumentException("resource must be the same as the resource in runtime");
    }
    mResource = paramRuntime.getResource();
  }
  
  void evaluateEvent(String paramString)
  {
    throw new UnsupportedOperationException("this code not yet written");
  }
}
