package com.google.tagmanager;

import android.os.Build.VERSION;
import com.google.android.gms.common.util.VisibleForTesting;

class CacheFactory<K, V>
{
  @VisibleForTesting
  final CacheSizeManager<K, V> mDefaultSizeManager = new CacheSizeManager()
  {
    public int sizeOf(Object paramAnonymousObject1, Object paramAnonymousObject2)
    {
      return 1;
    }
  };
  
  public CacheFactory() {}
  
  public Cache createCache(int paramInt)
  {
    return createCache(paramInt, mDefaultSizeManager);
  }
  
  public Cache createCache(int paramInt, CacheSizeManager paramCacheSizeManager)
  {
    if (paramInt <= 0) {
      throw new IllegalArgumentException("maxSize <= 0");
    }
    if (getSdkVersion() < 12) {
      return new SimpleCache(paramInt, paramCacheSizeManager);
    }
    return new LRUCache(paramInt, paramCacheSizeManager);
  }
  
  int getSdkVersion()
  {
    return Build.VERSION.SDK_INT;
  }
  
  public static abstract interface CacheSizeManager<K, V>
  {
    public abstract int sizeOf(Object paramObject1, Object paramObject2);
  }
}
