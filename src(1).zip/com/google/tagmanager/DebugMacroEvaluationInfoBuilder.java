package com.google.tagmanager;

import com.google.analytics.containertag.proto.Debug.MacroEvaluationInfo;
import com.google.analytics.containertag.proto.Debug.ResolvedFunctionCall;
import com.google.analytics.containertag.proto.Debug.RuleEvaluationStepInfo;

class DebugMacroEvaluationInfoBuilder
  implements MacroEvaluationInfoBuilder
{
  private Debug.MacroEvaluationInfo macroEvaluationInfo;
  
  public DebugMacroEvaluationInfoBuilder(Debug.MacroEvaluationInfo paramMacroEvaluationInfo)
  {
    macroEvaluationInfo = paramMacroEvaluationInfo;
  }
  
  public ResolvedFunctionCallBuilder createResult()
  {
    macroEvaluationInfo.result = new Debug.ResolvedFunctionCall();
    return new DebugResolvedFunctionCallBuilder(macroEvaluationInfo.result);
  }
  
  public RuleEvaluationStepInfoBuilder createRulesEvaluation()
  {
    macroEvaluationInfo.rulesEvaluation = new Debug.RuleEvaluationStepInfo();
    return new DebugRuleEvaluationStepInfoBuilder(macroEvaluationInfo.rulesEvaluation);
  }
}
