package com.google.tagmanager;

import com.google.analytics.containertag.common.FunctionType;
import java.util.Map;

class EqualsPredicate
  extends StringPredicate
{
  private static final String cachePath = FunctionType.EQUALS.toString();
  
  public EqualsPredicate()
  {
    super(cachePath);
  }
  
  public static String getFunctionId()
  {
    return cachePath;
  }
  
  protected boolean evaluateString(String paramString1, String paramString2, Map paramMap)
  {
    return paramString1.equals(paramString2);
  }
}
