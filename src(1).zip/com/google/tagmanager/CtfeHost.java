package com.google.tagmanager;

import com.google.android.gms.common.util.VisibleForTesting;

class CtfeHost
{
  private static final String CTFE_SERVER_ADDRESS = "https://www.googletagmanager.com";
  @VisibleForTesting
  static final String CTFE_URL_PATH_PREFIX = "/d?";
  static final String DEBUG_EVENT_NUMBER_QUERY = "&event_number=";
  private String mCtfeServerAddress = "https://www.googletagmanager.com";
  
  public CtfeHost() {}
  
  String constructCtfeDebugUrl(int paramInt)
  {
    return mCtfeServerAddress + "/d?" + PreviewManager.getInstance().getCTFEUrlDebugQuery() + "&event_number=" + paramInt;
  }
  
  public String getCtfeServerAddress()
  {
    return mCtfeServerAddress;
  }
  
  public void setCtfeServerAddress(String paramString)
  {
    mCtfeServerAddress = paramString;
    Log.i("The Ctfe server endpoint was changed to: " + paramString);
  }
}
