package com.google.tagmanager;

import android.annotation.TargetApi;
import android.util.LruCache;

@TargetApi(12)
class LRUCache<K, V>
  implements Cache<K, V>
{
  private LruCache<K, V> lruCache;
  
  LRUCache(int paramInt, final CacheFactory.CacheSizeManager paramCacheSizeManager)
  {
    lruCache = new LruCache(paramInt)
    {
      protected int sizeOf(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        return paramCacheSizeManager.sizeOf(paramAnonymousObject1, paramAnonymousObject2);
      }
    };
  }
  
  public Object get(Object paramObject)
  {
    return lruCache.get(paramObject);
  }
  
  public void put(Object paramObject1, Object paramObject2)
  {
    lruCache.put(paramObject1, paramObject2);
  }
}
