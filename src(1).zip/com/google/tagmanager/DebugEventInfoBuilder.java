package com.google.tagmanager;

import com.google.analytics.containertag.proto.Debug.DataLayerEventEvaluationInfo;
import com.google.analytics.containertag.proto.Debug.EventInfo;
import com.google.analytics.containertag.proto.Debug.MacroEvaluationInfo;
import com.google.android.gms.common.util.VisibleForTesting;

class DebugEventInfoBuilder
  implements EventInfoBuilder
{
  private DebugDataLayerEventEvaluationInfoBuilder dataLayerEventBuilder;
  @VisibleForTesting
  Debug.EventInfo eventInfoBuilder = new Debug.EventInfo();
  private DebugInformationHandler handler;
  private DebugMacroEvaluationInfoBuilder macroBuilder;
  
  public DebugEventInfoBuilder(int paramInt, String paramString1, String paramString2, String paramString3, DebugInformationHandler paramDebugInformationHandler)
  {
    eventInfoBuilder.eventType = paramInt;
    eventInfoBuilder.containerVersion = paramString1;
    eventInfoBuilder.containerId = paramString2;
    eventInfoBuilder.key = paramString3;
    handler = paramDebugInformationHandler;
    if (paramInt == 1)
    {
      eventInfoBuilder.dataLayerEventResult = new Debug.DataLayerEventEvaluationInfo();
      dataLayerEventBuilder = new DebugDataLayerEventEvaluationInfoBuilder(eventInfoBuilder.dataLayerEventResult);
      return;
    }
    eventInfoBuilder.macroResult = new Debug.MacroEvaluationInfo();
    macroBuilder = new DebugMacroEvaluationInfoBuilder(eventInfoBuilder.macroResult);
  }
  
  public DataLayerEventEvaluationInfoBuilder createDataLayerEventEvaluationInfoBuilder()
  {
    return dataLayerEventBuilder;
  }
  
  public MacroEvaluationInfoBuilder createMacroEvaluationInfoBuilder()
  {
    return macroBuilder;
  }
  
  public void processEventInfo()
  {
    handler.receiveEventInfo(eventInfoBuilder);
  }
}
