package com.google.analytics.midtier.proto.containertag;

import com.google.tagmanager.protobuf.nano.CodedInputByteBufferNano;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import com.google.tagmanager.protobuf.nano.ExtendableMessageNano;
import com.google.tagmanager.protobuf.nano.InvalidProtocolBufferNanoException;
import com.google.tagmanager.protobuf.nano.MessageNano;
import com.google.tagmanager.protobuf.nano.WireFormatNano;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public abstract interface TypeSystem
{
  public static final class Value
    extends ExtendableMessageNano
  {
    public static final Value[] EMPTY_ARRAY = new Value[0];
    public boolean boolean_ = false;
    public boolean containsReferences = false;
    public int[] escaping = WireFormatNano.EMPTY_INT_ARRAY;
    public String functionId = "";
    public long integer = 0L;
    public Value[] listItem = EMPTY_ARRAY;
    public String macroReference = "";
    public Value[] mapKey = EMPTY_ARRAY;
    public Value[] mapValue = EMPTY_ARRAY;
    public String string = "";
    public String tagReference = "";
    public Value[] templateToken = EMPTY_ARRAY;
    public int type = 1;
    
    public Value() {}
    
    public static Value parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new Value().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static Value parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (Value)MessageNano.mergeFrom(new Value(), paramArrayOfByte);
    }
    
    public final Value clear()
    {
      type = 1;
      string = "";
      listItem = EMPTY_ARRAY;
      mapKey = EMPTY_ARRAY;
      mapValue = EMPTY_ARRAY;
      macroReference = "";
      functionId = "";
      integer = 0L;
      boolean_ = false;
      templateToken = EMPTY_ARRAY;
      tagReference = "";
      escaping = WireFormatNano.EMPTY_INT_ARRAY;
      containsReferences = false;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof Value)) {
        return false;
      }
      paramObject = (Value)paramObject;
      if (type == type)
      {
        if (string != null) {
          break label208;
        }
        if (string == null) {
          if ((Arrays.equals(listItem, listItem)) && (Arrays.equals(mapKey, mapKey)) && (Arrays.equals(mapValue, mapValue)))
          {
            if (macroReference != null) {
              break label225;
            }
            if (macroReference == null)
            {
              label102:
              if (functionId != null) {
                break label242;
              }
              if (functionId == null) {
                label116:
                if ((integer == integer) && (boolean_ == boolean_) && (Arrays.equals(templateToken, templateToken)))
                {
                  if (tagReference != null) {
                    break label259;
                  }
                  if (tagReference == null) {
                    label167:
                    if ((Arrays.equals(escaping, escaping)) && (containsReferences == containsReferences))
                    {
                      if (unknownFieldData != null) {
                        break label276;
                      }
                      if (unknownFieldData == null) {
                        break label292;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      label208:
      label225:
      label242:
      label259:
      label276:
      while (!unknownFieldData.equals(unknownFieldData))
      {
        do
        {
          do
          {
            do
            {
              do
              {
                return false;
              } while (!string.equals(string));
              break;
            } while (!macroReference.equals(macroReference));
            break label102;
          } while (!functionId.equals(functionId));
          break label116;
        } while (!tagReference.equals(tagReference));
        break label167;
      }
      label292:
      return true;
    }
    
    public int getSerializedSize()
    {
      int i = 0 + CodedOutputByteBufferNano.computeInt32Size(1, type);
      int j = i;
      if (!string.equals("")) {
        j = i + CodedOutputByteBufferNano.computeStringSize(2, string);
      }
      i = j;
      Object localObject;
      int m;
      if (listItem != null)
      {
        localObject = listItem;
        m = localObject.length;
        k = 0;
        for (;;)
        {
          i = j;
          if (k >= m) {
            break;
          }
          j += CodedOutputByteBufferNano.computeMessageSize(3, localObject[k]);
          k += 1;
        }
      }
      j = i;
      if (mapKey != null)
      {
        localObject = mapKey;
        m = localObject.length;
        k = 0;
        for (;;)
        {
          j = i;
          if (k >= m) {
            break;
          }
          i += CodedOutputByteBufferNano.computeMessageSize(4, localObject[k]);
          k += 1;
        }
      }
      i = j;
      if (mapValue != null)
      {
        localObject = mapValue;
        m = localObject.length;
        k = 0;
        for (;;)
        {
          i = j;
          if (k >= m) {
            break;
          }
          j += CodedOutputByteBufferNano.computeMessageSize(5, localObject[k]);
          k += 1;
        }
      }
      j = i;
      if (!macroReference.equals("")) {
        j = i + CodedOutputByteBufferNano.computeStringSize(6, macroReference);
      }
      i = j;
      if (!functionId.equals("")) {
        i = j + CodedOutputByteBufferNano.computeStringSize(7, functionId);
      }
      int k = i;
      if (integer != 0L) {
        k = i + CodedOutputByteBufferNano.computeInt64Size(8, integer);
      }
      j = k;
      if (containsReferences) {
        j = k + CodedOutputByteBufferNano.computeBoolSize(9, containsReferences);
      }
      i = j;
      if (escaping != null)
      {
        i = j;
        if (escaping.length > 0)
        {
          k = 0;
          localObject = escaping;
          m = localObject.length;
          i = 0;
          while (i < m)
          {
            k += CodedOutputByteBufferNano.computeInt32SizeNoTag(localObject[i]);
            i += 1;
          }
          i = j + k + escaping.length * 1;
        }
      }
      j = i;
      if (templateToken != null)
      {
        localObject = templateToken;
        m = localObject.length;
        k = 0;
        for (;;)
        {
          j = i;
          if (k >= m) {
            break;
          }
          i += CodedOutputByteBufferNano.computeMessageSize(11, localObject[k]);
          k += 1;
        }
      }
      i = j;
      if (boolean_) {
        i = j + CodedOutputByteBufferNano.computeBoolSize(12, boolean_);
      }
      j = i;
      if (!tagReference.equals("")) {
        j = i + CodedOutputByteBufferNano.computeStringSize(13, tagReference);
      }
      i = j + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int i1 = 1;
      int n = 0;
      int j = type;
      int i;
      label43:
      label55:
      label67:
      label76:
      label85:
      int m;
      if (string == null)
      {
        i = 0;
        i = (j + 527) * 31 + i;
        if (listItem != null) {
          break label217;
        }
        j = i * 31;
        if (mapKey != null) {
          break label268;
        }
        j *= 31;
        if (mapValue != null) {
          break label321;
        }
        j *= 31;
        if (macroReference != null) {
          break label374;
        }
        i = 0;
        if (functionId != null) {
          break label385;
        }
        k = 0;
        int i2 = (int)(integer ^ integer >>> 32);
        if (!boolean_) {
          break label396;
        }
        m = 1;
        label110:
        i = (((j * 31 + i) * 31 + k) * 31 + i2) * 31 + m;
        if (templateToken != null) {
          break label402;
        }
        k = i * 31;
        label146:
        if (tagReference != null) {
          break label453;
        }
        i = 0;
        label155:
        i = k * 31 + i;
        if (escaping != null) {
          break label464;
        }
        j = i * 31;
        if (!containsReferences) {
          break label496;
        }
        i = i1;
        label184:
        if (unknownFieldData != null) {
          break label501;
        }
      }
      label217:
      label268:
      label321:
      label374:
      label385:
      label396:
      label402:
      label453:
      label464:
      label496:
      label501:
      for (int k = n;; k = unknownFieldData.hashCode())
      {
        return (j * 31 + i) * 31 + k;
        i = string.hashCode();
        break;
        k = 0;
        j = i;
        if (k >= listItem.length) {
          break label43;
        }
        if (listItem[k] == null) {}
        for (j = 0;; j = listItem[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= mapKey.length) {
          break label55;
        }
        if (mapKey[k] == null) {}
        for (j = 0;; j = mapKey[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= mapValue.length) {
          break label67;
        }
        if (mapValue[k] == null) {}
        for (j = 0;; j = mapValue[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        i = macroReference.hashCode();
        break label76;
        k = functionId.hashCode();
        break label85;
        m = 2;
        break label110;
        j = 0;
        k = i;
        if (j >= templateToken.length) {
          break label146;
        }
        if (templateToken[j] == null) {}
        for (k = 0;; k = templateToken[j].hashCode())
        {
          i = i * 31 + k;
          j += 1;
          break;
        }
        i = tagReference.hashCode();
        break label155;
        k = 0;
        for (;;)
        {
          j = i;
          if (k >= escaping.length) {
            break;
          }
          i = i * 31 + escaping[k];
          k += 1;
        }
        i = 2;
        break label184;
      }
    }
    
    public Value mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        int j;
        Object localObject;
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 8: 
          i = paramCodedInputByteBufferNano.readInt32();
          if ((i == 1) || (i == 2) || (i == 3) || (i == 4) || (i == 5) || (i == 6) || (i == 7) || (i == 8) || (i == 9)) {
            type = i;
          } else {
            type = 1;
          }
          break;
        case 18: 
          string = paramCodedInputByteBufferNano.readString();
          break;
        case 26: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 26);
          if (listItem == null) {}
          for (i = 0;; i = listItem.length)
          {
            localObject = new Value[i + j];
            if (listItem != null) {
              System.arraycopy(listItem, 0, localObject, 0, i);
            }
            listItem = ((Value[])localObject);
            while (i < listItem.length - 1)
            {
              listItem[i] = new Value();
              paramCodedInputByteBufferNano.readMessage(listItem[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          listItem[i] = new Value();
          paramCodedInputByteBufferNano.readMessage(listItem[i]);
          break;
        case 34: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 34);
          if (mapKey == null) {}
          for (i = 0;; i = mapKey.length)
          {
            localObject = new Value[i + j];
            if (mapKey != null) {
              System.arraycopy(mapKey, 0, localObject, 0, i);
            }
            mapKey = ((Value[])localObject);
            while (i < mapKey.length - 1)
            {
              mapKey[i] = new Value();
              paramCodedInputByteBufferNano.readMessage(mapKey[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          mapKey[i] = new Value();
          paramCodedInputByteBufferNano.readMessage(mapKey[i]);
          break;
        case 42: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 42);
          if (mapValue == null) {}
          for (i = 0;; i = mapValue.length)
          {
            localObject = new Value[i + j];
            if (mapValue != null) {
              System.arraycopy(mapValue, 0, localObject, 0, i);
            }
            mapValue = ((Value[])localObject);
            while (i < mapValue.length - 1)
            {
              mapValue[i] = new Value();
              paramCodedInputByteBufferNano.readMessage(mapValue[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          mapValue[i] = new Value();
          paramCodedInputByteBufferNano.readMessage(mapValue[i]);
          break;
        case 50: 
          macroReference = paramCodedInputByteBufferNano.readString();
          break;
        case 58: 
          functionId = paramCodedInputByteBufferNano.readString();
          break;
        case 64: 
          integer = paramCodedInputByteBufferNano.readInt64();
          break;
        case 72: 
          containsReferences = paramCodedInputByteBufferNano.readBool();
          break;
        case 80: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 80);
          i = escaping.length;
          localObject = new int[i + j];
          System.arraycopy(escaping, 0, localObject, 0, i);
          escaping = ((int[])localObject);
          while (i < escaping.length - 1)
          {
            escaping[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          escaping[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 90: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 90);
          if (templateToken == null) {}
          for (i = 0;; i = templateToken.length)
          {
            localObject = new Value[i + j];
            if (templateToken != null) {
              System.arraycopy(templateToken, 0, localObject, 0, i);
            }
            templateToken = ((Value[])localObject);
            while (i < templateToken.length - 1)
            {
              templateToken[i] = new Value();
              paramCodedInputByteBufferNano.readMessage(templateToken[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          templateToken[i] = new Value();
          paramCodedInputByteBufferNano.readMessage(templateToken[i]);
          break;
        case 96: 
          boolean_ = paramCodedInputByteBufferNano.readBool();
          break;
        case 106: 
          tagReference = paramCodedInputByteBufferNano.readString();
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      paramCodedOutputByteBufferNano.writeInt32(1, type);
      if (!string.equals("")) {
        paramCodedOutputByteBufferNano.writeString(2, string);
      }
      Object localObject;
      int j;
      int i;
      if (listItem != null)
      {
        localObject = listItem;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(3, localObject[i]);
          i += 1;
        }
      }
      if (mapKey != null)
      {
        localObject = mapKey;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(4, localObject[i]);
          i += 1;
        }
      }
      if (mapValue != null)
      {
        localObject = mapValue;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(5, localObject[i]);
          i += 1;
        }
      }
      if (!macroReference.equals("")) {
        paramCodedOutputByteBufferNano.writeString(6, macroReference);
      }
      if (!functionId.equals("")) {
        paramCodedOutputByteBufferNano.writeString(7, functionId);
      }
      if (integer != 0L) {
        paramCodedOutputByteBufferNano.writeInt64(8, integer);
      }
      if (containsReferences) {
        paramCodedOutputByteBufferNano.writeBool(9, containsReferences);
      }
      if ((escaping != null) && (escaping.length > 0))
      {
        localObject = escaping;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(10, localObject[i]);
          i += 1;
        }
      }
      if (templateToken != null)
      {
        localObject = templateToken;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(11, localObject[i]);
          i += 1;
        }
      }
      if (boolean_) {
        paramCodedOutputByteBufferNano.writeBool(12, boolean_);
      }
      if (!tagReference.equals("")) {
        paramCodedOutputByteBufferNano.writeString(13, tagReference);
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
    
    public static abstract interface Escaping
    {
      public static final int CONVERT_JS_VALUE_TO_EXPRESSION = 16;
      public static final int ESCAPE_CSS_STRING = 10;
      public static final int ESCAPE_HTML = 1;
      public static final int ESCAPE_HTML_ATTRIBUTE = 3;
      public static final int ESCAPE_HTML_ATTRIBUTE_NOSPACE = 4;
      public static final int ESCAPE_HTML_RCDATA = 2;
      public static final int ESCAPE_JS_REGEX = 9;
      public static final int ESCAPE_JS_STRING = 7;
      public static final int ESCAPE_JS_VALUE = 8;
      public static final int ESCAPE_URI = 12;
      public static final int FILTER_CSS_VALUE = 11;
      public static final int FILTER_HTML_ATTRIBUTES = 6;
      public static final int FILTER_HTML_ELEMENT_NAME = 5;
      public static final int FILTER_NORMALIZE_URI = 14;
      public static final int NORMALIZE_URI = 13;
      public static final int NO_AUTOESCAPE = 15;
      public static final int TEXT = 17;
    }
    
    public static abstract interface Type
    {
      public static final int BOOLEAN = 8;
      public static final int FUNCTION_ID = 5;
      public static final int INTEGER = 6;
      public static final int LIST = 2;
      public static final int MACRO_REFERENCE = 4;
      public static final int SORT_MENU_ITEM = 3;
      public static final int STRING = 1;
      public static final int TAG_REFERENCE = 9;
      public static final int TEMPLATE = 7;
    }
  }
}
