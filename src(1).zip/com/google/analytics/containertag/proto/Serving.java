package com.google.analytics.containertag.proto;

import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import com.google.tagmanager.protobuf.nano.CodedInputByteBufferNano;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import com.google.tagmanager.protobuf.nano.ExtendableMessageNano;
import com.google.tagmanager.protobuf.nano.Extension;
import com.google.tagmanager.protobuf.nano.Extension.TypeLiteral;
import com.google.tagmanager.protobuf.nano.InvalidProtocolBufferNanoException;
import com.google.tagmanager.protobuf.nano.MessageNano;
import com.google.tagmanager.protobuf.nano.WireFormatNano;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public abstract interface Serving
{
  public static final class CacheOption
    extends ExtendableMessageNano
  {
    public static final CacheOption[] EMPTY_ARRAY = new CacheOption[0];
    public int expirationSeconds = 0;
    public int gcacheExpirationSeconds = 0;
    public int level = 1;
    
    public CacheOption() {}
    
    public static CacheOption parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new CacheOption().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static CacheOption parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (CacheOption)MessageNano.mergeFrom(new CacheOption(), paramArrayOfByte);
    }
    
    public final CacheOption clear()
    {
      level = 1;
      expirationSeconds = 0;
      gcacheExpirationSeconds = 0;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof CacheOption)) {
        return false;
      }
      paramObject = (CacheOption)paramObject;
      if ((level == level) && (expirationSeconds == expirationSeconds) && (gcacheExpirationSeconds == gcacheExpirationSeconds))
      {
        if (unknownFieldData != null) {
          break label70;
        }
        if (unknownFieldData == null) {
          break label86;
        }
      }
      label70:
      while (!unknownFieldData.equals(unknownFieldData)) {
        return false;
      }
      label86:
      return true;
    }
    
    public int getSerializedSize()
    {
      int j = 0;
      if (level != 1) {
        j = 0 + CodedOutputByteBufferNano.computeInt32Size(1, level);
      }
      int i = j;
      if (expirationSeconds != 0) {
        i = j + CodedOutputByteBufferNano.computeInt32Size(2, expirationSeconds);
      }
      j = i;
      if (gcacheExpirationSeconds != 0) {
        j = i + CodedOutputByteBufferNano.computeInt32Size(3, gcacheExpirationSeconds);
      }
      i = j + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int j = level;
      int k = expirationSeconds;
      int m = gcacheExpirationSeconds;
      if (unknownFieldData == null) {}
      for (int i = 0;; i = unknownFieldData.hashCode()) {
        return (((j + 527) * 31 + k) * 31 + m) * 31 + i;
      }
    }
    
    public CacheOption mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 8: 
          i = paramCodedInputByteBufferNano.readInt32();
          if ((i == 1) || (i == 2) || (i == 3)) {
            level = i;
          } else {
            level = 1;
          }
          break;
        case 16: 
          expirationSeconds = paramCodedInputByteBufferNano.readInt32();
          break;
        case 24: 
          gcacheExpirationSeconds = paramCodedInputByteBufferNano.readInt32();
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      if (level != 1) {
        paramCodedOutputByteBufferNano.writeInt32(1, level);
      }
      if (expirationSeconds != 0) {
        paramCodedOutputByteBufferNano.writeInt32(2, expirationSeconds);
      }
      if (gcacheExpirationSeconds != 0) {
        paramCodedOutputByteBufferNano.writeInt32(3, gcacheExpirationSeconds);
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
    
    public static abstract interface CacheLevel
    {
      public static final int NO_CACHE = 1;
      public static final int PRIVATE = 2;
      public static final int PUBLIC = 3;
    }
  }
  
  public static final class Container
    extends ExtendableMessageNano
  {
    public static final Container[] EMPTY_ARRAY = new Container[0];
    public String containerId = "";
    public Serving.Resource jsResource = null;
    public int state = 1;
    public String version = "";
    
    public Container() {}
    
    public static Container parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new Container().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static Container parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (Container)MessageNano.mergeFrom(new Container(), paramArrayOfByte);
    }
    
    public final Container clear()
    {
      jsResource = null;
      containerId = "";
      state = 1;
      version = "";
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof Container)) {
        return false;
      }
      paramObject = (Container)paramObject;
      if (jsResource == null) {
        if (jsResource == null)
        {
          if (containerId != null) {
            break label107;
          }
          if (containerId == null) {
            label49:
            if (state == state)
            {
              if (version != null) {
                break label124;
              }
              if (version == null)
              {
                label74:
                if (unknownFieldData != null) {
                  break label141;
                }
                if (unknownFieldData == null) {
                  break label157;
                }
              }
            }
          }
        }
      }
      label107:
      label124:
      label141:
      while (!unknownFieldData.equals(unknownFieldData))
      {
        do
        {
          do
          {
            do
            {
              return false;
            } while (!jsResource.equals(jsResource));
            break;
          } while (!containerId.equals(containerId));
          break label49;
        } while (!version.equals(version));
        break label74;
      }
      label157:
      return true;
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      if (jsResource != null) {
        i = 0 + CodedOutputByteBufferNano.computeMessageSize(1, jsResource);
      }
      int j = i + CodedOutputByteBufferNano.computeStringSize(3, containerId) + CodedOutputByteBufferNano.computeInt32Size(4, state);
      i = j;
      if (!version.equals("")) {
        i = j + CodedOutputByteBufferNano.computeStringSize(5, version);
      }
      i += WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int m = 0;
      int i;
      int j;
      label21:
      int n;
      int k;
      if (jsResource == null)
      {
        i = 0;
        if (containerId != null) {
          break label82;
        }
        j = 0;
        n = state;
        if (version != null) {
          break label93;
        }
        k = 0;
        label36:
        if (unknownFieldData != null) {
          break label104;
        }
      }
      for (;;)
      {
        return ((((i + 527) * 31 + j) * 31 + n) * 31 + k) * 31 + m;
        i = jsResource.hashCode();
        break;
        label82:
        j = containerId.hashCode();
        break label21;
        label93:
        k = version.hashCode();
        break label36;
        label104:
        m = unknownFieldData.hashCode();
      }
    }
    
    public Container mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 10: 
          jsResource = new Serving.Resource();
          paramCodedInputByteBufferNano.readMessage(jsResource);
          break;
        case 26: 
          containerId = paramCodedInputByteBufferNano.readString();
          break;
        case 32: 
          i = paramCodedInputByteBufferNano.readInt32();
          if ((i == 1) || (i == 2)) {
            state = i;
          } else {
            state = 1;
          }
          break;
        case 42: 
          version = paramCodedInputByteBufferNano.readString();
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      if (jsResource != null) {
        paramCodedOutputByteBufferNano.writeMessage(1, jsResource);
      }
      paramCodedOutputByteBufferNano.writeString(3, containerId);
      paramCodedOutputByteBufferNano.writeInt32(4, state);
      if (!version.equals("")) {
        paramCodedOutputByteBufferNano.writeString(5, version);
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static final class FunctionCall
    extends ExtendableMessageNano
  {
    public static final FunctionCall[] EMPTY_ARRAY = new FunctionCall[0];
    public int function = 0;
    public boolean liveOnly = false;
    public int name = 0;
    public int[] property = WireFormatNano.EMPTY_INT_ARRAY;
    public boolean serverSide = false;
    
    public FunctionCall() {}
    
    public static FunctionCall parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new FunctionCall().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static FunctionCall parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (FunctionCall)MessageNano.mergeFrom(new FunctionCall(), paramArrayOfByte);
    }
    
    public final FunctionCall clear()
    {
      property = WireFormatNano.EMPTY_INT_ARRAY;
      function = 0;
      name = 0;
      liveOnly = false;
      serverSide = false;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof FunctionCall)) {
        return false;
      }
      paramObject = (FunctionCall)paramObject;
      if ((Arrays.equals(property, property)) && (function == function) && (name == name) && (liveOnly == liveOnly) && (serverSide == serverSide))
      {
        if (unknownFieldData != null) {
          break label95;
        }
        if (unknownFieldData == null) {
          break label111;
        }
      }
      label95:
      while (!unknownFieldData.equals(unknownFieldData)) {
        return false;
      }
      label111:
      return true;
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      if (serverSide) {
        i = 0 + CodedOutputByteBufferNano.computeBoolSize(1, serverSide);
      }
      int k = i + CodedOutputByteBufferNano.computeInt32Size(2, function);
      i = k;
      if (property != null)
      {
        i = k;
        if (property.length > 0)
        {
          j = 0;
          int[] arrayOfInt = property;
          int m = arrayOfInt.length;
          i = 0;
          while (i < m)
          {
            j += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[i]);
            i += 1;
          }
          i = k + j + property.length * 1;
        }
      }
      int j = i;
      if (name != 0) {
        j = i + CodedOutputByteBufferNano.computeInt32Size(4, name);
      }
      i = j;
      if (liveOnly) {
        i = j + CodedOutputByteBufferNano.computeBoolSize(6, liveOnly);
      }
      i += WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int m = 1;
      int i = 17;
      int j;
      int n;
      int i1;
      label40:
      int k;
      if (property == null)
      {
        j = 17 * 31;
        n = function;
        i1 = name;
        if (!liveOnly) {
          break label122;
        }
        i = 1;
        if (!serverSide) {
          break label127;
        }
        k = m;
        label50:
        if (unknownFieldData != null) {
          break label132;
        }
      }
      label122:
      label127:
      label132:
      for (m = 0;; m = unknownFieldData.hashCode())
      {
        return ((((j * 31 + n) * 31 + i1) * 31 + i) * 31 + k) * 31 + m;
        k = 0;
        for (;;)
        {
          j = i;
          if (k >= property.length) {
            break;
          }
          i = i * 31 + property[k];
          k += 1;
        }
        i = 2;
        break label40;
        k = 2;
        break label50;
      }
    }
    
    public FunctionCall mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 8: 
          serverSide = paramCodedInputByteBufferNano.readBool();
          break;
        case 16: 
          function = paramCodedInputByteBufferNano.readInt32();
          break;
        case 24: 
          int j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 24);
          i = property.length;
          int[] arrayOfInt = new int[i + j];
          System.arraycopy(property, 0, arrayOfInt, 0, i);
          property = arrayOfInt;
          while (i < property.length - 1)
          {
            property[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          property[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 32: 
          name = paramCodedInputByteBufferNano.readInt32();
          break;
        case 48: 
          liveOnly = paramCodedInputByteBufferNano.readBool();
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      if (serverSide) {
        paramCodedOutputByteBufferNano.writeBool(1, serverSide);
      }
      paramCodedOutputByteBufferNano.writeInt32(2, function);
      if (property != null)
      {
        int[] arrayOfInt = property;
        int j = arrayOfInt.length;
        int i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(3, arrayOfInt[i]);
          i += 1;
        }
      }
      if (name != 0) {
        paramCodedOutputByteBufferNano.writeInt32(4, name);
      }
      if (liveOnly) {
        paramCodedOutputByteBufferNano.writeBool(6, liveOnly);
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static final class GaExperimentRandom
    extends ExtendableMessageNano
  {
    public static final GaExperimentRandom[] EMPTY_ARRAY = new GaExperimentRandom[0];
    public long lifetimeInMilliseconds = 0L;
    public long maxRandom = 2147483647L;
    public long minRandom = 0L;
    public boolean retainOriginalValue = false;
    public String string = "";
    
    public GaExperimentRandom() {}
    
    public static GaExperimentRandom parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new GaExperimentRandom().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static GaExperimentRandom parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (GaExperimentRandom)MessageNano.mergeFrom(new GaExperimentRandom(), paramArrayOfByte);
    }
    
    public final GaExperimentRandom clear()
    {
      string = "";
      minRandom = 0L;
      maxRandom = 2147483647L;
      retainOriginalValue = false;
      lifetimeInMilliseconds = 0L;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof GaExperimentRandom)) {
        return false;
      }
      paramObject = (GaExperimentRandom)paramObject;
      if (string == null) {
        if (string == null) {
          if ((minRandom == minRandom) && (maxRandom == maxRandom) && (retainOriginalValue == retainOriginalValue) && (lifetimeInMilliseconds == lifetimeInMilliseconds))
          {
            if (unknownFieldData != null) {
              break label115;
            }
            if (unknownFieldData == null) {
              break label131;
            }
          }
        }
      }
      label115:
      while (!unknownFieldData.equals(unknownFieldData))
      {
        do
        {
          return false;
        } while (!string.equals(string));
        break;
      }
      label131:
      return true;
    }
    
    public int getSerializedSize()
    {
      int j = 0;
      if (!string.equals("")) {
        j = 0 + CodedOutputByteBufferNano.computeStringSize(1, string);
      }
      int i = j;
      if (minRandom != 0L) {
        i = j + CodedOutputByteBufferNano.computeInt64Size(2, minRandom);
      }
      j = i;
      if (maxRandom != 2147483647L) {
        j = i + CodedOutputByteBufferNano.computeInt64Size(3, maxRandom);
      }
      i = j;
      if (retainOriginalValue) {
        i = j + CodedOutputByteBufferNano.computeBoolSize(4, retainOriginalValue);
      }
      j = i;
      if (lifetimeInMilliseconds != 0L) {
        j = i + CodedOutputByteBufferNano.computeInt64Size(5, lifetimeInMilliseconds);
      }
      i = j + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int k = 0;
      int i;
      int m;
      int n;
      int j;
      label50:
      int i1;
      if (string == null)
      {
        i = 0;
        m = (int)(minRandom ^ minRandom >>> 32);
        n = (int)(maxRandom ^ maxRandom >>> 32);
        if (!retainOriginalValue) {
          break label117;
        }
        j = 1;
        i1 = (int)(lifetimeInMilliseconds ^ lifetimeInMilliseconds >>> 32);
        if (unknownFieldData != null) {
          break label122;
        }
      }
      for (;;)
      {
        return (((((i + 527) * 31 + m) * 31 + n) * 31 + j) * 31 + i1) * 31 + k;
        i = string.hashCode();
        break;
        label117:
        j = 2;
        break label50;
        label122:
        k = unknownFieldData.hashCode();
      }
    }
    
    public GaExperimentRandom mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 10: 
          string = paramCodedInputByteBufferNano.readString();
          break;
        case 16: 
          minRandom = paramCodedInputByteBufferNano.readInt64();
          break;
        case 24: 
          maxRandom = paramCodedInputByteBufferNano.readInt64();
          break;
        case 32: 
          retainOriginalValue = paramCodedInputByteBufferNano.readBool();
          break;
        case 40: 
          lifetimeInMilliseconds = paramCodedInputByteBufferNano.readInt64();
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      if (!string.equals("")) {
        paramCodedOutputByteBufferNano.writeString(1, string);
      }
      if (minRandom != 0L) {
        paramCodedOutputByteBufferNano.writeInt64(2, minRandom);
      }
      if (maxRandom != 2147483647L) {
        paramCodedOutputByteBufferNano.writeInt64(3, maxRandom);
      }
      if (retainOriginalValue) {
        paramCodedOutputByteBufferNano.writeBool(4, retainOriginalValue);
      }
      if (lifetimeInMilliseconds != 0L) {
        paramCodedOutputByteBufferNano.writeInt64(5, lifetimeInMilliseconds);
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static final class GaExperimentSupplemental
    extends ExtendableMessageNano
  {
    public static final GaExperimentSupplemental[] EMPTY_ARRAY = new GaExperimentSupplemental[0];
    public Serving.GaExperimentRandom[] experimentRandom = Serving.GaExperimentRandom.EMPTY_ARRAY;
    public TypeSystem.Value[] valueToClear = TypeSystem.Value.EMPTY_ARRAY;
    public TypeSystem.Value[] valueToPush = TypeSystem.Value.EMPTY_ARRAY;
    
    public GaExperimentSupplemental() {}
    
    public static GaExperimentSupplemental parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new GaExperimentSupplemental().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static GaExperimentSupplemental parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (GaExperimentSupplemental)MessageNano.mergeFrom(new GaExperimentSupplemental(), paramArrayOfByte);
    }
    
    public final GaExperimentSupplemental clear()
    {
      valueToPush = TypeSystem.Value.EMPTY_ARRAY;
      valueToClear = TypeSystem.Value.EMPTY_ARRAY;
      experimentRandom = Serving.GaExperimentRandom.EMPTY_ARRAY;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof GaExperimentSupplemental)) {
        return false;
      }
      paramObject = (GaExperimentSupplemental)paramObject;
      if ((Arrays.equals(valueToPush, valueToPush)) && (Arrays.equals(valueToClear, valueToClear)) && (Arrays.equals(experimentRandom, experimentRandom)))
      {
        if (unknownFieldData != null) {
          break label79;
        }
        if (unknownFieldData == null) {
          break label95;
        }
      }
      label79:
      while (!unknownFieldData.equals(unknownFieldData)) {
        return false;
      }
      label95:
      return true;
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      int j = 0;
      Object localObject;
      int m;
      if (valueToPush != null)
      {
        localObject = valueToPush;
        m = localObject.length;
        k = 0;
        for (;;)
        {
          i = j;
          if (k >= m) {
            break;
          }
          j += CodedOutputByteBufferNano.computeMessageSize(1, localObject[k]);
          k += 1;
        }
      }
      j = i;
      if (valueToClear != null)
      {
        localObject = valueToClear;
        m = localObject.length;
        k = 0;
        for (;;)
        {
          j = i;
          if (k >= m) {
            break;
          }
          i += CodedOutputByteBufferNano.computeMessageSize(2, localObject[k]);
          k += 1;
        }
      }
      int k = j;
      if (experimentRandom != null)
      {
        localObject = experimentRandom;
        m = localObject.length;
        i = 0;
        for (;;)
        {
          k = j;
          if (i >= m) {
            break;
          }
          j += CodedOutputByteBufferNano.computeMessageSize(3, localObject[i]);
          i += 1;
        }
      }
      i = k + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int m = 0;
      int i = 17;
      int j;
      if (valueToPush == null)
      {
        j = 17 * 31;
        if (valueToClear != null) {
          break label111;
        }
        j *= 31;
        label31:
        if (experimentRandom != null) {
          break label164;
        }
        j *= 31;
        label43:
        if (unknownFieldData != null) {
          break label217;
        }
      }
      label111:
      label164:
      label217:
      for (i = m;; i = unknownFieldData.hashCode())
      {
        return j * 31 + i;
        int k = 0;
        j = i;
        if (k >= valueToPush.length) {
          break;
        }
        if (valueToPush[k] == null) {}
        for (j = 0;; j = valueToPush[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= valueToClear.length) {
          break label31;
        }
        if (valueToClear[k] == null) {}
        for (j = 0;; j = valueToClear[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= experimentRandom.length) {
          break label43;
        }
        if (experimentRandom[k] == null) {}
        for (j = 0;; j = experimentRandom[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
      }
    }
    
    public GaExperimentSupplemental mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        int j;
        Object localObject;
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 10: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 10);
          if (valueToPush == null) {}
          for (i = 0;; i = valueToPush.length)
          {
            localObject = new TypeSystem.Value[i + j];
            if (valueToPush != null) {
              System.arraycopy(valueToPush, 0, localObject, 0, i);
            }
            valueToPush = ((TypeSystem.Value[])localObject);
            while (i < valueToPush.length - 1)
            {
              valueToPush[i] = new TypeSystem.Value();
              paramCodedInputByteBufferNano.readMessage(valueToPush[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          valueToPush[i] = new TypeSystem.Value();
          paramCodedInputByteBufferNano.readMessage(valueToPush[i]);
          break;
        case 18: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 18);
          if (valueToClear == null) {}
          for (i = 0;; i = valueToClear.length)
          {
            localObject = new TypeSystem.Value[i + j];
            if (valueToClear != null) {
              System.arraycopy(valueToClear, 0, localObject, 0, i);
            }
            valueToClear = ((TypeSystem.Value[])localObject);
            while (i < valueToClear.length - 1)
            {
              valueToClear[i] = new TypeSystem.Value();
              paramCodedInputByteBufferNano.readMessage(valueToClear[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          valueToClear[i] = new TypeSystem.Value();
          paramCodedInputByteBufferNano.readMessage(valueToClear[i]);
          break;
        case 26: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 26);
          if (experimentRandom == null) {}
          for (i = 0;; i = experimentRandom.length)
          {
            localObject = new Serving.GaExperimentRandom[i + j];
            if (experimentRandom != null) {
              System.arraycopy(experimentRandom, 0, localObject, 0, i);
            }
            experimentRandom = ((Serving.GaExperimentRandom[])localObject);
            while (i < experimentRandom.length - 1)
            {
              experimentRandom[i] = new Serving.GaExperimentRandom();
              paramCodedInputByteBufferNano.readMessage(experimentRandom[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          experimentRandom[i] = new Serving.GaExperimentRandom();
          paramCodedInputByteBufferNano.readMessage(experimentRandom[i]);
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      Object localObject;
      int j;
      int i;
      if (valueToPush != null)
      {
        localObject = valueToPush;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(1, localObject[i]);
          i += 1;
        }
      }
      if (valueToClear != null)
      {
        localObject = valueToClear;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(2, localObject[i]);
          i += 1;
        }
      }
      if (experimentRandom != null)
      {
        localObject = experimentRandom;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(3, localObject[i]);
          i += 1;
        }
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static final class Property
    extends ExtendableMessageNano
  {
    public static final Property[] EMPTY_ARRAY = new Property[0];
    public int type = 0;
    public int value = 0;
    
    public Property() {}
    
    public static Property parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new Property().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static Property parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (Property)MessageNano.mergeFrom(new Property(), paramArrayOfByte);
    }
    
    public final Property clear()
    {
      type = 0;
      value = 0;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof Property)) {
        return false;
      }
      paramObject = (Property)paramObject;
      if ((type == type) && (value == value))
      {
        if (unknownFieldData != null) {
          break label59;
        }
        if (unknownFieldData == null) {
          break label75;
        }
      }
      label59:
      while (!unknownFieldData.equals(unknownFieldData)) {
        return false;
      }
      label75:
      return true;
    }
    
    public int getSerializedSize()
    {
      int i = 0 + CodedOutputByteBufferNano.computeInt32Size(1, type) + CodedOutputByteBufferNano.computeInt32Size(2, value) + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int j = type;
      int k = value;
      if (unknownFieldData == null) {}
      for (int i = 0;; i = unknownFieldData.hashCode()) {
        return ((j + 527) * 31 + k) * 31 + i;
      }
    }
    
    public Property mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 8: 
          type = paramCodedInputByteBufferNano.readInt32();
          break;
        case 16: 
          value = paramCodedInputByteBufferNano.readInt32();
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      paramCodedOutputByteBufferNano.writeInt32(1, type);
      paramCodedOutputByteBufferNano.writeInt32(2, value);
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static final class Resource
    extends ExtendableMessageNano
  {
    public static final Resource[] EMPTY_ARRAY = new Resource[0];
    private static final String TEMPLATE_VERSION_SET_DEFAULT = "0";
    public String[] key = WireFormatNano.EMPTY_STRING_ARRAY;
    public Serving.CacheOption liveJsCacheOption = null;
    public Serving.FunctionCall[] macro = Serving.FunctionCall.EMPTY_ARRAY;
    public String malwareScanAuthCode = "";
    public boolean oBSOLETEEnableAutoEventTracking = false;
    public Serving.FunctionCall[] predicate = Serving.FunctionCall.EMPTY_ARRAY;
    public String previewAuthCode = "";
    public Serving.Property[] property = Serving.Property.EMPTY_ARRAY;
    public float reportingSampleRate = 0.0F;
    public int resourceFormatVersion = 0;
    public Serving.Rule[] rule = Serving.Rule.EMPTY_ARRAY;
    public String[] supplemental = WireFormatNano.EMPTY_STRING_ARRAY;
    public Serving.FunctionCall[] tag = Serving.FunctionCall.EMPTY_ARRAY;
    public String templateVersionSet = "0";
    public String[] usageContext = WireFormatNano.EMPTY_STRING_ARRAY;
    public TypeSystem.Value[] value = TypeSystem.Value.EMPTY_ARRAY;
    public String version = "";
    
    public Resource() {}
    
    public static Resource parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new Resource().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static Resource parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (Resource)MessageNano.mergeFrom(new Resource(), paramArrayOfByte);
    }
    
    public final Resource clear()
    {
      supplemental = WireFormatNano.EMPTY_STRING_ARRAY;
      key = WireFormatNano.EMPTY_STRING_ARRAY;
      value = TypeSystem.Value.EMPTY_ARRAY;
      property = Serving.Property.EMPTY_ARRAY;
      macro = Serving.FunctionCall.EMPTY_ARRAY;
      tag = Serving.FunctionCall.EMPTY_ARRAY;
      predicate = Serving.FunctionCall.EMPTY_ARRAY;
      rule = Serving.Rule.EMPTY_ARRAY;
      previewAuthCode = "";
      malwareScanAuthCode = "";
      templateVersionSet = "0";
      version = "";
      liveJsCacheOption = null;
      reportingSampleRate = 0.0F;
      oBSOLETEEnableAutoEventTracking = false;
      usageContext = WireFormatNano.EMPTY_STRING_ARRAY;
      resourceFormatVersion = 0;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof Resource)) {
        return false;
      }
      paramObject = (Resource)paramObject;
      if ((Arrays.equals(supplemental, supplemental)) && (Arrays.equals(key, key)) && (Arrays.equals(value, value)) && (Arrays.equals(property, property)) && (Arrays.equals(macro, macro)) && (Arrays.equals(tag, tag)) && (Arrays.equals(predicate, predicate)) && (Arrays.equals(rule, rule)))
      {
        if (previewAuthCode != null) {
          break label267;
        }
        if (previewAuthCode == null)
        {
          if (malwareScanAuthCode != null) {
            break label284;
          }
          if (malwareScanAuthCode == null)
          {
            label161:
            if (templateVersionSet != null) {
              break label301;
            }
            if (templateVersionSet == null)
            {
              label175:
              if (version != null) {
                break label318;
              }
              if (version == null)
              {
                label189:
                if (liveJsCacheOption != null) {
                  break label335;
                }
                if (liveJsCacheOption == null) {
                  label203:
                  if ((reportingSampleRate == reportingSampleRate) && (oBSOLETEEnableAutoEventTracking == oBSOLETEEnableAutoEventTracking) && (Arrays.equals(usageContext, usageContext)) && (resourceFormatVersion == resourceFormatVersion))
                  {
                    if (unknownFieldData != null) {
                      break label352;
                    }
                    if (unknownFieldData == null) {
                      break label368;
                    }
                  }
                }
              }
            }
          }
        }
      }
      label267:
      label284:
      label301:
      label318:
      label335:
      label352:
      while (!unknownFieldData.equals(unknownFieldData))
      {
        do
        {
          do
          {
            do
            {
              do
              {
                do
                {
                  return false;
                } while (!previewAuthCode.equals(previewAuthCode));
                break;
              } while (!malwareScanAuthCode.equals(malwareScanAuthCode));
              break label161;
            } while (!templateVersionSet.equals(templateVersionSet));
            break label175;
          } while (!version.equals(version));
          break label189;
        } while (!liveJsCacheOption.equals(liveJsCacheOption));
        break label203;
      }
      label368:
      return true;
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      int j = i;
      Object localObject;
      if (key != null)
      {
        j = i;
        if (key.length > 0)
        {
          j = 0;
          localObject = key;
          k = localObject.length;
          i = 0;
          while (i < k)
          {
            j += CodedOutputByteBufferNano.computeStringSizeNoTag(localObject[i]);
            i += 1;
          }
          j = 0 + j + key.length * 1;
        }
      }
      i = j;
      int m;
      if (value != null)
      {
        localObject = value;
        m = localObject.length;
        k = 0;
        for (;;)
        {
          i = j;
          if (k >= m) {
            break;
          }
          j += CodedOutputByteBufferNano.computeMessageSize(2, localObject[k]);
          k += 1;
        }
      }
      j = i;
      if (property != null)
      {
        localObject = property;
        m = localObject.length;
        k = 0;
        for (;;)
        {
          j = i;
          if (k >= m) {
            break;
          }
          i += CodedOutputByteBufferNano.computeMessageSize(3, localObject[k]);
          k += 1;
        }
      }
      i = j;
      if (macro != null)
      {
        localObject = macro;
        m = localObject.length;
        k = 0;
        for (;;)
        {
          i = j;
          if (k >= m) {
            break;
          }
          j += CodedOutputByteBufferNano.computeMessageSize(4, localObject[k]);
          k += 1;
        }
      }
      j = i;
      if (tag != null)
      {
        localObject = tag;
        m = localObject.length;
        k = 0;
        for (;;)
        {
          j = i;
          if (k >= m) {
            break;
          }
          i += CodedOutputByteBufferNano.computeMessageSize(5, localObject[k]);
          k += 1;
        }
      }
      i = j;
      if (predicate != null)
      {
        localObject = predicate;
        m = localObject.length;
        k = 0;
        for (;;)
        {
          i = j;
          if (k >= m) {
            break;
          }
          j += CodedOutputByteBufferNano.computeMessageSize(6, localObject[k]);
          k += 1;
        }
      }
      j = i;
      if (rule != null)
      {
        localObject = rule;
        m = localObject.length;
        k = 0;
        for (;;)
        {
          j = i;
          if (k >= m) {
            break;
          }
          i += CodedOutputByteBufferNano.computeMessageSize(7, localObject[k]);
          k += 1;
        }
      }
      i = j;
      if (!previewAuthCode.equals("")) {
        i = j + CodedOutputByteBufferNano.computeStringSize(9, previewAuthCode);
      }
      j = i;
      if (!malwareScanAuthCode.equals("")) {
        j = i + CodedOutputByteBufferNano.computeStringSize(10, malwareScanAuthCode);
      }
      i = j;
      if (!templateVersionSet.equals("0")) {
        i = j + CodedOutputByteBufferNano.computeStringSize(12, templateVersionSet);
      }
      j = i;
      if (!version.equals("")) {
        j = i + CodedOutputByteBufferNano.computeStringSize(13, version);
      }
      int k = j;
      if (liveJsCacheOption != null) {
        k = j + CodedOutputByteBufferNano.computeMessageSize(14, liveJsCacheOption);
      }
      i = k;
      if (reportingSampleRate != 0.0F) {
        i = k + CodedOutputByteBufferNano.computeFloatSize(15, reportingSampleRate);
      }
      j = i;
      if (usageContext != null)
      {
        j = i;
        if (usageContext.length > 0)
        {
          k = 0;
          localObject = usageContext;
          m = localObject.length;
          j = 0;
          while (j < m)
          {
            k += CodedOutputByteBufferNano.computeStringSizeNoTag(localObject[j]);
            j += 1;
          }
          j = i + k + usageContext.length * 2;
        }
      }
      k = j;
      if (resourceFormatVersion != 0) {
        k = j + CodedOutputByteBufferNano.computeInt32Size(17, resourceFormatVersion);
      }
      i = k;
      if (oBSOLETEEnableAutoEventTracking) {
        i = k + CodedOutputByteBufferNano.computeBoolSize(18, oBSOLETEEnableAutoEventTracking);
      }
      j = i;
      if (supplemental != null)
      {
        j = i;
        if (supplemental.length > 0)
        {
          k = 0;
          localObject = supplemental;
          m = localObject.length;
          j = 0;
          while (j < m)
          {
            k += CodedOutputByteBufferNano.computeStringSizeNoTag(localObject[j]);
            j += 1;
          }
          j = i + k + supplemental.length * 2;
        }
      }
      i = j + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int i3 = 0;
      int i = 17;
      int j;
      label31:
      label43:
      label55:
      label67:
      label79:
      label91:
      label103:
      label112:
      int k;
      label121:
      int m;
      label131:
      int n;
      label141:
      int i1;
      label151:
      int i2;
      if (supplemental == null)
      {
        j = 17 * 31;
        if (key != null) {
          break label302;
        }
        j *= 31;
        if (value != null) {
          break label355;
        }
        j *= 31;
        if (property != null) {
          break label408;
        }
        j *= 31;
        if (macro != null) {
          break label461;
        }
        j *= 31;
        if (tag != null) {
          break label514;
        }
        j *= 31;
        if (predicate != null) {
          break label567;
        }
        j *= 31;
        if (rule != null) {
          break label620;
        }
        j *= 31;
        if (previewAuthCode != null) {
          break label673;
        }
        i = 0;
        if (malwareScanAuthCode != null) {
          break label684;
        }
        k = 0;
        if (templateVersionSet != null) {
          break label695;
        }
        m = 0;
        if (version != null) {
          break label707;
        }
        n = 0;
        if (liveJsCacheOption != null) {
          break label719;
        }
        i1 = 0;
        int i4 = Float.floatToIntBits(reportingSampleRate);
        if (!oBSOLETEEnableAutoEventTracking) {
          break label731;
        }
        i2 = 1;
        label170:
        i = ((((((j * 31 + i) * 31 + k) * 31 + m) * 31 + n) * 31 + i1) * 31 + i4) * 31 + i2;
        if (usageContext != null) {
          break label737;
        }
        k = i * 31;
        label224:
        j = resourceFormatVersion;
        if (unknownFieldData != null) {
          break label788;
        }
      }
      label302:
      label355:
      label408:
      label461:
      label514:
      label567:
      label620:
      label673:
      label684:
      label695:
      label707:
      label719:
      label731:
      label737:
      label788:
      for (i = i3;; i = unknownFieldData.hashCode())
      {
        return (k * 31 + j) * 31 + i;
        k = 0;
        j = i;
        if (k >= supplemental.length) {
          break;
        }
        if (supplemental[k] == null) {}
        for (j = 0;; j = supplemental[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= key.length) {
          break label31;
        }
        if (key[k] == null) {}
        for (j = 0;; j = key[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= value.length) {
          break label43;
        }
        if (value[k] == null) {}
        for (j = 0;; j = value[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= property.length) {
          break label55;
        }
        if (property[k] == null) {}
        for (j = 0;; j = property[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= macro.length) {
          break label67;
        }
        if (macro[k] == null) {}
        for (j = 0;; j = macro[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= tag.length) {
          break label79;
        }
        if (tag[k] == null) {}
        for (j = 0;; j = tag[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= predicate.length) {
          break label91;
        }
        if (predicate[k] == null) {}
        for (j = 0;; j = predicate[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= rule.length) {
          break label103;
        }
        if (rule[k] == null) {}
        for (j = 0;; j = rule[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        i = previewAuthCode.hashCode();
        break label112;
        k = malwareScanAuthCode.hashCode();
        break label121;
        m = templateVersionSet.hashCode();
        break label131;
        n = version.hashCode();
        break label141;
        i1 = liveJsCacheOption.hashCode();
        break label151;
        i2 = 2;
        break label170;
        j = 0;
        k = i;
        if (j >= usageContext.length) {
          break label224;
        }
        if (usageContext[j] == null) {}
        for (k = 0;; k = usageContext[j].hashCode())
        {
          i = i * 31 + k;
          j += 1;
          break;
        }
      }
    }
    
    public Resource mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        int j;
        Object localObject;
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 10: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 10);
          i = key.length;
          localObject = new String[i + j];
          System.arraycopy(key, 0, localObject, 0, i);
          key = ((String[])localObject);
          while (i < key.length - 1)
          {
            key[i] = paramCodedInputByteBufferNano.readString();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          key[i] = paramCodedInputByteBufferNano.readString();
          break;
        case 18: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 18);
          if (value == null) {}
          for (i = 0;; i = value.length)
          {
            localObject = new TypeSystem.Value[i + j];
            if (value != null) {
              System.arraycopy(value, 0, localObject, 0, i);
            }
            value = ((TypeSystem.Value[])localObject);
            while (i < value.length - 1)
            {
              value[i] = new TypeSystem.Value();
              paramCodedInputByteBufferNano.readMessage(value[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          value[i] = new TypeSystem.Value();
          paramCodedInputByteBufferNano.readMessage(value[i]);
          break;
        case 26: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 26);
          if (property == null) {}
          for (i = 0;; i = property.length)
          {
            localObject = new Serving.Property[i + j];
            if (property != null) {
              System.arraycopy(property, 0, localObject, 0, i);
            }
            property = ((Serving.Property[])localObject);
            while (i < property.length - 1)
            {
              property[i] = new Serving.Property();
              paramCodedInputByteBufferNano.readMessage(property[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          property[i] = new Serving.Property();
          paramCodedInputByteBufferNano.readMessage(property[i]);
          break;
        case 34: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 34);
          if (macro == null) {}
          for (i = 0;; i = macro.length)
          {
            localObject = new Serving.FunctionCall[i + j];
            if (macro != null) {
              System.arraycopy(macro, 0, localObject, 0, i);
            }
            macro = ((Serving.FunctionCall[])localObject);
            while (i < macro.length - 1)
            {
              macro[i] = new Serving.FunctionCall();
              paramCodedInputByteBufferNano.readMessage(macro[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          macro[i] = new Serving.FunctionCall();
          paramCodedInputByteBufferNano.readMessage(macro[i]);
          break;
        case 42: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 42);
          if (tag == null) {}
          for (i = 0;; i = tag.length)
          {
            localObject = new Serving.FunctionCall[i + j];
            if (tag != null) {
              System.arraycopy(tag, 0, localObject, 0, i);
            }
            tag = ((Serving.FunctionCall[])localObject);
            while (i < tag.length - 1)
            {
              tag[i] = new Serving.FunctionCall();
              paramCodedInputByteBufferNano.readMessage(tag[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          tag[i] = new Serving.FunctionCall();
          paramCodedInputByteBufferNano.readMessage(tag[i]);
          break;
        case 50: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 50);
          if (predicate == null) {}
          for (i = 0;; i = predicate.length)
          {
            localObject = new Serving.FunctionCall[i + j];
            if (predicate != null) {
              System.arraycopy(predicate, 0, localObject, 0, i);
            }
            predicate = ((Serving.FunctionCall[])localObject);
            while (i < predicate.length - 1)
            {
              predicate[i] = new Serving.FunctionCall();
              paramCodedInputByteBufferNano.readMessage(predicate[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          predicate[i] = new Serving.FunctionCall();
          paramCodedInputByteBufferNano.readMessage(predicate[i]);
          break;
        case 58: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 58);
          if (rule == null) {}
          for (i = 0;; i = rule.length)
          {
            localObject = new Serving.Rule[i + j];
            if (rule != null) {
              System.arraycopy(rule, 0, localObject, 0, i);
            }
            rule = ((Serving.Rule[])localObject);
            while (i < rule.length - 1)
            {
              rule[i] = new Serving.Rule();
              paramCodedInputByteBufferNano.readMessage(rule[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          rule[i] = new Serving.Rule();
          paramCodedInputByteBufferNano.readMessage(rule[i]);
          break;
        case 74: 
          previewAuthCode = paramCodedInputByteBufferNano.readString();
          break;
        case 82: 
          malwareScanAuthCode = paramCodedInputByteBufferNano.readString();
          break;
        case 98: 
          templateVersionSet = paramCodedInputByteBufferNano.readString();
          break;
        case 106: 
          version = paramCodedInputByteBufferNano.readString();
          break;
        case 114: 
          liveJsCacheOption = new Serving.CacheOption();
          paramCodedInputByteBufferNano.readMessage(liveJsCacheOption);
          break;
        case 125: 
          reportingSampleRate = paramCodedInputByteBufferNano.readFloat();
          break;
        case 130: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 130);
          i = usageContext.length;
          localObject = new String[i + j];
          System.arraycopy(usageContext, 0, localObject, 0, i);
          usageContext = ((String[])localObject);
          while (i < usageContext.length - 1)
          {
            usageContext[i] = paramCodedInputByteBufferNano.readString();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          usageContext[i] = paramCodedInputByteBufferNano.readString();
          break;
        case 136: 
          resourceFormatVersion = paramCodedInputByteBufferNano.readInt32();
          break;
        case 144: 
          oBSOLETEEnableAutoEventTracking = paramCodedInputByteBufferNano.readBool();
          break;
        case 154: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 154);
          i = supplemental.length;
          localObject = new String[i + j];
          System.arraycopy(supplemental, 0, localObject, 0, i);
          supplemental = ((String[])localObject);
          while (i < supplemental.length - 1)
          {
            supplemental[i] = paramCodedInputByteBufferNano.readString();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          supplemental[i] = paramCodedInputByteBufferNano.readString();
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      Object localObject;
      int j;
      int i;
      if (key != null)
      {
        localObject = key;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeString(1, localObject[i]);
          i += 1;
        }
      }
      if (value != null)
      {
        localObject = value;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(2, localObject[i]);
          i += 1;
        }
      }
      if (property != null)
      {
        localObject = property;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(3, localObject[i]);
          i += 1;
        }
      }
      if (macro != null)
      {
        localObject = macro;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(4, localObject[i]);
          i += 1;
        }
      }
      if (tag != null)
      {
        localObject = tag;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(5, localObject[i]);
          i += 1;
        }
      }
      if (predicate != null)
      {
        localObject = predicate;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(6, localObject[i]);
          i += 1;
        }
      }
      if (rule != null)
      {
        localObject = rule;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(7, localObject[i]);
          i += 1;
        }
      }
      if (!previewAuthCode.equals("")) {
        paramCodedOutputByteBufferNano.writeString(9, previewAuthCode);
      }
      if (!malwareScanAuthCode.equals("")) {
        paramCodedOutputByteBufferNano.writeString(10, malwareScanAuthCode);
      }
      if (!templateVersionSet.equals("0")) {
        paramCodedOutputByteBufferNano.writeString(12, templateVersionSet);
      }
      if (!version.equals("")) {
        paramCodedOutputByteBufferNano.writeString(13, version);
      }
      if (liveJsCacheOption != null) {
        paramCodedOutputByteBufferNano.writeMessage(14, liveJsCacheOption);
      }
      if (reportingSampleRate != 0.0F) {
        paramCodedOutputByteBufferNano.writeFloat(15, reportingSampleRate);
      }
      if (usageContext != null)
      {
        localObject = usageContext;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeString(16, localObject[i]);
          i += 1;
        }
      }
      if (resourceFormatVersion != 0) {
        paramCodedOutputByteBufferNano.writeInt32(17, resourceFormatVersion);
      }
      if (oBSOLETEEnableAutoEventTracking) {
        paramCodedOutputByteBufferNano.writeBool(18, oBSOLETEEnableAutoEventTracking);
      }
      if (supplemental != null)
      {
        localObject = supplemental;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeString(19, localObject[i]);
          i += 1;
        }
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static abstract interface ResourceState
  {
    public static final int LIVE = 2;
    public static final int PREVIEW = 1;
  }
  
  public static abstract interface ResourceType
  {
    public static final int CLEAR_CACHE = 6;
    public static final int GET_COOKIE = 5;
    public static final int JS_RESOURCE = 1;
    public static final int NS_RESOURCE = 2;
    public static final int PIXEL_COLLECTION = 3;
    public static final int RAW_PROTO = 7;
    public static final int SET_COOKIE = 4;
  }
  
  public static final class Rule
    extends ExtendableMessageNano
  {
    public static final Rule[] EMPTY_ARRAY = new Rule[0];
    public int[] addMacro = WireFormatNano.EMPTY_INT_ARRAY;
    public int[] addMacroRuleName = WireFormatNano.EMPTY_INT_ARRAY;
    public int[] addTag = WireFormatNano.EMPTY_INT_ARRAY;
    public int[] addTagRuleName = WireFormatNano.EMPTY_INT_ARRAY;
    public int[] negativePredicate = WireFormatNano.EMPTY_INT_ARRAY;
    public int[] positivePredicate = WireFormatNano.EMPTY_INT_ARRAY;
    public int[] removeMacro = WireFormatNano.EMPTY_INT_ARRAY;
    public int[] removeMacroRuleName = WireFormatNano.EMPTY_INT_ARRAY;
    public int[] removeTag = WireFormatNano.EMPTY_INT_ARRAY;
    public int[] removeTagRuleName = WireFormatNano.EMPTY_INT_ARRAY;
    
    public Rule() {}
    
    public static Rule parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new Rule().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static Rule parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (Rule)MessageNano.mergeFrom(new Rule(), paramArrayOfByte);
    }
    
    public final Rule clear()
    {
      positivePredicate = WireFormatNano.EMPTY_INT_ARRAY;
      negativePredicate = WireFormatNano.EMPTY_INT_ARRAY;
      addTag = WireFormatNano.EMPTY_INT_ARRAY;
      removeTag = WireFormatNano.EMPTY_INT_ARRAY;
      addTagRuleName = WireFormatNano.EMPTY_INT_ARRAY;
      removeTagRuleName = WireFormatNano.EMPTY_INT_ARRAY;
      addMacro = WireFormatNano.EMPTY_INT_ARRAY;
      removeMacro = WireFormatNano.EMPTY_INT_ARRAY;
      addMacroRuleName = WireFormatNano.EMPTY_INT_ARRAY;
      removeMacroRuleName = WireFormatNano.EMPTY_INT_ARRAY;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof Rule)) {
        return false;
      }
      paramObject = (Rule)paramObject;
      if ((Arrays.equals(positivePredicate, positivePredicate)) && (Arrays.equals(negativePredicate, negativePredicate)) && (Arrays.equals(addTag, addTag)) && (Arrays.equals(removeTag, removeTag)) && (Arrays.equals(addTagRuleName, addTagRuleName)) && (Arrays.equals(removeTagRuleName, removeTagRuleName)) && (Arrays.equals(addMacro, addMacro)) && (Arrays.equals(removeMacro, removeMacro)) && (Arrays.equals(addMacroRuleName, addMacroRuleName)) && (Arrays.equals(removeMacroRuleName, removeMacroRuleName)))
      {
        if (unknownFieldData != null) {
          break label177;
        }
        if (unknownFieldData == null) {
          break label193;
        }
      }
      label177:
      while (!unknownFieldData.equals(unknownFieldData)) {
        return false;
      }
      label193:
      return true;
    }
    
    public int getSerializedSize()
    {
      int j = 0;
      int i = j;
      int[] arrayOfInt;
      int k;
      if (positivePredicate != null)
      {
        i = j;
        if (positivePredicate.length > 0)
        {
          j = 0;
          arrayOfInt = positivePredicate;
          k = arrayOfInt.length;
          i = 0;
          while (i < k)
          {
            j += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[i]);
            i += 1;
          }
          i = 0 + j + positivePredicate.length * 1;
        }
      }
      j = i;
      int m;
      if (negativePredicate != null)
      {
        j = i;
        if (negativePredicate.length > 0)
        {
          k = 0;
          arrayOfInt = negativePredicate;
          m = arrayOfInt.length;
          j = 0;
          while (j < m)
          {
            k += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[j]);
            j += 1;
          }
          j = i + k + negativePredicate.length * 1;
        }
      }
      i = j;
      if (addTag != null)
      {
        i = j;
        if (addTag.length > 0)
        {
          k = 0;
          arrayOfInt = addTag;
          m = arrayOfInt.length;
          i = 0;
          while (i < m)
          {
            k += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[i]);
            i += 1;
          }
          i = j + k + addTag.length * 1;
        }
      }
      j = i;
      if (removeTag != null)
      {
        j = i;
        if (removeTag.length > 0)
        {
          k = 0;
          arrayOfInt = removeTag;
          m = arrayOfInt.length;
          j = 0;
          while (j < m)
          {
            k += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[j]);
            j += 1;
          }
          j = i + k + removeTag.length * 1;
        }
      }
      i = j;
      if (addTagRuleName != null)
      {
        i = j;
        if (addTagRuleName.length > 0)
        {
          k = 0;
          arrayOfInt = addTagRuleName;
          m = arrayOfInt.length;
          i = 0;
          while (i < m)
          {
            k += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[i]);
            i += 1;
          }
          i = j + k + addTagRuleName.length * 1;
        }
      }
      j = i;
      if (removeTagRuleName != null)
      {
        j = i;
        if (removeTagRuleName.length > 0)
        {
          k = 0;
          arrayOfInt = removeTagRuleName;
          m = arrayOfInt.length;
          j = 0;
          while (j < m)
          {
            k += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[j]);
            j += 1;
          }
          j = i + k + removeTagRuleName.length * 1;
        }
      }
      i = j;
      if (addMacro != null)
      {
        i = j;
        if (addMacro.length > 0)
        {
          k = 0;
          arrayOfInt = addMacro;
          m = arrayOfInt.length;
          i = 0;
          while (i < m)
          {
            k += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[i]);
            i += 1;
          }
          i = j + k + addMacro.length * 1;
        }
      }
      j = i;
      if (removeMacro != null)
      {
        j = i;
        if (removeMacro.length > 0)
        {
          k = 0;
          arrayOfInt = removeMacro;
          m = arrayOfInt.length;
          j = 0;
          while (j < m)
          {
            k += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[j]);
            j += 1;
          }
          j = i + k + removeMacro.length * 1;
        }
      }
      i = j;
      if (addMacroRuleName != null)
      {
        i = j;
        if (addMacroRuleName.length > 0)
        {
          k = 0;
          arrayOfInt = addMacroRuleName;
          m = arrayOfInt.length;
          i = 0;
          while (i < m)
          {
            k += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[i]);
            i += 1;
          }
          i = j + k + addMacroRuleName.length * 1;
        }
      }
      j = i;
      if (removeMacroRuleName != null)
      {
        j = i;
        if (removeMacroRuleName.length > 0)
        {
          k = 0;
          arrayOfInt = removeMacroRuleName;
          m = arrayOfInt.length;
          j = 0;
          while (j < m)
          {
            k += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[j]);
            j += 1;
          }
          j = i + k + removeMacroRuleName.length * 1;
        }
      }
      i = j + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int j = 17;
      if (positivePredicate == null)
      {
        i = 17 * 31;
        if (negativePredicate != null) {
          break label172;
        }
        i *= 31;
        if (addTag != null) {
          break label206;
        }
        i *= 31;
        if (removeTag != null) {
          break label240;
        }
        i *= 31;
        if (addTagRuleName != null) {
          break label274;
        }
        i *= 31;
        if (removeTagRuleName != null) {
          break label308;
        }
        i *= 31;
        if (addMacro != null) {
          break label342;
        }
        i *= 31;
        if (removeMacro != null) {
          break label376;
        }
        i *= 31;
        if (addMacroRuleName != null) {
          break label410;
        }
        i *= 31;
        if (removeMacroRuleName != null) {
          break label444;
        }
        j = i * 31;
        if (unknownFieldData != null) {
          break label476;
        }
      }
      label172:
      label206:
      label240:
      label274:
      label308:
      label342:
      label376:
      label410:
      label444:
      label476:
      for (int i = 0;; i = unknownFieldData.hashCode())
      {
        return j * 31 + i;
        int k = 0;
        for (;;)
        {
          i = j;
          if (k >= positivePredicate.length) {
            break;
          }
          j = j * 31 + positivePredicate[k];
          k += 1;
        }
        k = 0;
        j = i;
        for (;;)
        {
          i = j;
          if (k >= negativePredicate.length) {
            break;
          }
          j = j * 31 + negativePredicate[k];
          k += 1;
        }
        k = 0;
        j = i;
        for (;;)
        {
          i = j;
          if (k >= addTag.length) {
            break;
          }
          j = j * 31 + addTag[k];
          k += 1;
        }
        k = 0;
        j = i;
        for (;;)
        {
          i = j;
          if (k >= removeTag.length) {
            break;
          }
          j = j * 31 + removeTag[k];
          k += 1;
        }
        k = 0;
        j = i;
        for (;;)
        {
          i = j;
          if (k >= addTagRuleName.length) {
            break;
          }
          j = j * 31 + addTagRuleName[k];
          k += 1;
        }
        k = 0;
        j = i;
        for (;;)
        {
          i = j;
          if (k >= removeTagRuleName.length) {
            break;
          }
          j = j * 31 + removeTagRuleName[k];
          k += 1;
        }
        k = 0;
        j = i;
        for (;;)
        {
          i = j;
          if (k >= addMacro.length) {
            break;
          }
          j = j * 31 + addMacro[k];
          k += 1;
        }
        k = 0;
        j = i;
        for (;;)
        {
          i = j;
          if (k >= removeMacro.length) {
            break;
          }
          j = j * 31 + removeMacro[k];
          k += 1;
        }
        k = 0;
        j = i;
        for (;;)
        {
          i = j;
          if (k >= addMacroRuleName.length) {
            break;
          }
          j = j * 31 + addMacroRuleName[k];
          k += 1;
        }
        k = 0;
        for (;;)
        {
          j = i;
          if (k >= removeMacroRuleName.length) {
            break;
          }
          i = i * 31 + removeMacroRuleName[k];
          k += 1;
        }
      }
    }
    
    public Rule mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        int j;
        int[] arrayOfInt;
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 8: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 8);
          i = positivePredicate.length;
          arrayOfInt = new int[i + j];
          System.arraycopy(positivePredicate, 0, arrayOfInt, 0, i);
          positivePredicate = arrayOfInt;
          while (i < positivePredicate.length - 1)
          {
            positivePredicate[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          positivePredicate[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 16: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 16);
          i = negativePredicate.length;
          arrayOfInt = new int[i + j];
          System.arraycopy(negativePredicate, 0, arrayOfInt, 0, i);
          negativePredicate = arrayOfInt;
          while (i < negativePredicate.length - 1)
          {
            negativePredicate[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          negativePredicate[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 24: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 24);
          i = addTag.length;
          arrayOfInt = new int[i + j];
          System.arraycopy(addTag, 0, arrayOfInt, 0, i);
          addTag = arrayOfInt;
          while (i < addTag.length - 1)
          {
            addTag[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          addTag[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 32: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 32);
          i = removeTag.length;
          arrayOfInt = new int[i + j];
          System.arraycopy(removeTag, 0, arrayOfInt, 0, i);
          removeTag = arrayOfInt;
          while (i < removeTag.length - 1)
          {
            removeTag[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          removeTag[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 40: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 40);
          i = addTagRuleName.length;
          arrayOfInt = new int[i + j];
          System.arraycopy(addTagRuleName, 0, arrayOfInt, 0, i);
          addTagRuleName = arrayOfInt;
          while (i < addTagRuleName.length - 1)
          {
            addTagRuleName[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          addTagRuleName[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 48: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 48);
          i = removeTagRuleName.length;
          arrayOfInt = new int[i + j];
          System.arraycopy(removeTagRuleName, 0, arrayOfInt, 0, i);
          removeTagRuleName = arrayOfInt;
          while (i < removeTagRuleName.length - 1)
          {
            removeTagRuleName[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          removeTagRuleName[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 56: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 56);
          i = addMacro.length;
          arrayOfInt = new int[i + j];
          System.arraycopy(addMacro, 0, arrayOfInt, 0, i);
          addMacro = arrayOfInt;
          while (i < addMacro.length - 1)
          {
            addMacro[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          addMacro[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 64: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 64);
          i = removeMacro.length;
          arrayOfInt = new int[i + j];
          System.arraycopy(removeMacro, 0, arrayOfInt, 0, i);
          removeMacro = arrayOfInt;
          while (i < removeMacro.length - 1)
          {
            removeMacro[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          removeMacro[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 72: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 72);
          i = addMacroRuleName.length;
          arrayOfInt = new int[i + j];
          System.arraycopy(addMacroRuleName, 0, arrayOfInt, 0, i);
          addMacroRuleName = arrayOfInt;
          while (i < addMacroRuleName.length - 1)
          {
            addMacroRuleName[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          addMacroRuleName[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 80: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 80);
          i = removeMacroRuleName.length;
          arrayOfInt = new int[i + j];
          System.arraycopy(removeMacroRuleName, 0, arrayOfInt, 0, i);
          removeMacroRuleName = arrayOfInt;
          while (i < removeMacroRuleName.length - 1)
          {
            removeMacroRuleName[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          removeMacroRuleName[i] = paramCodedInputByteBufferNano.readInt32();
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      int[] arrayOfInt;
      int j;
      int i;
      if (positivePredicate != null)
      {
        arrayOfInt = positivePredicate;
        j = arrayOfInt.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(1, arrayOfInt[i]);
          i += 1;
        }
      }
      if (negativePredicate != null)
      {
        arrayOfInt = negativePredicate;
        j = arrayOfInt.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(2, arrayOfInt[i]);
          i += 1;
        }
      }
      if (addTag != null)
      {
        arrayOfInt = addTag;
        j = arrayOfInt.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(3, arrayOfInt[i]);
          i += 1;
        }
      }
      if (removeTag != null)
      {
        arrayOfInt = removeTag;
        j = arrayOfInt.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(4, arrayOfInt[i]);
          i += 1;
        }
      }
      if (addTagRuleName != null)
      {
        arrayOfInt = addTagRuleName;
        j = arrayOfInt.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(5, arrayOfInt[i]);
          i += 1;
        }
      }
      if (removeTagRuleName != null)
      {
        arrayOfInt = removeTagRuleName;
        j = arrayOfInt.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(6, arrayOfInt[i]);
          i += 1;
        }
      }
      if (addMacro != null)
      {
        arrayOfInt = addMacro;
        j = arrayOfInt.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(7, arrayOfInt[i]);
          i += 1;
        }
      }
      if (removeMacro != null)
      {
        arrayOfInt = removeMacro;
        j = arrayOfInt.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(8, arrayOfInt[i]);
          i += 1;
        }
      }
      if (addMacroRuleName != null)
      {
        arrayOfInt = addMacroRuleName;
        j = arrayOfInt.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(9, arrayOfInt[i]);
          i += 1;
        }
      }
      if (removeMacroRuleName != null)
      {
        arrayOfInt = removeMacroRuleName;
        j = arrayOfInt.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(10, arrayOfInt[i]);
          i += 1;
        }
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static final class ServingValue
    extends ExtendableMessageNano
  {
    public static final ServingValue[] EMPTY_ARRAY = new ServingValue[0];
    public static final Extension<ServingValue> ext = Extension.create(101, new Extension.TypeLiteral() {});
    public int[] listItem = WireFormatNano.EMPTY_INT_ARRAY;
    public int macroNameReference = 0;
    public int macroReference = 0;
    public int[] mapKey = WireFormatNano.EMPTY_INT_ARRAY;
    public int[] mapValue = WireFormatNano.EMPTY_INT_ARRAY;
    public int tagReference = 0;
    public int[] templateToken = WireFormatNano.EMPTY_INT_ARRAY;
    
    public ServingValue() {}
    
    public static ServingValue parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new ServingValue().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static ServingValue parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (ServingValue)MessageNano.mergeFrom(new ServingValue(), paramArrayOfByte);
    }
    
    public final ServingValue clear()
    {
      listItem = WireFormatNano.EMPTY_INT_ARRAY;
      mapKey = WireFormatNano.EMPTY_INT_ARRAY;
      mapValue = WireFormatNano.EMPTY_INT_ARRAY;
      macroReference = 0;
      templateToken = WireFormatNano.EMPTY_INT_ARRAY;
      macroNameReference = 0;
      tagReference = 0;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof ServingValue)) {
        return false;
      }
      paramObject = (ServingValue)paramObject;
      if ((Arrays.equals(listItem, listItem)) && (Arrays.equals(mapKey, mapKey)) && (Arrays.equals(mapValue, mapValue)) && (macroReference == macroReference) && (Arrays.equals(templateToken, templateToken)) && (macroNameReference == macroNameReference) && (tagReference == tagReference))
      {
        if (unknownFieldData != null) {
          break label126;
        }
        if (unknownFieldData == null) {
          break label142;
        }
      }
      label126:
      while (!unknownFieldData.equals(unknownFieldData)) {
        return false;
      }
      label142:
      return true;
    }
    
    public int getSerializedSize()
    {
      int j = 0;
      int i = j;
      int[] arrayOfInt;
      if (listItem != null)
      {
        i = j;
        if (listItem.length > 0)
        {
          j = 0;
          arrayOfInt = listItem;
          k = arrayOfInt.length;
          i = 0;
          while (i < k)
          {
            j += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[i]);
            i += 1;
          }
          i = 0 + j + listItem.length * 1;
        }
      }
      j = i;
      int m;
      if (mapKey != null)
      {
        j = i;
        if (mapKey.length > 0)
        {
          k = 0;
          arrayOfInt = mapKey;
          m = arrayOfInt.length;
          j = 0;
          while (j < m)
          {
            k += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[j]);
            j += 1;
          }
          j = i + k + mapKey.length * 1;
        }
      }
      int k = j;
      if (mapValue != null)
      {
        k = j;
        if (mapValue.length > 0)
        {
          k = 0;
          arrayOfInt = mapValue;
          m = arrayOfInt.length;
          i = 0;
          while (i < m)
          {
            k += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[i]);
            i += 1;
          }
          k = j + k + mapValue.length * 1;
        }
      }
      i = k;
      if (macroReference != 0) {
        i = k + CodedOutputByteBufferNano.computeInt32Size(4, macroReference);
      }
      j = i;
      if (templateToken != null)
      {
        j = i;
        if (templateToken.length > 0)
        {
          k = 0;
          arrayOfInt = templateToken;
          m = arrayOfInt.length;
          j = 0;
          while (j < m)
          {
            k += CodedOutputByteBufferNano.computeInt32SizeNoTag(arrayOfInt[j]);
            j += 1;
          }
          j = i + k + templateToken.length * 1;
        }
      }
      i = j;
      if (macroNameReference != 0) {
        i = j + CodedOutputByteBufferNano.computeInt32Size(6, macroNameReference);
      }
      j = i;
      if (tagReference != 0) {
        j = i + CodedOutputByteBufferNano.computeInt32Size(7, tagReference);
      }
      i = j + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int j = 17;
      int k;
      int m;
      if (listItem == null)
      {
        i = 17 * 31;
        if (mapKey != null) {
          break label132;
        }
        i *= 31;
        if (mapValue != null) {
          break label166;
        }
        k = i * 31;
        i = k * 31 + macroReference;
        if (templateToken != null) {
          break label198;
        }
        j = i * 31;
        k = macroNameReference;
        m = tagReference;
        if (unknownFieldData != null) {
          break label230;
        }
      }
      label132:
      label166:
      label198:
      label230:
      for (int i = 0;; i = unknownFieldData.hashCode())
      {
        return ((j * 31 + k) * 31 + m) * 31 + i;
        k = 0;
        for (;;)
        {
          i = j;
          if (k >= listItem.length) {
            break;
          }
          j = j * 31 + listItem[k];
          k += 1;
        }
        k = 0;
        j = i;
        for (;;)
        {
          i = j;
          if (k >= mapKey.length) {
            break;
          }
          j = j * 31 + mapKey[k];
          k += 1;
        }
        j = 0;
        for (;;)
        {
          k = i;
          if (j >= mapValue.length) {
            break;
          }
          i = i * 31 + mapValue[j];
          j += 1;
        }
        k = 0;
        for (;;)
        {
          j = i;
          if (k >= templateToken.length) {
            break;
          }
          i = i * 31 + templateToken[k];
          k += 1;
        }
      }
    }
    
    public ServingValue mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        int j;
        int[] arrayOfInt;
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 8: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 8);
          i = listItem.length;
          arrayOfInt = new int[i + j];
          System.arraycopy(listItem, 0, arrayOfInt, 0, i);
          listItem = arrayOfInt;
          while (i < listItem.length - 1)
          {
            listItem[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          listItem[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 16: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 16);
          i = mapKey.length;
          arrayOfInt = new int[i + j];
          System.arraycopy(mapKey, 0, arrayOfInt, 0, i);
          mapKey = arrayOfInt;
          while (i < mapKey.length - 1)
          {
            mapKey[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          mapKey[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 24: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 24);
          i = mapValue.length;
          arrayOfInt = new int[i + j];
          System.arraycopy(mapValue, 0, arrayOfInt, 0, i);
          mapValue = arrayOfInt;
          while (i < mapValue.length - 1)
          {
            mapValue[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          mapValue[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 32: 
          macroReference = paramCodedInputByteBufferNano.readInt32();
          break;
        case 40: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 40);
          i = templateToken.length;
          arrayOfInt = new int[i + j];
          System.arraycopy(templateToken, 0, arrayOfInt, 0, i);
          templateToken = arrayOfInt;
          while (i < templateToken.length - 1)
          {
            templateToken[i] = paramCodedInputByteBufferNano.readInt32();
            paramCodedInputByteBufferNano.readTag();
            i += 1;
          }
          templateToken[i] = paramCodedInputByteBufferNano.readInt32();
          break;
        case 48: 
          macroNameReference = paramCodedInputByteBufferNano.readInt32();
          break;
        case 56: 
          tagReference = paramCodedInputByteBufferNano.readInt32();
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      int[] arrayOfInt;
      int j;
      int i;
      if (listItem != null)
      {
        arrayOfInt = listItem;
        j = arrayOfInt.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(1, arrayOfInt[i]);
          i += 1;
        }
      }
      if (mapKey != null)
      {
        arrayOfInt = mapKey;
        j = arrayOfInt.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(2, arrayOfInt[i]);
          i += 1;
        }
      }
      if (mapValue != null)
      {
        arrayOfInt = mapValue;
        j = arrayOfInt.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(3, arrayOfInt[i]);
          i += 1;
        }
      }
      if (macroReference != 0) {
        paramCodedOutputByteBufferNano.writeInt32(4, macroReference);
      }
      if (templateToken != null)
      {
        arrayOfInt = templateToken;
        j = arrayOfInt.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeInt32(5, arrayOfInt[i]);
          i += 1;
        }
      }
      if (macroNameReference != 0) {
        paramCodedOutputByteBufferNano.writeInt32(6, macroNameReference);
      }
      if (tagReference != 0) {
        paramCodedOutputByteBufferNano.writeInt32(7, tagReference);
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static final class Supplemental
    extends ExtendableMessageNano
  {
    public static final Supplemental[] EMPTY_ARRAY = new Supplemental[0];
    public Serving.GaExperimentSupplemental experimentSupplemental = null;
    public String name = "";
    public TypeSystem.Value value = null;
    
    public Supplemental() {}
    
    public static Supplemental parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new Supplemental().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static Supplemental parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (Supplemental)MessageNano.mergeFrom(new Supplemental(), paramArrayOfByte);
    }
    
    public final Supplemental clear()
    {
      name = "";
      value = null;
      experimentSupplemental = null;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof Supplemental)) {
        return false;
      }
      paramObject = (Supplemental)paramObject;
      if (name == null) {
        if (name == null)
        {
          if (value != null) {
            break label96;
          }
          if (value == null)
          {
            label49:
            if (experimentSupplemental != null) {
              break label113;
            }
            if (experimentSupplemental == null)
            {
              label63:
              if (unknownFieldData != null) {
                break label130;
              }
              if (unknownFieldData == null) {
                break label146;
              }
            }
          }
        }
      }
      label96:
      label113:
      label130:
      while (!unknownFieldData.equals(unknownFieldData))
      {
        do
        {
          do
          {
            do
            {
              return false;
            } while (!name.equals(name));
            break;
          } while (!value.equals(value));
          break label49;
        } while (!experimentSupplemental.equals(experimentSupplemental));
        break label63;
      }
      label146:
      return true;
    }
    
    public int getSerializedSize()
    {
      int j = 0;
      if (!name.equals("")) {
        j = 0 + CodedOutputByteBufferNano.computeStringSize(1, name);
      }
      int i = j;
      if (value != null) {
        i = j + CodedOutputByteBufferNano.computeMessageSize(2, value);
      }
      j = i;
      if (experimentSupplemental != null) {
        j = i + CodedOutputByteBufferNano.computeMessageSize(3, experimentSupplemental);
      }
      i = j + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int m = 0;
      int i;
      int j;
      label21:
      int k;
      if (name == null)
      {
        i = 0;
        if (value != null) {
          break label70;
        }
        j = 0;
        if (experimentSupplemental != null) {
          break label81;
        }
        k = 0;
        label30:
        if (unknownFieldData != null) {
          break label92;
        }
      }
      for (;;)
      {
        return (((i + 527) * 31 + j) * 31 + k) * 31 + m;
        i = name.hashCode();
        break;
        label70:
        j = value.hashCode();
        break label21;
        label81:
        k = experimentSupplemental.hashCode();
        break label30;
        label92:
        m = unknownFieldData.hashCode();
      }
    }
    
    public Supplemental mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 10: 
          name = paramCodedInputByteBufferNano.readString();
          break;
        case 18: 
          value = new TypeSystem.Value();
          paramCodedInputByteBufferNano.readMessage(value);
          break;
        case 26: 
          experimentSupplemental = new Serving.GaExperimentSupplemental();
          paramCodedInputByteBufferNano.readMessage(experimentSupplemental);
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      if (!name.equals("")) {
        paramCodedOutputByteBufferNano.writeString(1, name);
      }
      if (value != null) {
        paramCodedOutputByteBufferNano.writeMessage(2, value);
      }
      if (experimentSupplemental != null) {
        paramCodedOutputByteBufferNano.writeMessage(3, experimentSupplemental);
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static final class SupplementedResource
    extends ExtendableMessageNano
  {
    public static final SupplementedResource[] EMPTY_ARRAY = new SupplementedResource[0];
    public String fingerprint = "";
    public Serving.Resource resource = null;
    public Serving.Supplemental[] supplemental = Serving.Supplemental.EMPTY_ARRAY;
    
    public SupplementedResource() {}
    
    public static SupplementedResource parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new SupplementedResource().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static SupplementedResource parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (SupplementedResource)MessageNano.mergeFrom(new SupplementedResource(), paramArrayOfByte);
    }
    
    public final SupplementedResource clear()
    {
      supplemental = Serving.Supplemental.EMPTY_ARRAY;
      resource = null;
      fingerprint = "";
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof SupplementedResource)) {
        return false;
      }
      paramObject = (SupplementedResource)paramObject;
      if (Arrays.equals(supplemental, supplemental))
      {
        if (resource != null) {
          break label79;
        }
        if (resource == null)
        {
          if (fingerprint != null) {
            break label96;
          }
          if (fingerprint == null)
          {
            label63:
            if (unknownFieldData != null) {
              break label113;
            }
            if (unknownFieldData == null) {
              break label129;
            }
          }
        }
      }
      label79:
      label96:
      label113:
      while (!unknownFieldData.equals(unknownFieldData))
      {
        do
        {
          do
          {
            return false;
          } while (!resource.equals(resource));
          break;
        } while (!fingerprint.equals(fingerprint));
        break label63;
      }
      label129:
      return true;
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      int j = 0;
      if (supplemental != null)
      {
        Serving.Supplemental[] arrayOfSupplemental = supplemental;
        int m = arrayOfSupplemental.length;
        int k = 0;
        for (;;)
        {
          i = j;
          if (k >= m) {
            break;
          }
          j += CodedOutputByteBufferNano.computeMessageSize(1, arrayOfSupplemental[k]);
          k += 1;
        }
      }
      j = i;
      if (resource != null) {
        j = i + CodedOutputByteBufferNano.computeMessageSize(2, resource);
      }
      i = j;
      if (!fingerprint.equals("")) {
        i = j + CodedOutputByteBufferNano.computeStringSize(3, fingerprint);
      }
      i += WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int m = 0;
      int i = 17;
      int j;
      label28:
      int k;
      if (supplemental == null)
      {
        j = 17 * 31;
        if (resource != null) {
          break label113;
        }
        i = 0;
        if (fingerprint != null) {
          break label124;
        }
        k = 0;
        label37:
        if (unknownFieldData != null) {
          break label135;
        }
      }
      for (;;)
      {
        return ((j * 31 + i) * 31 + k) * 31 + m;
        k = 0;
        j = i;
        if (k >= supplemental.length) {
          break;
        }
        if (supplemental[k] == null) {}
        for (j = 0;; j = supplemental[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        label113:
        i = resource.hashCode();
        break label28;
        label124:
        k = fingerprint.hashCode();
        break label37;
        label135:
        m = unknownFieldData.hashCode();
      }
    }
    
    public SupplementedResource mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 10: 
          int j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 10);
          if (supplemental == null) {}
          for (i = 0;; i = supplemental.length)
          {
            Serving.Supplemental[] arrayOfSupplemental = new Serving.Supplemental[i + j];
            if (supplemental != null) {
              System.arraycopy(supplemental, 0, arrayOfSupplemental, 0, i);
            }
            supplemental = arrayOfSupplemental;
            while (i < supplemental.length - 1)
            {
              supplemental[i] = new Serving.Supplemental();
              paramCodedInputByteBufferNano.readMessage(supplemental[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          supplemental[i] = new Serving.Supplemental();
          paramCodedInputByteBufferNano.readMessage(supplemental[i]);
          break;
        case 18: 
          resource = new Serving.Resource();
          paramCodedInputByteBufferNano.readMessage(resource);
          break;
        case 26: 
          fingerprint = paramCodedInputByteBufferNano.readString();
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      if (supplemental != null)
      {
        Serving.Supplemental[] arrayOfSupplemental = supplemental;
        int j = arrayOfSupplemental.length;
        int i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(1, arrayOfSupplemental[i]);
          i += 1;
        }
      }
      if (resource != null) {
        paramCodedOutputByteBufferNano.writeMessage(2, resource);
      }
      if (!fingerprint.equals("")) {
        paramCodedOutputByteBufferNano.writeString(3, fingerprint);
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
}
