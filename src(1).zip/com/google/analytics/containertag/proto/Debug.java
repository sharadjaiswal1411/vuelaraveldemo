package com.google.analytics.containertag.proto;

import com.google.analytics.midtier.proto.containertag.TypeSystem.Value;
import com.google.tagmanager.protobuf.nano.CodedInputByteBufferNano;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import com.google.tagmanager.protobuf.nano.ExtendableMessageNano;
import com.google.tagmanager.protobuf.nano.Extension;
import com.google.tagmanager.protobuf.nano.Extension.TypeLiteral;
import com.google.tagmanager.protobuf.nano.InvalidProtocolBufferNanoException;
import com.google.tagmanager.protobuf.nano.MessageNano;
import com.google.tagmanager.protobuf.nano.WireFormatNano;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public abstract interface Debug
{
  public static final class DataLayerEventEvaluationInfo
    extends ExtendableMessageNano
  {
    public static final DataLayerEventEvaluationInfo[] EMPTY_ARRAY = new DataLayerEventEvaluationInfo[0];
    public Debug.ResolvedFunctionCall[] results = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
    public Debug.RuleEvaluationStepInfo rulesEvaluation = null;
    
    public DataLayerEventEvaluationInfo() {}
    
    public static DataLayerEventEvaluationInfo parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new DataLayerEventEvaluationInfo().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static DataLayerEventEvaluationInfo parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (DataLayerEventEvaluationInfo)MessageNano.mergeFrom(new DataLayerEventEvaluationInfo(), paramArrayOfByte);
    }
    
    public final DataLayerEventEvaluationInfo clear()
    {
      rulesEvaluation = null;
      results = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof DataLayerEventEvaluationInfo)) {
        return false;
      }
      paramObject = (DataLayerEventEvaluationInfo)paramObject;
      if (rulesEvaluation == null) {
        if (rulesEvaluation == null) {
          if (Arrays.equals(results, results))
          {
            if (unknownFieldData != null) {
              break label82;
            }
            if (unknownFieldData == null) {
              break label98;
            }
          }
        }
      }
      label82:
      while (!unknownFieldData.equals(unknownFieldData))
      {
        do
        {
          return false;
        } while (!rulesEvaluation.equals(rulesEvaluation));
        break;
      }
      label98:
      return true;
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      if (rulesEvaluation != null) {
        i = 0 + CodedOutputByteBufferNano.computeMessageSize(1, rulesEvaluation);
      }
      int k = i;
      if (results != null)
      {
        Debug.ResolvedFunctionCall[] arrayOfResolvedFunctionCall = results;
        int m = arrayOfResolvedFunctionCall.length;
        int j = 0;
        for (;;)
        {
          k = i;
          if (j >= m) {
            break;
          }
          i += CodedOutputByteBufferNano.computeMessageSize(2, arrayOfResolvedFunctionCall[j]);
          j += 1;
        }
      }
      i = k + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int m = 0;
      int k;
      if (rulesEvaluation == null)
      {
        i = 0;
        i += 527;
        if (results != null) {
          break label58;
        }
        k = i * 31;
        label30:
        if (unknownFieldData != null) {
          break label109;
        }
      }
      label58:
      label109:
      for (int i = m;; i = unknownFieldData.hashCode())
      {
        return k * 31 + i;
        i = rulesEvaluation.hashCode();
        break;
        int j = 0;
        k = i;
        if (j >= results.length) {
          break label30;
        }
        if (results[j] == null) {}
        for (k = 0;; k = results[j].hashCode())
        {
          i = i * 31 + k;
          j += 1;
          break;
        }
      }
    }
    
    public DataLayerEventEvaluationInfo mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 10: 
          rulesEvaluation = new Debug.RuleEvaluationStepInfo();
          paramCodedInputByteBufferNano.readMessage(rulesEvaluation);
          break;
        case 18: 
          int j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 18);
          if (results == null) {}
          for (i = 0;; i = results.length)
          {
            Debug.ResolvedFunctionCall[] arrayOfResolvedFunctionCall = new Debug.ResolvedFunctionCall[i + j];
            if (results != null) {
              System.arraycopy(results, 0, arrayOfResolvedFunctionCall, 0, i);
            }
            results = arrayOfResolvedFunctionCall;
            while (i < results.length - 1)
            {
              results[i] = new Debug.ResolvedFunctionCall();
              paramCodedInputByteBufferNano.readMessage(results[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          results[i] = new Debug.ResolvedFunctionCall();
          paramCodedInputByteBufferNano.readMessage(results[i]);
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      if (rulesEvaluation != null) {
        paramCodedOutputByteBufferNano.writeMessage(1, rulesEvaluation);
      }
      if (results != null)
      {
        Debug.ResolvedFunctionCall[] arrayOfResolvedFunctionCall = results;
        int j = arrayOfResolvedFunctionCall.length;
        int i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(2, arrayOfResolvedFunctionCall[i]);
          i += 1;
        }
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static final class DebugEvents
    extends ExtendableMessageNano
  {
    public static final DebugEvents[] EMPTY_ARRAY = new DebugEvents[0];
    public Debug.EventInfo[] event = Debug.EventInfo.EMPTY_ARRAY;
    
    public DebugEvents() {}
    
    public static DebugEvents parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new DebugEvents().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static DebugEvents parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (DebugEvents)MessageNano.mergeFrom(new DebugEvents(), paramArrayOfByte);
    }
    
    public final DebugEvents clear()
    {
      event = Debug.EventInfo.EMPTY_ARRAY;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof DebugEvents)) {
        return false;
      }
      paramObject = (DebugEvents)paramObject;
      if (Arrays.equals(event, event))
      {
        if (unknownFieldData != null) {
          break label51;
        }
        if (unknownFieldData == null) {
          break label67;
        }
      }
      label51:
      while (!unknownFieldData.equals(unknownFieldData)) {
        return false;
      }
      label67:
      return true;
    }
    
    public int getSerializedSize()
    {
      int k = 0;
      int i = 0;
      if (event != null)
      {
        Debug.EventInfo[] arrayOfEventInfo = event;
        int m = arrayOfEventInfo.length;
        int j = 0;
        for (;;)
        {
          k = i;
          if (j >= m) {
            break;
          }
          i += CodedOutputByteBufferNano.computeMessageSize(1, arrayOfEventInfo[j]);
          j += 1;
        }
      }
      i = k + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int m = 0;
      int i = 17;
      int k;
      if (event == null)
      {
        k = 17 * 31;
        if (unknownFieldData != null) {
          break label87;
        }
      }
      label87:
      for (i = m;; i = unknownFieldData.hashCode())
      {
        return k * 31 + i;
        int j = 0;
        k = i;
        if (j >= event.length) {
          break;
        }
        if (event[j] == null) {}
        for (k = 0;; k = event[j].hashCode())
        {
          i = i * 31 + k;
          j += 1;
          break;
        }
      }
    }
    
    public DebugEvents mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 10: 
          int j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 10);
          if (event == null) {}
          for (i = 0;; i = event.length)
          {
            Debug.EventInfo[] arrayOfEventInfo = new Debug.EventInfo[i + j];
            if (event != null) {
              System.arraycopy(event, 0, arrayOfEventInfo, 0, i);
            }
            event = arrayOfEventInfo;
            while (i < event.length - 1)
            {
              event[i] = new Debug.EventInfo();
              paramCodedInputByteBufferNano.readMessage(event[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          event[i] = new Debug.EventInfo();
          paramCodedInputByteBufferNano.readMessage(event[i]);
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      if (event != null)
      {
        Debug.EventInfo[] arrayOfEventInfo = event;
        int j = arrayOfEventInfo.length;
        int i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(1, arrayOfEventInfo[i]);
          i += 1;
        }
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static final class EventInfo
    extends ExtendableMessageNano
  {
    public static final EventInfo[] EMPTY_ARRAY = new EventInfo[0];
    public String containerId = "";
    public String containerVersion = "";
    public Debug.DataLayerEventEvaluationInfo dataLayerEventResult = null;
    public int eventType = 1;
    public String key = "";
    public Debug.MacroEvaluationInfo macroResult = null;
    
    public EventInfo() {}
    
    public static EventInfo parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new EventInfo().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static EventInfo parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (EventInfo)MessageNano.mergeFrom(new EventInfo(), paramArrayOfByte);
    }
    
    public final EventInfo clear()
    {
      eventType = 1;
      containerVersion = "";
      containerId = "";
      key = "";
      macroResult = null;
      dataLayerEventResult = null;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof EventInfo)) {
        return false;
      }
      paramObject = (EventInfo)paramObject;
      if (eventType == eventType)
      {
        if (containerVersion != null) {
          break label118;
        }
        if (containerVersion == null)
        {
          if (containerId != null) {
            break label135;
          }
          if (containerId == null)
          {
            label60:
            if (key != null) {
              break label152;
            }
            if (key == null)
            {
              label74:
              if (macroResult != null) {
                break label169;
              }
              if (macroResult == null)
              {
                label88:
                if (dataLayerEventResult != null) {
                  break label186;
                }
                if (dataLayerEventResult == null)
                {
                  label102:
                  if (unknownFieldData != null) {
                    break label203;
                  }
                  if (unknownFieldData == null) {
                    break label219;
                  }
                }
              }
            }
          }
        }
      }
      label118:
      label135:
      label152:
      label169:
      label186:
      label203:
      while (!unknownFieldData.equals(unknownFieldData))
      {
        do
        {
          do
          {
            do
            {
              do
              {
                do
                {
                  return false;
                } while (!containerVersion.equals(containerVersion));
                break;
              } while (!containerId.equals(containerId));
              break label60;
            } while (!key.equals(key));
            break label74;
          } while (!macroResult.equals(macroResult));
          break label88;
        } while (!dataLayerEventResult.equals(dataLayerEventResult));
        break label102;
      }
      label219:
      return true;
    }
    
    public int getSerializedSize()
    {
      int j = 0;
      if (eventType != 1) {
        j = 0 + CodedOutputByteBufferNano.computeInt32Size(1, eventType);
      }
      int i = j;
      if (!containerVersion.equals("")) {
        i = j + CodedOutputByteBufferNano.computeStringSize(2, containerVersion);
      }
      j = i;
      if (!containerId.equals("")) {
        j = i + CodedOutputByteBufferNano.computeStringSize(3, containerId);
      }
      i = j;
      if (!key.equals("")) {
        i = j + CodedOutputByteBufferNano.computeStringSize(4, key);
      }
      j = i;
      if (macroResult != null) {
        j = i + CodedOutputByteBufferNano.computeMessageSize(6, macroResult);
      }
      i = j;
      if (dataLayerEventResult != null) {
        i = j + CodedOutputByteBufferNano.computeMessageSize(7, dataLayerEventResult);
      }
      i += WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int i1 = 0;
      int i2 = eventType;
      int i;
      int j;
      label27:
      int k;
      label36:
      int m;
      label46:
      int n;
      if (containerVersion == null)
      {
        i = 0;
        if (containerId != null) {
          break label114;
        }
        j = 0;
        if (key != null) {
          break label125;
        }
        k = 0;
        if (macroResult != null) {
          break label136;
        }
        m = 0;
        if (dataLayerEventResult != null) {
          break label148;
        }
        n = 0;
        label56:
        if (unknownFieldData != null) {
          break label160;
        }
      }
      for (;;)
      {
        return ((((((i2 + 527) * 31 + i) * 31 + j) * 31 + k) * 31 + m) * 31 + n) * 31 + i1;
        i = containerVersion.hashCode();
        break;
        label114:
        j = containerId.hashCode();
        break label27;
        label125:
        k = key.hashCode();
        break label36;
        label136:
        m = macroResult.hashCode();
        break label46;
        label148:
        n = dataLayerEventResult.hashCode();
        break label56;
        label160:
        i1 = unknownFieldData.hashCode();
      }
    }
    
    public EventInfo mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 8: 
          i = paramCodedInputByteBufferNano.readInt32();
          if ((i == 1) || (i == 2)) {
            eventType = i;
          } else {
            eventType = 1;
          }
          break;
        case 18: 
          containerVersion = paramCodedInputByteBufferNano.readString();
          break;
        case 26: 
          containerId = paramCodedInputByteBufferNano.readString();
          break;
        case 34: 
          key = paramCodedInputByteBufferNano.readString();
          break;
        case 50: 
          macroResult = new Debug.MacroEvaluationInfo();
          paramCodedInputByteBufferNano.readMessage(macroResult);
          break;
        case 58: 
          dataLayerEventResult = new Debug.DataLayerEventEvaluationInfo();
          paramCodedInputByteBufferNano.readMessage(dataLayerEventResult);
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      if (eventType != 1) {
        paramCodedOutputByteBufferNano.writeInt32(1, eventType);
      }
      if (!containerVersion.equals("")) {
        paramCodedOutputByteBufferNano.writeString(2, containerVersion);
      }
      if (!containerId.equals("")) {
        paramCodedOutputByteBufferNano.writeString(3, containerId);
      }
      if (!key.equals("")) {
        paramCodedOutputByteBufferNano.writeString(4, key);
      }
      if (macroResult != null) {
        paramCodedOutputByteBufferNano.writeMessage(6, macroResult);
      }
      if (dataLayerEventResult != null) {
        paramCodedOutputByteBufferNano.writeMessage(7, dataLayerEventResult);
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
    
    public static abstract interface EventType
    {
      public static final int DATA_LAYER_EVENT = 1;
      public static final int MACRO_REFERENCE = 2;
    }
  }
  
  public static final class MacroEvaluationInfo
    extends ExtendableMessageNano
  {
    public static final MacroEvaluationInfo[] EMPTY_ARRAY = new MacroEvaluationInfo[0];
    public static final Extension<MacroEvaluationInfo> macro = Extension.create(47497405, new Extension.TypeLiteral() {});
    public Debug.ResolvedFunctionCall result = null;
    public Debug.RuleEvaluationStepInfo rulesEvaluation = null;
    
    public MacroEvaluationInfo() {}
    
    public static MacroEvaluationInfo parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new MacroEvaluationInfo().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static MacroEvaluationInfo parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (MacroEvaluationInfo)MessageNano.mergeFrom(new MacroEvaluationInfo(), paramArrayOfByte);
    }
    
    public final MacroEvaluationInfo clear()
    {
      rulesEvaluation = null;
      result = null;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof MacroEvaluationInfo)) {
        return false;
      }
      paramObject = (MacroEvaluationInfo)paramObject;
      if (rulesEvaluation == null) {
        if (rulesEvaluation == null)
        {
          if (result != null) {
            break label82;
          }
          if (result == null)
          {
            label49:
            if (unknownFieldData != null) {
              break label99;
            }
            if (unknownFieldData == null) {
              break label115;
            }
          }
        }
      }
      label82:
      label99:
      while (!unknownFieldData.equals(unknownFieldData))
      {
        do
        {
          do
          {
            return false;
          } while (!rulesEvaluation.equals(rulesEvaluation));
          break;
        } while (!result.equals(result));
        break label49;
      }
      label115:
      return true;
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      if (rulesEvaluation != null) {
        i = 0 + CodedOutputByteBufferNano.computeMessageSize(1, rulesEvaluation);
      }
      int j = i;
      if (result != null) {
        j = i + CodedOutputByteBufferNano.computeMessageSize(3, result);
      }
      i = j + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int k = 0;
      int i;
      int j;
      if (rulesEvaluation == null)
      {
        i = 0;
        if (result != null) {
          break label54;
        }
        j = 0;
        label20:
        if (unknownFieldData != null) {
          break label65;
        }
      }
      for (;;)
      {
        return ((i + 527) * 31 + j) * 31 + k;
        i = rulesEvaluation.hashCode();
        break;
        label54:
        j = result.hashCode();
        break label20;
        label65:
        k = unknownFieldData.hashCode();
      }
    }
    
    public MacroEvaluationInfo mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 10: 
          rulesEvaluation = new Debug.RuleEvaluationStepInfo();
          paramCodedInputByteBufferNano.readMessage(rulesEvaluation);
          break;
        case 26: 
          result = new Debug.ResolvedFunctionCall();
          paramCodedInputByteBufferNano.readMessage(result);
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      if (rulesEvaluation != null) {
        paramCodedOutputByteBufferNano.writeMessage(1, rulesEvaluation);
      }
      if (result != null) {
        paramCodedOutputByteBufferNano.writeMessage(3, result);
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static final class ResolvedFunctionCall
    extends ExtendableMessageNano
  {
    public static final ResolvedFunctionCall[] EMPTY_ARRAY = new ResolvedFunctionCall[0];
    public String associatedRuleName = "";
    public Debug.ResolvedProperty[] properties = Debug.ResolvedProperty.EMPTY_ARRAY;
    public TypeSystem.Value result = null;
    
    public ResolvedFunctionCall() {}
    
    public static ResolvedFunctionCall parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new ResolvedFunctionCall().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static ResolvedFunctionCall parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (ResolvedFunctionCall)MessageNano.mergeFrom(new ResolvedFunctionCall(), paramArrayOfByte);
    }
    
    public final ResolvedFunctionCall clear()
    {
      properties = Debug.ResolvedProperty.EMPTY_ARRAY;
      result = null;
      associatedRuleName = "";
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof ResolvedFunctionCall)) {
        return false;
      }
      paramObject = (ResolvedFunctionCall)paramObject;
      if (Arrays.equals(properties, properties))
      {
        if (result != null) {
          break label79;
        }
        if (result == null)
        {
          if (associatedRuleName != null) {
            break label96;
          }
          if (associatedRuleName == null)
          {
            label63:
            if (unknownFieldData != null) {
              break label113;
            }
            if (unknownFieldData == null) {
              break label129;
            }
          }
        }
      }
      label79:
      label96:
      label113:
      while (!unknownFieldData.equals(unknownFieldData))
      {
        do
        {
          do
          {
            return false;
          } while (!result.equals(result));
          break;
        } while (!associatedRuleName.equals(associatedRuleName));
        break label63;
      }
      label129:
      return true;
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      int j = 0;
      if (properties != null)
      {
        Debug.ResolvedProperty[] arrayOfResolvedProperty = properties;
        int m = arrayOfResolvedProperty.length;
        int k = 0;
        for (;;)
        {
          i = j;
          if (k >= m) {
            break;
          }
          j += CodedOutputByteBufferNano.computeMessageSize(1, arrayOfResolvedProperty[k]);
          k += 1;
        }
      }
      j = i;
      if (result != null) {
        j = i + CodedOutputByteBufferNano.computeMessageSize(2, result);
      }
      i = j;
      if (!associatedRuleName.equals("")) {
        i = j + CodedOutputByteBufferNano.computeStringSize(3, associatedRuleName);
      }
      i += WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int m = 0;
      int i = 17;
      int j;
      label28:
      int k;
      if (properties == null)
      {
        j = 17 * 31;
        if (result != null) {
          break label113;
        }
        i = 0;
        if (associatedRuleName != null) {
          break label124;
        }
        k = 0;
        label37:
        if (unknownFieldData != null) {
          break label135;
        }
      }
      for (;;)
      {
        return ((j * 31 + i) * 31 + k) * 31 + m;
        k = 0;
        j = i;
        if (k >= properties.length) {
          break;
        }
        if (properties[k] == null) {}
        for (j = 0;; j = properties[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        label113:
        i = result.hashCode();
        break label28;
        label124:
        k = associatedRuleName.hashCode();
        break label37;
        label135:
        m = unknownFieldData.hashCode();
      }
    }
    
    public ResolvedFunctionCall mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 10: 
          int j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 10);
          if (properties == null) {}
          for (i = 0;; i = properties.length)
          {
            Debug.ResolvedProperty[] arrayOfResolvedProperty = new Debug.ResolvedProperty[i + j];
            if (properties != null) {
              System.arraycopy(properties, 0, arrayOfResolvedProperty, 0, i);
            }
            properties = arrayOfResolvedProperty;
            while (i < properties.length - 1)
            {
              properties[i] = new Debug.ResolvedProperty();
              paramCodedInputByteBufferNano.readMessage(properties[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          properties[i] = new Debug.ResolvedProperty();
          paramCodedInputByteBufferNano.readMessage(properties[i]);
          break;
        case 18: 
          result = new TypeSystem.Value();
          paramCodedInputByteBufferNano.readMessage(result);
          break;
        case 26: 
          associatedRuleName = paramCodedInputByteBufferNano.readString();
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      if (properties != null)
      {
        Debug.ResolvedProperty[] arrayOfResolvedProperty = properties;
        int j = arrayOfResolvedProperty.length;
        int i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(1, arrayOfResolvedProperty[i]);
          i += 1;
        }
      }
      if (result != null) {
        paramCodedOutputByteBufferNano.writeMessage(2, result);
      }
      if (!associatedRuleName.equals("")) {
        paramCodedOutputByteBufferNano.writeString(3, associatedRuleName);
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static final class ResolvedProperty
    extends ExtendableMessageNano
  {
    public static final ResolvedProperty[] EMPTY_ARRAY = new ResolvedProperty[0];
    public String key = "";
    public TypeSystem.Value value = null;
    
    public ResolvedProperty() {}
    
    public static ResolvedProperty parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new ResolvedProperty().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static ResolvedProperty parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (ResolvedProperty)MessageNano.mergeFrom(new ResolvedProperty(), paramArrayOfByte);
    }
    
    public final ResolvedProperty clear()
    {
      key = "";
      value = null;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof ResolvedProperty)) {
        return false;
      }
      paramObject = (ResolvedProperty)paramObject;
      if (key == null) {
        if (key == null)
        {
          if (value != null) {
            break label82;
          }
          if (value == null)
          {
            label49:
            if (unknownFieldData != null) {
              break label99;
            }
            if (unknownFieldData == null) {
              break label115;
            }
          }
        }
      }
      label82:
      label99:
      while (!unknownFieldData.equals(unknownFieldData))
      {
        do
        {
          do
          {
            return false;
          } while (!key.equals(key));
          break;
        } while (!value.equals(value));
        break label49;
      }
      label115:
      return true;
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      if (!key.equals("")) {
        i = 0 + CodedOutputByteBufferNano.computeStringSize(1, key);
      }
      int j = i;
      if (value != null) {
        j = i + CodedOutputByteBufferNano.computeMessageSize(2, value);
      }
      i = j + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int k = 0;
      int i;
      int j;
      if (key == null)
      {
        i = 0;
        if (value != null) {
          break label54;
        }
        j = 0;
        label20:
        if (unknownFieldData != null) {
          break label65;
        }
      }
      for (;;)
      {
        return ((i + 527) * 31 + j) * 31 + k;
        i = key.hashCode();
        break;
        label54:
        j = value.hashCode();
        break label20;
        label65:
        k = unknownFieldData.hashCode();
      }
    }
    
    public ResolvedProperty mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 10: 
          key = paramCodedInputByteBufferNano.readString();
          break;
        case 18: 
          value = new TypeSystem.Value();
          paramCodedInputByteBufferNano.readMessage(value);
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      if (!key.equals("")) {
        paramCodedOutputByteBufferNano.writeString(1, key);
      }
      if (value != null) {
        paramCodedOutputByteBufferNano.writeMessage(2, value);
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static final class ResolvedRule
    extends ExtendableMessageNano
  {
    public static final ResolvedRule[] EMPTY_ARRAY = new ResolvedRule[0];
    public Debug.ResolvedFunctionCall[] addMacros = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
    public Debug.ResolvedFunctionCall[] addTags = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
    public Debug.ResolvedFunctionCall[] negativePredicates = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
    public Debug.ResolvedFunctionCall[] positivePredicates = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
    public Debug.ResolvedFunctionCall[] removeMacros = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
    public Debug.ResolvedFunctionCall[] removeTags = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
    public TypeSystem.Value result = null;
    
    public ResolvedRule() {}
    
    public static ResolvedRule parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new ResolvedRule().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static ResolvedRule parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (ResolvedRule)MessageNano.mergeFrom(new ResolvedRule(), paramArrayOfByte);
    }
    
    public final ResolvedRule clear()
    {
      positivePredicates = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
      negativePredicates = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
      addTags = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
      removeTags = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
      addMacros = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
      removeMacros = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
      result = null;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof ResolvedRule)) {
        return false;
      }
      paramObject = (ResolvedRule)paramObject;
      if ((Arrays.equals(positivePredicates, positivePredicates)) && (Arrays.equals(negativePredicates, negativePredicates)) && (Arrays.equals(addTags, addTags)) && (Arrays.equals(removeTags, removeTags)) && (Arrays.equals(addMacros, addMacros)) && (Arrays.equals(removeMacros, removeMacros)))
      {
        if (result != null) {
          break label135;
        }
        if (result == null)
        {
          if (unknownFieldData != null) {
            break label152;
          }
          if (unknownFieldData == null) {
            break label168;
          }
        }
      }
      label135:
      label152:
      while (!unknownFieldData.equals(unknownFieldData))
      {
        do
        {
          return false;
        } while (!result.equals(result));
        break;
      }
      label168:
      return true;
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      int j = 0;
      Debug.ResolvedFunctionCall[] arrayOfResolvedFunctionCall;
      int m;
      int k;
      if (positivePredicates != null)
      {
        arrayOfResolvedFunctionCall = positivePredicates;
        m = arrayOfResolvedFunctionCall.length;
        k = 0;
        for (;;)
        {
          i = j;
          if (k >= m) {
            break;
          }
          j += CodedOutputByteBufferNano.computeMessageSize(1, arrayOfResolvedFunctionCall[k]);
          k += 1;
        }
      }
      j = i;
      if (negativePredicates != null)
      {
        arrayOfResolvedFunctionCall = negativePredicates;
        m = arrayOfResolvedFunctionCall.length;
        k = 0;
        for (;;)
        {
          j = i;
          if (k >= m) {
            break;
          }
          i += CodedOutputByteBufferNano.computeMessageSize(2, arrayOfResolvedFunctionCall[k]);
          k += 1;
        }
      }
      i = j;
      if (addTags != null)
      {
        arrayOfResolvedFunctionCall = addTags;
        m = arrayOfResolvedFunctionCall.length;
        k = 0;
        for (;;)
        {
          i = j;
          if (k >= m) {
            break;
          }
          j += CodedOutputByteBufferNano.computeMessageSize(3, arrayOfResolvedFunctionCall[k]);
          k += 1;
        }
      }
      j = i;
      if (removeTags != null)
      {
        arrayOfResolvedFunctionCall = removeTags;
        m = arrayOfResolvedFunctionCall.length;
        k = 0;
        for (;;)
        {
          j = i;
          if (k >= m) {
            break;
          }
          i += CodedOutputByteBufferNano.computeMessageSize(4, arrayOfResolvedFunctionCall[k]);
          k += 1;
        }
      }
      i = j;
      if (addMacros != null)
      {
        arrayOfResolvedFunctionCall = addMacros;
        m = arrayOfResolvedFunctionCall.length;
        k = 0;
        for (;;)
        {
          i = j;
          if (k >= m) {
            break;
          }
          j += CodedOutputByteBufferNano.computeMessageSize(5, arrayOfResolvedFunctionCall[k]);
          k += 1;
        }
      }
      j = i;
      if (removeMacros != null)
      {
        arrayOfResolvedFunctionCall = removeMacros;
        m = arrayOfResolvedFunctionCall.length;
        k = 0;
        for (;;)
        {
          j = i;
          if (k >= m) {
            break;
          }
          i += CodedOutputByteBufferNano.computeMessageSize(6, arrayOfResolvedFunctionCall[k]);
          k += 1;
        }
      }
      i = j;
      if (result != null) {
        i = j + CodedOutputByteBufferNano.computeMessageSize(7, result);
      }
      i += WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int m = 0;
      int i = 17;
      int j;
      if (positivePredicates == null)
      {
        j = 17 * 31;
        if (negativePredicates != null) {
          break label161;
        }
        j *= 31;
        label31:
        if (addTags != null) {
          break label214;
        }
        j *= 31;
        label43:
        if (removeTags != null) {
          break label267;
        }
        j *= 31;
        label55:
        if (addMacros != null) {
          break label320;
        }
        j *= 31;
        label67:
        if (removeMacros != null) {
          break label373;
        }
        j *= 31;
        label79:
        if (result != null) {
          break label426;
        }
        i = 0;
        label88:
        if (unknownFieldData != null) {
          break label437;
        }
      }
      label161:
      label214:
      label267:
      label320:
      label373:
      label426:
      label437:
      for (int k = m;; k = unknownFieldData.hashCode())
      {
        return (j * 31 + i) * 31 + k;
        k = 0;
        j = i;
        if (k >= positivePredicates.length) {
          break;
        }
        if (positivePredicates[k] == null) {}
        for (j = 0;; j = positivePredicates[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= negativePredicates.length) {
          break label31;
        }
        if (negativePredicates[k] == null) {}
        for (j = 0;; j = negativePredicates[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= addTags.length) {
          break label43;
        }
        if (addTags[k] == null) {}
        for (j = 0;; j = addTags[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= removeTags.length) {
          break label55;
        }
        if (removeTags[k] == null) {}
        for (j = 0;; j = removeTags[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= addMacros.length) {
          break label67;
        }
        if (addMacros[k] == null) {}
        for (j = 0;; j = addMacros[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= removeMacros.length) {
          break label79;
        }
        if (removeMacros[k] == null) {}
        for (j = 0;; j = removeMacros[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        i = result.hashCode();
        break label88;
      }
    }
    
    public ResolvedRule mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        int j;
        Debug.ResolvedFunctionCall[] arrayOfResolvedFunctionCall;
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 10: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 10);
          if (positivePredicates == null) {}
          for (i = 0;; i = positivePredicates.length)
          {
            arrayOfResolvedFunctionCall = new Debug.ResolvedFunctionCall[i + j];
            if (positivePredicates != null) {
              System.arraycopy(positivePredicates, 0, arrayOfResolvedFunctionCall, 0, i);
            }
            positivePredicates = arrayOfResolvedFunctionCall;
            while (i < positivePredicates.length - 1)
            {
              positivePredicates[i] = new Debug.ResolvedFunctionCall();
              paramCodedInputByteBufferNano.readMessage(positivePredicates[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          positivePredicates[i] = new Debug.ResolvedFunctionCall();
          paramCodedInputByteBufferNano.readMessage(positivePredicates[i]);
          break;
        case 18: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 18);
          if (negativePredicates == null) {}
          for (i = 0;; i = negativePredicates.length)
          {
            arrayOfResolvedFunctionCall = new Debug.ResolvedFunctionCall[i + j];
            if (negativePredicates != null) {
              System.arraycopy(negativePredicates, 0, arrayOfResolvedFunctionCall, 0, i);
            }
            negativePredicates = arrayOfResolvedFunctionCall;
            while (i < negativePredicates.length - 1)
            {
              negativePredicates[i] = new Debug.ResolvedFunctionCall();
              paramCodedInputByteBufferNano.readMessage(negativePredicates[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          negativePredicates[i] = new Debug.ResolvedFunctionCall();
          paramCodedInputByteBufferNano.readMessage(negativePredicates[i]);
          break;
        case 26: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 26);
          if (addTags == null) {}
          for (i = 0;; i = addTags.length)
          {
            arrayOfResolvedFunctionCall = new Debug.ResolvedFunctionCall[i + j];
            if (addTags != null) {
              System.arraycopy(addTags, 0, arrayOfResolvedFunctionCall, 0, i);
            }
            addTags = arrayOfResolvedFunctionCall;
            while (i < addTags.length - 1)
            {
              addTags[i] = new Debug.ResolvedFunctionCall();
              paramCodedInputByteBufferNano.readMessage(addTags[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          addTags[i] = new Debug.ResolvedFunctionCall();
          paramCodedInputByteBufferNano.readMessage(addTags[i]);
          break;
        case 34: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 34);
          if (removeTags == null) {}
          for (i = 0;; i = removeTags.length)
          {
            arrayOfResolvedFunctionCall = new Debug.ResolvedFunctionCall[i + j];
            if (removeTags != null) {
              System.arraycopy(removeTags, 0, arrayOfResolvedFunctionCall, 0, i);
            }
            removeTags = arrayOfResolvedFunctionCall;
            while (i < removeTags.length - 1)
            {
              removeTags[i] = new Debug.ResolvedFunctionCall();
              paramCodedInputByteBufferNano.readMessage(removeTags[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          removeTags[i] = new Debug.ResolvedFunctionCall();
          paramCodedInputByteBufferNano.readMessage(removeTags[i]);
          break;
        case 42: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 42);
          if (addMacros == null) {}
          for (i = 0;; i = addMacros.length)
          {
            arrayOfResolvedFunctionCall = new Debug.ResolvedFunctionCall[i + j];
            if (addMacros != null) {
              System.arraycopy(addMacros, 0, arrayOfResolvedFunctionCall, 0, i);
            }
            addMacros = arrayOfResolvedFunctionCall;
            while (i < addMacros.length - 1)
            {
              addMacros[i] = new Debug.ResolvedFunctionCall();
              paramCodedInputByteBufferNano.readMessage(addMacros[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          addMacros[i] = new Debug.ResolvedFunctionCall();
          paramCodedInputByteBufferNano.readMessage(addMacros[i]);
          break;
        case 50: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 50);
          if (removeMacros == null) {}
          for (i = 0;; i = removeMacros.length)
          {
            arrayOfResolvedFunctionCall = new Debug.ResolvedFunctionCall[i + j];
            if (removeMacros != null) {
              System.arraycopy(removeMacros, 0, arrayOfResolvedFunctionCall, 0, i);
            }
            removeMacros = arrayOfResolvedFunctionCall;
            while (i < removeMacros.length - 1)
            {
              removeMacros[i] = new Debug.ResolvedFunctionCall();
              paramCodedInputByteBufferNano.readMessage(removeMacros[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          removeMacros[i] = new Debug.ResolvedFunctionCall();
          paramCodedInputByteBufferNano.readMessage(removeMacros[i]);
          break;
        case 58: 
          result = new TypeSystem.Value();
          paramCodedInputByteBufferNano.readMessage(result);
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      Debug.ResolvedFunctionCall[] arrayOfResolvedFunctionCall;
      int j;
      int i;
      if (positivePredicates != null)
      {
        arrayOfResolvedFunctionCall = positivePredicates;
        j = arrayOfResolvedFunctionCall.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(1, arrayOfResolvedFunctionCall[i]);
          i += 1;
        }
      }
      if (negativePredicates != null)
      {
        arrayOfResolvedFunctionCall = negativePredicates;
        j = arrayOfResolvedFunctionCall.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(2, arrayOfResolvedFunctionCall[i]);
          i += 1;
        }
      }
      if (addTags != null)
      {
        arrayOfResolvedFunctionCall = addTags;
        j = arrayOfResolvedFunctionCall.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(3, arrayOfResolvedFunctionCall[i]);
          i += 1;
        }
      }
      if (removeTags != null)
      {
        arrayOfResolvedFunctionCall = removeTags;
        j = arrayOfResolvedFunctionCall.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(4, arrayOfResolvedFunctionCall[i]);
          i += 1;
        }
      }
      if (addMacros != null)
      {
        arrayOfResolvedFunctionCall = addMacros;
        j = arrayOfResolvedFunctionCall.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(5, arrayOfResolvedFunctionCall[i]);
          i += 1;
        }
      }
      if (removeMacros != null)
      {
        arrayOfResolvedFunctionCall = removeMacros;
        j = arrayOfResolvedFunctionCall.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(6, arrayOfResolvedFunctionCall[i]);
          i += 1;
        }
      }
      if (result != null) {
        paramCodedOutputByteBufferNano.writeMessage(7, result);
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
  
  public static final class RuleEvaluationStepInfo
    extends ExtendableMessageNano
  {
    public static final RuleEvaluationStepInfo[] EMPTY_ARRAY = new RuleEvaluationStepInfo[0];
    public Debug.ResolvedFunctionCall[] enabledFunctions = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
    public Debug.ResolvedRule[] rules = Debug.ResolvedRule.EMPTY_ARRAY;
    
    public RuleEvaluationStepInfo() {}
    
    public static RuleEvaluationStepInfo parseFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      return new RuleEvaluationStepInfo().mergeFrom(paramCodedInputByteBufferNano);
    }
    
    public static RuleEvaluationStepInfo parseFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferNanoException
    {
      return (RuleEvaluationStepInfo)MessageNano.mergeFrom(new RuleEvaluationStepInfo(), paramArrayOfByte);
    }
    
    public final RuleEvaluationStepInfo clear()
    {
      rules = Debug.ResolvedRule.EMPTY_ARRAY;
      enabledFunctions = Debug.ResolvedFunctionCall.EMPTY_ARRAY;
      unknownFieldData = null;
      cachedSize = -1;
      return this;
    }
    
    public final boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof RuleEvaluationStepInfo)) {
        return false;
      }
      paramObject = (RuleEvaluationStepInfo)paramObject;
      if ((Arrays.equals(rules, rules)) && (Arrays.equals(enabledFunctions, enabledFunctions)))
      {
        if (unknownFieldData != null) {
          break label65;
        }
        if (unknownFieldData == null) {
          break label81;
        }
      }
      label65:
      while (!unknownFieldData.equals(unknownFieldData)) {
        return false;
      }
      label81:
      return true;
    }
    
    public int getSerializedSize()
    {
      int i = 0;
      int j = 0;
      Object localObject;
      int m;
      if (rules != null)
      {
        localObject = rules;
        m = localObject.length;
        k = 0;
        for (;;)
        {
          i = j;
          if (k >= m) {
            break;
          }
          j += CodedOutputByteBufferNano.computeMessageSize(1, localObject[k]);
          k += 1;
        }
      }
      int k = i;
      if (enabledFunctions != null)
      {
        localObject = enabledFunctions;
        m = localObject.length;
        j = 0;
        for (;;)
        {
          k = i;
          if (j >= m) {
            break;
          }
          i += CodedOutputByteBufferNano.computeMessageSize(2, localObject[j]);
          j += 1;
        }
      }
      i = k + WireFormatNano.computeWireSize(unknownFieldData);
      cachedSize = i;
      return i;
    }
    
    public int hashCode()
    {
      int m = 0;
      int i = 17;
      int j;
      if (rules == null)
      {
        j = 17 * 31;
        if (enabledFunctions != null) {
          break label99;
        }
        j *= 31;
        label31:
        if (unknownFieldData != null) {
          break label152;
        }
      }
      label99:
      label152:
      for (i = m;; i = unknownFieldData.hashCode())
      {
        return j * 31 + i;
        int k = 0;
        j = i;
        if (k >= rules.length) {
          break;
        }
        if (rules[k] == null) {}
        for (j = 0;; j = rules[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
        k = 0;
        i = j;
        j = i;
        if (k >= enabledFunctions.length) {
          break label31;
        }
        if (enabledFunctions[k] == null) {}
        for (j = 0;; j = enabledFunctions[k].hashCode())
        {
          i = i * 31 + j;
          k += 1;
          break;
        }
      }
    }
    
    public RuleEvaluationStepInfo mergeFrom(CodedInputByteBufferNano paramCodedInputByteBufferNano)
      throws IOException
    {
      for (;;)
      {
        int i = paramCodedInputByteBufferNano.readTag();
        int j;
        Object localObject;
        switch (i)
        {
        default: 
          if (unknownFieldData == null) {
            unknownFieldData = new ArrayList();
          }
          if (WireFormatNano.storeUnknownField(unknownFieldData, paramCodedInputByteBufferNano, i)) {}
          break;
        case 0: 
          return this;
        case 10: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 10);
          if (rules == null) {}
          for (i = 0;; i = rules.length)
          {
            localObject = new Debug.ResolvedRule[i + j];
            if (rules != null) {
              System.arraycopy(rules, 0, localObject, 0, i);
            }
            rules = ((Debug.ResolvedRule[])localObject);
            while (i < rules.length - 1)
            {
              rules[i] = new Debug.ResolvedRule();
              paramCodedInputByteBufferNano.readMessage(rules[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          rules[i] = new Debug.ResolvedRule();
          paramCodedInputByteBufferNano.readMessage(rules[i]);
          break;
        case 18: 
          j = WireFormatNano.getRepeatedFieldArrayLength(paramCodedInputByteBufferNano, 18);
          if (enabledFunctions == null) {}
          for (i = 0;; i = enabledFunctions.length)
          {
            localObject = new Debug.ResolvedFunctionCall[i + j];
            if (enabledFunctions != null) {
              System.arraycopy(enabledFunctions, 0, localObject, 0, i);
            }
            enabledFunctions = ((Debug.ResolvedFunctionCall[])localObject);
            while (i < enabledFunctions.length - 1)
            {
              enabledFunctions[i] = new Debug.ResolvedFunctionCall();
              paramCodedInputByteBufferNano.readMessage(enabledFunctions[i]);
              paramCodedInputByteBufferNano.readTag();
              i += 1;
            }
          }
          enabledFunctions[i] = new Debug.ResolvedFunctionCall();
          paramCodedInputByteBufferNano.readMessage(enabledFunctions[i]);
        }
      }
    }
    
    public void writeTo(CodedOutputByteBufferNano paramCodedOutputByteBufferNano)
      throws IOException
    {
      Object localObject;
      int j;
      int i;
      if (rules != null)
      {
        localObject = rules;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(1, localObject[i]);
          i += 1;
        }
      }
      if (enabledFunctions != null)
      {
        localObject = enabledFunctions;
        j = localObject.length;
        i = 0;
        while (i < j)
        {
          paramCodedOutputByteBufferNano.writeMessage(2, localObject[i]);
          i += 1;
        }
      }
      WireFormatNano.writeUnknownFields(unknownFieldData, paramCodedOutputByteBufferNano);
    }
  }
}
