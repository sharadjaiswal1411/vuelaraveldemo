package com.google.analytics.tracking.android;

import java.util.List;
import java.util.Map;

abstract interface AnalyticsClient
{
  public abstract void clearHits();
  
  public abstract void connect();
  
  public abstract void disconnect();
  
  public abstract void sendHit(Map paramMap, long paramLong, String paramString, List paramList);
}
