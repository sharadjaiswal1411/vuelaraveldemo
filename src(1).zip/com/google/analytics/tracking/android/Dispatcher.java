package com.google.analytics.tracking.android;

import java.util.List;

abstract interface Dispatcher
{
  public abstract void close();
  
  public abstract int dispatchHits(List paramList);
  
  public abstract boolean okToDispatch();
  
  public abstract void overrideHostUrl(String paramString);
}
