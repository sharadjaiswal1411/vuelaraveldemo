package com.google.analytics.tracking.android;

import android.text.TextUtils;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Tracker
{
  private final AppFieldsDefaultProvider mAppFieldsDefaultProvider;
  private final ClientIdDefaultProvider mClientIdDefaultProvider;
  private final TrackerHandler mHandler;
  private final String mName;
  private final Map<String, String> mParams = new HashMap();
  private RateLimiter mRateLimiter;
  private final ScreenResolutionDefaultProvider mScreenResolutionDefaultProvider;
  
  Tracker(String paramString1, String paramString2, TrackerHandler paramTrackerHandler)
  {
    this(paramString1, paramString2, paramTrackerHandler, ClientIdDefaultProvider.getProvider(), ScreenResolutionDefaultProvider.getProvider(), AppFieldsDefaultProvider.getProvider(), new SendHitRateLimiter());
  }
  
  Tracker(String paramString1, String paramString2, TrackerHandler paramTrackerHandler, ClientIdDefaultProvider paramClientIdDefaultProvider, ScreenResolutionDefaultProvider paramScreenResolutionDefaultProvider, AppFieldsDefaultProvider paramAppFieldsDefaultProvider, RateLimiter paramRateLimiter)
  {
    if (TextUtils.isEmpty(paramString1)) {
      throw new IllegalArgumentException("Tracker name cannot be empty.");
    }
    mName = paramString1;
    mHandler = paramTrackerHandler;
    mParams.put("&tid", paramString2);
    mParams.put("useSecure", "1");
    mClientIdDefaultProvider = paramClientIdDefaultProvider;
    mScreenResolutionDefaultProvider = paramScreenResolutionDefaultProvider;
    mAppFieldsDefaultProvider = paramAppFieldsDefaultProvider;
    mRateLimiter = paramRateLimiter;
  }
  
  public String get(String paramString)
  {
    GAUsage.getInstance().setUsage(GAUsage.Field.GET);
    if (TextUtils.isEmpty(paramString)) {
      return null;
    }
    if (mParams.containsKey(paramString)) {
      return (String)mParams.get(paramString);
    }
    if (paramString.equals("&ul")) {
      return Utils.getLanguage(Locale.getDefault());
    }
    if ((mClientIdDefaultProvider != null) && (mClientIdDefaultProvider.providesField(paramString))) {
      return mClientIdDefaultProvider.getValue(paramString);
    }
    if ((mScreenResolutionDefaultProvider != null) && (mScreenResolutionDefaultProvider.providesField(paramString))) {
      return mScreenResolutionDefaultProvider.getValue(paramString);
    }
    if ((mAppFieldsDefaultProvider != null) && (mAppFieldsDefaultProvider.providesField(paramString))) {
      return mAppFieldsDefaultProvider.getValue(paramString);
    }
    return null;
  }
  
  public String getName()
  {
    GAUsage.getInstance().setUsage(GAUsage.Field.GET_TRACKER_NAME);
    return mName;
  }
  
  RateLimiter getRateLimiter()
  {
    return mRateLimiter;
  }
  
  public void send(Map paramMap)
  {
    GAUsage.getInstance().setUsage(GAUsage.Field.SEND);
    HashMap localHashMap = new HashMap();
    localHashMap.putAll(mParams);
    if (paramMap != null) {
      localHashMap.putAll(paramMap);
    }
    if (TextUtils.isEmpty((CharSequence)localHashMap.get("&tid"))) {
      Log.w(String.format("Missing tracking id (%s) parameter.", new Object[] { "&tid" }));
    }
    String str = (String)localHashMap.get("&t");
    paramMap = str;
    if (TextUtils.isEmpty(str))
    {
      Log.w(String.format("Missing hit type (%s) parameter.", new Object[] { "&t" }));
      paramMap = "";
    }
    if ((!paramMap.equals("transaction")) && (!paramMap.equals("item")) && (!mRateLimiter.tokenAvailable()))
    {
      Log.w("Too many hits sent too quickly, rate limiting invoked.");
      return;
    }
    mHandler.sendHit(localHashMap);
  }
  
  public void set(String paramString1, String paramString2)
  {
    GAUsage.getInstance().setUsage(GAUsage.Field.SET);
    if (paramString2 == null)
    {
      mParams.remove(paramString1);
      return;
    }
    mParams.put(paramString1, paramString2);
  }
}
