package com.google.analytics.tracking.android;

import android.content.Context;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.UUID;

class ClientIdDefaultProvider
  implements DefaultProvider
{
  private static ClientIdDefaultProvider sInstance;
  private static final Object sInstanceLock = new Object();
  private String mClientId;
  private boolean mClientIdLoaded = false;
  private final Object mClientIdLock = new Object();
  private final Context mContext;
  
  protected ClientIdDefaultProvider(Context paramContext)
  {
    mContext = paramContext;
    asyncInitializeClientId();
  }
  
  private void asyncInitializeClientId()
  {
    new Thread("client_id_fetcher")
    {
      public void run()
      {
        Object localObject = mClientIdLock;
        try
        {
          ClientIdDefaultProvider.access$102(ClientIdDefaultProvider.this, initializeClientId());
          ClientIdDefaultProvider.access$202(ClientIdDefaultProvider.this, true);
          mClientIdLock.notifyAll();
          return;
        }
        catch (Throwable localThrowable)
        {
          throw localThrowable;
        }
      }
    }.start();
  }
  
  /* Error */
  private String blockingGetClientId()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 30	com/google/analytics/tracking/android/ClientIdDefaultProvider:mClientIdLoaded	Z
    //   4: ifne +40 -> 44
    //   7: aload_0
    //   8: getfield 32	com/google/analytics/tracking/android/ClientIdDefaultProvider:mClientIdLock	Ljava/lang/Object;
    //   11: astore_1
    //   12: aload_1
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield 30	com/google/analytics/tracking/android/ClientIdDefaultProvider:mClientIdLoaded	Z
    //   18: ifne +24 -> 42
    //   21: ldc 63
    //   23: invokestatic 69	com/google/analytics/tracking/android/Log:v	(Ljava/lang/String;)V
    //   26: aload_0
    //   27: getfield 32	com/google/analytics/tracking/android/ClientIdDefaultProvider:mClientIdLock	Ljava/lang/Object;
    //   30: astore_2
    //   31: aload_2
    //   32: invokevirtual 72	java/lang/Object:wait	()V
    //   35: aload_0
    //   36: getfield 30	com/google/analytics/tracking/android/ClientIdDefaultProvider:mClientIdLoaded	Z
    //   39: ifeq -13 -> 26
    //   42: aload_1
    //   43: monitorexit
    //   44: ldc 74
    //   46: invokestatic 69	com/google/analytics/tracking/android/Log:v	(Ljava/lang/String;)V
    //   49: aload_0
    //   50: getfield 43	com/google/analytics/tracking/android/ClientIdDefaultProvider:mClientId	Ljava/lang/String;
    //   53: areturn
    //   54: astore_2
    //   55: new 76	java/lang/StringBuilder
    //   58: dup
    //   59: invokespecial 77	java/lang/StringBuilder:<init>	()V
    //   62: ldc 79
    //   64: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   67: aload_2
    //   68: invokevirtual 86	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   71: invokevirtual 89	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   74: invokestatic 92	com/google/analytics/tracking/android/Log:e	(Ljava/lang/String;)V
    //   77: goto -42 -> 35
    //   80: astore_2
    //   81: aload_1
    //   82: monitorexit
    //   83: aload_2
    //   84: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	85	0	this	ClientIdDefaultProvider
    //   11	71	1	localObject1	Object
    //   30	2	2	localObject2	Object
    //   54	14	2	localInterruptedException	InterruptedException
    //   80	4	2	localThrowable	Throwable
    // Exception table:
    //   from	to	target	type
    //   31	35	54	java/lang/InterruptedException
    //   14	26	80	java/lang/Throwable
    //   31	35	80	java/lang/Throwable
    //   35	42	80	java/lang/Throwable
    //   42	44	80	java/lang/Throwable
    //   55	77	80	java/lang/Throwable
    //   81	83	80	java/lang/Throwable
  }
  
  static void dropInstance()
  {
    Object localObject = sInstanceLock;
    try
    {
      sInstance = null;
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public static ClientIdDefaultProvider getProvider()
  {
    Object localObject = sInstanceLock;
    try
    {
      ClientIdDefaultProvider localClientIdDefaultProvider = sInstance;
      return localClientIdDefaultProvider;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public static void initializeProvider(Context paramContext)
  {
    Object localObject = sInstanceLock;
    try
    {
      if (sInstance == null) {
        sInstance = new ClientIdDefaultProvider(paramContext);
      }
      return;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  private boolean storeClientId(String paramString)
  {
    try
    {
      Log.v("Storing clientId.");
      Object localObject = mContext;
      localObject = ((Context)localObject).openFileOutput("gaClientId", 0);
      ((FileOutputStream)localObject).write(paramString.getBytes());
      ((FileOutputStream)localObject).close();
      return true;
    }
    catch (FileNotFoundException paramString)
    {
      Log.e("Error creating clientId file.");
      return false;
    }
    catch (IOException paramString)
    {
      Log.e("Error writing to clientId file.");
    }
    return false;
  }
  
  protected String generateClientId()
  {
    String str = UUID.randomUUID().toString().toLowerCase();
    if (!storeClientId(str)) {
      return "0";
    }
    return str;
  }
  
  public String getValue(String paramString)
  {
    if ("&cid".equals(paramString)) {
      return blockingGetClientId();
    }
    return null;
  }
  
  String initializeClientId()
  {
    localObject5 = null;
    localObject4 = null;
    for (Object localObject1 = mContext;; localObject1 = localObject4)
    {
      try
      {
        localFileInputStream = ((Context)localObject1).openFileInput("gaClientId");
        localObject1 = new byte['?'];
        i = localFileInputStream.read((byte[])localObject1, 0, 128);
        int j = localFileInputStream.available();
        if (j <= 0) {
          break label80;
        }
        Log.e("clientId file seems corrupted, deleting it.");
        localFileInputStream.close();
        localObject1 = mContext;
        ((Context)localObject1).deleteFile("gaClientId");
        localObject1 = localObject4;
      }
      catch (FileNotFoundException localFileNotFoundException1)
      {
        int i;
        for (;;)
        {
          localObject2 = localObject4;
        }
        Object localObject2 = new String((byte[])localObject2, 0, i);
      }
      catch (IOException localIOException1)
      {
        label80:
        Object localObject3;
        for (;;)
        {
          try
          {
            FileInputStream localFileInputStream;
            localFileInputStream.close();
          }
          catch (IOException localIOException2)
          {
            continue;
          }
          catch (FileNotFoundException localFileNotFoundException2) {}
          localIOException1 = localIOException1;
          localObject3 = localObject5;
          Log.e("Error reading clientId file, deleting it.");
          mContext.deleteFile("gaClientId");
        }
        return localObject3;
      }
      if (localObject1 != null) {
        return localObject1;
      }
      return generateClientId();
      if (i > 0) {
        break;
      }
      Log.e("clientId file seems empty, deleting it.");
      localFileInputStream.close();
      localObject1 = mContext;
      ((Context)localObject1).deleteFile("gaClientId");
    }
  }
  
  public boolean providesField(String paramString)
  {
    return "&cid".equals(paramString);
  }
}
