package com.google.analytics.tracking.android;

import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

abstract interface AnalyticsThread
{
  public abstract void clearHits();
  
  public abstract void dispatch();
  
  public abstract LinkedBlockingQueue getQueue();
  
  public abstract Thread getThread();
  
  public abstract void sendHit(Map paramMap);
  
  public abstract void setForceLocalDispatch();
}
