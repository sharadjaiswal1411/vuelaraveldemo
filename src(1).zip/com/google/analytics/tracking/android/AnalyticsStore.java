package com.google.analytics.tracking.android;

import java.util.Collection;
import java.util.Map;

abstract interface AnalyticsStore
{
  public abstract void clearHits(long paramLong);
  
  public abstract void close();
  
  public abstract void dispatch();
  
  public abstract Dispatcher getDispatcher();
  
  public abstract void putHit(Map paramMap, long paramLong, String paramString, Collection paramCollection);
  
  public abstract void setDispatch(boolean paramBoolean);
}
