package com.google.analytics.tracking.android;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build.VERSION;
import android.text.TextUtils;
import com.google.android.com.analytics.internal.Command;
import com.google.android.gms.common.util.VisibleForTesting;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.http.impl.client.DefaultHttpClient;

class PersistentAnalyticsStore
  implements AnalyticsStore
{
  private static final String CREATE_HITS_TABLE = String.format("CREATE TABLE IF NOT EXISTS %s ( '%s' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, '%s' INTEGER NOT NULL, '%s' TEXT NOT NULL, '%s' TEXT NOT NULL, '%s' INTEGER);", new Object[] { "hits2", "hit_id", "hit_time", "hit_url", "hit_string", "hit_app_id" });
  private static final String DATABASE_FILENAME = "google_analytics_v2.db";
  @VisibleForTesting
  static final String HITS_TABLE = "hits2";
  @VisibleForTesting
  static final String HIT_APP_ID = "hit_app_id";
  @VisibleForTesting
  static final String HIT_ID = "hit_id";
  @VisibleForTesting
  static final String HIT_STRING = "hit_string";
  @VisibleForTesting
  static final String HIT_TIME = "hit_time";
  @VisibleForTesting
  static final String HIT_URL = "hit_url";
  private Clock mClock;
  private final Context mContext;
  private final String mDatabaseName;
  private final AnalyticsDatabaseHelper mDbHelper;
  private volatile Dispatcher mDispatcher;
  private long mLastDeleteStaleHitsTime;
  private final AnalyticsStoreStateListener mListener;
  
  PersistentAnalyticsStore(AnalyticsStoreStateListener paramAnalyticsStoreStateListener, Context paramContext)
  {
    this(paramAnalyticsStoreStateListener, paramContext, "google_analytics_v2.db");
  }
  
  PersistentAnalyticsStore(AnalyticsStoreStateListener paramAnalyticsStoreStateListener, Context paramContext, String paramString)
  {
    mContext = paramContext.getApplicationContext();
    mDatabaseName = paramString;
    mListener = paramAnalyticsStoreStateListener;
    mClock = new Clock()
    {
      public long currentTimeMillis()
      {
        return System.currentTimeMillis();
      }
    };
    mDbHelper = new AnalyticsDatabaseHelper(mContext, mDatabaseName);
    mDispatcher = new SimpleNetworkDispatcher(new DefaultHttpClient(), mContext);
    mLastDeleteStaleHitsTime = 0L;
  }
  
  private void fillVersionParameter(Map paramMap, Collection paramCollection)
  {
    String str = "&_v".substring(1);
    if (paramCollection != null)
    {
      paramCollection = paramCollection.iterator();
      while (paramCollection.hasNext())
      {
        Command localCommand = (Command)paramCollection.next();
        if ("appendVersion".equals(localCommand.getId())) {
          paramMap.put(str, localCommand.getValue());
        }
      }
    }
  }
  
  static String generateHitString(Map paramMap)
  {
    ArrayList localArrayList = new ArrayList(paramMap.size());
    paramMap = paramMap.entrySet().iterator();
    while (paramMap.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)paramMap.next();
      localArrayList.add(HitBuilder.encode((String)localEntry.getKey()) + "=" + HitBuilder.encode((String)localEntry.getValue()));
    }
    return TextUtils.join("&", localArrayList);
  }
  
  private SQLiteDatabase getWritableDatabase(String paramString)
  {
    Object localObject = mDbHelper;
    try
    {
      localObject = ((AnalyticsDatabaseHelper)localObject).getWritableDatabase();
      return localObject;
    }
    catch (SQLiteException localSQLiteException)
    {
      Log.w(paramString);
    }
    return null;
  }
  
  private void removeOldHitIfFull()
  {
    int i = getNumStoredHits() - 2000 + 1;
    if (i > 0)
    {
      List localList = peekHitIds(i);
      Log.v("Store full, deleting " + localList.size() + " hits to make room.");
      deleteHits((String[])localList.toArray(new String[0]));
    }
  }
  
  private void writeHitToDatabase(Map paramMap, long paramLong, String paramString)
  {
    SQLiteDatabase localSQLiteDatabase = getWritableDatabase("Error opening database for putHit");
    if (localSQLiteDatabase == null) {
      return;
    }
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("hit_string", generateHitString(paramMap));
    localContentValues.put("hit_time", Long.valueOf(paramLong));
    l = 0L;
    paramLong = l;
    if (paramMap.containsKey("AppUID")) {}
    try
    {
      paramMap = paramMap.get("AppUID");
      paramMap = (String)paramMap;
      paramLong = Long.parseLong(paramMap);
    }
    catch (NumberFormatException paramMap)
    {
      for (;;)
      {
        paramLong = l;
      }
    }
    localContentValues.put("hit_app_id", Long.valueOf(paramLong));
    paramMap = paramString;
    if (paramString == null) {
      paramMap = "http://www.google-analytics.com/collect";
    }
    if (paramMap.length() == 0)
    {
      Log.w("Empty path: not sending hit");
      return;
    }
    localContentValues.put("hit_url", paramMap);
    try
    {
      localSQLiteDatabase.insert("hits2", null, localContentValues);
      paramMap = mListener;
      paramMap.reportStoreIsEmpty(false);
      return;
    }
    catch (SQLiteException paramMap)
    {
      Log.w("Error storing hit");
      return;
    }
  }
  
  public void clearHits(long paramLong)
  {
    boolean bool = true;
    Object localObject = getWritableDatabase("Error opening database for clearHits");
    if (localObject != null)
    {
      if (paramLong == 0L)
      {
        ((SQLiteDatabase)localObject).delete("hits2", null, null);
        localObject = mListener;
        if (getNumStoredHits() != 0) {
          break label82;
        }
      }
      for (;;)
      {
        ((AnalyticsStoreStateListener)localObject).reportStoreIsEmpty(bool);
        return;
        ((SQLiteDatabase)localObject).delete("hits2", "hit_app_id = ?", new String[] { Long.valueOf(paramLong).toString() });
        break;
        label82:
        bool = false;
      }
    }
  }
  
  public void close()
  {
    Object localObject = mDbHelper;
    try
    {
      ((AnalyticsDatabaseHelper)localObject).getWritableDatabase().close();
      localObject = mDispatcher;
      ((Dispatcher)localObject).close();
      return;
    }
    catch (SQLiteException localSQLiteException)
    {
      Log.w("Error opening database for close");
    }
  }
  
  void deleteHits(Collection paramCollection)
  {
    if ((paramCollection == null) || (paramCollection.isEmpty()))
    {
      Log.w("Empty/Null collection passed to deleteHits.");
      return;
    }
    String[] arrayOfString = new String[paramCollection.size()];
    int i = 0;
    paramCollection = paramCollection.iterator();
    while (paramCollection.hasNext())
    {
      arrayOfString[i] = String.valueOf(((Hit)paramCollection.next()).getHitId());
      i += 1;
    }
    deleteHits(arrayOfString);
  }
  
  void deleteHits(String[] paramArrayOfString)
  {
    boolean bool = true;
    if ((paramArrayOfString == null) || (paramArrayOfString.length == 0))
    {
      Log.w("Empty hitIds passed to deleteHits.");
      return;
    }
    Object localObject = getWritableDatabase("Error opening database for deleteHits.");
    if (localObject != null)
    {
      String str = String.format("HIT_ID in (%s)", new Object[] { TextUtils.join(",", Collections.nCopies(paramArrayOfString.length, "?")) });
      for (;;)
      {
        try
        {
          ((SQLiteDatabase)localObject).delete("hits2", str, paramArrayOfString);
          localObject = mListener;
          int i = getNumStoredHits();
          if (i == 0)
          {
            ((AnalyticsStoreStateListener)localObject).reportStoreIsEmpty(bool);
            return;
          }
        }
        catch (SQLiteException localSQLiteException)
        {
          Log.w("Error deleting hits " + paramArrayOfString);
          return;
        }
        bool = false;
      }
    }
  }
  
  int deleteStaleHits()
  {
    boolean bool = true;
    long l = mClock.currentTimeMillis();
    if (l <= mLastDeleteStaleHitsTime + 86400000L) {
      return 0;
    }
    mLastDeleteStaleHitsTime = l;
    Object localObject = getWritableDatabase("Error opening database for deleteStaleHits.");
    if (localObject != null)
    {
      int i = ((SQLiteDatabase)localObject).delete("hits2", "HIT_TIME < ?", new String[] { Long.toString(mClock.currentTimeMillis() - 2592000000L) });
      localObject = mListener;
      if (getNumStoredHits() == 0) {}
      for (;;)
      {
        ((AnalyticsStoreStateListener)localObject).reportStoreIsEmpty(bool);
        return i;
        bool = false;
      }
    }
    return 0;
  }
  
  public void dispatch()
  {
    Log.v("Dispatch running...");
    if (!mDispatcher.okToDispatch()) {
      return;
    }
    List localList = peekHits(40);
    if (localList.isEmpty())
    {
      Log.v("...nothing to dispatch");
      mListener.reportStoreIsEmpty(true);
      return;
    }
    int i = mDispatcher.dispatchHits(localList);
    Log.v("sent " + i + " of " + localList.size() + " hits");
    deleteHits(localList.subList(0, Math.min(i, localList.size())));
    if ((i == localList.size()) && (getNumStoredHits() > 0)) {
      GAServiceManager.getInstance().dispatchLocalHits();
    }
  }
  
  public AnalyticsDatabaseHelper getDbHelper()
  {
    return mDbHelper;
  }
  
  public Dispatcher getDispatcher()
  {
    return mDispatcher;
  }
  
  AnalyticsDatabaseHelper getHelper()
  {
    return mDbHelper;
  }
  
  int getNumStoredHits()
  {
    int j = 0;
    int i = 0;
    Object localObject4 = getWritableDatabase("Error opening database for getNumStoredHits.");
    if (localObject4 == null) {
      return 0;
    }
    Object localObject2 = null;
    localObject1 = null;
    try
    {
      Cursor localCursor = ((SQLiteDatabase)localObject4).rawQuery("SELECT COUNT(*) from hits2", null);
      localObject4 = localCursor;
      localObject1 = localObject4;
      localObject2 = localObject4;
      boolean bool = localCursor.moveToFirst();
      if (bool)
      {
        localObject1 = localObject4;
        localObject2 = localObject4;
        long l = localCursor.getLong(0);
        i = (int)l;
      }
      j = i;
      if (localCursor != null)
      {
        localCursor.close();
        j = i;
      }
    }
    catch (SQLiteException localSQLiteException)
    {
      do
      {
        localObject3 = localObject1;
        Log.w("Error getting numStoredHits");
      } while (localObject1 == null);
      localObject1.close();
      return 0;
    }
    catch (Throwable localThrowable)
    {
      Object localObject3;
      if (localObject3 == null) {
        break label141;
      }
      localObject3.close();
      throw localThrowable;
    }
    return j;
  }
  
  List peekHitIds(int paramInt)
  {
    ArrayList localArrayList = new ArrayList();
    if (paramInt <= 0)
    {
      Log.w("Invalid maxHits specified. Skipping");
      return localArrayList;
    }
    SQLiteDatabase localSQLiteDatabase = getWritableDatabase("Error opening database for peekHitIds.");
    if (localSQLiteDatabase != null)
    {
      Cursor localCursor4 = null;
      Cursor localCursor3 = null;
      Cursor localCursor2 = localCursor3;
      Cursor localCursor1 = localCursor4;
      try
      {
        String str1 = String.format("%s ASC", new Object[] { "hit_id" });
        localCursor2 = localCursor3;
        localCursor1 = localCursor4;
        String str2 = Integer.toString(paramInt);
        localCursor2 = localCursor3;
        localCursor1 = localCursor4;
        localCursor4 = localSQLiteDatabase.query("hits2", new String[] { "hit_id" }, null, null, null, null, str1, str2);
        localCursor3 = localCursor4;
        localCursor2 = localCursor3;
        localCursor1 = localCursor3;
        boolean bool = localCursor4.moveToFirst();
        if (bool) {
          do
          {
            localCursor2 = localCursor3;
            localCursor1 = localCursor3;
            localArrayList.add(String.valueOf(localCursor4.getLong(0)));
            localCursor2 = localCursor3;
            localCursor1 = localCursor3;
            bool = localCursor4.moveToNext();
          } while (bool);
        }
        if (localCursor4 != null)
        {
          localCursor4.close();
          return localArrayList;
        }
      }
      catch (SQLiteException localSQLiteException)
      {
        localCursor1 = localCursor2;
        Log.w("Error in peekHits fetching hitIds: " + localSQLiteException.getMessage());
        if (localCursor2 != null)
        {
          localCursor2.close();
          return localArrayList;
        }
      }
      catch (Throwable localThrowable)
      {
        if (localCursor1 != null) {
          localCursor1.close();
        }
        throw localThrowable;
      }
    }
    return localArrayList;
  }
  
  /* Error */
  public List peekHits(int paramInt)
  {
    // Byte code:
    //   0: new 158	java/util/ArrayList
    //   3: dup
    //   4: invokespecial 454	java/util/ArrayList:<init>	()V
    //   7: astore 10
    //   9: aload_0
    //   10: ldc_w 480
    //   13: invokespecial 260	com/google/analytics/tracking/android/PersistentAnalyticsStore:getWritableDatabase	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteDatabase;
    //   16: astore 12
    //   18: aload 12
    //   20: ifnonnull +6 -> 26
    //   23: aload 10
    //   25: areturn
    //   26: aconst_null
    //   27: astore 9
    //   29: aconst_null
    //   30: astore 6
    //   32: aload 6
    //   34: astore 8
    //   36: aload 9
    //   38: astore 7
    //   40: ldc_w 460
    //   43: iconst_1
    //   44: anewarray 4	java/lang/Object
    //   47: dup
    //   48: iconst_0
    //   49: ldc 26
    //   51: aastore
    //   52: invokestatic 58	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   55: astore 11
    //   57: aload 6
    //   59: astore 8
    //   61: aload 9
    //   63: astore 7
    //   65: iload_1
    //   66: invokestatic 464	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   69: astore 13
    //   71: aload 6
    //   73: astore 8
    //   75: aload 9
    //   77: astore 7
    //   79: aload 12
    //   81: ldc 19
    //   83: iconst_2
    //   84: anewarray 54	java/lang/String
    //   87: dup
    //   88: iconst_0
    //   89: ldc 26
    //   91: aastore
    //   92: dup
    //   93: iconst_1
    //   94: ldc 32
    //   96: aastore
    //   97: aconst_null
    //   98: aconst_null
    //   99: aconst_null
    //   100: aconst_null
    //   101: aload 11
    //   103: aload 13
    //   105: invokevirtual 468	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   108: astore 11
    //   110: aload 11
    //   112: astore 6
    //   114: aload 6
    //   116: astore 8
    //   118: aload 6
    //   120: astore 7
    //   122: new 158	java/util/ArrayList
    //   125: dup
    //   126: invokespecial 454	java/util/ArrayList:<init>	()V
    //   129: astore 9
    //   131: aload 11
    //   133: invokeinterface 446 1 0
    //   138: istore_3
    //   139: iload_3
    //   140: ifeq +47 -> 187
    //   143: aload 9
    //   145: new 339	com/google/analytics/tracking/android/Hit
    //   148: dup
    //   149: aconst_null
    //   150: aload 11
    //   152: iconst_0
    //   153: invokeinterface 450 2 0
    //   158: aload 11
    //   160: iconst_1
    //   161: invokeinterface 450 2 0
    //   166: invokespecial 483	com/google/analytics/tracking/android/Hit:<init>	(Ljava/lang/String;JJ)V
    //   169: invokeinterface 202 2 0
    //   174: pop
    //   175: aload 11
    //   177: invokeinterface 471 1 0
    //   182: istore_3
    //   183: iload_3
    //   184: ifne -41 -> 143
    //   187: aload 11
    //   189: ifnull +10 -> 199
    //   192: aload 11
    //   194: invokeinterface 451 1 0
    //   199: iconst_0
    //   200: istore_2
    //   201: aload 6
    //   203: astore 8
    //   205: aload 6
    //   207: astore 7
    //   209: ldc_w 460
    //   212: iconst_1
    //   213: anewarray 4	java/lang/Object
    //   216: dup
    //   217: iconst_0
    //   218: ldc 26
    //   220: aastore
    //   221: invokestatic 58	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   224: astore 10
    //   226: aload 6
    //   228: astore 8
    //   230: aload 6
    //   232: astore 7
    //   234: iload_1
    //   235: invokestatic 464	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   238: astore 11
    //   240: aload 6
    //   242: astore 8
    //   244: aload 6
    //   246: astore 7
    //   248: aload 12
    //   250: ldc 19
    //   252: iconst_3
    //   253: anewarray 54	java/lang/String
    //   256: dup
    //   257: iconst_0
    //   258: ldc 26
    //   260: aastore
    //   261: dup
    //   262: iconst_1
    //   263: ldc 29
    //   265: aastore
    //   266: dup
    //   267: iconst_2
    //   268: ldc 35
    //   270: aastore
    //   271: aconst_null
    //   272: aconst_null
    //   273: aconst_null
    //   274: aconst_null
    //   275: aload 10
    //   277: aload 11
    //   279: invokevirtual 468	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   282: astore 10
    //   284: aload 10
    //   286: astore 6
    //   288: aload 6
    //   290: astore 8
    //   292: aload 6
    //   294: astore 7
    //   296: aload 10
    //   298: invokeinterface 446 1 0
    //   303: istore_3
    //   304: iload_3
    //   305: ifeq +153 -> 458
    //   308: iload_2
    //   309: istore_1
    //   310: aload 10
    //   312: checkcast 485	android/database/sqlite/SQLiteCursor
    //   315: astore 11
    //   317: aload 6
    //   319: astore 8
    //   321: aload 6
    //   323: astore 7
    //   325: aload 11
    //   327: invokevirtual 491	android/database/AbstractWindowedCursor:getWindow	()Landroid/database/CursorWindow;
    //   330: invokevirtual 496	android/database/CursorWindow:getNumRows	()I
    //   333: istore_2
    //   334: iload_2
    //   335: ifle +215 -> 550
    //   338: aload 6
    //   340: astore 8
    //   342: aload 6
    //   344: astore 7
    //   346: aload 9
    //   348: iload_1
    //   349: invokeinterface 499 2 0
    //   354: astore 11
    //   356: aload 6
    //   358: astore 7
    //   360: aload 11
    //   362: checkcast 339	com/google/analytics/tracking/android/Hit
    //   365: astore 11
    //   367: aload 6
    //   369: astore 8
    //   371: aload 6
    //   373: astore 7
    //   375: aload 11
    //   377: aload 10
    //   379: iconst_1
    //   380: invokeinterface 502 2 0
    //   385: invokevirtual 505	com/google/analytics/tracking/android/Hit:setHitString	(Ljava/lang/String;)V
    //   388: aload 6
    //   390: astore 8
    //   392: aload 6
    //   394: astore 7
    //   396: aload 9
    //   398: iload_1
    //   399: invokeinterface 499 2 0
    //   404: astore 11
    //   406: aload 11
    //   408: checkcast 339	com/google/analytics/tracking/android/Hit
    //   411: astore 11
    //   413: aload 6
    //   415: astore 8
    //   417: aload 6
    //   419: astore 7
    //   421: aload 11
    //   423: aload 10
    //   425: iconst_2
    //   426: invokeinterface 502 2 0
    //   431: invokevirtual 508	com/google/analytics/tracking/android/Hit:setHitUrl	(Ljava/lang/String;)V
    //   434: iload_1
    //   435: iconst_1
    //   436: iadd
    //   437: istore_1
    //   438: aload 6
    //   440: astore 8
    //   442: aload 6
    //   444: astore 7
    //   446: aload 10
    //   448: invokeinterface 471 1 0
    //   453: istore_3
    //   454: iload_3
    //   455: ifne -145 -> 310
    //   458: aload 10
    //   460: ifnull +10 -> 470
    //   463: aload 10
    //   465: invokeinterface 451 1 0
    //   470: aload 9
    //   472: areturn
    //   473: astore 9
    //   475: aload 8
    //   477: astore 6
    //   479: aload 10
    //   481: astore 8
    //   483: aload 6
    //   485: astore 7
    //   487: new 176	java/lang/StringBuilder
    //   490: dup
    //   491: invokespecial 177	java/lang/StringBuilder:<init>	()V
    //   494: ldc_w 473
    //   497: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   500: aload 9
    //   502: invokevirtual 478	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   505: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   508: invokevirtual 197	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   511: invokestatic 223	com/google/analytics/tracking/android/Log:w	(Ljava/lang/String;)V
    //   514: aload 6
    //   516: ifnull +10 -> 526
    //   519: aload 6
    //   521: invokeinterface 451 1 0
    //   526: aload 8
    //   528: areturn
    //   529: astore 8
    //   531: aload 7
    //   533: astore 6
    //   535: aload 6
    //   537: ifnull +10 -> 547
    //   540: aload 6
    //   542: invokeinterface 451 1 0
    //   547: aload 8
    //   549: athrow
    //   550: aload 6
    //   552: astore 8
    //   554: aload 6
    //   556: astore 7
    //   558: aload 9
    //   560: iload_1
    //   561: invokeinterface 499 2 0
    //   566: astore 11
    //   568: aload 6
    //   570: astore 7
    //   572: aload 11
    //   574: checkcast 339	com/google/analytics/tracking/android/Hit
    //   577: astore 11
    //   579: aload 6
    //   581: astore 8
    //   583: aload 6
    //   585: astore 7
    //   587: aload 11
    //   589: invokevirtual 343	com/google/analytics/tracking/android/Hit:getHitId	()J
    //   592: lstore 4
    //   594: aload 6
    //   596: astore 8
    //   598: aload 6
    //   600: astore 7
    //   602: ldc_w 510
    //   605: iconst_1
    //   606: anewarray 4	java/lang/Object
    //   609: dup
    //   610: iconst_0
    //   611: lload 4
    //   613: invokestatic 274	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   616: aastore
    //   617: invokestatic 58	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   620: invokestatic 223	com/google/analytics/tracking/android/Log:w	(Ljava/lang/String;)V
    //   623: goto -189 -> 434
    //   626: astore 6
    //   628: aload 8
    //   630: astore 7
    //   632: new 176	java/lang/StringBuilder
    //   635: dup
    //   636: invokespecial 177	java/lang/StringBuilder:<init>	()V
    //   639: ldc_w 512
    //   642: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   645: aload 6
    //   647: invokevirtual 478	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   650: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   653: invokevirtual 197	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   656: invokestatic 223	com/google/analytics/tracking/android/Log:w	(Ljava/lang/String;)V
    //   659: aload 8
    //   661: astore 7
    //   663: new 158	java/util/ArrayList
    //   666: dup
    //   667: invokespecial 454	java/util/ArrayList:<init>	()V
    //   670: astore 6
    //   672: iconst_0
    //   673: istore_1
    //   674: aload 8
    //   676: astore 7
    //   678: aload 9
    //   680: invokeinterface 513 1 0
    //   685: astore 9
    //   687: aload 8
    //   689: astore 7
    //   691: aload 9
    //   693: invokeinterface 130 1 0
    //   698: istore_3
    //   699: iload_3
    //   700: ifeq +42 -> 742
    //   703: aload 8
    //   705: astore 7
    //   707: aload 9
    //   709: invokeinterface 134 1 0
    //   714: checkcast 339	com/google/analytics/tracking/android/Hit
    //   717: astore 10
    //   719: aload 8
    //   721: astore 7
    //   723: aload 10
    //   725: invokevirtual 516	com/google/analytics/tracking/android/Hit:getHitParams	()Ljava/lang/String;
    //   728: invokestatic 519	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   731: istore_3
    //   732: iload_1
    //   733: istore_2
    //   734: iload_3
    //   735: ifeq +24 -> 759
    //   738: iload_1
    //   739: ifeq +18 -> 757
    //   742: aload 8
    //   744: ifnull +10 -> 754
    //   747: aload 8
    //   749: invokeinterface 451 1 0
    //   754: aload 6
    //   756: areturn
    //   757: iconst_1
    //   758: istore_2
    //   759: aload 8
    //   761: astore 7
    //   763: aload 6
    //   765: aload 10
    //   767: invokeinterface 202 2 0
    //   772: pop
    //   773: iload_2
    //   774: istore_1
    //   775: goto -88 -> 687
    //   778: astore 6
    //   780: aload 7
    //   782: ifnull +10 -> 792
    //   785: aload 7
    //   787: invokeinterface 451 1 0
    //   792: aload 6
    //   794: athrow
    //   795: astore 8
    //   797: goto -262 -> 535
    //   800: astore 7
    //   802: aload 9
    //   804: astore 8
    //   806: aload 7
    //   808: astore 9
    //   810: goto -327 -> 483
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	813	0	this	PersistentAnalyticsStore
    //   0	813	1	paramInt	int
    //   200	574	2	i	int
    //   138	597	3	bool	boolean
    //   592	20	4	l	long
    //   30	569	6	localObject1	Object
    //   626	20	6	localSQLiteException1	SQLiteException
    //   670	94	6	localArrayList1	ArrayList
    //   778	15	6	localThrowable1	Throwable
    //   38	748	7	localObject2	Object
    //   800	7	7	localSQLiteException2	SQLiteException
    //   34	493	8	localObject3	Object
    //   529	19	8	localThrowable2	Throwable
    //   552	208	8	localObject4	Object
    //   795	1	8	localThrowable3	Throwable
    //   804	1	8	localObject5	Object
    //   27	444	9	localArrayList2	ArrayList
    //   473	206	9	localSQLiteException3	SQLiteException
    //   685	124	9	localObject6	Object
    //   7	759	10	localObject7	Object
    //   55	533	11	localObject8	Object
    //   16	233	12	localSQLiteDatabase	SQLiteDatabase
    //   69	35	13	str	String
    // Exception table:
    //   from	to	target	type
    //   40	57	473	android/database/sqlite/SQLiteException
    //   65	71	473	android/database/sqlite/SQLiteException
    //   79	110	473	android/database/sqlite/SQLiteException
    //   122	131	473	android/database/sqlite/SQLiteException
    //   40	57	529	java/lang/Throwable
    //   65	71	529	java/lang/Throwable
    //   79	110	529	java/lang/Throwable
    //   122	131	529	java/lang/Throwable
    //   487	514	529	java/lang/Throwable
    //   209	226	626	android/database/sqlite/SQLiteException
    //   234	240	626	android/database/sqlite/SQLiteException
    //   248	284	626	android/database/sqlite/SQLiteException
    //   296	304	626	android/database/sqlite/SQLiteException
    //   325	334	626	android/database/sqlite/SQLiteException
    //   346	356	626	android/database/sqlite/SQLiteException
    //   375	388	626	android/database/sqlite/SQLiteException
    //   396	406	626	android/database/sqlite/SQLiteException
    //   421	434	626	android/database/sqlite/SQLiteException
    //   446	454	626	android/database/sqlite/SQLiteException
    //   558	568	626	android/database/sqlite/SQLiteException
    //   587	594	626	android/database/sqlite/SQLiteException
    //   602	623	626	android/database/sqlite/SQLiteException
    //   209	226	778	java/lang/Throwable
    //   234	240	778	java/lang/Throwable
    //   248	284	778	java/lang/Throwable
    //   296	304	778	java/lang/Throwable
    //   325	334	778	java/lang/Throwable
    //   346	356	778	java/lang/Throwable
    //   360	367	778	java/lang/Throwable
    //   375	388	778	java/lang/Throwable
    //   396	406	778	java/lang/Throwable
    //   421	434	778	java/lang/Throwable
    //   446	454	778	java/lang/Throwable
    //   558	568	778	java/lang/Throwable
    //   572	579	778	java/lang/Throwable
    //   587	594	778	java/lang/Throwable
    //   602	623	778	java/lang/Throwable
    //   632	659	778	java/lang/Throwable
    //   663	672	778	java/lang/Throwable
    //   678	687	778	java/lang/Throwable
    //   691	699	778	java/lang/Throwable
    //   707	719	778	java/lang/Throwable
    //   723	732	778	java/lang/Throwable
    //   763	773	778	java/lang/Throwable
    //   131	139	795	java/lang/Throwable
    //   143	183	795	java/lang/Throwable
    //   131	139	800	android/database/sqlite/SQLiteException
    //   143	183	800	android/database/sqlite/SQLiteException
  }
  
  public void putHit(Map paramMap, long paramLong, String paramString, Collection paramCollection)
  {
    deleteStaleHits();
    removeOldHitIfFull();
    fillVersionParameter(paramMap, paramCollection);
    writeHitToDatabase(paramMap, paramLong, paramString);
  }
  
  public void setClock(Clock paramClock)
  {
    mClock = paramClock;
  }
  
  public void setDispatch(boolean paramBoolean)
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a3 = a2\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
  }
  
  void setDispatcher(Dispatcher paramDispatcher)
  {
    mDispatcher = paramDispatcher;
  }
  
  void setLastDeleteStaleHitsTime(long paramLong)
  {
    mLastDeleteStaleHitsTime = paramLong;
  }
  
  @VisibleForTesting
  class AnalyticsDatabaseHelper
    extends SQLiteOpenHelper
  {
    private boolean mBadDatabase;
    private long mLastDatabaseCheckTime = 0L;
    
    AnalyticsDatabaseHelper(Context paramContext, String paramString)
    {
      super(paramString, null, 1);
    }
    
    private boolean tablePresent(String paramString, SQLiteDatabase paramSQLiteDatabase)
    {
      Object localObject2 = null;
      Object localObject1 = null;
      boolean bool;
      try
      {
        paramSQLiteDatabase = paramSQLiteDatabase.query("SQLITE_MASTER", new String[] { "name" }, "name=?", new String[] { paramString }, null, null, null);
        localObject2 = paramSQLiteDatabase;
        localObject1 = localObject2;
        bool = paramSQLiteDatabase.moveToFirst();
        if (paramSQLiteDatabase != null)
        {
          paramSQLiteDatabase.close();
          return bool;
        }
      }
      catch (SQLiteException paramSQLiteDatabase)
      {
        localObject2 = localObject1;
        Log.w("Error querying for table " + paramString);
        if (localObject1 != null) {
          localObject1.close();
        }
        return false;
      }
      catch (Throwable paramString)
      {
        if (localObject2 != null) {
          ((Cursor)localObject2).close();
        }
        throw paramString;
      }
      return bool;
    }
    
    private void validateColumnsPresent(SQLiteDatabase paramSQLiteDatabase)
    {
      Cursor localCursor = paramSQLiteDatabase.rawQuery("SELECT * FROM hits2 WHERE 0", null);
      HashSet localHashSet = new HashSet();
      try
      {
        String[] arrayOfString = localCursor.getColumnNames();
        i = 0;
        for (;;)
        {
          int j = arrayOfString.length;
          if (i >= j) {
            break;
          }
          localHashSet.add(arrayOfString[i]);
          i += 1;
        }
        localCursor.close();
        if ((!localHashSet.remove("hit_id")) || (!localHashSet.remove("hit_url")) || (!localHashSet.remove("hit_string")) || (!localHashSet.remove("hit_time"))) {
          throw new SQLiteException("Database column missing");
        }
      }
      catch (Throwable paramSQLiteDatabase)
      {
        localCursor.close();
        throw paramSQLiteDatabase;
      }
      if (!localHashSet.remove("hit_app_id")) {}
      for (int i = 1; !localHashSet.isEmpty(); i = 0) {
        throw new SQLiteException("Database has extra columns");
      }
      if (i != 0) {
        paramSQLiteDatabase.execSQL("ALTER TABLE hits2 ADD COLUMN hit_app_id");
      }
    }
    
    public SQLiteDatabase getWritableDatabase()
    {
      if ((mBadDatabase) && (mLastDatabaseCheckTime + 3600000L > mClock.currentTimeMillis())) {
        throw new SQLiteException("Database creation failed");
      }
      Object localObject1 = null;
      mBadDatabase = true;
      mLastDatabaseCheckTime = mClock.currentTimeMillis();
      try
      {
        localObject2 = super.getWritableDatabase();
        localObject1 = localObject2;
      }
      catch (SQLiteException localSQLiteException)
      {
        for (;;)
        {
          Object localObject2;
          mContext.getDatabasePath(mDatabaseName).delete();
        }
      }
      localObject2 = localObject1;
      if (localObject1 == null) {
        localObject2 = super.getWritableDatabase();
      }
      mBadDatabase = false;
      return localObject2;
    }
    
    boolean isBadDatabase()
    {
      return mBadDatabase;
    }
    
    public void onCreate(SQLiteDatabase paramSQLiteDatabase)
    {
      FutureApis.setOwnerOnlyReadWrite(paramSQLiteDatabase.getPath());
    }
    
    public void onOpen(SQLiteDatabase paramSQLiteDatabase)
    {
      Cursor localCursor;
      if (Build.VERSION.SDK_INT < 15) {
        localCursor = paramSQLiteDatabase.rawQuery("PRAGMA journal_mode=memory", null);
      }
      try
      {
        localCursor.moveToFirst();
        localCursor.close();
        if (!tablePresent("hits2", paramSQLiteDatabase))
        {
          paramSQLiteDatabase.execSQL(PersistentAnalyticsStore.CREATE_HITS_TABLE);
          return;
        }
      }
      catch (Throwable paramSQLiteDatabase)
      {
        localCursor.close();
        throw paramSQLiteDatabase;
      }
      validateColumnsPresent(paramSQLiteDatabase);
    }
    
    public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {}
    
    void setBadDatabase(boolean paramBoolean)
    {
      mBadDatabase = paramBoolean;
    }
  }
}
