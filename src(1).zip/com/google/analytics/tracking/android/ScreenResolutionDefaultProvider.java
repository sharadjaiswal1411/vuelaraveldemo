package com.google.analytics.tracking.android;

import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;

class ScreenResolutionDefaultProvider
  implements DefaultProvider
{
  private static ScreenResolutionDefaultProvider sInstance;
  private static Object sInstanceLock = new Object();
  private final Context mContext;
  
  protected ScreenResolutionDefaultProvider(Context paramContext)
  {
    mContext = paramContext;
  }
  
  static void dropInstance()
  {
    Object localObject = sInstanceLock;
    try
    {
      sInstance = null;
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public static ScreenResolutionDefaultProvider getProvider()
  {
    Object localObject = sInstanceLock;
    try
    {
      ScreenResolutionDefaultProvider localScreenResolutionDefaultProvider = sInstance;
      return localScreenResolutionDefaultProvider;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public static void initializeProvider(Context paramContext)
  {
    Object localObject = sInstanceLock;
    try
    {
      if (sInstance == null) {
        sInstance = new ScreenResolutionDefaultProvider(paramContext);
      }
      return;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  protected String getScreenResolutionString()
  {
    DisplayMetrics localDisplayMetrics = mContext.getResources().getDisplayMetrics();
    return widthPixels + "x" + heightPixels;
  }
  
  public String getValue(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    if (paramString.equals("&sr")) {
      return getScreenResolutionString();
    }
    return null;
  }
  
  public boolean providesField(String paramString)
  {
    return "&sr".equals(paramString);
  }
}
