package com.google.analytics.tracking.android;

import java.util.List;
import java.util.Map;

abstract interface ServiceProxy
{
  public abstract void clearHits();
  
  public abstract void createService();
  
  public abstract void dispatch();
  
  public abstract void putHit(Map paramMap, long paramLong, String paramString, List paramList);
  
  public abstract void setForceLocalDispatch();
}
