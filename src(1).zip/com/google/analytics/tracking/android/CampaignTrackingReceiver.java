package com.google.analytics.tracking.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class CampaignTrackingReceiver
  extends BroadcastReceiver
{
  static final String CAMPAIGN_KEY = "referrer";
  static final String INSTALL_ACTION = "com.android.vending.INSTALL_REFERRER";
  
  public CampaignTrackingReceiver() {}
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    String str = paramIntent.getStringExtra("referrer");
    if ("com.android.vending.INSTALL_REFERRER".equals(paramIntent.getAction()))
    {
      if (str == null) {
        return;
      }
      paramIntent = new Intent(paramContext, CampaignTrackingService.class);
      paramIntent.putExtra("referrer", str);
      paramContext.startService(paramIntent);
    }
  }
}
