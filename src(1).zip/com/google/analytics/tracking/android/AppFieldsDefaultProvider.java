package com.google.analytics.tracking.android;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;

class AppFieldsDefaultProvider
  implements DefaultProvider
{
  private static AppFieldsDefaultProvider sInstance;
  private static Object sInstanceLock = new Object();
  protected String mAppId;
  protected String mAppInstallerId;
  protected String mAppName;
  protected String mAppVersion;
  
  protected AppFieldsDefaultProvider() {}
  
  private AppFieldsDefaultProvider(Context paramContext)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    mAppId = paramContext.getPackageName();
    mAppInstallerId = localPackageManager.getInstallerPackageName(mAppId);
    str = mAppId;
    localObject2 = null;
    try
    {
      PackageInfo localPackageInfo = localPackageManager.getPackageInfo(paramContext.getPackageName(), 0);
      localObject1 = localObject2;
      paramContext = str;
      if (localPackageInfo != null)
      {
        paramContext = applicationInfo;
        paramContext = localPackageManager.getApplicationLabel(paramContext).toString();
        localObject1 = versionName;
      }
    }
    catch (PackageManager.NameNotFoundException paramContext)
    {
      for (;;)
      {
        Log.e("Error retrieving package info: appName set to " + str);
        Object localObject1 = localObject2;
        paramContext = str;
      }
    }
    mAppName = paramContext;
    mAppVersion = ((String)localObject1);
  }
  
  static void dropInstance()
  {
    Object localObject = sInstanceLock;
    try
    {
      sInstance = null;
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public static AppFieldsDefaultProvider getProvider()
  {
    return sInstance;
  }
  
  public static void initializeProvider(Context paramContext)
  {
    Object localObject = sInstanceLock;
    try
    {
      if (sInstance == null) {
        sInstance = new AppFieldsDefaultProvider(paramContext);
      }
      return;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public String getValue(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    if (paramString.equals("&an")) {
      return mAppName;
    }
    if (paramString.equals("&av")) {
      return mAppVersion;
    }
    if (paramString.equals("&aid")) {
      return mAppId;
    }
    if (paramString.equals("&aiid")) {
      return mAppInstallerId;
    }
    return null;
  }
  
  public boolean providesField(String paramString)
  {
    return ("&an".equals(paramString)) || ("&av".equals(paramString)) || ("&aid".equals(paramString)) || ("&aiid".equals(paramString));
  }
}
