package com.google.analytics.tracking.android;

class SendHitRateLimiter
  implements RateLimiter
{
  private long mLastTrackTime;
  private final int mMaxTokens;
  private final long mMillisecondsPerToken;
  private final Object mTokenLock = new Object();
  private double mTokens;
  
  public SendHitRateLimiter()
  {
    this(60, 2000L);
  }
  
  public SendHitRateLimiter(int paramInt, long paramLong)
  {
    mMaxTokens = paramInt;
    mTokens = mMaxTokens;
    mMillisecondsPerToken = paramLong;
  }
  
  void setLastTrackTime(long paramLong)
  {
    mLastTrackTime = paramLong;
  }
  
  void setTokensAvailable(long paramLong)
  {
    mTokens = paramLong;
  }
  
  public boolean tokenAvailable()
  {
    Object localObject = mTokenLock;
    try
    {
      long l = System.currentTimeMillis();
      if (mTokens < mMaxTokens)
      {
        double d = (l - mLastTrackTime) / mMillisecondsPerToken;
        if (d > 0.0D) {
          mTokens = Math.min(mMaxTokens, mTokens + d);
        }
      }
      mLastTrackTime = l;
      if (mTokens >= 1.0D)
      {
        mTokens -= 1.0D;
        return true;
      }
      Log.w("Excessive tracking detected.  Tracking call ignored.");
      return false;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
}
