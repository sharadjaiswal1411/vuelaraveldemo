package com.google.analytics.tracking.android;

public abstract class ServiceManager
{
  public ServiceManager() {}
  
  public abstract void dispatchLocalHits();
  
  abstract void onRadioPowered();
  
  public abstract void setForceLocalDispatch();
  
  public abstract void setLocalDispatchPeriod(int paramInt);
  
  abstract void updateConnectivityStatus(boolean paramBoolean);
}
