package com.google.analytics.tracking.android;

abstract interface DefaultProvider
{
  public abstract String getValue(String paramString);
  
  public abstract boolean providesField(String paramString);
}
