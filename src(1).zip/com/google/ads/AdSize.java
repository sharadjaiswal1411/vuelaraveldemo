package com.google.ads;

import android.content.Context;

@Deprecated
public final class AdSize
{
  public static final int AUTO_HEIGHT = -2;
  public static final AdSize BANNER;
  public static final int FULL_WIDTH = -1;
  public static final AdSize IAB_BANNER = new AdSize(468, 60, "as");
  public static final AdSize IAB_LEADERBOARD = new AdSize(728, 90, "as");
  public static final AdSize IAB_MRECT;
  public static final AdSize IAB_WIDE_SKYSCRAPER = new AdSize(160, 600, "as");
  public static final int LANDSCAPE_AD_HEIGHT = 32;
  public static final int LARGE_AD_HEIGHT = 90;
  public static final int PORTRAIT_AD_HEIGHT = 50;
  public static final AdSize SMART_BANNER = new AdSize(-1, -2, "mb");
  private final com.google.android.com.ads.AdSize data;
  
  static
  {
    BANNER = new AdSize(320, 50, "mb");
    IAB_MRECT = new AdSize(300, 250, "as");
  }
  
  public AdSize(int paramInt1, int paramInt2)
  {
    this(new com.google.android.com.ads.AdSize(paramInt1, paramInt2));
  }
  
  private AdSize(int paramInt1, int paramInt2, String paramString)
  {
    this(new com.google.android.com.ads.AdSize(paramInt1, paramInt2));
  }
  
  public AdSize(com.google.android.com.ads.AdSize paramAdSize)
  {
    data = paramAdSize;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof AdSize)) {
      return false;
    }
    paramObject = (AdSize)paramObject;
    return data.equals(data);
  }
  
  public AdSize findBestSize(AdSize... paramVarArgs)
  {
    Object localObject = null;
    if (paramVarArgs == null) {
      return null;
    }
    float f1 = 0.0F;
    int j = getWidth();
    int k = getHeight();
    int m = paramVarArgs.length;
    int i = 0;
    if (i < m)
    {
      AdSize localAdSize = paramVarArgs[i];
      int n = localAdSize.getWidth();
      int i1 = localAdSize.getHeight();
      float f2;
      if (isSizeAppropriate(n, i1))
      {
        float f3 = n * i1 / (j * k);
        f2 = f3;
        if (f3 > 1.0F) {
          f2 = 1.0F / f3;
        }
        if (f2 > f1) {
          localObject = localAdSize;
        }
      }
      for (;;)
      {
        i += 1;
        f1 = f2;
        break;
        f2 = f1;
      }
    }
    return localObject;
  }
  
  public int getHeight()
  {
    return data.getHeight();
  }
  
  public int getHeightInPixels(Context paramContext)
  {
    return data.getHeightInPixels(paramContext);
  }
  
  public int getWidth()
  {
    return data.getWidth();
  }
  
  public int getWidthInPixels(Context paramContext)
  {
    return data.getWidthInPixels(paramContext);
  }
  
  public int hashCode()
  {
    return data.hashCode();
  }
  
  public boolean isAutoHeight()
  {
    return data.isAutoHeight();
  }
  
  public boolean isCustomAdSize()
  {
    return false;
  }
  
  public boolean isFullWidth()
  {
    return data.isFullWidth();
  }
  
  public boolean isSizeAppropriate(int paramInt1, int paramInt2)
  {
    int i = getWidth();
    int j = getHeight();
    return (paramInt1 <= i * 1.25F) && (paramInt1 >= i * 0.8F) && (paramInt2 <= j * 1.25F) && (paramInt2 >= j * 0.8F);
  }
  
  public String toString()
  {
    return data.toString();
  }
}
