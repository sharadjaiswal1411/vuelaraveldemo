package com.google.ads.mediation;

import android.location.Location;
import com.google.ads.AdRequest.Gender;
import java.util.Date;
import java.util.Set;

@Deprecated
public final class MediationAdRequest
{
  private final Date birthday;
  private final boolean element;
  private final AdRequest.Gender gender;
  private final Set<String> keywords;
  private final Location location;
  
  public MediationAdRequest(Date paramDate, AdRequest.Gender paramGender, Set paramSet, boolean paramBoolean, Location paramLocation)
  {
    birthday = paramDate;
    gender = paramGender;
    keywords = paramSet;
    element = paramBoolean;
    location = paramLocation;
  }
  
  public Integer getAgeInYears()
  {
    return null;
  }
  
  public Date getBirthday()
  {
    return birthday;
  }
  
  public AdRequest.Gender getGender()
  {
    return gender;
  }
  
  public Set getKeywords()
  {
    return keywords;
  }
  
  public Location getLocation()
  {
    return location;
  }
  
  public boolean isTesting()
  {
    return element;
  }
}
