package com.google.ads.mediation.customevent;

@Deprecated
public abstract interface CustomEvent
{
  public abstract void destroy();
}
