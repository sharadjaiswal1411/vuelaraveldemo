package com.google.ads.mediation.customevent;

import android.app.Activity;
import android.view.View;
import com.google.ads.AdRequest.ErrorCode;
import com.google.ads.AdSize;
import com.google.ads.mediation.MediationAdRequest;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.android.com.internal.StringBuilder;

public final class CustomEventAdapter
  implements MediationBannerAdapter<com.google.android.gms.ads.mediation.customevent.CustomEventExtras, CustomEventServerParameters>, MediationInterstitialAdapter<com.google.android.gms.ads.mediation.customevent.CustomEventExtras, CustomEventServerParameters>
{
  private CustomEventBanner INTERNAL_ERROR;
  private View g;
  private CustomEventInterstitial this$0;
  
  public CustomEventAdapter() {}
  
  private static Object newInstance(String paramString)
  {
    try
    {
      Object localObject = Class.forName(paramString).newInstance();
      return localObject;
    }
    catch (Throwable localThrowable)
    {
      StringBuilder.d("Could not instantiate custom event adapter: " + paramString + ". " + localThrowable.getMessage());
    }
    return null;
  }
  
  private void startGame(View paramView)
  {
    g = paramView;
  }
  
  public void destroy()
  {
    if (INTERNAL_ERROR != null) {
      INTERNAL_ERROR.destroy();
    }
    if (this$0 != null) {
      this$0.destroy();
    }
  }
  
  public Class getAdditionalParametersType()
  {
    return com.google.android.gms.ads.mediation.customevent.CustomEventExtras.class;
  }
  
  public View getBannerView()
  {
    return g;
  }
  
  public Class getServerParametersType()
  {
    return CustomEventServerParameters.class;
  }
  
  public void requestBannerAd(MediationBannerListener paramMediationBannerListener, Activity paramActivity, CustomEventServerParameters paramCustomEventServerParameters, AdSize paramAdSize, MediationAdRequest paramMediationAdRequest, com.google.android.com.ads.mediation.customevent.CustomEventExtras paramCustomEventExtras)
  {
    INTERNAL_ERROR = ((CustomEventBanner)newInstance(className));
    if (INTERNAL_ERROR == null)
    {
      paramMediationBannerListener.onFailedToReceiveAd(this, AdRequest.ErrorCode.INTERNAL_ERROR);
      return;
    }
    if (paramCustomEventExtras == null) {}
    for (paramCustomEventExtras = null;; paramCustomEventExtras = paramCustomEventExtras.getExtra(label))
    {
      INTERNAL_ERROR.requestBannerAd(new a(this, paramMediationBannerListener), paramActivity, label, parameter, paramAdSize, paramMediationAdRequest, paramCustomEventExtras);
      return;
    }
  }
  
  public void requestInterstitialAd(MediationInterstitialListener paramMediationInterstitialListener, Activity paramActivity, CustomEventServerParameters paramCustomEventServerParameters, MediationAdRequest paramMediationAdRequest, com.google.android.com.ads.mediation.customevent.CustomEventExtras paramCustomEventExtras)
  {
    this$0 = ((CustomEventInterstitial)newInstance(className));
    if (this$0 == null)
    {
      paramMediationInterstitialListener.onFailedToReceiveAd(this, AdRequest.ErrorCode.INTERNAL_ERROR);
      return;
    }
    if (paramCustomEventExtras == null) {}
    for (paramCustomEventExtras = null;; paramCustomEventExtras = paramCustomEventExtras.getExtra(label))
    {
      this$0.requestInterstitialAd(new b(this, paramMediationInterstitialListener), paramActivity, label, parameter, paramMediationAdRequest, paramCustomEventExtras);
      return;
    }
  }
  
  public void showInterstitial()
  {
    this$0.showInterstitial();
  }
  
  private static final class a
    implements CustomEventBannerListener
  {
    private final CustomEventAdapter val$checkedItems;
    private final MediationBannerListener val$listener;
    
    public a(CustomEventAdapter paramCustomEventAdapter, MediationBannerListener paramMediationBannerListener)
    {
      val$checkedItems = paramCustomEventAdapter;
      val$listener = paramMediationBannerListener;
    }
    
    public void onClick()
    {
      StringBuilder.v("Custom event adapter called onFailedToReceiveAd.");
      val$listener.onClick(val$checkedItems);
    }
    
    public void onDismissScreen()
    {
      StringBuilder.v("Custom event adapter called onFailedToReceiveAd.");
      val$listener.onDismissScreen(val$checkedItems);
    }
    
    public void onFailedToReceiveAd()
    {
      StringBuilder.v("Custom event adapter called onFailedToReceiveAd.");
      val$listener.onFailedToReceiveAd(val$checkedItems, AdRequest.ErrorCode.NO_FILL);
    }
    
    public void onLeaveApplication()
    {
      StringBuilder.v("Custom event adapter called onFailedToReceiveAd.");
      val$listener.onLeaveApplication(val$checkedItems);
    }
    
    public void onPresentScreen()
    {
      StringBuilder.v("Custom event adapter called onFailedToReceiveAd.");
      val$listener.onPresentScreen(val$checkedItems);
    }
    
    public void onReceivedAd(View paramView)
    {
      StringBuilder.v("Custom event adapter called onReceivedAd.");
      CustomEventAdapter.onClick(val$checkedItems, paramView);
      val$listener.onReceivedAd(val$checkedItems);
    }
  }
  
  private class b
    implements CustomEventInterstitialListener
  {
    private final MediationInterstitialListener ecSpec;
    private final CustomEventAdapter publicKey;
    
    public b(CustomEventAdapter paramCustomEventAdapter, MediationInterstitialListener paramMediationInterstitialListener)
    {
      publicKey = paramCustomEventAdapter;
      ecSpec = paramMediationInterstitialListener;
    }
    
    public void onDismissScreen()
    {
      StringBuilder.v("Custom event adapter called onDismissScreen.");
      ecSpec.onDismissScreen(publicKey);
    }
    
    public void onFailedToReceiveAd()
    {
      StringBuilder.v("Custom event adapter called onFailedToReceiveAd.");
      ecSpec.onFailedToReceiveAd(publicKey, AdRequest.ErrorCode.NO_FILL);
    }
    
    public void onLeaveApplication()
    {
      StringBuilder.v("Custom event adapter called onLeaveApplication.");
      ecSpec.onLeaveApplication(publicKey);
    }
    
    public void onPresentScreen()
    {
      StringBuilder.v("Custom event adapter called onPresentScreen.");
      ecSpec.onPresentScreen(publicKey);
    }
    
    public void onReceivedAd()
    {
      StringBuilder.v("Custom event adapter called onReceivedAd.");
      ecSpec.onReceivedAd(CustomEventAdapter.this);
    }
  }
}
