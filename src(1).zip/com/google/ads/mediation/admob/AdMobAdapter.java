package com.google.ads.mediation.admob;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import com.google.android.com.ads.AdListener;
import com.google.android.com.ads.AdRequest;
import com.google.android.com.ads.AdRequest.Builder;
import com.google.android.com.ads.AdSize;
import com.google.android.com.ads.AdView;
import com.google.android.com.ads.InterstitialAd;
import com.google.android.com.ads.mediation.MediationAdRequest;
import com.google.android.com.ads.mediation.MediationBannerAdapter;
import com.google.android.com.ads.mediation.MediationBannerListener;
import com.google.android.com.ads.mediation.MediationInterstitialAdapter;
import com.google.android.com.ads.mediation.MediationInterstitialListener;
import com.google.android.com.internal.MyLog;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

public final class AdMobAdapter
  implements MediationBannerAdapter, MediationInterstitialAdapter
{
  private InterstitialAd mApp;
  private AdView mModel;
  
  public AdMobAdapter() {}
  
  private static AdRequest onPostExecute(Context paramContext, MediationAdRequest paramMediationAdRequest, Bundle paramBundle1, Bundle paramBundle2)
  {
    AdRequest.Builder localBuilder = new AdRequest.Builder();
    Object localObject = paramMediationAdRequest.getBirthday();
    if (localObject != null) {
      localBuilder.setBirthday((Date)localObject);
    }
    int i = paramMediationAdRequest.getGender();
    if (i != 0) {
      localBuilder.setGender(i);
    }
    localObject = paramMediationAdRequest.getKeywords();
    if (localObject != null)
    {
      localObject = ((Set)localObject).iterator();
      while (((Iterator)localObject).hasNext()) {
        localBuilder.addKeyword((String)((Iterator)localObject).next());
      }
    }
    if (paramMediationAdRequest.isTesting()) {
      localBuilder.addTestDevice(MyLog.getName(paramContext));
    }
    boolean bool;
    if (paramBundle2.getInt("tagForChildDirectedTreatment") != -1)
    {
      if (paramBundle2.getInt("tagForChildDirectedTreatment") == 1)
      {
        bool = true;
        localBuilder.tagForChildDirectedTreatment(bool);
      }
    }
    else {
      if (paramBundle1 == null) {
        break label227;
      }
    }
    for (;;)
    {
      paramBundle1.putInt("gw", 1);
      paramBundle1.putString("mad_hac", paramBundle2.getString("mad_hac"));
      if (!TextUtils.isEmpty(paramBundle2.getString("adJson"))) {
        paramBundle1.putString("_ad", paramBundle2.getString("adJson"));
      }
      paramBundle1.putBoolean("_noRefresh", true);
      localBuilder.addNetworkExtrasBundle(AdMobAdapter.class, paramBundle1);
      return localBuilder.build();
      bool = false;
      break;
      label227:
      paramBundle1 = new Bundle();
    }
  }
  
  public View getBannerView()
  {
    return mModel;
  }
  
  public void onDestroy()
  {
    if (mModel != null)
    {
      mModel.destroy();
      mModel = null;
    }
    if (mApp != null) {
      mApp = null;
    }
  }
  
  public void onPause()
  {
    if (mModel != null) {
      mModel.pause();
    }
  }
  
  public void onResume()
  {
    if (mModel != null) {
      mModel.resume();
    }
  }
  
  public void requestBannerAd(Context paramContext, MediationBannerListener paramMediationBannerListener, Bundle paramBundle1, AdSize paramAdSize, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2)
  {
    mModel = new AdView(paramContext);
    mModel.setAdSize(new AdSize(paramAdSize.getWidth(), paramAdSize.getHeight()));
    mModel.setAdUnitId(paramBundle1.getString("pubid"));
    mModel.setAdListener(new a(this, paramMediationBannerListener));
    mModel.loadAd(onPostExecute(paramContext, paramMediationAdRequest, paramBundle2, paramBundle1));
  }
  
  public void requestInterstitialAd(Context paramContext, MediationInterstitialListener paramMediationInterstitialListener, Bundle paramBundle1, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2)
  {
    mApp = new InterstitialAd(paramContext);
    mApp.setAdUnitId(paramBundle1.getString("pubid"));
    mApp.setAdListener(new b(this, paramMediationInterstitialListener));
    mApp.loadAd(onPostExecute(paramContext, paramMediationAdRequest, paramBundle2, paramBundle1));
  }
  
  public void showInterstitial()
  {
    mApp.show();
  }
  
  private static final class a
    extends AdListener
  {
    private final AdMobAdapter dep;
    private final MediationBannerListener products;
    
    public a(AdMobAdapter paramAdMobAdapter, MediationBannerListener paramMediationBannerListener)
    {
      dep = paramAdMobAdapter;
      products = paramMediationBannerListener;
    }
    
    public void onAdClosed()
    {
      products.onAdClosed(dep);
    }
    
    public void onAdFailedToLoad(int paramInt)
    {
      products.onAdFailedToLoad(dep, paramInt);
    }
    
    public void onAdLeftApplication()
    {
      products.onAdLeftApplication(dep);
    }
    
    public void onAdLoaded()
    {
      products.onAdLoaded(dep);
    }
    
    public void onAdOpened()
    {
      products.onAdClicked(dep);
      products.onAdOpened(dep);
    }
  }
  
  private static final class b
    extends AdListener
  {
    private final AdMobAdapter dep;
    private final MediationInterstitialListener products;
    
    public b(AdMobAdapter paramAdMobAdapter, MediationInterstitialListener paramMediationInterstitialListener)
    {
      dep = paramAdMobAdapter;
      products = paramMediationInterstitialListener;
    }
    
    public void onAdClosed()
    {
      products.onAdClosed(dep);
    }
    
    public void onAdFailedToLoad(int paramInt)
    {
      products.onAdFailedToLoad(dep, paramInt);
    }
    
    public void onAdLeftApplication()
    {
      products.onAdLeftApplication(dep);
    }
    
    public void onAdLoaded()
    {
      products.onAdLoaded(dep);
    }
    
    public void onAdOpened()
    {
      products.onAdOpened(dep);
    }
  }
}
