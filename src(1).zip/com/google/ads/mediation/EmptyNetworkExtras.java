package com.google.ads.mediation;

@Deprecated
public final class EmptyNetworkExtras
  implements NetworkExtras
{
  public EmptyNetworkExtras() {}
}
