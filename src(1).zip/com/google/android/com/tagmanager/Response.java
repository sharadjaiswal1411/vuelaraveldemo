package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class Response
  extends Message
{
  private static final String description = Priority.W.toString();
  
  public Response()
  {
    super(description, new String[0]);
  }
  
  public boolean equals()
  {
    return false;
  }
  
  public Integer evaluate(Map paramMap)
  {
    return Boolean.add(Long.valueOf(System.currentTimeMillis()));
  }
}
