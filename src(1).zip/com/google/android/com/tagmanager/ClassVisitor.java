package com.google.android.com.tagmanager;

class ClassVisitor
  implements m.a
{
  ClassVisitor() {}
  
  public aa a()
  {
    return new w();
  }
  
  public Menu add()
  {
    return new MenuWrapper();
  }
}
