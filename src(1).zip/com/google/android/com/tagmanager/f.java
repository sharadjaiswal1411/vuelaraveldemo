package com.google.android.com.tagmanager;

import android.content.Context;
import com.google.android.gms.internal.c.j;
import com.google.android.gms.tagmanager.bg;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

class f
  implements Item
{
  private final String a;
  private Label b;
  private bg<c.j> c;
  private final ScheduledExecutorService e;
  private ScheduledFuture<?> f;
  private final co.a i;
  private boolean mClosed;
  private final Context mContext;
  private String s;
  
  public f(Context paramContext, String paramString, Label paramLabel)
  {
    this(paramContext, paramString, paramLabel, null, null);
  }
  
  f(Context paramContext, String paramString, Label paramLabel, co.b paramB, co.a paramA) {}
  
  private b c(String paramString)
  {
    b localB = i.a(b);
    localB.a(c);
    localB.a(s);
    localB.b(paramString);
    return localB;
  }
  
  private void close()
  {
    try
    {
      if (mClosed) {
        throw new IllegalStateException("called method after closed");
      }
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public void a(long paramLong, String paramString)
  {
    try
    {
      Log.w("loadAfterDelay: containerId=" + a + " delay=" + paramLong);
      close();
      if (c == null) {
        throw new IllegalStateException("callback must be set before loadAfterDelay() is called.");
      }
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
    if (f != null) {
      f.cancel(false);
    }
    f = e.schedule(c(paramString), paramLong, TimeUnit.MILLISECONDS);
  }
  
  public void a(c paramC)
  {
    try
    {
      close();
      c = paramC;
      return;
    }
    catch (Throwable paramC)
    {
      throw paramC;
    }
  }
  
  public void a(String paramString)
  {
    try
    {
      close();
      s = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void release()
  {
    try
    {
      close();
      if (f != null) {
        f.cancel(false);
      }
      e.shutdown();
      mClosed = true;
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
}
