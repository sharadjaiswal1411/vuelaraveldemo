package com.google.android.com.tagmanager;

import com.google.android.com.common.ClickListeners.Releasable;

abstract interface Item
  extends Releasable
{
  public abstract void a(long paramLong, String paramString);
  
  public abstract void a(c paramC);
  
  public abstract void a(String paramString);
}
