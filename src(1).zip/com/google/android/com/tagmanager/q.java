package com.google.android.com.tagmanager;

abstract interface q
{
  public abstract i.a a(String paramString);
  
  public abstract i.a b(String paramString);
  
  public abstract boolean b();
}
