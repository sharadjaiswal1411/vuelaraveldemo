package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class DataTypeIDLookup
  extends Message
{
  private static final String TAG = Priority.level.toString();
  
  public DataTypeIDLookup()
  {
    super(TAG, new String[0]);
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    return Boolean.add("4.00");
  }
}
