package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import com.google.android.com.internal.class_3;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

class Config
  extends Variance
{
  private static final String ID = Priority.message.toString();
  private static final String mKey = class_3.code.toString();
  
  public Config()
  {
    super(ID);
  }
  
  protected boolean apply(String paramString1, String paramString2, Map paramMap)
  {
    if (Boolean.valueOf((Integer)paramMap.get(mKey)).booleanValue()) {}
    for (int i = 66;; i = 64) {
      try
      {
        boolean bool = Pattern.compile(paramString2, i).matcher(paramString1).find();
        return bool;
      }
      catch (PatternSyntaxException paramString1)
      {
        return false;
      }
    }
  }
}
