package com.google.android.com.tagmanager;

import android.content.Context;
import android.os.Process;
import com.google.android.com.ads.identifier.AdvertisingIdClient.Info;
import com.google.android.com.internal.Clock;
import com.google.android.com.internal.SystemClock;

class Dictionary
{
  private static Dictionary cache;
  private static Object input = new Object();
  private volatile AdvertisingIdClient.Info current;
  private volatile long delay = 900000L;
  private volatile long finished;
  private volatile boolean mClosed = false;
  private final Context mContext;
  private final Clock this$0;
  private final Thread thread;
  private volatile long timeout = 30000L;
  private DataSource view = new FileHandle(this);
  
  private Dictionary(Context paramContext)
  {
    this(paramContext, null, SystemClock.get());
  }
  
  Dictionary(Context paramContext, DataSource paramDataSource, Clock paramClock)
  {
    this$0 = paramClock;
    if (paramContext != null) {}
    for (mContext = paramContext.getApplicationContext();; mContext = paramContext)
    {
      if (paramDataSource != null) {
        view = paramDataSource;
      }
      thread = new Thread(new MonthByWeekFragment.2(this));
      return;
    }
  }
  
  static Dictionary close(Context paramContext)
  {
    Object localObject;
    if (cache == null) {
      localObject = input;
    }
    try
    {
      if (cache == null)
      {
        cache = new Dictionary(paramContext);
        cache.start();
      }
      return cache;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  private void close()
  {
    if (this$0.currentTimeMillis() - finished < timeout) {
      return;
    }
    interrupt();
    finished = this$0.currentTimeMillis();
  }
  
  private void run()
  {
    Process.setThreadPriority(10);
    while (!mClosed)
    {
      Object localObject = view;
      try
      {
        localObject = ((DataSource)localObject).getProgress();
        current = ((AdvertisingIdClient.Info)localObject);
        long l = delay;
        Thread.sleep(l);
      }
      catch (InterruptedException localInterruptedException)
      {
        Log.i("sleep interrupted in AdvertiserDataPoller thread; continuing");
      }
    }
  }
  
  public String get()
  {
    close();
    if (current == null) {
      return null;
    }
    return current.getId();
  }
  
  void interrupt()
  {
    thread.interrupt();
  }
  
  public boolean isLimitAdTrackingEnabled()
  {
    close();
    if (current == null) {
      return true;
    }
    return current.isLimitAdTrackingEnabled();
  }
  
  void start()
  {
    thread.start();
  }
}
