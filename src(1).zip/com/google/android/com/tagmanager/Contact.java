package com.google.android.com.tagmanager;

import android.content.Context;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class Contact
  extends Message
{
  private static final String DEFAULT_KEYSTORE_PATH = Priority.d.toString();
  private final Dictionary prefix;
  
  public Contact(Context paramContext)
  {
    this(Dictionary.close(paramContext));
  }
  
  Contact(Dictionary paramDictionary)
  {
    super(DEFAULT_KEYSTORE_PATH, new String[0]);
    prefix = paramDictionary;
  }
  
  public boolean equals()
  {
    return false;
  }
  
  public Integer evaluate(Map paramMap)
  {
    if (!prefix.isLimitAdTrackingEnabled()) {}
    for (boolean bool = true;; bool = false) {
      return Boolean.add(java.lang.Boolean.valueOf(bool));
    }
  }
}
