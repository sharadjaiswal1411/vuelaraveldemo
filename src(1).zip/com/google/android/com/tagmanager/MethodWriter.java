package com.google.android.com.tagmanager;

import android.os.Looper;
import com.google.android.com.common.ClickListeners.Status;

class MethodWriter
  implements ContainerHolder
{
  private Container a;
  private x b;
  private Start c;
  private final Looper d;
  private boolean e;
  private Container f;
  private Status i;
  private TagManager this$0;
  
  public MethodWriter(Status paramStatus)
  {
    i = paramStatus;
    d = null;
  }
  
  public MethodWriter(TagManager paramTagManager, Looper paramLooper, Container paramContainer, x paramX)
  {
    this$0 = paramTagManager;
    if (paramLooper != null) {}
    for (;;)
    {
      d = paramLooper;
      a = paramContainer;
      b = paramX;
      i = Status.type;
      paramTagManager.a(this);
      return;
      paramLooper = Looper.getMainLooper();
    }
  }
  
  private void f()
  {
    if (c != null) {
      c.close(f.close());
    }
  }
  
  public void a(Container paramContainer)
  {
    for (;;)
    {
      try
      {
        boolean bool = e;
        if (bool) {
          return;
        }
        if (paramContainer == null)
        {
          Log.e("Unexpected null container.");
          continue;
        }
        f = paramContainer;
      }
      catch (Throwable paramContainer)
      {
        throw paramContainer;
      }
      f();
    }
  }
  
  void a(String paramString)
  {
    if (e)
    {
      Log.e("setCtfeUrlPathAndQuery called on a released ContainerHolder.");
      return;
    }
    b.a(paramString);
  }
  
  /* Error */
  public void b(String paramString)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 76	com/google/android/com/tagmanager/MethodWriter:e	Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifeq +6 -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: getfield 40	com/google/android/com/tagmanager/MethodWriter:a	Lcom/google/android/com/tagmanager/Container;
    //   18: aload_1
    //   19: invokevirtual 90	com/google/android/com/tagmanager/Container:f	(Ljava/lang/String;)V
    //   22: goto -11 -> 11
    //   25: astore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_1
    //   29: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	30	0	this	MethodWriter
    //   0	30	1	paramString	String
    //   6	2	2	bool	boolean
    // Exception table:
    //   from	to	target	type
    //   2	7	25	java/lang/Throwable
    //   14	22	25	java/lang/Throwable
  }
  
  String c()
  {
    if (e)
    {
      Log.e("setCtfeUrlPathAndQuery called on a released ContainerHolder.");
      return "";
    }
    return b.c();
  }
  
  /* Error */
  public Container getContainer()
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield 76	com/google/android/com/tagmanager/MethodWriter:e	Z
    //   8: ifeq +12 -> 20
    //   11: ldc 98
    //   13: invokestatic 82	com/google/android/com/tagmanager/Log:e	(Ljava/lang/String;)V
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_1
    //   19: areturn
    //   20: aload_0
    //   21: getfield 62	com/google/android/com/tagmanager/MethodWriter:f	Lcom/google/android/com/tagmanager/Container;
    //   24: ifnull +16 -> 40
    //   27: aload_0
    //   28: aload_0
    //   29: getfield 62	com/google/android/com/tagmanager/MethodWriter:f	Lcom/google/android/com/tagmanager/Container;
    //   32: putfield 40	com/google/android/com/tagmanager/MethodWriter:a	Lcom/google/android/com/tagmanager/Container;
    //   35: aload_0
    //   36: aconst_null
    //   37: putfield 62	com/google/android/com/tagmanager/MethodWriter:f	Lcom/google/android/com/tagmanager/Container;
    //   40: aload_0
    //   41: getfield 40	com/google/android/com/tagmanager/MethodWriter:a	Lcom/google/android/com/tagmanager/Container;
    //   44: astore_1
    //   45: goto -29 -> 16
    //   48: astore_1
    //   49: aload_0
    //   50: monitorexit
    //   51: aload_1
    //   52: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	53	0	this	MethodWriter
    //   1	44	1	localContainer	Container
    //   48	4	1	localThrowable	Throwable
    // Exception table:
    //   from	to	target	type
    //   4	16	48	java/lang/Throwable
    //   20	40	48	java/lang/Throwable
    //   40	45	48	java/lang/Throwable
  }
  
  String getContainerId()
  {
    if (e)
    {
      Log.e("getContainerId called on a released ContainerHolder.");
      return "";
    }
    return a.getContainerId();
  }
  
  public Status getStatus()
  {
    return i;
  }
  
  /* Error */
  public void refresh()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 76	com/google/android/com/tagmanager/MethodWriter:e	Z
    //   6: ifeq +11 -> 17
    //   9: ldc 108
    //   11: invokestatic 82	com/google/android/com/tagmanager/Log:e	(Ljava/lang/String;)V
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: aload_0
    //   18: getfield 42	com/google/android/com/tagmanager/MethodWriter:b	Lcom/google/android/com/tagmanager/x;
    //   21: invokeinterface 110 1 0
    //   26: goto -12 -> 14
    //   29: astore_1
    //   30: aload_0
    //   31: monitorexit
    //   32: aload_1
    //   33: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	34	0	this	MethodWriter
    //   29	4	1	localThrowable	Throwable
    // Exception table:
    //   from	to	target	type
    //   2	14	29	java/lang/Throwable
    //   17	26	29	java/lang/Throwable
  }
  
  /* Error */
  public void release()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 76	com/google/android/com/tagmanager/MethodWriter:e	Z
    //   6: ifeq +11 -> 17
    //   9: ldc 113
    //   11: invokestatic 82	com/google/android/com/tagmanager/Log:e	(Ljava/lang/String;)V
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: aload_0
    //   18: iconst_1
    //   19: putfield 76	com/google/android/com/tagmanager/MethodWriter:e	Z
    //   22: aload_0
    //   23: getfield 38	com/google/android/com/tagmanager/MethodWriter:this$0	Lcom/google/android/com/tagmanager/TagManager;
    //   26: aload_0
    //   27: invokevirtual 117	com/google/android/com/tagmanager/TagManager:get	(Lcom/google/android/com/tagmanager/MethodWriter;)Z
    //   30: pop
    //   31: aload_0
    //   32: getfield 40	com/google/android/com/tagmanager/MethodWriter:a	Lcom/google/android/com/tagmanager/Container;
    //   35: invokevirtual 119	com/google/android/com/tagmanager/Container:release	()V
    //   38: aload_0
    //   39: aconst_null
    //   40: putfield 40	com/google/android/com/tagmanager/MethodWriter:a	Lcom/google/android/com/tagmanager/Container;
    //   43: aload_0
    //   44: aconst_null
    //   45: putfield 62	com/google/android/com/tagmanager/MethodWriter:f	Lcom/google/android/com/tagmanager/Container;
    //   48: aload_0
    //   49: aconst_null
    //   50: putfield 42	com/google/android/com/tagmanager/MethodWriter:b	Lcom/google/android/com/tagmanager/x;
    //   53: aload_0
    //   54: aconst_null
    //   55: putfield 60	com/google/android/com/tagmanager/MethodWriter:c	Lcom/google/android/com/tagmanager/Start;
    //   58: goto -44 -> 14
    //   61: astore_1
    //   62: aload_0
    //   63: monitorexit
    //   64: aload_1
    //   65: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	66	0	this	MethodWriter
    //   61	4	1	localThrowable	Throwable
    // Exception table:
    //   from	to	target	type
    //   2	14	61	java/lang/Throwable
    //   17	58	61	java/lang/Throwable
  }
  
  public void setContainerAvailableListener(ContainerHolder.ContainerAvailableListener paramContainerAvailableListener)
  {
    for (;;)
    {
      try
      {
        if (e)
        {
          Log.e("ContainerHolder is released.");
          return;
        }
        if (paramContainerAvailableListener == null)
        {
          c = null;
          continue;
        }
        c = new Start(this, paramContainerAvailableListener, d);
      }
      catch (Throwable paramContainerAvailableListener)
      {
        throw paramContainerAvailableListener;
      }
      if (f != null) {
        f();
      }
    }
  }
}
