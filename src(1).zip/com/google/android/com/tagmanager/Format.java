package com.google.android.com.tagmanager;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class Format
  extends Message
{
  private static final String id = Priority.Q.toString();
  private final Context mContext;
  
  public Format(Context paramContext)
  {
    super(id, new String[0]);
    mContext = paramContext;
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    paramMap = new DisplayMetrics();
    ((WindowManager)mContext.getSystemService("window")).getDefaultDisplay().getMetrics(paramMap);
    int i = widthPixels;
    int j = heightPixels;
    return Boolean.add(i + "x" + j);
  }
}
