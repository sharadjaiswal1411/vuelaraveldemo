package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;

class w
  implements aa
{
  w() {}
  
  public FieldVisitor a(String paramString)
  {
    return new FieldVisitorTee();
  }
  
  public void a(Integer paramInteger) {}
}
