package com.google.android.com.tagmanager;

import com.google.android.gms.tagmanager.k;

class LRUCache<K, V>
  implements k<K, V>
{
  private android.util.LruCache<K, V> lruCache;
  
  LRUCache(int paramInt, LruCache paramLruCache)
  {
    lruCache = new bb.1(this, paramInt, paramLruCache);
  }
  
  public Object get(Object paramObject)
  {
    return lruCache.get(paramObject);
  }
  
  public void put(Object paramObject1, Object paramObject2)
  {
    lruCache.put(paramObject1, paramObject2);
  }
}
