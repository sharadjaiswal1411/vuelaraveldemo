package com.google.android.com.tagmanager;

import com.google.android.com.ads.identifier.AdvertisingIdClient.Info;

public abstract interface DataSource
{
  public abstract AdvertisingIdClient.Info getProgress();
}
