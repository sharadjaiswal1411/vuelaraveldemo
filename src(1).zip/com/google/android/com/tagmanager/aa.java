package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;

abstract interface aa
{
  public abstract FieldVisitor a(String paramString);
  
  public abstract void a(Integer paramInteger);
}
