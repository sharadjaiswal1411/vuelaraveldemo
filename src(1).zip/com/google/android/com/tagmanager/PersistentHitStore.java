package com.google.android.com.tagmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.text.TextUtils;
import com.google.android.com.internal.Clock;
import com.google.android.com.internal.SystemClock;
import java.util.Collections;
import java.util.List;
import org.apache.http.impl.client.DefaultHttpClient;

class PersistentHitStore
  implements HitStore
{
  private static final String CREATE_HITS_TABLE = String.format("CREATE TABLE IF NOT EXISTS %s ( '%s' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, '%s' INTEGER NOT NULL, '%s' TEXT NOT NULL,'%s' INTEGER NOT NULL);", new Object[] { "gtm_hits", "hit_id", "hit_time", "hit_url", "hit_first_send_time" });
  private Clock mClock;
  private final Context mContext;
  private final String mDatabaseName;
  private final ca.b mDbHelper;
  private volatile Dispatcher mDispatcher;
  private final App mListener;
  private final int sampleRate;
  private long size;
  
  PersistentHitStore(App paramApp, Context paramContext)
  {
    this(paramApp, paramContext, "gtm_urls.db", 2000);
  }
  
  PersistentHitStore(App paramApp, Context paramContext, String paramString, int paramInt)
  {
    mContext = paramContext.getApplicationContext();
    mDatabaseName = paramString;
    mListener = paramApp;
    mClock = SystemClock.get();
    mDbHelper = new ca.b(this, mContext, mDatabaseName);
    mDispatcher = new Settings(new DefaultHttpClient(), mContext, new ca.a(this));
    size = 0L;
    sampleRate = paramInt;
  }
  
  private void getItem(long paramLong1, long paramLong2)
  {
    SQLiteDatabase localSQLiteDatabase = getWritableDatabase("Error opening database for getNumStoredHits.");
    if (localSQLiteDatabase == null) {
      return;
    }
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("hit_first_send_time", Long.valueOf(paramLong2));
    try
    {
      localSQLiteDatabase.update("gtm_hits", localContentValues, "hit_id=?", new String[] { String.valueOf(paramLong1) });
      return;
    }
    catch (SQLiteException localSQLiteException)
    {
      Log.append("Error setting HIT_FIRST_DISPATCH_TIME for hitId: " + paramLong1);
      start(paramLong1);
    }
  }
  
  private void getItem(long paramLong, String paramString)
  {
    SQLiteDatabase localSQLiteDatabase = getWritableDatabase("Error opening database for putHit");
    if (localSQLiteDatabase == null) {
      return;
    }
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("hit_time", Long.valueOf(paramLong));
    localContentValues.put("hit_url", paramString);
    localContentValues.put("hit_first_send_time", Integer.valueOf(0));
    try
    {
      localSQLiteDatabase.insert("gtm_hits", null, localContentValues);
      paramString = mListener;
      paramString.remove(false);
      return;
    }
    catch (SQLiteException paramString)
    {
      Log.append("Error storing hit");
    }
  }
  
  private SQLiteDatabase getWritableDatabase(String paramString)
  {
    Object localObject = mDbHelper;
    try
    {
      localObject = ((ca.b)localObject).getWritableDatabase();
      return localObject;
    }
    catch (SQLiteException localSQLiteException)
    {
      Log.append(paramString);
    }
    return null;
  }
  
  private void start()
  {
    int i = getItem() - sampleRate + 1;
    if (i > 0)
    {
      List localList = getLogs(i);
      Log.w("Store full, deleting " + localList.size() + " hits to make room.");
      delete((String[])localList.toArray(new String[0]));
    }
  }
  
  private void start(long paramLong)
  {
    delete(new String[] { String.valueOf(paramLong) });
  }
  
  public void close(long paramLong, String paramString)
  {
    delete();
    start();
    getItem(paramLong, paramString);
  }
  
  /* Error */
  int count()
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: aload_0
    //   4: ldc 121
    //   6: invokespecial 125	com/google/android/com/tagmanager/PersistentHitStore:getWritableDatabase	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteDatabase;
    //   9: astore_2
    //   10: aload_2
    //   11: ifnonnull +5 -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_2
    //   17: ldc 33
    //   19: iconst_2
    //   20: anewarray 43	java/lang/String
    //   23: dup
    //   24: iconst_0
    //   25: ldc 35
    //   27: aastore
    //   28: dup
    //   29: iconst_1
    //   30: ldc 41
    //   32: aastore
    //   33: ldc -12
    //   35: aconst_null
    //   36: aconst_null
    //   37: aconst_null
    //   38: aconst_null
    //   39: invokevirtual 248	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   42: astore_2
    //   43: aload_2
    //   44: invokeinterface 253 1 0
    //   49: istore_1
    //   50: aload_2
    //   51: ifnull +9 -> 60
    //   54: aload_2
    //   55: invokeinterface 255 1 0
    //   60: iload_1
    //   61: ireturn
    //   62: astore_2
    //   63: aconst_null
    //   64: astore_2
    //   65: ldc_w 257
    //   68: invokestatic 169	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   71: aload_2
    //   72: ifnull +39 -> 111
    //   75: aload_2
    //   76: invokeinterface 255 1 0
    //   81: iconst_0
    //   82: ireturn
    //   83: astore_3
    //   84: aload 4
    //   86: astore_2
    //   87: aload_2
    //   88: ifnull +9 -> 97
    //   91: aload_2
    //   92: invokeinterface 255 1 0
    //   97: aload_3
    //   98: athrow
    //   99: astore_3
    //   100: goto -13 -> 87
    //   103: astore_3
    //   104: goto -17 -> 87
    //   107: astore_3
    //   108: goto -43 -> 65
    //   111: iconst_0
    //   112: ireturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	113	0	this	PersistentHitStore
    //   49	12	1	i	int
    //   9	46	2	localObject1	Object
    //   62	1	2	localSQLiteException1	SQLiteException
    //   64	28	2	localObject2	Object
    //   83	15	3	localThrowable1	Throwable
    //   99	1	3	localThrowable2	Throwable
    //   103	1	3	localThrowable3	Throwable
    //   107	1	3	localSQLiteException2	SQLiteException
    //   1	84	4	localObject3	Object
    // Exception table:
    //   from	to	target	type
    //   16	43	62	android/database/sqlite/SQLiteException
    //   16	43	83	java/lang/Throwable
    //   43	50	99	java/lang/Throwable
    //   65	71	103	java/lang/Throwable
    //   43	50	107	android/database/sqlite/SQLiteException
  }
  
  int delete()
  {
    boolean bool = true;
    long l = mClock.currentTimeMillis();
    if (l <= size + 86400000L) {
      return 0;
    }
    size = l;
    Object localObject = getWritableDatabase("Error opening database for deleteStaleHits.");
    if (localObject != null)
    {
      int i = ((SQLiteDatabase)localObject).delete("gtm_hits", "HIT_TIME < ?", new String[] { Long.toString(mClock.currentTimeMillis() - 2592000000L) });
      localObject = mListener;
      if (getItem() == 0) {}
      for (;;)
      {
        ((App)localObject).remove(bool);
        return i;
        bool = false;
      }
    }
    return 0;
  }
  
  void delete(String[] paramArrayOfString)
  {
    boolean bool = true;
    if (paramArrayOfString != null)
    {
      if (paramArrayOfString.length == 0) {
        return;
      }
      SQLiteDatabase localSQLiteDatabase = getWritableDatabase("Error opening database for deleteHits.");
      if (localSQLiteDatabase != null)
      {
        String str = String.format("HIT_ID in (%s)", new Object[] { TextUtils.join(",", Collections.nCopies(paramArrayOfString.length, "?")) });
        for (;;)
        {
          try
          {
            localSQLiteDatabase.delete("gtm_hits", str, paramArrayOfString);
            paramArrayOfString = mListener;
            int i = getItem();
            if (i == 0)
            {
              paramArrayOfString.remove(bool);
              return;
            }
          }
          catch (SQLiteException paramArrayOfString)
          {
            Log.append("Error deleting hits");
            return;
          }
          bool = false;
        }
      }
    }
  }
  
  public void dispatch()
  {
    Log.w("GTM Dispatch running...");
    if (!mDispatcher.isConnected()) {
      return;
    }
    List localList = peekHits(40);
    if (localList.isEmpty())
    {
      Log.w("...nothing to dispatch");
      mListener.remove(true);
      return;
    }
    mDispatcher.dispatchHits(localList);
    if (count() > 0) {
      GAServiceManager.getInstance().initialize();
    }
  }
  
  int getItem()
  {
    Object localObject2 = null;
    Object localObject1 = null;
    int i = 0;
    Object localObject4 = getWritableDatabase("Error opening database for getNumStoredHits.");
    if (localObject4 == null) {
      return 0;
    }
    try
    {
      Cursor localCursor = ((SQLiteDatabase)localObject4).rawQuery("SELECT COUNT(*) from gtm_hits", null);
      localObject4 = localCursor;
      localObject1 = localObject4;
      localObject2 = localObject4;
      boolean bool = localCursor.moveToFirst();
      if (bool)
      {
        localObject1 = localObject4;
        localObject2 = localObject4;
        long l = localCursor.getLong(0);
        i = (int)l;
      }
      if (localCursor != null)
      {
        localCursor.close();
        return i;
      }
    }
    catch (SQLiteException localSQLiteException)
    {
      localObject3 = localObject1;
      Log.append("Error getting numStoredHits");
      if (localObject1 == null) {
        break label137;
      }
      localObject1.close();
      return 0;
    }
    catch (Throwable localThrowable)
    {
      Object localObject3;
      if (localObject3 != null) {
        localObject3.close();
      }
      throw localThrowable;
    }
    return i;
    label137:
    return 0;
  }
  
  /* Error */
  List getLogs(int paramInt)
  {
    // Byte code:
    //   0: new 347	java/util/ArrayList
    //   3: dup
    //   4: invokespecial 348	java/util/ArrayList:<init>	()V
    //   7: astore 6
    //   9: iload_1
    //   10: ifgt +12 -> 22
    //   13: ldc_w 350
    //   16: invokestatic 169	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   19: aload 6
    //   21: areturn
    //   22: aload_0
    //   23: ldc_w 352
    //   26: invokespecial 125	com/google/android/com/tagmanager/PersistentHitStore:getWritableDatabase	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteDatabase;
    //   29: astore_3
    //   30: aload_3
    //   31: ifnonnull +6 -> 37
    //   34: aload 6
    //   36: areturn
    //   37: ldc_w 354
    //   40: iconst_1
    //   41: anewarray 4	java/lang/Object
    //   44: dup
    //   45: iconst_0
    //   46: ldc 35
    //   48: aastore
    //   49: invokestatic 47	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   52: astore 4
    //   54: iload_1
    //   55: invokestatic 357	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   58: astore 5
    //   60: aload_3
    //   61: ldc 33
    //   63: iconst_1
    //   64: anewarray 43	java/lang/String
    //   67: dup
    //   68: iconst_0
    //   69: ldc 35
    //   71: aastore
    //   72: aconst_null
    //   73: aconst_null
    //   74: aconst_null
    //   75: aconst_null
    //   76: aload 4
    //   78: aload 5
    //   80: invokevirtual 360	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   83: astore 5
    //   85: aload 5
    //   87: astore 4
    //   89: aload 4
    //   91: astore_3
    //   92: aload 5
    //   94: invokeinterface 339 1 0
    //   99: istore_2
    //   100: iload_2
    //   101: ifeq +40 -> 141
    //   104: aload 4
    //   106: astore_3
    //   107: aload 6
    //   109: aload 5
    //   111: iconst_0
    //   112: invokeinterface 343 2 0
    //   117: invokestatic 143	java/lang/String:valueOf	(J)Ljava/lang/String;
    //   120: invokeinterface 364 2 0
    //   125: pop
    //   126: aload 4
    //   128: astore_3
    //   129: aload 5
    //   131: invokeinterface 367 1 0
    //   136: istore_2
    //   137: iload_2
    //   138: ifne -34 -> 104
    //   141: aload 5
    //   143: ifnull +10 -> 153
    //   146: aload 5
    //   148: invokeinterface 255 1 0
    //   153: aload 6
    //   155: areturn
    //   156: astore 5
    //   158: aconst_null
    //   159: astore 4
    //   161: aload 4
    //   163: astore_3
    //   164: new 151	java/lang/StringBuilder
    //   167: dup
    //   168: invokespecial 152	java/lang/StringBuilder:<init>	()V
    //   171: ldc_w 369
    //   174: invokevirtual 158	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   177: aload 5
    //   179: invokevirtual 374	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   182: invokevirtual 158	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   185: invokevirtual 164	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   188: invokestatic 169	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   191: aload 4
    //   193: ifnull -40 -> 153
    //   196: aload 4
    //   198: invokeinterface 255 1 0
    //   203: aload 6
    //   205: areturn
    //   206: astore 4
    //   208: aconst_null
    //   209: astore_3
    //   210: aload_3
    //   211: ifnull +9 -> 220
    //   214: aload_3
    //   215: invokeinterface 255 1 0
    //   220: aload 4
    //   222: athrow
    //   223: astore 4
    //   225: goto -15 -> 210
    //   228: astore 5
    //   230: goto -69 -> 161
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	233	0	this	PersistentHitStore
    //   0	233	1	paramInt	int
    //   99	39	2	bool	boolean
    //   29	186	3	localObject1	Object
    //   52	145	4	localObject2	Object
    //   206	15	4	localThrowable1	Throwable
    //   223	1	4	localThrowable2	Throwable
    //   58	89	5	localObject3	Object
    //   156	22	5	localSQLiteException1	SQLiteException
    //   228	1	5	localSQLiteException2	SQLiteException
    //   7	197	6	localArrayList	java.util.ArrayList
    // Exception table:
    //   from	to	target	type
    //   37	85	156	android/database/sqlite/SQLiteException
    //   37	85	206	java/lang/Throwable
    //   92	100	223	java/lang/Throwable
    //   107	126	223	java/lang/Throwable
    //   129	137	223	java/lang/Throwable
    //   164	191	223	java/lang/Throwable
    //   92	100	228	android/database/sqlite/SQLiteException
    //   107	126	228	android/database/sqlite/SQLiteException
    //   129	137	228	android/database/sqlite/SQLiteException
  }
  
  /* Error */
  public List peekHits(int paramInt)
  {
    // Byte code:
    //   0: new 347	java/util/ArrayList
    //   3: dup
    //   4: invokespecial 348	java/util/ArrayList:<init>	()V
    //   7: astore 8
    //   9: aload_0
    //   10: ldc_w 376
    //   13: invokespecial 125	com/google/android/com/tagmanager/PersistentHitStore:getWritableDatabase	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteDatabase;
    //   16: astore 10
    //   18: aload 10
    //   20: ifnonnull +6 -> 26
    //   23: aload 8
    //   25: areturn
    //   26: aconst_null
    //   27: astore 9
    //   29: ldc_w 354
    //   32: iconst_1
    //   33: anewarray 4	java/lang/Object
    //   36: dup
    //   37: iconst_0
    //   38: ldc 35
    //   40: aastore
    //   41: invokestatic 47	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   44: astore 6
    //   46: iload_1
    //   47: invokestatic 357	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   50: astore 7
    //   52: aload 10
    //   54: ldc 33
    //   56: iconst_3
    //   57: anewarray 43	java/lang/String
    //   60: dup
    //   61: iconst_0
    //   62: ldc 35
    //   64: aastore
    //   65: dup
    //   66: iconst_1
    //   67: ldc 37
    //   69: aastore
    //   70: dup
    //   71: iconst_2
    //   72: ldc 41
    //   74: aastore
    //   75: aconst_null
    //   76: aconst_null
    //   77: aconst_null
    //   78: aconst_null
    //   79: aload 6
    //   81: aload 7
    //   83: invokevirtual 360	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   86: astore 6
    //   88: aload 6
    //   90: astore 7
    //   92: new 347	java/util/ArrayList
    //   95: dup
    //   96: invokespecial 348	java/util/ArrayList:<init>	()V
    //   99: astore 9
    //   101: aload 6
    //   103: invokeinterface 339 1 0
    //   108: istore_3
    //   109: iload_3
    //   110: ifeq +54 -> 164
    //   113: aload 9
    //   115: new 378	com/google/android/com/tagmanager/Hit
    //   118: dup
    //   119: aload 6
    //   121: iconst_0
    //   122: invokeinterface 343 2 0
    //   127: aload 6
    //   129: iconst_1
    //   130: invokeinterface 343 2 0
    //   135: aload 6
    //   137: iconst_2
    //   138: invokeinterface 343 2 0
    //   143: invokespecial 381	com/google/android/com/tagmanager/Hit:<init>	(JJJ)V
    //   146: invokeinterface 364 2 0
    //   151: pop
    //   152: aload 6
    //   154: invokeinterface 367 1 0
    //   159: istore_3
    //   160: iload_3
    //   161: ifne -48 -> 113
    //   164: aload 6
    //   166: ifnull +10 -> 176
    //   169: aload 6
    //   171: invokeinterface 255 1 0
    //   176: aload 7
    //   178: astore 6
    //   180: ldc_w 354
    //   183: iconst_1
    //   184: anewarray 4	java/lang/Object
    //   187: dup
    //   188: iconst_0
    //   189: ldc 35
    //   191: aastore
    //   192: invokestatic 47	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   195: astore 8
    //   197: aload 7
    //   199: astore 6
    //   201: iload_1
    //   202: invokestatic 357	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   205: astore 11
    //   207: aload 7
    //   209: astore 6
    //   211: aload 10
    //   213: ldc 33
    //   215: iconst_2
    //   216: anewarray 43	java/lang/String
    //   219: dup
    //   220: iconst_0
    //   221: ldc 35
    //   223: aastore
    //   224: dup
    //   225: iconst_1
    //   226: ldc 39
    //   228: aastore
    //   229: aconst_null
    //   230: aconst_null
    //   231: aconst_null
    //   232: aconst_null
    //   233: aload 8
    //   235: aload 11
    //   237: invokevirtual 360	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   240: astore 8
    //   242: aload 8
    //   244: invokeinterface 339 1 0
    //   249: istore_3
    //   250: iload_3
    //   251: ifeq +67 -> 318
    //   254: iconst_0
    //   255: istore_1
    //   256: aload 8
    //   258: checkcast 383	android/database/sqlite/SQLiteCursor
    //   261: astore 6
    //   263: aload 6
    //   265: invokevirtual 389	android/database/AbstractWindowedCursor:getWindow	()Landroid/database/CursorWindow;
    //   268: invokevirtual 394	android/database/CursorWindow:getNumRows	()I
    //   271: istore_2
    //   272: iload_2
    //   273: ifle +136 -> 409
    //   276: aload 9
    //   278: iload_1
    //   279: invokeinterface 397 2 0
    //   284: astore 6
    //   286: aload 6
    //   288: checkcast 378	com/google/android/com/tagmanager/Hit
    //   291: astore 6
    //   293: aload 6
    //   295: aload 8
    //   297: iconst_1
    //   298: invokeinterface 400 2 0
    //   303: invokevirtual 402	com/google/android/com/tagmanager/Hit:format	(Ljava/lang/String;)V
    //   306: aload 8
    //   308: invokeinterface 367 1 0
    //   313: istore_3
    //   314: iload_3
    //   315: ifne +365 -> 680
    //   318: aload 8
    //   320: ifnull +10 -> 330
    //   323: aload 8
    //   325: invokeinterface 255 1 0
    //   330: aload 9
    //   332: areturn
    //   333: astore 9
    //   335: aconst_null
    //   336: astore 6
    //   338: aload 8
    //   340: astore 7
    //   342: aload 9
    //   344: astore 8
    //   346: new 151	java/lang/StringBuilder
    //   349: dup
    //   350: invokespecial 152	java/lang/StringBuilder:<init>	()V
    //   353: ldc_w 369
    //   356: invokevirtual 158	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   359: aload 8
    //   361: invokevirtual 374	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   364: invokevirtual 158	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   367: invokevirtual 164	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   370: invokestatic 169	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   373: aload 6
    //   375: ifnull +312 -> 687
    //   378: aload 6
    //   380: invokeinterface 255 1 0
    //   385: aload 7
    //   387: areturn
    //   388: astore 7
    //   390: aload 9
    //   392: astore 6
    //   394: aload 6
    //   396: ifnull +10 -> 406
    //   399: aload 6
    //   401: invokeinterface 255 1 0
    //   406: aload 7
    //   408: athrow
    //   409: aload 9
    //   411: iload_1
    //   412: invokeinterface 397 2 0
    //   417: astore 6
    //   419: aload 6
    //   421: checkcast 378	com/google/android/com/tagmanager/Hit
    //   424: astore 6
    //   426: aload 6
    //   428: invokevirtual 404	com/google/android/com/tagmanager/Hit:get	()J
    //   431: lstore 4
    //   433: ldc_w 406
    //   436: iconst_1
    //   437: anewarray 4	java/lang/Object
    //   440: dup
    //   441: iconst_0
    //   442: lload 4
    //   444: invokestatic 134	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   447: aastore
    //   448: invokestatic 47	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   451: invokestatic 169	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   454: goto -148 -> 306
    //   457: astore 6
    //   459: aload 8
    //   461: astore 7
    //   463: aload 6
    //   465: astore 8
    //   467: aload 7
    //   469: astore 6
    //   471: new 151	java/lang/StringBuilder
    //   474: dup
    //   475: invokespecial 152	java/lang/StringBuilder:<init>	()V
    //   478: ldc_w 408
    //   481: invokevirtual 158	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   484: aload 8
    //   486: invokevirtual 374	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   489: invokevirtual 158	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   492: invokevirtual 164	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   495: invokestatic 169	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   498: aload 7
    //   500: astore 6
    //   502: new 347	java/util/ArrayList
    //   505: dup
    //   506: invokespecial 348	java/util/ArrayList:<init>	()V
    //   509: astore 8
    //   511: iconst_0
    //   512: istore_1
    //   513: aload 7
    //   515: astore 6
    //   517: aload 9
    //   519: invokeinterface 412 1 0
    //   524: astore 9
    //   526: aload 7
    //   528: astore 6
    //   530: aload 9
    //   532: invokeinterface 417 1 0
    //   537: istore_3
    //   538: iload_3
    //   539: ifeq +42 -> 581
    //   542: aload 7
    //   544: astore 6
    //   546: aload 9
    //   548: invokeinterface 421 1 0
    //   553: checkcast 378	com/google/android/com/tagmanager/Hit
    //   556: astore 10
    //   558: aload 7
    //   560: astore 6
    //   562: aload 10
    //   564: invokevirtual 423	com/google/android/com/tagmanager/Hit:format	()Ljava/lang/String;
    //   567: invokestatic 426	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   570: istore_3
    //   571: iload_1
    //   572: istore_2
    //   573: iload_3
    //   574: ifeq +24 -> 598
    //   577: iload_1
    //   578: ifeq +18 -> 596
    //   581: aload 7
    //   583: ifnull +10 -> 593
    //   586: aload 7
    //   588: invokeinterface 255 1 0
    //   593: aload 8
    //   595: areturn
    //   596: iconst_1
    //   597: istore_2
    //   598: aload 7
    //   600: astore 6
    //   602: aload 8
    //   604: aload 10
    //   606: invokeinterface 364 2 0
    //   611: pop
    //   612: iload_2
    //   613: istore_1
    //   614: goto -88 -> 526
    //   617: astore 7
    //   619: aload 6
    //   621: ifnull +10 -> 631
    //   624: aload 6
    //   626: invokeinterface 255 1 0
    //   631: aload 7
    //   633: athrow
    //   634: astore 7
    //   636: aload 8
    //   638: astore 6
    //   640: goto -21 -> 619
    //   643: astore 8
    //   645: goto -178 -> 467
    //   648: astore 7
    //   650: goto -256 -> 394
    //   653: astore 7
    //   655: goto -261 -> 394
    //   658: astore 9
    //   660: aload 8
    //   662: astore 7
    //   664: aload 9
    //   666: astore 8
    //   668: goto -322 -> 346
    //   671: astore 8
    //   673: aload 9
    //   675: astore 7
    //   677: goto -331 -> 346
    //   680: iload_1
    //   681: iconst_1
    //   682: iadd
    //   683: istore_1
    //   684: goto -428 -> 256
    //   687: aload 7
    //   689: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	690	0	this	PersistentHitStore
    //   0	690	1	paramInt	int
    //   271	342	2	i	int
    //   108	466	3	bool	boolean
    //   431	12	4	l	long
    //   44	383	6	localObject1	Object
    //   457	7	6	localSQLiteException1	SQLiteException
    //   469	170	6	localObject2	Object
    //   50	336	7	localObject3	Object
    //   388	19	7	localThrowable1	Throwable
    //   461	138	7	localObject4	Object
    //   617	15	7	localThrowable2	Throwable
    //   634	1	7	localThrowable3	Throwable
    //   648	1	7	localThrowable4	Throwable
    //   653	1	7	localThrowable5	Throwable
    //   662	26	7	localSQLiteException2	SQLiteException
    //   7	630	8	localObject5	Object
    //   643	18	8	localSQLiteException3	SQLiteException
    //   666	1	8	localObject6	Object
    //   671	1	8	localSQLiteException4	SQLiteException
    //   27	304	9	localArrayList	java.util.ArrayList
    //   333	185	9	localSQLiteException5	SQLiteException
    //   524	23	9	localIterator	java.util.Iterator
    //   658	16	9	localSQLiteException6	SQLiteException
    //   16	589	10	localObject7	Object
    //   205	31	11	str	String
    // Exception table:
    //   from	to	target	type
    //   29	88	333	android/database/sqlite/SQLiteException
    //   29	88	388	java/lang/Throwable
    //   242	250	457	android/database/sqlite/SQLiteException
    //   263	272	457	android/database/sqlite/SQLiteException
    //   276	286	457	android/database/sqlite/SQLiteException
    //   293	306	457	android/database/sqlite/SQLiteException
    //   306	314	457	android/database/sqlite/SQLiteException
    //   409	419	457	android/database/sqlite/SQLiteException
    //   426	433	457	android/database/sqlite/SQLiteException
    //   433	454	457	android/database/sqlite/SQLiteException
    //   180	197	617	java/lang/Throwable
    //   201	207	617	java/lang/Throwable
    //   211	242	617	java/lang/Throwable
    //   471	498	617	java/lang/Throwable
    //   502	511	617	java/lang/Throwable
    //   517	526	617	java/lang/Throwable
    //   530	538	617	java/lang/Throwable
    //   546	558	617	java/lang/Throwable
    //   562	571	617	java/lang/Throwable
    //   602	612	617	java/lang/Throwable
    //   242	250	634	java/lang/Throwable
    //   263	272	634	java/lang/Throwable
    //   276	286	634	java/lang/Throwable
    //   293	306	634	java/lang/Throwable
    //   306	314	634	java/lang/Throwable
    //   409	419	634	java/lang/Throwable
    //   419	426	634	java/lang/Throwable
    //   426	433	634	java/lang/Throwable
    //   433	454	634	java/lang/Throwable
    //   180	197	643	android/database/sqlite/SQLiteException
    //   201	207	643	android/database/sqlite/SQLiteException
    //   211	242	643	android/database/sqlite/SQLiteException
    //   92	101	648	java/lang/Throwable
    //   101	109	648	java/lang/Throwable
    //   113	160	648	java/lang/Throwable
    //   346	373	653	java/lang/Throwable
    //   92	101	658	android/database/sqlite/SQLiteException
    //   101	109	671	android/database/sqlite/SQLiteException
    //   113	160	671	android/database/sqlite/SQLiteException
  }
}
