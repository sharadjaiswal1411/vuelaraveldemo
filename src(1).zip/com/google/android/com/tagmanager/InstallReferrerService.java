package com.google.android.com.tagmanager;

import android.app.IntentService;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import com.google.android.com.analytics.CampaignTrackingService;

public final class InstallReferrerService
  extends IntentService
{
  Context a;
  CampaignTrackingService o;
  
  public InstallReferrerService()
  {
    super("InstallReferrerService");
  }
  
  public InstallReferrerService(String paramString)
  {
    super(paramString);
  }
  
  private void a(Context paramContext, Intent paramIntent)
  {
    if (o == null) {
      o = new CampaignTrackingService();
    }
    o.processIntent(paramContext, paramIntent);
  }
  
  protected void onHandleIntent(Intent paramIntent)
  {
    String str = paramIntent.getStringExtra("referrer");
    if (a != null) {}
    for (Context localContext = a;; localContext = getApplicationContext())
    {
      Tools.writeFile(localContext, str);
      a(localContext, paramIntent);
      return;
    }
  }
}
