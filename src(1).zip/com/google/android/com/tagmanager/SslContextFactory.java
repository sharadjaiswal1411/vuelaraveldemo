package com.google.android.com.tagmanager;

import com.google.android.com.internal.Priority;
import java.util.Map;

class SslContextFactory
  extends Variance
{
  private static final String DEFAULT_KEYSTORE_PATH = Priority.meta.toString();
  
  public SslContextFactory()
  {
    super(DEFAULT_KEYSTORE_PATH);
  }
  
  protected boolean apply(String paramString1, String paramString2, Map paramMap)
  {
    return paramString1.contains(paramString2);
  }
}
