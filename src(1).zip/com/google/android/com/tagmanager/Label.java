package com.google.android.com.tagmanager;

class Label
{
  private String mName = "https://www.googletagmanager.com";
  
  public Label() {}
  
  public String getName()
  {
    return mName;
  }
}
