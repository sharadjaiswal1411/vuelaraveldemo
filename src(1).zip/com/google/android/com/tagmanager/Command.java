package com.google.android.com.tagmanager;

import android.content.Context;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import com.google.android.com.internal.class_3;
import java.util.Map;

class Command
  extends Message
{
  private static final String ARG0 = class_3.log.toString();
  private static final String COMPONENT;
  private static final String ID = Priority.FUNCTION.toString();
  private final Context context;
  
  static
  {
    COMPONENT = class_3.dumpOnErrorField.toString();
  }
  
  public Command(Context paramContext)
  {
    super(ID, new String[] { ARG0 });
    context = paramContext;
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    Object localObject = (Integer)paramMap.get(ARG0);
    if (localObject == null) {
      return Boolean.get();
    }
    localObject = Boolean.toString((Integer)localObject);
    paramMap = (Integer)paramMap.get(COMPONENT);
    if (paramMap != null) {}
    for (paramMap = Boolean.toString(paramMap);; paramMap = null)
    {
      paramMap = Tools.create(context, (String)localObject, paramMap);
      if (paramMap == null) {
        break;
      }
      return Boolean.add(paramMap);
    }
    return Boolean.get();
  }
}
