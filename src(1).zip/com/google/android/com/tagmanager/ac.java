package com.google.android.com.tagmanager;

abstract interface ac
{
  public abstract aa a();
  
  public abstract Menu add();
}
