package com.google.android.com.tagmanager;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Build.VERSION;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;
import java.util.Locale;
import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpHost;
import org.apache.http.HttpMessage;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.message.BasicHttpEntityEnclosingRequest;

class Settings
  implements Dispatcher
{
  private final Context context;
  private final HttpClient httpClient;
  private da.a progress;
  private final String userAgent;
  
  Settings(HttpClient paramHttpClient, Context paramContext, da.a paramA)
  {
    context = paramContext.getApplicationContext();
    userAgent = createUserAgentString("GoogleTagManager", "4.00", Build.VERSION.RELEASE, query(Locale.getDefault()), Build.MODEL, Build.ID);
    httpClient = paramHttpClient;
    progress = paramA;
  }
  
  private void execute(HttpEntityEnclosingRequest paramHttpEntityEnclosingRequest)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    Object localObject = paramHttpEntityEnclosingRequest.getAllHeaders();
    int j = localObject.length;
    int i = 0;
    while (i < j)
    {
      localStringBuffer.append(localObject[i].toString()).append("\n");
      i += 1;
    }
    localStringBuffer.append(paramHttpEntityEnclosingRequest.getRequestLine().toString()).append("\n");
    if (paramHttpEntityEnclosingRequest.getEntity() != null) {}
    try
    {
      paramHttpEntityEnclosingRequest = paramHttpEntityEnclosingRequest.getEntity().getContent();
      if (paramHttpEntityEnclosingRequest != null)
      {
        i = paramHttpEntityEnclosingRequest.available();
        if (i > 0)
        {
          localObject = new byte[i];
          paramHttpEntityEnclosingRequest.read((byte[])localObject);
          localStringBuffer.append("POST:\n");
          localStringBuffer.append(new String((byte[])localObject)).append("\n");
        }
      }
    }
    catch (IOException paramHttpEntityEnclosingRequest)
    {
      for (;;)
      {
        Log.w("Error Writing hit to log...");
      }
    }
    Log.w(localStringBuffer.toString());
  }
  
  private HttpEntityEnclosingRequest get(URL paramURL)
  {
    try
    {
      paramURL = new BasicHttpEntityEnclosingRequest("GET", paramURL.toURI().toString());
      String str = userAgent;
      Log.append("Exception sending hit: " + localURISyntaxException1.getClass().getSimpleName());
    }
    catch (URISyntaxException localURISyntaxException1)
    {
      try
      {
        paramURL.addHeader("User-Agent", str);
        return paramURL;
      }
      catch (URISyntaxException localURISyntaxException2)
      {
        for (;;) {}
      }
      localURISyntaxException1 = localURISyntaxException1;
      paramURL = null;
    }
    Log.append(localURISyntaxException1.getMessage());
    return paramURL;
  }
  
  static String query(Locale paramLocale)
  {
    if (paramLocale == null) {
      return null;
    }
    if ((paramLocale.getLanguage() != null) && (paramLocale.getLanguage().length() != 0))
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(paramLocale.getLanguage().toLowerCase());
      if ((paramLocale.getCountry() != null) && (paramLocale.getCountry().length() != 0)) {
        localStringBuilder.append("-").append(paramLocale.getCountry().toLowerCase());
      }
      return localStringBuilder.toString();
    }
    return null;
  }
  
  String createUserAgentString(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
  {
    return String.format("%s/%s (Linux; U; Android %s; %s; %s Build/%s)", new Object[] { paramString1, paramString2, paramString3, paramString4, paramString5, paramString6 });
  }
  
  public void dispatchHits(List paramList)
  {
    int n = Math.min(paramList.size(), 40);
    int i = 1;
    int m = 0;
    if (m < n)
    {
      Hit localHit = (Hit)paramList.get(m);
      Object localObject2 = getUrl(localHit);
      if (localObject2 == null)
      {
        Log.append("No destination: discarding hit.");
        progress.dispatchHits(localHit);
      }
      for (;;)
      {
        m += 1;
        break;
        Object localObject1 = get((URL)localObject2);
        if (localObject1 == null)
        {
          progress.dispatchHits(localHit);
        }
        else
        {
          localObject2 = new HttpHost(((URL)localObject2).getHost(), ((URL)localObject2).getPort(), ((URL)localObject2).getProtocol());
          ((HttpMessage)localObject1).addHeader("Host", ((HttpHost)localObject2).toHostString());
          execute((HttpEntityEnclosingRequest)localObject1);
          int j = i;
          Object localObject3;
          int k;
          if (i != 0)
          {
            localObject3 = context;
            k = i;
          }
          try
          {
            NetworkReceiver.execute((Context)localObject3);
            j = 0;
            localObject3 = httpClient;
            k = j;
            i = j;
            localObject1 = ((HttpClient)localObject3).execute((HttpHost)localObject2, (HttpRequest)localObject1);
            k = j;
            i = j;
            int i1 = ((HttpResponse)localObject1).getStatusLine().getStatusCode();
            k = j;
            i = j;
            localObject2 = ((HttpResponse)localObject1).getEntity();
            if (localObject2 != null)
            {
              k = j;
              i = j;
              ((HttpEntity)localObject2).consumeContent();
            }
            if (i1 != 200)
            {
              k = j;
              i = j;
              Log.append("Bad response: " + ((HttpResponse)localObject1).getStatusLine().getStatusCode());
              localObject1 = progress;
              k = j;
              i = j;
              ((da.a)localObject1).update(localHit);
            }
            for (;;)
            {
              i = j;
              break;
              localObject1 = progress;
              k = j;
              i = j;
              ((da.a)localObject1).execute(localHit);
            }
          }
          catch (ClientProtocolException localClientProtocolException)
          {
            Log.append("ClientProtocolException sending hit; discarding hit...");
            progress.dispatchHits(localHit);
            i = k;
          }
          catch (IOException localIOException)
          {
            Log.append("Exception sending hit: " + localIOException.getClass().getSimpleName());
            Log.append(localIOException.getMessage());
            progress.update(localHit);
          }
        }
      }
    }
  }
  
  URL getUrl(Hit paramHit)
  {
    paramHit = paramHit.format();
    try
    {
      paramHit = new URL(paramHit);
      return paramHit;
    }
    catch (MalformedURLException paramHit)
    {
      Log.e("Error trying to parse the GTM url.");
    }
    return null;
  }
  
  public boolean isConnected()
  {
    NetworkInfo localNetworkInfo = ((ConnectivityManager)context.getSystemService("connectivity")).getActiveNetworkInfo();
    if ((localNetworkInfo == null) || (!localNetworkInfo.isConnected()))
    {
      Log.w("...no network connectivity");
      return false;
    }
    return true;
  }
}
