package com.google.android.com.tagmanager;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.google.android.gms.internal.c.j;
import com.google.android.gms.tagmanager.bg;

class b
  implements Runnable
{
  private volatile String a;
  private bg<c.j> b;
  private volatile Label c;
  private final String g;
  private final Context mContext;
  private final StringConvert this$0;
  private final String y;
  private volatile String z;
  
  public b(Context paramContext, String paramString, Label paramLabel)
  {
    this(paramContext, paramString, new StringConvert(), paramLabel);
  }
  
  b(Context paramContext, String paramString, StringConvert paramStringConvert, Label paramLabel)
  {
    mContext = paramContext;
    this$0 = paramStringConvert;
    g = paramString;
    c = paramLabel;
    y = ("/r?id=" + paramString);
    z = y;
    a = null;
  }
  
  private boolean send()
  {
    NetworkInfo localNetworkInfo = ((ConnectivityManager)mContext.getSystemService("connectivity")).getActiveNetworkInfo();
    if ((localNetworkInfo == null) || (!localNetworkInfo.isConnected()))
    {
      Log.w("...no network connectivity");
      return false;
    }
    return true;
  }
  
  /* Error */
  private void write()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 97	com/google/android/com/tagmanager/b:send	()Z
    //   4: ifne +16 -> 20
    //   7: aload_0
    //   8: getfield 99	com/google/android/com/tagmanager/b:b	Lcom/google/android/com/tagmanager/c;
    //   11: getstatic 105	com/google/android/com/tagmanager/bg$a:s	Lcom/google/android/com/tagmanager/bg$a;
    //   14: invokeinterface 110 2 0
    //   19: return
    //   20: ldc 112
    //   22: invokestatic 88	com/google/android/com/tagmanager/Log:w	(Ljava/lang/String;)V
    //   25: aload_0
    //   26: invokevirtual 114	com/google/android/com/tagmanager/b:a	()Ljava/lang/String;
    //   29: astore_3
    //   30: aload_0
    //   31: getfield 36	com/google/android/com/tagmanager/b:this$0	Lcom/google/android/com/tagmanager/StringConvert;
    //   34: invokevirtual 118	com/google/android/com/tagmanager/StringConvert:create	()Lcom/google/android/com/tagmanager/HttpConnection;
    //   37: astore_2
    //   38: aload_2
    //   39: aload_3
    //   40: invokeinterface 124 2 0
    //   45: astore 4
    //   47: new 126	java/io/ByteArrayOutputStream
    //   50: dup
    //   51: invokespecial 127	java/io/ByteArrayOutputStream:<init>	()V
    //   54: astore 5
    //   56: aload 4
    //   58: aload 5
    //   60: invokestatic 132	com/google/android/com/tagmanager/ByteVector:write	(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    //   63: aload 5
    //   65: invokevirtual 136	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   68: invokestatic 141	com/google/android/com/internal/Context:a	([B)Lcom/google/android/com/internal/Context;
    //   71: astore 4
    //   73: new 42	java/lang/StringBuilder
    //   76: dup
    //   77: invokespecial 43	java/lang/StringBuilder:<init>	()V
    //   80: ldc -113
    //   82: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   85: aload 4
    //   87: invokevirtual 146	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   90: invokevirtual 53	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   93: invokestatic 88	com/google/android/com/tagmanager/Log:w	(Ljava/lang/String;)V
    //   96: aload 4
    //   98: getfield 149	com/google/android/com/internal/Context:b	Lcom/google/android/com/internal/Node;
    //   101: astore 5
    //   103: aload 5
    //   105: ifnonnull +47 -> 152
    //   108: aload 4
    //   110: getfield 152	com/google/android/com/internal/Context:a	[Lcom/google/android/com/internal/Attribute;
    //   113: arraylength
    //   114: istore_1
    //   115: iload_1
    //   116: ifne +36 -> 152
    //   119: new 42	java/lang/StringBuilder
    //   122: dup
    //   123: invokespecial 43	java/lang/StringBuilder:<init>	()V
    //   126: ldc -102
    //   128: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   131: astore 5
    //   133: aload_0
    //   134: getfield 38	com/google/android/com/tagmanager/b:g	Ljava/lang/String;
    //   137: astore 6
    //   139: aload 5
    //   141: aload 6
    //   143: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   146: invokevirtual 53	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   149: invokestatic 88	com/google/android/com/tagmanager/Log:w	(Ljava/lang/String;)V
    //   152: aload_0
    //   153: getfield 99	com/google/android/com/tagmanager/b:b	Lcom/google/android/com/tagmanager/c;
    //   156: astore 5
    //   158: aload 5
    //   160: aload 4
    //   162: invokeinterface 157 2 0
    //   167: aload_2
    //   168: invokeinterface 160 1 0
    //   173: ldc -94
    //   175: invokestatic 88	com/google/android/com/tagmanager/Log:w	(Ljava/lang/String;)V
    //   178: return
    //   179: astore 4
    //   181: new 42	java/lang/StringBuilder
    //   184: dup
    //   185: invokespecial 43	java/lang/StringBuilder:<init>	()V
    //   188: ldc -92
    //   190: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   193: aload_3
    //   194: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   197: ldc -90
    //   199: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   202: aload_0
    //   203: getfield 38	com/google/android/com/tagmanager/b:g	Ljava/lang/String;
    //   206: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   209: ldc -88
    //   211: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   214: invokevirtual 53	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   217: invokestatic 170	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   220: aload_0
    //   221: getfield 99	com/google/android/com/tagmanager/b:b	Lcom/google/android/com/tagmanager/c;
    //   224: getstatic 172	com/google/android/com/tagmanager/bg$a:b	Lcom/google/android/com/tagmanager/bg$a;
    //   227: invokeinterface 110 2 0
    //   232: aload_2
    //   233: invokeinterface 160 1 0
    //   238: return
    //   239: astore 4
    //   241: new 42	java/lang/StringBuilder
    //   244: dup
    //   245: invokespecial 43	java/lang/StringBuilder:<init>	()V
    //   248: ldc -82
    //   250: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   253: aload_3
    //   254: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   257: ldc -80
    //   259: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   262: aload 4
    //   264: invokevirtual 179	java/io/IOException:getMessage	()Ljava/lang/String;
    //   267: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   270: invokevirtual 53	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   273: aload 4
    //   275: invokestatic 183	com/google/android/com/tagmanager/Log:d	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   278: aload_0
    //   279: getfield 99	com/google/android/com/tagmanager/b:b	Lcom/google/android/com/tagmanager/c;
    //   282: getstatic 185	com/google/android/com/tagmanager/bg$a:c	Lcom/google/android/com/tagmanager/bg$a;
    //   285: invokeinterface 110 2 0
    //   290: aload_2
    //   291: invokeinterface 160 1 0
    //   296: return
    //   297: astore 4
    //   299: new 42	java/lang/StringBuilder
    //   302: dup
    //   303: invokespecial 43	java/lang/StringBuilder:<init>	()V
    //   306: ldc -69
    //   308: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   311: aload_3
    //   312: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   315: ldc -80
    //   317: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   320: aload 4
    //   322: invokevirtual 179	java/io/IOException:getMessage	()Ljava/lang/String;
    //   325: invokevirtual 49	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   328: invokevirtual 53	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   331: aload 4
    //   333: invokestatic 183	com/google/android/com/tagmanager/Log:d	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   336: aload_0
    //   337: getfield 99	com/google/android/com/tagmanager/b:b	Lcom/google/android/com/tagmanager/c;
    //   340: getstatic 172	com/google/android/com/tagmanager/bg$a:b	Lcom/google/android/com/tagmanager/bg$a;
    //   343: invokeinterface 110 2 0
    //   348: aload_2
    //   349: invokeinterface 160 1 0
    //   354: return
    //   355: astore_3
    //   356: aload_2
    //   357: invokeinterface 160 1 0
    //   362: aload_3
    //   363: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	364	0	this	b
    //   114	2	1	i	int
    //   37	320	2	localHttpConnection	HttpConnection
    //   29	283	3	str1	String
    //   355	8	3	localThrowable	Throwable
    //   45	116	4	localObject1	Object
    //   179	1	4	localFileNotFoundException	java.io.FileNotFoundException
    //   239	35	4	localIOException1	java.io.IOException
    //   297	35	4	localIOException2	java.io.IOException
    //   54	105	5	localObject2	Object
    //   137	5	6	str2	String
    // Exception table:
    //   from	to	target	type
    //   38	47	179	java/io/FileNotFoundException
    //   38	47	239	java/io/IOException
    //   47	73	297	java/io/IOException
    //   73	96	297	java/io/IOException
    //   119	133	297	java/io/IOException
    //   139	152	297	java/io/IOException
    //   158	167	297	java/io/IOException
    //   38	47	355	java/lang/Throwable
    //   47	73	355	java/lang/Throwable
    //   73	96	355	java/lang/Throwable
    //   96	103	355	java/lang/Throwable
    //   108	115	355	java/lang/Throwable
    //   119	133	355	java/lang/Throwable
    //   133	139	355	java/lang/Throwable
    //   139	152	355	java/lang/Throwable
    //   158	167	355	java/lang/Throwable
    //   181	232	355	java/lang/Throwable
    //   241	290	355	java/lang/Throwable
    //   299	348	355	java/lang/Throwable
  }
  
  String a()
  {
    String str3 = c.getName() + z + "&v=a65833898";
    String str1 = str3;
    String str2 = str1;
    if (a != null)
    {
      str2 = str1;
      if (!a.trim().equals("")) {
        str2 = str3 + "&pv=" + a;
      }
    }
    if (a.a().getValue().equals(cd.a.b)) {
      return str2 + "&gtm_debug=x";
    }
    return str2;
  }
  
  void a(c paramC)
  {
    b = paramC;
  }
  
  void a(String paramString)
  {
    if (paramString == null)
    {
      z = y;
      return;
    }
    Log.d("Setting CTFE URL path: " + paramString);
    z = paramString;
  }
  
  void b(String paramString)
  {
    Log.d("Setting previous container version: " + paramString);
    a = paramString;
  }
  
  public void run()
  {
    if (b == null) {
      throw new IllegalStateException("callback must be set before execute");
    }
    b.a();
    write();
  }
}
