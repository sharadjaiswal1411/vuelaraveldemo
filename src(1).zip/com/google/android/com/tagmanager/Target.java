package com.google.android.com.tagmanager;

public abstract interface Target
{
  public abstract State init();
}
