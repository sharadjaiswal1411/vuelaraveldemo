package com.google.android.com.tagmanager;

import android.os.Build.VERSION;
import com.google.android.com.internal.Priority;
import java.util.Map;

class Line
  extends Message
{
  private static final String title = Priority.b.toString();
  
  public Line()
  {
    super(title, new String[0]);
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public com.google.android.com.internal.Integer evaluate(Map paramMap)
  {
    return Boolean.add(Integer.valueOf(Build.VERSION.SDK_INT));
  }
}
