package com.google.android.com.tagmanager;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build.VERSION;
import java.io.File;
import java.util.HashSet;
import java.util.Set;

class Database
  extends SQLiteOpenHelper
{
  Database(Context paramContext, android.content.Context paramContext1, String paramString)
  {
    super(paramContext1, paramString, null, 1);
  }
  
  /* Error */
  private boolean exec(String paramString, SQLiteDatabase paramSQLiteDatabase)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: aload_2
    //   4: ldc 24
    //   6: iconst_1
    //   7: anewarray 26	java/lang/String
    //   10: dup
    //   11: iconst_0
    //   12: ldc 28
    //   14: aastore
    //   15: ldc 30
    //   17: iconst_1
    //   18: anewarray 26	java/lang/String
    //   21: dup
    //   22: iconst_0
    //   23: aload_1
    //   24: aastore
    //   25: aconst_null
    //   26: aconst_null
    //   27: aconst_null
    //   28: invokevirtual 36	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   31: astore_2
    //   32: aload_2
    //   33: invokeinterface 42 1 0
    //   38: istore_3
    //   39: aload_2
    //   40: ifnull +77 -> 117
    //   43: aload_2
    //   44: invokeinterface 46 1 0
    //   49: iload_3
    //   50: ireturn
    //   51: astore_2
    //   52: aconst_null
    //   53: astore_2
    //   54: new 48	java/lang/StringBuilder
    //   57: dup
    //   58: invokespecial 50	java/lang/StringBuilder:<init>	()V
    //   61: ldc 52
    //   63: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: aload_1
    //   67: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   70: invokevirtual 60	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   73: invokestatic 65	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   76: aload_2
    //   77: ifnull +9 -> 86
    //   80: aload_2
    //   81: invokeinterface 46 1 0
    //   86: iconst_0
    //   87: ireturn
    //   88: astore_1
    //   89: aload 4
    //   91: astore_2
    //   92: aload_2
    //   93: ifnull +9 -> 102
    //   96: aload_2
    //   97: invokeinterface 46 1 0
    //   102: aload_1
    //   103: athrow
    //   104: astore_1
    //   105: goto -13 -> 92
    //   108: astore_1
    //   109: goto -17 -> 92
    //   112: astore 4
    //   114: goto -60 -> 54
    //   117: iload_3
    //   118: ireturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	119	0	this	Database
    //   0	119	1	paramString	String
    //   0	119	2	paramSQLiteDatabase	SQLiteDatabase
    //   38	80	3	bool	boolean
    //   1	89	4	localObject	Object
    //   112	1	4	localSQLiteException	SQLiteException
    // Exception table:
    //   from	to	target	type
    //   3	32	51	android/database/sqlite/SQLiteException
    //   3	32	88	java/lang/Throwable
    //   32	39	104	java/lang/Throwable
    //   54	76	108	java/lang/Throwable
    //   32	39	112	android/database/sqlite/SQLiteException
  }
  
  private void update(SQLiteDatabase paramSQLiteDatabase)
  {
    paramSQLiteDatabase = paramSQLiteDatabase.rawQuery("SELECT * FROM datalayer WHERE 0", null);
    HashSet localHashSet = new HashSet();
    try
    {
      String[] arrayOfString = paramSQLiteDatabase.getColumnNames();
      int i = 0;
      for (;;)
      {
        int j = arrayOfString.length;
        if (i >= j) {
          break;
        }
        localHashSet.add(arrayOfString[i]);
        i += 1;
      }
      paramSQLiteDatabase.close();
      if ((!localHashSet.remove("key")) || (!localHashSet.remove("value")) || (!localHashSet.remove("ID")) || (!localHashSet.remove("expires"))) {
        throw new SQLiteException("Database column missing");
      }
    }
    catch (Throwable localThrowable)
    {
      paramSQLiteDatabase.close();
      throw localThrowable;
    }
    if (!localThrowable.isEmpty()) {
      throw new SQLiteException("Database has extra columns");
    }
  }
  
  public SQLiteDatabase getWritableDatabase()
  {
    Object localObject = null;
    try
    {
      SQLiteDatabase localSQLiteDatabase = super.getWritableDatabase();
      localObject = localSQLiteDatabase;
    }
    catch (SQLiteException localSQLiteException)
    {
      for (;;)
      {
        Context.access$getMContext(context).getDatabasePath("google_tagmanager.db").delete();
      }
    }
    if (localObject == null) {
      return super.getWritableDatabase();
    }
    return localObject;
  }
  
  public void onCreate(SQLiteDatabase paramSQLiteDatabase)
  {
    Utils.copyFile(paramSQLiteDatabase.getPath());
  }
  
  public void onOpen(SQLiteDatabase paramSQLiteDatabase)
  {
    Cursor localCursor;
    if (Build.VERSION.SDK_INT < 15) {
      localCursor = paramSQLiteDatabase.rawQuery("PRAGMA journal_mode=memory", null);
    }
    try
    {
      localCursor.moveToFirst();
      localCursor.close();
      if (!exec("datalayer", paramSQLiteDatabase))
      {
        paramSQLiteDatabase.execSQL(Context.access$getCREATE_HITS_TABLE());
        return;
      }
    }
    catch (Throwable paramSQLiteDatabase)
    {
      localCursor.close();
      throw paramSQLiteDatabase;
    }
    update(paramSQLiteDatabase);
  }
  
  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {}
}
