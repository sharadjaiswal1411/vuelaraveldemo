package com.google.android.com.tagmanager;

import android.content.Context;
import com.google.android.com.analytics.GoogleAnalytics;
import com.google.android.com.analytics.Tracker;

class EasyTracker
{
  private Context mContext;
  private GoogleAnalytics preferences;
  private Tracker tracker;
  
  EasyTracker(Context paramContext)
  {
    mContext = paramContext;
  }
  
  private void getInstance(String paramString)
  {
    try
    {
      if (preferences == null)
      {
        preferences = GoogleAnalytics.getInstance(mContext);
        preferences.setLogger(new de.a());
        tracker = preferences.newTracker(paramString);
      }
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public Tracker getTracker(String paramString)
  {
    getInstance(paramString);
    return tracker;
  }
}
