package com.google.android.com.tagmanager;

import com.google.android.com.internal.Priority;
import java.util.Map;

class ImageLoader
  extends Object
{
  private static final String header = Priority.Y.toString();
  
  public ImageLoader()
  {
    super(header);
  }
  
  protected boolean get(UnsignedInteger paramUnsignedInteger1, UnsignedInteger paramUnsignedInteger2, Map paramMap)
  {
    return paramUnsignedInteger1.compareTo(paramUnsignedInteger2) >= 0;
  }
}
