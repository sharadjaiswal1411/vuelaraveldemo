package com.google.android.com.tagmanager;

import android.util.Log;

class Frame
  implements Logger
{
  private int b = 5;
  
  Frame() {}
  
  public void a(String paramString)
  {
    if (b <= 4) {
      Log.i("GoogleTagManager", paramString);
    }
  }
  
  public void a(String paramString, Throwable paramThrowable)
  {
    if (b <= 6) {
      Log.e("GoogleTagManager", paramString, paramThrowable);
    }
  }
  
  public void b(String paramString)
  {
    if (b <= 6) {
      Log.e("GoogleTagManager", paramString);
    }
  }
  
  public void d(String paramString)
  {
    if (b <= 3) {
      Log.d("GoogleTagManager", paramString);
    }
  }
  
  public void d(String paramString, Throwable paramThrowable)
  {
    if (b <= 5) {
      Log.w("GoogleTagManager", paramString, paramThrowable);
    }
  }
  
  public void set(String paramString)
  {
    if (b <= 5) {
      Log.w("GoogleTagManager", paramString);
    }
  }
  
  public void setLogLevel(int paramInt)
  {
    b = paramInt;
  }
  
  public void toString(String paramString)
  {
    if (b <= 2) {
      Log.v("GoogleTagManager", paramString);
    }
  }
}
