package com.google.android.com.tagmanager;

public abstract interface x
{
  public abstract void a();
  
  public abstract void a(String paramString);
  
  public abstract String c();
}
