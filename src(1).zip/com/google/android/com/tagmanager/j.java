package com.google.android.com.tagmanager;

import com.google.android.com.common.ClickListeners.MethodWriter;
import com.google.android.com.common.ClickListeners.Status;
import com.google.android.com.internal.Clock;
import com.google.android.com.internal.Context;
import com.google.android.gms.internal.c.j;
import com.google.android.gms.tagmanager.bg;

class j
  implements bg<c.j>
{
  private j(d paramD) {}
  
  public void a() {}
  
  public void a(Context paramContext)
  {
    d localD = a;
    try
    {
      if (b == null)
      {
        if (ea).b == null)
        {
          Log.e("Current resource is null; network resource is also null");
          d.b(a, 3600000L);
          return;
        }
        b = ea).b;
      }
      d.b(a, paramContext, d.g(a).currentTimeMillis(), false);
      Log.w("setting refresh time to current time: " + d.f(a));
      if (!d.d(a)) {
        d.b(a, paramContext);
      }
      return;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public void a(bg.a paramA)
  {
    if (d.c(a) != null) {
      a.a(d.c(a));
    }
    for (;;)
    {
      d.b(a, 3600000L);
      return;
      a.a(a.a(Status.d));
    }
  }
}
