package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import com.google.android.com.internal.class_3;
import java.util.Map;

class Token
  extends Message
{
  private static final String DEFAULT_VALUE = class_3.to.toString();
  private static final String NAME;
  private static final String URL = Priority.priority.toString();
  private final DataLayer stack;
  
  static
  {
    NAME = class_3.name.toString();
  }
  
  public Token(DataLayer paramDataLayer)
  {
    super(URL, new String[] { NAME });
    stack = paramDataLayer;
  }
  
  public boolean equals()
  {
    return false;
  }
  
  public Integer evaluate(Map paramMap)
  {
    Object localObject = stack.get(Boolean.toString((Integer)paramMap.get(NAME)));
    if (localObject == null)
    {
      paramMap = (Integer)paramMap.get(DEFAULT_VALUE);
      if (paramMap != null) {
        return paramMap;
      }
      return Boolean.get();
    }
    return Boolean.add(localObject);
  }
}
