package com.google.android.com.tagmanager;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import com.google.android.com.internal.Priority;
import java.util.Map;

class MessageHeader
  extends Message
{
  private static final String id = Priority.WARN.toString();
  private final Context mContext;
  
  public MessageHeader(Context paramContext)
  {
    super(id, new String[0]);
    mContext = paramContext;
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public com.google.android.com.internal.Integer evaluate(Map paramMap)
  {
    paramMap = mContext;
    try
    {
      paramMap = paramMap.getPackageManager();
      Context localContext = mContext;
      paramMap = paramMap.getPackageInfo(localContext.getPackageName(), 0);
      int i = versionCode;
      paramMap = Boolean.add(Integer.valueOf(i));
      return paramMap;
    }
    catch (PackageManager.NameNotFoundException paramMap)
    {
      Log.e("Package name " + mContext.getPackageName() + " not found. " + paramMap.getMessage());
    }
    return Boolean.get();
  }
}
