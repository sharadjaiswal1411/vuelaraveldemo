package com.google.android.com.tagmanager;

import com.google.android.com.internal.Priority;
import java.util.Map;

class DataFilterIDLookup
  extends Variance
{
  private static final String TAG = Priority.code.toString();
  
  public DataFilterIDLookup()
  {
    super(TAG);
  }
  
  protected boolean apply(String paramString1, String paramString2, Map paramMap)
  {
    return paramString1.startsWith(paramString2);
  }
}
