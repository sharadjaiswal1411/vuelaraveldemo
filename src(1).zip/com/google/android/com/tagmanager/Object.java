package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import java.util.Map;

abstract class Object
  extends Predicate
{
  public Object(String paramString)
  {
    super(paramString);
  }
  
  protected boolean evaluate(Integer paramInteger1, Integer paramInteger2, Map paramMap)
  {
    paramInteger1 = Boolean.add(paramInteger1);
    paramInteger2 = Boolean.add(paramInteger2);
    if ((paramInteger1 == Boolean.add()) || (paramInteger2 == Boolean.add())) {
      return false;
    }
    return get(paramInteger1, paramInteger2, paramMap);
  }
  
  protected abstract boolean get(UnsignedInteger paramUnsignedInteger1, UnsignedInteger paramUnsignedInteger2, Map paramMap);
}
