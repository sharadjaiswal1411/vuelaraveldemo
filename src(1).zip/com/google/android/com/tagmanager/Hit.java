package com.google.android.com.tagmanager;

import android.text.TextUtils;

class Hit
{
  private String cachedStr;
  private final long data;
  private final long filter;
  private final long key;
  
  Hit(long paramLong1, long paramLong2, long paramLong3)
  {
    key = paramLong1;
    filter = paramLong2;
    data = paramLong3;
  }
  
  String format()
  {
    return cachedStr;
  }
  
  void format(String paramString)
  {
    if (paramString != null)
    {
      if (TextUtils.isEmpty(paramString.trim())) {
        return;
      }
      cachedStr = paramString;
    }
  }
  
  long get()
  {
    return key;
  }
  
  long getBytes()
  {
    return data;
  }
}
