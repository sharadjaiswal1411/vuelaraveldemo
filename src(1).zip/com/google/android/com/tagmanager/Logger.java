package com.google.android.com.tagmanager;

abstract interface Logger
{
  public abstract void a(String paramString);
  
  public abstract void a(String paramString, Throwable paramThrowable);
  
  public abstract void b(String paramString);
  
  public abstract void d(String paramString);
  
  public abstract void d(String paramString, Throwable paramThrowable);
  
  public abstract void set(String paramString);
  
  public abstract void setLogLevel(int paramInt);
  
  public abstract void toString(String paramString);
}
