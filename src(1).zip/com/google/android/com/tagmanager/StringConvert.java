package com.google.android.com.tagmanager;

import android.os.Build.VERSION;

class StringConvert
{
  StringConvert() {}
  
  public HttpConnection create()
  {
    if (getSdkVersion() < 8) {
      return new DiskLruCache();
    }
    return new Connection();
  }
  
  int getSdkVersion()
  {
    return Build.VERSION.SDK_INT;
  }
}
