package com.google.android.com.tagmanager;

class MethodVisitor
  implements AnnotationVisitor
{
  MethodVisitor() {}
  
  public AnnotationVisitor visitAnnotation(int paramInt)
  {
    return new MethodVisitor();
  }
  
  public m.a visitAnnotation()
  {
    return new ClassVisitor();
  }
  
  public AnnotationVisitor visitLocalVariableAnnotation(int paramInt)
  {
    return new MethodVisitor();
  }
  
  public AnnotationVisitor visitParameterAnnotation(int paramInt)
  {
    return new MethodVisitor();
  }
  
  public AnnotationVisitor visitTypeAnnotation(int paramInt)
  {
    return new MethodVisitor();
  }
}
