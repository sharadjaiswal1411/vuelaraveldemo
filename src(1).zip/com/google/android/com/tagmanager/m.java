package com.google.android.com.tagmanager;

abstract interface m
{
  public abstract void start(Runnable paramRunnable);
  
  public abstract void write(String paramString);
}
