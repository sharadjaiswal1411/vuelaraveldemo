package com.google.android.com.tagmanager;

import com.google.android.com.common.ClickListeners.Releasable;
import com.google.android.com.internal.it.a;

abstract interface XYPlot
  extends Releasable
{
  public abstract cq.c a(int paramInt);
  
  public abstract void a(c paramC);
  
  public abstract void b();
  
  public abstract void b(it.a paramA);
}
