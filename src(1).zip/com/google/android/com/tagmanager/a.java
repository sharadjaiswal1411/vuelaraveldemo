package com.google.android.com.tagmanager;

import android.net.Uri;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

class a
{
  private static a j;
  private volatile cd.a a;
  private volatile String c;
  private volatile String m;
  private volatile String p;
  
  a()
  {
    clear();
  }
  
  static a a()
  {
    try
    {
      if (j == null) {
        j = new a();
      }
      a localA = j;
      return localA;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  private String getTitle(Uri paramUri)
  {
    return paramUri.getQuery().replace("&gtm_debug=x", "");
  }
  
  private String read(String paramString)
  {
    return paramString.split("&")[0].split("=")[1];
  }
  
  boolean a(Uri paramUri)
  {
    boolean bool = true;
    String str;
    try
    {
      str = URLDecoder.decode(paramUri.toString(), "UTF-8");
      if (!str.matches("^tagmanager.c.\\S+:\\/\\/preview\\/p\\?id=\\S+&gtm_auth=\\S+&gtm_preview=\\d+(&gtm_debug=x)?$")) {
        break label153;
      }
      Log.w("Container preview url: " + str);
      if (!str.matches(".*?&gtm_debug=x$")) {
        break label138;
      }
      a = cd.a.b;
    }
    catch (UnsupportedEncodingException paramUri)
    {
      for (;;)
      {
        bool = false;
        continue;
        a = cd.a.i;
      }
    }
    catch (Throwable paramUri)
    {
      throw paramUri;
    }
    p = getTitle(paramUri);
    if ((a == cd.a.i) || (a == cd.a.b)) {
      m = ("/r?" + p);
    }
    c = read(p);
    for (;;)
    {
      return bool;
      label138:
      label153:
      if (str.matches("^tagmanager.c.\\S+:\\/\\/preview\\/p\\?id=\\S+&gtm_preview=$"))
      {
        if (read(paramUri.getQuery()).equals(c))
        {
          Log.w("Exit preview mode for container: " + c);
          a = cd.a.a;
          m = null;
        }
      }
      else
      {
        Log.append("Invalid preview uri: " + str);
        bool = false;
        continue;
      }
      bool = false;
    }
  }
  
  String b()
  {
    return m;
  }
  
  void clear()
  {
    a = cd.a.a;
    m = null;
    c = null;
    p = null;
  }
  
  String getContainerId()
  {
    return c;
  }
  
  cd.a getValue()
  {
    return a;
  }
}
