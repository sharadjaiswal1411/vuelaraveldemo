package com.google.android.com.tagmanager;

import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import com.google.android.com.common.ClickListeners.PendingResult;
import com.google.android.gms.tagmanager.n;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class TagManager
{
  private static TagManager sInstance;
  private final ConcurrentMap<n, Boolean> c;
  private final Label mContainers;
  private final android.content.Context mContext;
  private final a mDescriptor;
  private final DataLayer this$0;
  
  TagManager(android.content.Context paramContext, a paramA, DataLayer paramDataLayer)
  {
    if (paramContext == null) {
      throw new NullPointerException("context cannot be null");
    }
    mContext = paramContext.getApplicationContext();
    mDescriptor = paramA;
    c = new ConcurrentHashMap();
    this$0 = paramDataLayer;
    this$0.putAll(new TagManager.1(this));
    this$0.putAll(new Bookmark(mContext));
    mContainers = new Label();
  }
  
  private void b(String paramString)
  {
    Iterator localIterator = c.keySet().iterator();
    while (localIterator.hasNext()) {
      ((MethodWriter)localIterator.next()).b(paramString);
    }
  }
  
  public static TagManager getInstance(android.content.Context paramContext)
  {
    try
    {
      if (sInstance != null) {
        break label65;
      }
      if (paramContext == null)
      {
        Log.e("TagManager.getInstance requires non-null context.");
        throw new NullPointerException();
      }
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
    sInstance = new TagManager(paramContext, new TagManager.2(), new DataLayer(new Context(paramContext)));
    label65:
    paramContext = sInstance;
    return paramContext;
  }
  
  void a(MethodWriter paramMethodWriter)
  {
    c.put(paramMethodWriter, Boolean.valueOf(true));
  }
  
  boolean b(Uri paramUri)
  {
    for (;;)
    {
      boolean bool;
      Object localObject2;
      try
      {
        localObject1 = a.a();
        if (!((a)localObject1).a(paramUri)) {
          break label240;
        }
        paramUri = ((a)localObject1).getContainerId();
        int i = 3.d[localObject1.getValue().ordinal()];
        switch (i)
        {
        default: 
          bool = true;
          return bool;
        }
      }
      catch (Throwable paramUri)
      {
        throw paramUri;
      }
      Object localObject1 = c.keySet().iterator();
      if (((Iterator)localObject1).hasNext())
      {
        localObject2 = (MethodWriter)((Iterator)localObject1).next();
        if (((MethodWriter)localObject2).getContainerId().equals(paramUri))
        {
          ((MethodWriter)localObject2).a(null);
          ((MethodWriter)localObject2).refresh();
        }
      }
      else
      {
        continue;
        localObject2 = c.keySet().iterator();
        while (((Iterator)localObject2).hasNext())
        {
          MethodWriter localMethodWriter = (MethodWriter)((Iterator)localObject2).next();
          if (localMethodWriter.getContainerId().equals(paramUri))
          {
            localMethodWriter.a(((a)localObject1).b());
            localMethodWriter.refresh();
          }
          else if (localMethodWriter.c() != null)
          {
            localMethodWriter.a(null);
            localMethodWriter.refresh();
          }
        }
        continue;
        label240:
        bool = false;
      }
    }
  }
  
  boolean get(MethodWriter paramMethodWriter)
  {
    return c.remove(paramMethodWriter) != null;
  }
  
  public DataLayer getDataLayer()
  {
    return this$0;
  }
  
  public PendingResult loadContainerDefaultOnly(String paramString, int paramInt)
  {
    paramString = mDescriptor.a(mContext, this, null, paramString, paramInt, mContainers);
    paramString.a();
    return paramString;
  }
  
  public PendingResult loadContainerDefaultOnly(String paramString, int paramInt, Handler paramHandler)
  {
    paramString = mDescriptor.a(mContext, this, paramHandler.getLooper(), paramString, paramInt, mContainers);
    paramString.a();
    return paramString;
  }
  
  public PendingResult loadContainerPreferFresh(String paramString, int paramInt)
  {
    paramString = mDescriptor.a(mContext, this, null, paramString, paramInt, mContainers);
    paramString.c();
    return paramString;
  }
  
  public PendingResult loadContainerPreferFresh(String paramString, int paramInt, Handler paramHandler)
  {
    paramString = mDescriptor.a(mContext, this, paramHandler.getLooper(), paramString, paramInt, mContainers);
    paramString.c();
    return paramString;
  }
  
  public PendingResult loadContainerPreferNonDefault(String paramString, int paramInt)
  {
    paramString = mDescriptor.a(mContext, this, null, paramString, paramInt, mContainers);
    paramString.updateMenuView();
    return paramString;
  }
  
  public PendingResult loadContainerPreferNonDefault(String paramString, int paramInt, Handler paramHandler)
  {
    paramString = mDescriptor.a(mContext, this, paramHandler.getLooper(), paramString, paramInt, mContainers);
    paramString.updateMenuView();
    return paramString;
  }
  
  public void setVerboseLoggingEnabled(boolean paramBoolean)
  {
    if (paramBoolean) {}
    for (int i = 2;; i = 5)
    {
      Log.setLogLevel(i);
      return;
    }
  }
  
  abstract interface a
  {
    public abstract d a(android.content.Context paramContext, TagManager paramTagManager, Looper paramLooper, String paramString, int paramInt, Label paramLabel);
  }
}
