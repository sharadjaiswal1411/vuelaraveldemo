package com.google.android.com.tagmanager;

import com.google.android.com.internal.Priority;
import java.util.Map;

class BeanMetaData
  extends Object
{
  private static final String DEFAULT_KEYSTORE_PATH = Priority.height.toString();
  
  public BeanMetaData()
  {
    super(DEFAULT_KEYSTORE_PATH);
  }
  
  protected boolean get(UnsignedInteger paramUnsignedInteger1, UnsignedInteger paramUnsignedInteger2, Map paramMap)
  {
    return paramUnsignedInteger1.compareTo(paramUnsignedInteger2) <= 0;
  }
}
