package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import com.google.android.com.internal.class_3;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

class Key
  extends Message
{
  private static final String ARG0;
  private static final String ARG1;
  private static final String GROUP = class_3.u.toString();
  private static final String ID = Priority.HANDSHAKE.toString();
  private static final String IGNORE_CASE;
  
  static
  {
    ARG0 = class_3.FAILURE.toString();
    ARG1 = class_3.SUCCESS.toString();
    IGNORE_CASE = class_3.code.toString();
  }
  
  public Key()
  {
    super(ID, new String[] { ARG0, ARG1 });
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    Object localObject = (Integer)paramMap.get(ARG0);
    Integer localInteger = (Integer)paramMap.get(ARG1);
    if ((localObject == null) || (localObject == Boolean.get()) || (localInteger == null) || (localInteger == Boolean.get())) {
      return Boolean.get();
    }
    int i = 64;
    if (Boolean.valueOf((Integer)paramMap.get(IGNORE_CASE)).booleanValue()) {
      i = 66;
    }
    paramMap = (Integer)paramMap.get(GROUP);
    int j;
    if (paramMap != null)
    {
      paramMap = Boolean.getValue(paramMap);
      if (paramMap == Boolean.size()) {
        return Boolean.get();
      }
      int k = paramMap.intValue();
      j = k;
      if (k < 0) {
        return Boolean.get();
      }
    }
    else
    {
      j = 1;
    }
    try
    {
      paramMap = Boolean.toString((Integer)localObject);
      localObject = Boolean.toString(localInteger);
      localInteger = null;
      localObject = Pattern.compile((String)localObject, i).matcher(paramMap);
      boolean bool = ((Matcher)localObject).find();
      paramMap = localInteger;
      if (bool)
      {
        i = ((Matcher)localObject).groupCount();
        paramMap = localInteger;
        if (i >= j) {
          paramMap = ((Matcher)localObject).group(j);
        }
      }
      if (paramMap == null)
      {
        paramMap = Boolean.get();
        return paramMap;
      }
      paramMap = Boolean.add(paramMap);
      return paramMap;
    }
    catch (PatternSyntaxException paramMap) {}
    return Boolean.get();
  }
}
