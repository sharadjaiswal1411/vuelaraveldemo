package com.google.android.com.tagmanager;

abstract interface k
{
  public abstract boolean inflate();
}
