package com.google.android.com.tagmanager;

import android.content.Context;
import android.os.Handler;

class GAServiceManager
  extends ServiceManager
{
  private static final Object id = new Object();
  private static GAServiceManager instance;
  private int TAG = 1800000;
  private boolean authenticated = false;
  private boolean cache = false;
  private boolean connected = true;
  private Context ctx;
  private boolean data = true;
  private Handler handler;
  private boolean initDone = true;
  private App listener = new cx.1(this);
  private NetworkReceiver networkReceiver;
  private HitStore store;
  private volatile m thread;
  
  private GAServiceManager() {}
  
  private void close()
  {
    handler = new Handler(ctx.getMainLooper(), new cx.2(this));
    if (TAG > 0) {
      handler.sendMessageDelayed(handler.obtainMessage(1, id), TAG);
    }
  }
  
  public static GAServiceManager getInstance()
  {
    if (instance == null) {
      instance = new GAServiceManager();
    }
    return instance;
  }
  
  private void onCreate()
  {
    networkReceiver = new NetworkReceiver(this);
    networkReceiver.register(ctx);
  }
  
  void close(boolean paramBoolean1, boolean paramBoolean2)
  {
    for (;;)
    {
      try
      {
        if (cache == paramBoolean1)
        {
          boolean bool = connected;
          if (bool == paramBoolean2) {
            return;
          }
        }
        if (((paramBoolean1) || (!paramBoolean2)) && (TAG > 0)) {
          handler.removeMessages(1, id);
        }
        if ((!paramBoolean1) && (paramBoolean2) && (TAG > 0)) {
          handler.sendMessageDelayed(handler.obtainMessage(1, id), TAG);
        }
        localStringBuilder = new StringBuilder().append("PowerSaveMode ");
        if (paramBoolean1) {
          break label153;
        }
        if (paramBoolean2) {
          break label146;
        }
      }
      catch (Throwable localThrowable)
      {
        StringBuilder localStringBuilder;
        String str1;
        throw localThrowable;
      }
      Log.w(str1);
      cache = paramBoolean1;
      connected = paramBoolean2;
      continue;
      label146:
      String str2 = "terminated.";
      continue;
      label153:
      str2 = "initiated.";
    }
  }
  
  HitStore getStore()
  {
    try
    {
      if (store != null) {
        break label50;
      }
      if (ctx == null) {
        throw new IllegalStateException("Cant get a store unless we have a context");
      }
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
    store = new PersistentHitStore(listener, ctx);
    label50:
    if (handler == null) {
      close();
    }
    authenticated = true;
    if (initDone)
    {
      initialize();
      initDone = false;
    }
    if ((networkReceiver == null) && (data)) {
      onCreate();
    }
    HitStore localHitStore = store;
    return localHitStore;
  }
  
  /* Error */
  public void initialize()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 48	com/google/android/com/tagmanager/GAServiceManager:authenticated	Z
    //   6: ifne +16 -> 22
    //   9: ldc -90
    //   11: invokestatic 141	com/google/android/com/tagmanager/Log:w	(Ljava/lang/String;)V
    //   14: aload_0
    //   15: iconst_1
    //   16: putfield 46	com/google/android/com/tagmanager/GAServiceManager:initDone	Z
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: aload_0
    //   23: getfield 168	com/google/android/com/tagmanager/GAServiceManager:thread	Lcom/google/android/com/tagmanager/m;
    //   26: new 170	com/google/android/com/tagmanager/cx$3
    //   29: dup
    //   30: aload_0
    //   31: invokespecial 171	com/google/android/com/tagmanager/cx$3:<init>	(Lcom/google/android/com/tagmanager/GAServiceManager;)V
    //   34: invokeinterface 177 2 0
    //   39: goto -20 -> 19
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	47	0	this	GAServiceManager
    //   42	4	1	localThrowable	Throwable
    // Exception table:
    //   from	to	target	type
    //   2	19	42	java/lang/Throwable
    //   22	39	42	java/lang/Throwable
  }
  
  /* Error */
  void initialize(Context paramContext, m paramM)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 72	com/google/android/com/tagmanager/GAServiceManager:ctx	Landroid/content/Context;
    //   6: astore_3
    //   7: aload_3
    //   8: ifnull +6 -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: aload_1
    //   16: invokevirtual 182	android/content/Context:getApplicationContext	()Landroid/content/Context;
    //   19: putfield 72	com/google/android/com/tagmanager/GAServiceManager:ctx	Landroid/content/Context;
    //   22: aload_0
    //   23: getfield 168	com/google/android/com/tagmanager/GAServiceManager:thread	Lcom/google/android/com/tagmanager/m;
    //   26: ifnonnull -15 -> 11
    //   29: aload_0
    //   30: aload_2
    //   31: putfield 168	com/google/android/com/tagmanager/GAServiceManager:thread	Lcom/google/android/com/tagmanager/m;
    //   34: goto -23 -> 11
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	42	0	this	GAServiceManager
    //   0	42	1	paramContext	Context
    //   0	42	2	paramM	m
    //   6	2	3	localContext	Context
    // Exception table:
    //   from	to	target	type
    //   2	7	37	java/lang/Throwable
    //   14	34	37	java/lang/Throwable
  }
  
  void initialize(boolean paramBoolean)
  {
    try
    {
      close(cache, paramBoolean);
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  void write()
  {
    try
    {
      if ((!cache) && (connected) && (TAG > 0))
      {
        handler.removeMessages(1, id);
        handler.sendMessage(handler.obtainMessage(1, id));
      }
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
}
