package com.google.android.com.tagmanager;

import android.content.Context;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class Chunk
  extends Message
{
  private static final String ENCODING = Priority.c.toString();
  private final Context mContext;
  
  public Chunk(Context paramContext)
  {
    super(ENCODING, new String[0]);
    mContext = paramContext;
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    return Boolean.add(mContext.getPackageName());
  }
}
