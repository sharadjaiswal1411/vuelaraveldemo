package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import java.util.Map;

abstract class Operator
  extends Message
{
  public Operator(String paramString, String... paramVarArgs)
  {
    super(paramString, paramVarArgs);
  }
  
  public boolean equals()
  {
    return false;
  }
  
  public Integer evaluate(Map paramMap)
  {
    run(paramMap);
    return Boolean.get();
  }
  
  public abstract void run(Map paramMap);
}
