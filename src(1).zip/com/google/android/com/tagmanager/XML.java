package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import com.google.android.com.internal.class_3;
import java.io.UnsupportedEncodingException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

class XML
  extends Message
{
  private static final String ARG0 = class_3.FAILURE.toString();
  private static final String ARG1 = class_3.HANDSHAKE.toString();
  private static final String ID = Priority.UNCHALLENGED.toString();
  private static final String IGNORE_CASE = class_3.CONSTRAINT.toString();
  private static final String i = class_3.set.toString();
  
  public XML()
  {
    super(ID, new String[] { ARG0 });
  }
  
  private void parse(Set paramSet, String paramString)
  {
    int j = 0;
    while (j < paramString.length())
    {
      paramSet.add(Character.valueOf(paramString.charAt(j)));
      j += 1;
    }
  }
  
  private void put(StringBuilder paramStringBuilder, String paramString, az.a paramA, Set paramSet)
  {
    paramStringBuilder.append(toString(paramString, paramA, paramSet));
  }
  
  private String toString(String paramString, az.a paramA, Set paramSet)
  {
    switch (az.1.u[paramA.ordinal()])
    {
    default: 
      return paramString;
    case 1: 
      try
      {
        paramA = Card.encode(paramString);
        return paramA;
      }
      catch (UnsupportedEncodingException paramA)
      {
        Log.e("Joiner: unsupported encoding", paramA);
        return paramString;
      }
    }
    paramString = paramString.replace("\\", "\\\\");
    paramA = paramSet.iterator();
    while (paramA.hasNext())
    {
      paramSet = ((Character)paramA.next()).toString();
      paramString = paramString.replace(paramSet, "\\" + paramSet);
    }
    return paramString;
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    Integer localInteger = (Integer)paramMap.get(ARG0);
    if (localInteger == null) {
      return Boolean.get();
    }
    Object localObject1 = (Integer)paramMap.get(ARG1);
    String str1;
    Object localObject2;
    if (localObject1 != null)
    {
      str1 = Boolean.toString((Integer)localObject1);
      localObject1 = (Integer)paramMap.get(IGNORE_CASE);
      if (localObject1 == null) {
        break label193;
      }
      localObject2 = Boolean.toString((Integer)localObject1);
      label75:
      localObject1 = az.a.C;
      paramMap = (Integer)paramMap.get(i);
      if (paramMap == null) {
        break label428;
      }
      paramMap = Boolean.toString(paramMap);
      if (!"url".equals(paramMap)) {
        break label200;
      }
      paramMap = az.a.i;
      localObject1 = null;
    }
    for (;;)
    {
      label118:
      StringBuilder localStringBuilder = new StringBuilder();
      switch (type)
      {
      default: 
        put(localStringBuilder, Boolean.toString(localInteger), paramMap, (Set)localObject1);
      }
      for (;;)
      {
        return Boolean.add(localStringBuilder.toString());
        str1 = "";
        break;
        label193:
        localObject2 = "=";
        break label75;
        label200:
        if ("backslash".equals(paramMap))
        {
          paramMap = az.a.b;
          localObject1 = new HashSet();
          parse((Set)localObject1, str1);
          parse((Set)localObject1, (String)localObject2);
          ((Set)localObject1).remove(Character.valueOf('\\'));
          break label118;
        }
        Log.e("Joiner: unsupported escape type: " + paramMap);
        return Boolean.get();
        int j = 1;
        localObject2 = value;
        int m = localObject2.length;
        int k = 0;
        while (k < m)
        {
          localInteger = localObject2[k];
          if (j == 0) {
            localStringBuilder.append(str1);
          }
          put(localStringBuilder, Boolean.toString(localInteger), paramMap, (Set)localObject1);
          k += 1;
          j = 0;
        }
        j = 0;
        while (j < n.length)
        {
          if (j > 0) {
            localStringBuilder.append(str1);
          }
          String str2 = Boolean.toString(n[j]);
          String str3 = Boolean.toString(i[j]);
          put(localStringBuilder, str2, paramMap, (Set)localObject1);
          localStringBuilder.append((String)localObject2);
          put(localStringBuilder, str3, paramMap, (Set)localObject1);
          j += 1;
        }
      }
      label428:
      localStringBuilder = null;
      paramMap = (Map)localObject1;
      localObject1 = localStringBuilder;
    }
  }
}
