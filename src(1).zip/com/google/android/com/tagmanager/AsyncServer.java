package com.google.android.com.tagmanager;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.concurrent.LinkedBlockingQueue;

class AsyncServer
  extends Thread
  implements m
{
  private static AsyncServer mInstance;
  private volatile boolean mClosed = false;
  private final Context mContext;
  private volatile boolean mDisabled = false;
  private volatile HitStore mSelector;
  private final LinkedBlockingQueue<Runnable> queue = new LinkedBlockingQueue();
  
  private AsyncServer(Context paramContext)
  {
    super("GAThread");
    if (paramContext != null) {}
    for (mContext = paramContext.getApplicationContext();; mContext = paramContext)
    {
      start();
      return;
    }
  }
  
  static AsyncServer getDefault(Context paramContext)
  {
    if (mInstance == null) {
      mInstance = new AsyncServer(paramContext);
    }
    return mInstance;
  }
  
  private String stop(Throwable paramThrowable)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    PrintStream localPrintStream = new PrintStream(localByteArrayOutputStream);
    paramThrowable.printStackTrace(localPrintStream);
    localPrintStream.flush();
    return new String(localByteArrayOutputStream.toByteArray());
  }
  
  void report(String paramString, long paramLong)
  {
    start(new as.1(this, this, paramLong, paramString));
  }
  
  public void run()
  {
    while (!mClosed) {
      try
      {
        Object localObject = queue;
        try
        {
          localObject = ((LinkedBlockingQueue)localObject).take();
          localObject = (Runnable)localObject;
          boolean bool = mDisabled;
          if (!bool) {
            ((Runnable)localObject).run();
          }
        }
        catch (InterruptedException localInterruptedException)
        {
          Log.i(localInterruptedException.toString());
        }
      }
      catch (Throwable localThrowable)
      {
        Log.e("Error on GAThread: " + stop(localThrowable));
        Log.e("Google Analytics is shutting down.");
        mDisabled = true;
      }
    }
  }
  
  public void start(Runnable paramRunnable)
  {
    queue.add(paramRunnable);
  }
  
  public void write(String paramString)
  {
    report(paramString, System.currentTimeMillis());
  }
}
