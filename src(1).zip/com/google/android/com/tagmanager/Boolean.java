package com.google.android.com.tagmanager;

import com.google.android.com.internal.Frame;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class Boolean
{
  private static String NULL;
  private static java.lang.Boolean TRUE;
  private static final Object key = null;
  private static UnsignedInteger next;
  private static com.google.android.com.internal.Integer pool = add(NULL);
  private static Map<Object, Object> settings;
  private static Long size = new Long(0L);
  private static List<Object> songs;
  private static Double value = new Double(0.0D);
  
  static
  {
    next = UnsignedInteger.add(0L);
    NULL = new String("");
    TRUE = new java.lang.Boolean(false);
    songs = new ArrayList(0);
    settings = new HashMap();
  }
  
  public static com.google.android.com.internal.Integer a(String paramString)
  {
    com.google.android.com.internal.Integer localInteger = new com.google.android.com.internal.Integer();
    type = 5;
    a = paramString;
    return localInteger;
  }
  
  public static com.google.android.com.internal.Integer add(Object paramObject)
  {
    boolean bool = false;
    Object localObject1 = new com.google.android.com.internal.Integer();
    if ((paramObject instanceof com.google.android.com.internal.Integer)) {
      return (com.google.android.com.internal.Integer)paramObject;
    }
    if ((paramObject instanceof String))
    {
      type = 1;
      data = ((String)paramObject);
    }
    for (;;)
    {
      size = bool;
      return localObject1;
      Object localObject2;
      Object localObject3;
      if ((paramObject instanceof List))
      {
        type = 2;
        localObject2 = (List)paramObject;
        paramObject = new ArrayList(((List)localObject2).size());
        localObject2 = ((List)localObject2).iterator();
        bool = false;
        if (((Iterator)localObject2).hasNext())
        {
          localObject3 = add(((Iterator)localObject2).next());
          if (localObject3 == pool) {
            return pool;
          }
          if ((bool) || (size)) {}
          for (bool = true;; bool = false)
          {
            paramObject.add(localObject3);
            break;
          }
        }
        value = ((com.google.android.com.internal.Integer[])paramObject.toArray(new com.google.android.com.internal.Integer[0]));
      }
      else if ((paramObject instanceof Map))
      {
        type = 3;
        localObject3 = ((Map)paramObject).entrySet();
        paramObject = new ArrayList(((Set)localObject3).size());
        localObject2 = new ArrayList(((Set)localObject3).size());
        localObject3 = ((Set)localObject3).iterator();
        bool = false;
        if (((Iterator)localObject3).hasNext())
        {
          Object localObject4 = (Map.Entry)((Iterator)localObject3).next();
          com.google.android.com.internal.Integer localInteger = add(((Map.Entry)localObject4).getKey());
          localObject4 = add(((Map.Entry)localObject4).getValue());
          if ((localInteger == pool) || (localObject4 == pool)) {
            return pool;
          }
          if ((bool) || (size) || (size)) {}
          for (bool = true;; bool = false)
          {
            paramObject.add(localInteger);
            ((List)localObject2).add(localObject4);
            break;
          }
        }
        n = ((com.google.android.com.internal.Integer[])paramObject.toArray(new com.google.android.com.internal.Integer[0]));
        i = ((com.google.android.com.internal.Integer[])((List)localObject2).toArray(new com.google.android.com.internal.Integer[0]));
      }
      else if (encode(paramObject))
      {
        type = 1;
        data = paramObject.toString();
      }
      else if (compareTo(paramObject))
      {
        type = 6;
        id = getValue(paramObject);
      }
      else
      {
        if (!(paramObject instanceof java.lang.Boolean)) {
          break;
        }
        type = 8;
        c = ((java.lang.Boolean)paramObject).booleanValue();
      }
    }
    localObject1 = new StringBuilder().append("Converting to Value from unknown object type: ");
    if (paramObject == null) {}
    for (paramObject = "null";; paramObject = paramObject.getClass().toString())
    {
      Log.e(paramObject);
      return pool;
    }
  }
  
  public static UnsignedInteger add()
  {
    return next;
  }
  
  public static UnsignedInteger add(com.google.android.com.internal.Integer paramInteger)
  {
    return plus(get(paramInteger));
  }
  
  private static UnsignedInteger add(String paramString)
  {
    try
    {
      UnsignedInteger localUnsignedInteger = UnsignedInteger.valueOf(paramString);
      return localUnsignedInteger;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      Log.e("Failed to convert '" + paramString + "' to a number.");
    }
    return next;
  }
  
  private static boolean compareTo(Object paramObject)
  {
    return ((paramObject instanceof Byte)) || ((paramObject instanceof Short)) || ((paramObject instanceof Integer)) || ((paramObject instanceof Long)) || (((paramObject instanceof UnsignedInteger)) && (((UnsignedInteger)paramObject).getValue()));
  }
  
  public static Long convert(Object paramObject)
  {
    if (compareTo(paramObject)) {
      return Long.valueOf(getValue(paramObject));
    }
    return read(get(paramObject));
  }
  
  private static boolean encode(Object paramObject)
  {
    return ((paramObject instanceof Double)) || ((paramObject instanceof Float)) || (((paramObject instanceof UnsignedInteger)) && (((UnsignedInteger)paramObject).divide()));
  }
  
  public static com.google.android.com.internal.Integer get()
  {
    return pool;
  }
  
  public static Object get(com.google.android.com.internal.Integer paramInteger)
  {
    int k = 0;
    int j = 0;
    int i = 0;
    if (paramInteger == null) {
      return key;
    }
    Object localObject1;
    Object localObject2;
    switch (type)
    {
    default: 
      Log.e("Failed to convert a value of type: " + type);
      return key;
    case 1: 
      return data;
    case 2: 
      localObject1 = new ArrayList(value.length);
      paramInteger = value;
      j = paramInteger.length;
      while (i < j)
      {
        localObject2 = get(paramInteger[i]);
        if (localObject2 == key) {
          return key;
        }
        ((ArrayList)localObject1).add(localObject2);
        i += 1;
      }
      return localObject1;
    case 3: 
      if (n.length != paramInteger.i.length)
      {
        Log.e("Converting an invalid value to object: " + paramInteger.toString());
        return key;
      }
      localObject1 = new HashMap(paramInteger.i.length);
      i = k;
      while (i < n.length)
      {
        localObject2 = get(n[i]);
        Object localObject3 = get(paramInteger.i[i]);
        if ((localObject2 == key) || (localObject3 == key)) {
          return key;
        }
        ((Map)localObject1).put(localObject2, localObject3);
        i += 1;
      }
      return localObject1;
    case 4: 
      Log.e("Trying to convert a macro reference to object");
      return key;
    case 5: 
      Log.e("Trying to convert a function id to object");
      return key;
    case 6: 
      return Long.valueOf(id);
    case 7: 
      localObject1 = new StringBuffer();
      paramInteger = s;
      k = paramInteger.length;
      i = j;
      while (i < k)
      {
        localObject2 = toString(paramInteger[i]);
        if (localObject2 == NULL) {
          return key;
        }
        ((StringBuffer)localObject1).append((String)localObject2);
        i += 1;
      }
      return ((StringBuffer)localObject1).toString();
    }
    return java.lang.Boolean.valueOf(c);
  }
  
  public static String get(Object paramObject)
  {
    if (paramObject == null) {
      return NULL;
    }
    return paramObject.toString();
  }
  
  public static java.lang.Boolean getBoolean()
  {
    return TRUE;
  }
  
  private static java.lang.Boolean getBoolean(String paramString)
  {
    if ("true".equalsIgnoreCase(paramString)) {
      return java.lang.Boolean.TRUE;
    }
    if ("false".equalsIgnoreCase(paramString)) {
      return java.lang.Boolean.FALSE;
    }
    return TRUE;
  }
  
  private static double getDouble(Object paramObject)
  {
    if ((paramObject instanceof Number)) {
      return ((Number)paramObject).doubleValue();
    }
    Log.e("getDouble received non-Number");
    return 0.0D;
  }
  
  public static Double getNumber(com.google.android.com.internal.Integer paramInteger)
  {
    return parse(get(paramInteger));
  }
  
  private static long getValue(Object paramObject)
  {
    if ((paramObject instanceof Number)) {
      return ((Number)paramObject).longValue();
    }
    Log.e("getInt64 received non-Number");
    return 0L;
  }
  
  public static Double getValue()
  {
    return value;
  }
  
  public static Long getValue(com.google.android.com.internal.Integer paramInteger)
  {
    return convert(get(paramInteger));
  }
  
  public static Double parse(Object paramObject)
  {
    if (encode(paramObject)) {
      return Double.valueOf(getDouble(paramObject));
    }
    return valueOf(get(paramObject));
  }
  
  public static UnsignedInteger plus(Object paramObject)
  {
    if ((paramObject instanceof UnsignedInteger)) {
      return (UnsignedInteger)paramObject;
    }
    if (compareTo(paramObject)) {
      return UnsignedInteger.add(getValue(paramObject));
    }
    if (encode(paramObject)) {
      return UnsignedInteger.add(Double.valueOf(getDouble(paramObject)));
    }
    return add(get(paramObject));
  }
  
  private static Long read(String paramString)
  {
    paramString = add(paramString);
    if (paramString == next) {
      return size;
    }
    return Long.valueOf(paramString.longValue());
  }
  
  public static Object setValue()
  {
    return key;
  }
  
  public static Long size()
  {
    return size;
  }
  
  public static java.lang.Boolean toString(Object paramObject)
  {
    if ((paramObject instanceof java.lang.Boolean)) {
      return (java.lang.Boolean)paramObject;
    }
    return getBoolean(get(paramObject));
  }
  
  public static String toString(com.google.android.com.internal.Integer paramInteger)
  {
    return get(get(paramInteger));
  }
  
  public static java.lang.Boolean valueOf(com.google.android.com.internal.Integer paramInteger)
  {
    return toString(get(paramInteger));
  }
  
  private static Double valueOf(String paramString)
  {
    paramString = add(paramString);
    if (paramString == next) {
      return value;
    }
    return Double.valueOf(paramString.doubleValue());
  }
  
  public static String valueOf()
  {
    return NULL;
  }
}
