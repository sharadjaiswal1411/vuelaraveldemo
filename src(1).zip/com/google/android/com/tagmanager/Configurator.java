package com.google.android.com.tagmanager;

class Configurator
  implements i.a
{
  Configurator() {}
  
  public ac a()
  {
    return new Widget();
  }
  
  public m.a b()
  {
    return new ClassVisitor();
  }
  
  public void c() {}
}
