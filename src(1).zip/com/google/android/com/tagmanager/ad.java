package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;

abstract interface ad
{
  public abstract aa a();
  
  public abstract void a(Integer paramInteger);
  
  public abstract ExtensionData b();
  
  public abstract ExtensionData c();
  
  public abstract aa getItem();
  
  public abstract ExtensionData p();
  
  public abstract ExtensionData setIcon();
}
