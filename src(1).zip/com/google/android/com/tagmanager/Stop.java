package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import com.google.android.com.internal.class_3;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class Stop
  extends Message
{
  private static final String ARG0 = class_3.g.toString();
  private static final String ARG1 = class_3.BOTTOM.toString();
  private static final String ID = Priority.D.toString();
  private final Point pointB;
  
  public Stop(Point paramPoint)
  {
    super(ID, new String[] { ARG0 });
    pointB = paramPoint;
  }
  
  public boolean equals()
  {
    return false;
  }
  
  public Integer evaluate(Map paramMap)
  {
    String str = Boolean.toString((Integer)paramMap.get(ARG0));
    HashMap localHashMap = new HashMap();
    paramMap = (Integer)paramMap.get(ARG1);
    if (paramMap != null)
    {
      paramMap = Boolean.get(paramMap);
      if (!(paramMap instanceof Map))
      {
        Log.append("FunctionCallMacro: expected ADDITIONAL_PARAMS to be a map.");
        return Boolean.get();
      }
      paramMap = ((Map)paramMap).entrySet().iterator();
      while (paramMap.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)paramMap.next();
        localHashMap.put(localEntry.getKey().toString(), localEntry.getValue());
      }
    }
    paramMap = pointB;
    try
    {
      paramMap = Boolean.add(paramMap.set(str, localHashMap));
      return paramMap;
    }
    catch (Exception paramMap)
    {
      Log.append("Custom macro/tag " + str + " threw exception " + paramMap.getMessage());
    }
    return Boolean.get();
  }
}
