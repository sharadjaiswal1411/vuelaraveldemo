package com.google.android.com.tagmanager;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import com.google.android.com.internal.InvalidProtocolBufferNanoException;
import com.google.android.com.internal.Node;
import com.google.android.gms.tagmanager.bg;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONException;

class Plot
  implements XYPlot
{
  private bg<com.google.android.gms.internal.it.a> c;
  private final String d;
  private final ExecutorService e;
  private final Context mContext;
  
  Plot(Context paramContext, String paramString)
  {
    mContext = paramContext;
    d = paramString;
    e = Executors.newSingleThreadExecutor();
  }
  
  private cq.c a(ByteArrayOutputStream paramByteArrayOutputStream)
  {
    try
    {
      paramByteArrayOutputStream = Type.a(paramByteArrayOutputStream.toString("UTF-8"));
      return paramByteArrayOutputStream;
    }
    catch (UnsupportedEncodingException paramByteArrayOutputStream)
    {
      Log.d("Tried to convert binary resource to string for JSON parsing; not UTF-8 format");
      return null;
    }
    catch (JSONException paramByteArrayOutputStream)
    {
      Log.append("Resource is a UTF-8 encoded string but doesn't contain a JSON container");
    }
    return null;
  }
  
  private cq.c a(byte[] paramArrayOfByte)
  {
    try
    {
      paramArrayOfByte = ByteVector.run(Node.toString(paramArrayOfByte));
      return paramArrayOfByte;
    }
    catch (InvalidProtocolBufferNanoException paramArrayOfByte)
    {
      Log.append("Resource doesn't contain a binary container");
      return null;
    }
    catch (cq.g paramArrayOfByte)
    {
      Log.append("Resource doesn't contain a binary container");
    }
    return null;
  }
  
  public cq.c a(int paramInt)
  {
    Log.w("Atttempting to load container from resource ID " + paramInt);
    Object localObject1 = mContext;
    try
    {
      Object localObject2 = ((Context)localObject1).getResources().openRawResource(paramInt);
      localObject1 = new ByteArrayOutputStream();
      ByteVector.write((InputStream)localObject2, (OutputStream)localObject1);
      localObject2 = a((ByteArrayOutputStream)localObject1);
      if (localObject2 != null) {
        return localObject2;
      }
      localObject1 = a(((ByteArrayOutputStream)localObject1).toByteArray());
      return localObject1;
    }
    catch (IOException localIOException)
    {
      Log.append("Error reading default container resource with ID " + paramInt);
      return null;
    }
    catch (Resources.NotFoundException localNotFoundException)
    {
      Log.append("No default container resource found.");
    }
    return null;
  }
  
  /* Error */
  void a()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 139	com/google/android/com/tagmanager/Plot:c	Lcom/google/android/com/tagmanager/c;
    //   4: ifnonnull +13 -> 17
    //   7: new 141	java/lang/IllegalStateException
    //   10: dup
    //   11: ldc -113
    //   13: invokespecial 145	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   16: athrow
    //   17: aload_0
    //   18: getfield 139	com/google/android/com/tagmanager/Plot:c	Lcom/google/android/com/tagmanager/c;
    //   21: astore_2
    //   22: aload_0
    //   23: astore_1
    //   24: aload_2
    //   25: invokeinterface 149 1 0
    //   30: ldc -105
    //   32: invokestatic 104	com/google/android/com/tagmanager/Log:w	(Ljava/lang/String;)V
    //   35: invokestatic 156	com/google/android/com/tagmanager/a:a	()Lcom/google/android/com/tagmanager/a;
    //   38: invokevirtual 160	com/google/android/com/tagmanager/a:getValue	()Lcom/google/android/com/tagmanager/cd$a;
    //   41: getstatic 166	com/google/android/com/tagmanager/cd$a:i	Lcom/google/android/com/tagmanager/cd$a;
    //   44: if_acmpeq +15 -> 59
    //   47: invokestatic 156	com/google/android/com/tagmanager/a:a	()Lcom/google/android/com/tagmanager/a;
    //   50: invokevirtual 160	com/google/android/com/tagmanager/a:getValue	()Lcom/google/android/com/tagmanager/cd$a;
    //   53: getstatic 169	com/google/android/com/tagmanager/cd$a:b	Lcom/google/android/com/tagmanager/cd$a;
    //   56: if_acmpne +32 -> 88
    //   59: aload_1
    //   60: getfield 24	com/google/android/com/tagmanager/Plot:d	Ljava/lang/String;
    //   63: invokestatic 156	com/google/android/com/tagmanager/a:a	()Lcom/google/android/com/tagmanager/a;
    //   66: invokevirtual 172	com/google/android/com/tagmanager/a:getContainerId	()Ljava/lang/String;
    //   69: invokevirtual 178	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   72: ifeq +16 -> 88
    //   75: aload_1
    //   76: getfield 139	com/google/android/com/tagmanager/Plot:c	Lcom/google/android/com/tagmanager/c;
    //   79: getstatic 184	com/google/android/com/tagmanager/bg$a:s	Lcom/google/android/com/tagmanager/bg$a;
    //   82: invokeinterface 187 2 0
    //   87: return
    //   88: new 189	java/io/FileInputStream
    //   91: dup
    //   92: aload_1
    //   93: invokevirtual 192	com/google/android/com/tagmanager/Plot:c	()Ljava/io/File;
    //   96: invokespecial 195	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   99: astore_2
    //   100: new 43	java/io/ByteArrayOutputStream
    //   103: dup
    //   104: invokespecial 117	java/io/ByteArrayOutputStream:<init>	()V
    //   107: astore_3
    //   108: aload_2
    //   109: aload_3
    //   110: invokestatic 121	com/google/android/com/tagmanager/ByteVector:write	(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    //   113: aload_1
    //   114: getfield 139	com/google/android/com/tagmanager/Plot:c	Lcom/google/android/com/tagmanager/c;
    //   117: astore_1
    //   118: aload_1
    //   119: aload_3
    //   120: invokevirtual 127	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   123: invokestatic 200	com/google/android/com/internal/it$a:a	([B)Lcom/google/android/com/internal/it$a;
    //   126: invokeinterface 203 2 0
    //   131: aload_2
    //   132: invokevirtual 206	java/io/FileInputStream:close	()V
    //   135: ldc -48
    //   137: invokestatic 104	com/google/android/com/tagmanager/Log:w	(Ljava/lang/String;)V
    //   140: return
    //   141: astore_2
    //   142: ldc -46
    //   144: invokestatic 59	com/google/android/com/tagmanager/Log:d	(Ljava/lang/String;)V
    //   147: aload_1
    //   148: getfield 139	com/google/android/com/tagmanager/Plot:c	Lcom/google/android/com/tagmanager/c;
    //   151: getstatic 184	com/google/android/com/tagmanager/bg$a:s	Lcom/google/android/com/tagmanager/bg$a;
    //   154: invokeinterface 187 2 0
    //   159: return
    //   160: astore_1
    //   161: ldc -44
    //   163: invokestatic 64	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   166: goto -31 -> 135
    //   169: astore_1
    //   170: ldc -42
    //   172: invokestatic 64	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   175: aload_0
    //   176: getfield 139	com/google/android/com/tagmanager/Plot:c	Lcom/google/android/com/tagmanager/c;
    //   179: getstatic 216	com/google/android/com/tagmanager/bg$a:c	Lcom/google/android/com/tagmanager/bg$a;
    //   182: invokeinterface 187 2 0
    //   187: aload_2
    //   188: invokevirtual 206	java/io/FileInputStream:close	()V
    //   191: goto -56 -> 135
    //   194: astore_1
    //   195: ldc -44
    //   197: invokestatic 64	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   200: goto -65 -> 135
    //   203: astore_1
    //   204: aload_2
    //   205: invokevirtual 206	java/io/FileInputStream:close	()V
    //   208: aload_1
    //   209: athrow
    //   210: astore_2
    //   211: ldc -44
    //   213: invokestatic 64	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   216: goto -8 -> 208
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	219	0	this	Plot
    //   23	125	1	localObject1	Object
    //   160	1	1	localIOException1	IOException
    //   169	1	1	localIOException2	IOException
    //   194	1	1	localIOException3	IOException
    //   203	6	1	localThrowable	Throwable
    //   21	111	2	localObject2	Object
    //   141	64	2	localFileNotFoundException	java.io.FileNotFoundException
    //   210	1	2	localIOException4	IOException
    //   107	13	3	localByteArrayOutputStream	ByteArrayOutputStream
    // Exception table:
    //   from	to	target	type
    //   88	100	141	java/io/FileNotFoundException
    //   131	135	160	java/io/IOException
    //   100	113	169	java/io/IOException
    //   118	131	169	java/io/IOException
    //   187	191	194	java/io/IOException
    //   100	113	203	java/lang/Throwable
    //   118	131	203	java/lang/Throwable
    //   170	187	203	java/lang/Throwable
    //   204	208	210	java/io/IOException
  }
  
  public void a(c paramC)
  {
    c = paramC;
  }
  
  /* Error */
  boolean a(com.google.android.com.internal.it.a paramA)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 192	com/google/android/com/tagmanager/Plot:c	()Ljava/io/File;
    //   4: astore_3
    //   5: new 220	java/io/FileOutputStream
    //   8: dup
    //   9: aload_3
    //   10: invokespecial 221	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   13: astore_2
    //   14: aload_2
    //   15: aload_1
    //   16: invokestatic 226	com/google/android/com/internal/Frame:a	(Lcom/google/android/com/internal/Frame;)[B
    //   19: invokevirtual 229	java/io/FileOutputStream:write	([B)V
    //   22: aload_2
    //   23: invokevirtual 230	java/io/FileOutputStream:close	()V
    //   26: iconst_1
    //   27: ireturn
    //   28: astore_1
    //   29: ldc -24
    //   31: invokestatic 234	com/google/android/com/tagmanager/Log:e	(Ljava/lang/String;)V
    //   34: iconst_0
    //   35: ireturn
    //   36: astore_1
    //   37: ldc -20
    //   39: invokestatic 64	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   42: iconst_1
    //   43: ireturn
    //   44: astore_1
    //   45: ldc -18
    //   47: invokestatic 64	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   50: aload_3
    //   51: invokevirtual 244	java/io/File:delete	()Z
    //   54: pop
    //   55: aload_2
    //   56: invokevirtual 230	java/io/FileOutputStream:close	()V
    //   59: iconst_0
    //   60: ireturn
    //   61: astore_1
    //   62: ldc -20
    //   64: invokestatic 64	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   67: iconst_0
    //   68: ireturn
    //   69: astore_1
    //   70: aload_2
    //   71: invokevirtual 230	java/io/FileOutputStream:close	()V
    //   74: aload_1
    //   75: athrow
    //   76: astore_2
    //   77: ldc -20
    //   79: invokestatic 64	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   82: goto -8 -> 74
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	85	0	this	Plot
    //   0	85	1	paramA	com.google.android.com.internal.it.a
    //   13	58	2	localFileOutputStream	java.io.FileOutputStream
    //   76	1	2	localIOException	IOException
    //   4	47	3	localFile	File
    // Exception table:
    //   from	to	target	type
    //   5	14	28	java/io/FileNotFoundException
    //   22	26	36	java/io/IOException
    //   14	22	44	java/io/IOException
    //   55	59	61	java/io/IOException
    //   14	22	69	java/lang/Throwable
    //   45	55	69	java/lang/Throwable
    //   70	74	76	java/io/IOException
  }
  
  public void b()
  {
    e.execute(new cp.1(this));
  }
  
  public void b(com.google.android.com.internal.it.a paramA)
  {
    e.execute(new cp.2(this, paramA));
  }
  
  File c()
  {
    String str = "resource_" + d;
    return new File(mContext.getDir("google_tagmanager", 0), str);
  }
  
  public void release()
  {
    try
    {
      e.shutdown();
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
}
