package com.google.android.com.tagmanager;

import android.util.Base64;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import com.google.android.com.internal.class_3;
import java.util.Map;

class Request
  extends Message
{
  private static final String ARG0;
  private static final String ARG1 = class_3.i.toString();
  private static final String GROUP;
  private static final String ID = Priority.id.toString();
  private static final String IGNORE_CASE = class_3.FOUND.toString();
  
  static
  {
    ARG0 = class_3.FAILURE.toString();
    GROUP = class_3.d.toString();
  }
  
  public Request()
  {
    super(ID, new String[] { ARG0 });
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    Object localObject = (Integer)paramMap.get(ARG0);
    if ((localObject == null) || (localObject == Boolean.get())) {
      return Boolean.get();
    }
    String str2 = Boolean.toString((Integer)localObject);
    localObject = (Integer)paramMap.get(ARG1);
    String str1;
    if (localObject == null)
    {
      str1 = "text";
      localObject = (Integer)paramMap.get(IGNORE_CASE);
      if (localObject != null) {
        break label161;
      }
      localObject = "base16";
      label84:
      paramMap = (Integer)paramMap.get(GROUP);
      if ((paramMap == null) || (!Boolean.valueOf(paramMap).booleanValue())) {
        break label346;
      }
    }
    label161:
    label278:
    label319:
    label346:
    for (int i = 3;; i = 2)
    {
      for (;;)
      {
        try
        {
          boolean bool = "text".equals(str1);
          if (bool)
          {
            paramMap = str2.getBytes();
            if (!"base16".equals(localObject)) {
              break label278;
            }
            paramMap = Base16.encode(paramMap);
            return Boolean.add(paramMap);
            str1 = Boolean.toString((Integer)localObject);
            break;
            localObject = Boolean.toString((Integer)localObject);
            break label84;
          }
          bool = "base16".equals(str1);
          if (bool)
          {
            paramMap = Base16.decode(str2);
            continue;
          }
          bool = "base64".equals(str1);
          if (bool)
          {
            paramMap = Base64.decode(str2, i);
            continue;
          }
          bool = "base64url".equals(str1);
          if (bool)
          {
            paramMap = Base64.decode(str2, i | 0x8);
            continue;
          }
          Log.e("Encode: unknown input format: " + str1);
          paramMap = Boolean.get();
          return paramMap;
        }
        catch (IllegalArgumentException paramMap)
        {
          Log.e("Encode: invalid input:");
          return Boolean.get();
        }
        if ("base64".equals(localObject))
        {
          paramMap = Base64.encodeToString(paramMap, i);
        }
        else
        {
          if (!"base64url".equals(localObject)) {
            break label319;
          }
          paramMap = Base64.encodeToString(paramMap, i | 0x8);
        }
      }
      Log.e("Encode: unknown output format: " + (String)localObject);
      return Boolean.get();
    }
  }
}
