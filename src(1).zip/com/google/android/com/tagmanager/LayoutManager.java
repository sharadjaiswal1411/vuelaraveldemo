package com.google.android.com.tagmanager;

import android.content.Context;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

class LayoutManager
  implements State
{
  private static final Object e = new Object();
  private static LayoutManager j;
  private m a;
  private k b;
  private String d;
  private String g;
  
  private LayoutManager(Context paramContext)
  {
    this(AsyncServer.getDefault(paramContext), new Model());
  }
  
  LayoutManager(m paramM, k paramK)
  {
    a = paramM;
    b = paramK;
  }
  
  public static State init(Context paramContext)
  {
    Object localObject = e;
    try
    {
      if (j == null) {
        j = new LayoutManager(paramContext);
      }
      paramContext = j;
      return paramContext;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public boolean a(String paramString)
  {
    if (!b.inflate())
    {
      Log.append("Too many urls sent too quickly with the TagManagerSender, rate limiting invoked.");
      return false;
    }
    Object localObject = paramString;
    if (g != null)
    {
      localObject = paramString;
      if (d == null) {}
    }
    try
    {
      localObject = new StringBuilder();
      String str = g;
      localObject = ((StringBuilder)localObject).append(str).append("?");
      str = d;
      localObject = str + "=" + URLEncoder.encode(paramString, "UTF-8");
      paramString = (String)localObject;
      Log.w("Sending wrapped url hit: " + (String)localObject);
      localObject = paramString;
      a.write((String)localObject);
      return true;
    }
    catch (UnsupportedEncodingException paramString)
    {
      Log.d("Error wrapping URL for testing.", paramString);
    }
    return false;
  }
}
