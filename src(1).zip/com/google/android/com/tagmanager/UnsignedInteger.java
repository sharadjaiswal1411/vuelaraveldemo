package com.google.android.com.tagmanager;

import com.google.android.gms.tagmanager.dg;

class UnsignedInteger
  extends Number
  implements Comparable<dg>
{
  private double _value;
  private long size;
  private boolean value;
  
  private UnsignedInteger(double paramDouble)
  {
    _value = paramDouble;
    value = false;
  }
  
  private UnsignedInteger(long paramLong)
  {
    size = paramLong;
    value = true;
  }
  
  public static UnsignedInteger add(long paramLong)
  {
    return new UnsignedInteger(paramLong);
  }
  
  public static UnsignedInteger add(Double paramDouble)
  {
    return new UnsignedInteger(paramDouble.doubleValue());
  }
  
  public static UnsignedInteger valueOf(String paramString)
    throws NumberFormatException
  {
    try
    {
      UnsignedInteger localUnsignedInteger1 = new UnsignedInteger(Long.parseLong(paramString));
      return localUnsignedInteger1;
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      try
      {
        UnsignedInteger localUnsignedInteger2 = new UnsignedInteger(Double.parseDouble(paramString));
        return localUnsignedInteger2;
      }
      catch (NumberFormatException localNumberFormatException2)
      {
        throw new NumberFormatException(paramString + " is not a valid TypedNumber");
      }
    }
  }
  
  public short add()
  {
    return (short)(int)longValue();
  }
  
  public byte byteValue()
  {
    return (byte)(int)longValue();
  }
  
  public int compareTo()
  {
    return (int)longValue();
  }
  
  public int compareTo(UnsignedInteger paramUnsignedInteger)
  {
    if ((getValue()) && (paramUnsignedInteger.getValue())) {
      return new Long(size).compareTo(Long.valueOf(size));
    }
    return Double.compare(doubleValue(), paramUnsignedInteger.doubleValue());
  }
  
  public boolean divide()
  {
    return !getValue();
  }
  
  public double doubleValue()
  {
    if (getValue()) {
      return size;
    }
    return _value;
  }
  
  public boolean equals(Object paramObject)
  {
    return ((paramObject instanceof UnsignedInteger)) && (compareTo((UnsignedInteger)paramObject) == 0);
  }
  
  public float floatValue()
  {
    return (float)doubleValue();
  }
  
  public boolean getValue()
  {
    return value;
  }
  
  public int hashCode()
  {
    return new Long(longValue()).hashCode();
  }
  
  public int intValue()
  {
    return compareTo();
  }
  
  public long longValue()
  {
    return serialize();
  }
  
  public long serialize()
  {
    if (getValue()) {
      return size;
    }
    return _value;
  }
  
  public short shortValue()
  {
    return add();
  }
  
  public String toString()
  {
    if (getValue()) {
      return Long.toString(size);
    }
    return Double.toString(_value);
  }
}
