package com.google.android.com.tagmanager;

class g
  implements x
{
  private g(d paramD) {}
  
  public void a()
  {
    if (d.b(a).inflate()) {
      d.b(a, 0L);
    }
  }
  
  public void a(String paramString)
  {
    a.a(paramString);
  }
  
  public String c()
  {
    return a.d();
  }
}
