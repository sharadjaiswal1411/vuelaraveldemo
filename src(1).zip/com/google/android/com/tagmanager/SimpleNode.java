package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class SimpleNode
  extends Message
{
  private static final String id = Priority.L.toString();
  private final String state;
  
  public SimpleNode(String paramString)
  {
    super(id, new String[0]);
    state = paramString;
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    if (state == null) {
      return Boolean.get();
    }
    return Boolean.add(state);
  }
}
