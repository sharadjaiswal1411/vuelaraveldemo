package com.google.android.com.tagmanager;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class Block
  extends Message
{
  private static final String time = Priority.DEBUG.toString();
  private final Context mContext;
  
  public Block(Context paramContext)
  {
    super(time, new String[0]);
    mContext = paramContext;
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    paramMap = mContext;
    try
    {
      paramMap = paramMap.getPackageManager();
      Context localContext = mContext;
      paramMap = Boolean.add(paramMap.getApplicationLabel(paramMap.getApplicationInfo(localContext.getPackageName(), 0)).toString());
      return paramMap;
    }
    catch (PackageManager.NameNotFoundException paramMap)
    {
      Log.e("App name is not found.", paramMap);
    }
    return Boolean.get();
  }
}
