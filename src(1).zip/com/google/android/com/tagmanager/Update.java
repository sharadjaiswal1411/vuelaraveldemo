package com.google.android.com.tagmanager;

import android.content.Context;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import com.google.android.com.internal.class_3;
import java.util.Map;

class Update
  extends Message
{
  private static final String path = Priority.$SwitchMap$cz$msebera$android$httpclient$auth$AuthProtocolState.toString();
  private static final String title = class_3.dumpOnErrorField.toString();
  private final Context context;
  
  public Update(Context paramContext)
  {
    super(path, new String[0]);
    context = paramContext;
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    if ((Integer)paramMap.get(title) != null) {}
    for (paramMap = Boolean.toString((Integer)paramMap.get(title));; paramMap = null)
    {
      paramMap = Tools.get(context, paramMap);
      if (paramMap == null) {
        break;
      }
      return Boolean.add(paramMap);
    }
    return Boolean.get();
  }
}
