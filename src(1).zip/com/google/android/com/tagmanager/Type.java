package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.class_3;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class Type
{
  public static cq.c a(String paramString)
    throws JSONException
  {
    paramString = get(new JSONObject(paramString));
    cq.d localD = cq.c.putByte();
    int i = 0;
    while (i < n.length)
    {
      localD.a(cq.a.a().a(class_3.a.toString(), n[i]).a(class_3.b.toString(), Boolean.a(Method.getValue())).a(Method.getDescriptor(), paramString.i[i]).a());
      i += 1;
    }
    return localD.b();
  }
  
  private static Integer get(Object paramObject)
    throws JSONException
  {
    return Boolean.add(toString(paramObject));
  }
  
  static Object toString(Object paramObject)
    throws JSONException
  {
    if ((paramObject instanceof JSONArray)) {
      throw new RuntimeException("JSONArrays are not supported");
    }
    if (JSONObject.NULL.equals(paramObject)) {
      throw new RuntimeException("JSON nulls are not supported");
    }
    if ((paramObject instanceof JSONObject))
    {
      paramObject = (JSONObject)paramObject;
      HashMap localHashMap = new HashMap();
      Iterator localIterator = paramObject.keys();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        localHashMap.put(str, toString(paramObject.get(str)));
      }
      return localHashMap;
    }
    return paramObject;
  }
}
