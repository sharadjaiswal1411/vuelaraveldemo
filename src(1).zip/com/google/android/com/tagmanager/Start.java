package com.google.android.com.tagmanager;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

class Start
  extends Handler
{
  private final ContainerHolder.ContainerAvailableListener ctx;
  
  public Start(MethodWriter paramMethodWriter, ContainerHolder.ContainerAvailableListener paramContainerAvailableListener, Looper paramLooper)
  {
    super(paramLooper);
    ctx = paramContainerAvailableListener;
  }
  
  public void close(String paramString)
  {
    sendMessage(obtainMessage(1, paramString));
  }
  
  public void handleMessage(Message paramMessage)
  {
    switch (what)
    {
    default: 
      Log.e("Don't know how to handle this message.");
      return;
    }
    showLoadingDialog((String)obj);
  }
  
  protected void showLoadingDialog(String paramString)
  {
    ctx.onContainerAvailable(callId, paramString);
  }
}
