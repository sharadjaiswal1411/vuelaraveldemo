package com.google.android.com.tagmanager;

final class Log
{
  static int ERROR;
  static Logger o = new Frame();
  
  public static void append(String paramString)
  {
    o.set(paramString);
  }
  
  public static void d(String paramString)
  {
    o.d(paramString);
  }
  
  public static void d(String paramString, Throwable paramThrowable)
  {
    o.d(paramString, paramThrowable);
  }
  
  public static void e(String paramString)
  {
    o.b(paramString);
  }
  
  public static void e(String paramString, Throwable paramThrowable)
  {
    o.a(paramString, paramThrowable);
  }
  
  public static int getLogLevel()
  {
    return ERROR;
  }
  
  public static void i(String paramString)
  {
    o.a(paramString);
  }
  
  public static void setLogLevel(int paramInt)
  {
    o.setLogLevel(paramInt);
  }
  
  public static void w(String paramString)
  {
    o.toString(paramString);
  }
}
