package com.google.android.com.tagmanager;

abstract interface AnnotationVisitor
{
  public abstract AnnotationVisitor visitAnnotation(int paramInt);
  
  public abstract m.a visitAnnotation();
  
  public abstract AnnotationVisitor visitLocalVariableAnnotation(int paramInt);
  
  public abstract AnnotationVisitor visitParameterAnnotation(int paramInt);
  
  public abstract AnnotationVisitor visitTypeAnnotation(int paramInt);
}
