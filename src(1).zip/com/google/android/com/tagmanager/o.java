package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;

class o
  implements ad
{
  o() {}
  
  public aa a()
  {
    return new w();
  }
  
  public void a(Integer paramInteger) {}
  
  public ExtensionData b()
  {
    return new bu.a(this);
  }
  
  public ExtensionData c()
  {
    return new bu.a(this);
  }
  
  public aa getItem()
  {
    return new w();
  }
  
  public ExtensionData p()
  {
    return new bu.a(this);
  }
  
  public ExtensionData setIcon()
  {
    return new bu.a(this);
  }
}
