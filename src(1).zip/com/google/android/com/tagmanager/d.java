package com.google.android.com.tagmanager;

import android.os.Looper;
import com.google.android.com.common.ClickListeners.Status;
import com.google.android.com.internal.Clock;
import com.google.android.com.internal.Node;
import com.google.android.com.internal.SystemClock;
import com.google.android.com.internal.it.a;
import com.google.android.gms.common.api.a.a;

class d
  extends a.a<com.google.android.gms.tagmanager.ContainerHolder>
{
  private volatile MethodWriter a;
  private final String b;
  private volatile boolean c;
  private final g d;
  private com.google.android.com.internal.Context e;
  private long f;
  private final int g;
  private final Clock i;
  private final k j;
  private XYPlot l;
  private final android.content.Context mContext;
  private Item o;
  private String q;
  private ClassReader r;
  private final TagManager v;
  private final Looper x;
  
  public d(android.content.Context paramContext, TagManager paramTagManager, Looper paramLooper, String paramString, int paramInt, Label paramLabel)
  {
    this(paramContext, paramTagManager, paramLooper, paramString, paramInt, new Plot(paramContext, paramString), new f(paramContext, paramString, paramLabel), SystemClock.get(), new Inflate(30, 900000L, 5000L, "refreshing", SystemClock.get()));
  }
  
  d(android.content.Context paramContext, TagManager paramTagManager, Looper paramLooper, String paramString, int paramInt, XYPlot paramXYPlot, Item paramItem, Clock paramClock, k paramK) {}
  
  private void a(boolean paramBoolean)
  {
    l.a(new e(this, null));
    o.a(new j(this, null));
    cq.c localC = l.a(g);
    if (localC != null) {
      a = new MethodWriter(v, x, new Container(mContext, v.getDataLayer(), b, 0L, localC), d);
    }
    r = new AnnotationWriter(this, paramBoolean);
    if (b())
    {
      o.a(0L, "");
      return;
    }
    l.b();
  }
  
  /* Error */
  private void b(long paramLong)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 104	com/google/android/com/tagmanager/d:o	Lcom/google/android/com/tagmanager/Item;
    //   6: ifnonnull +11 -> 17
    //   9: ldc -71
    //   11: invokestatic 190	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: aload_0
    //   18: getfield 104	com/google/android/com/tagmanager/d:o	Lcom/google/android/com/tagmanager/Item;
    //   21: lload_1
    //   22: aload_0
    //   23: getfield 116	com/google/android/com/tagmanager/d:e	Lcom/google/android/com/internal/Context;
    //   26: getfield 192	com/google/android/com/internal/Context:c	Ljava/lang/String;
    //   29: invokeinterface 174 4 0
    //   34: goto -20 -> 14
    //   37: astore_3
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_3
    //   41: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	42	0	this	d
    //   0	42	1	paramLong	long
    //   37	4	3	localThrowable	Throwable
    // Exception table:
    //   from	to	target	type
    //   2	14	37	java/lang/Throwable
    //   17	34	37	java/lang/Throwable
  }
  
  private void b(com.google.android.com.internal.Context paramContext)
  {
    try
    {
      if (l != null)
      {
        it.a localA = new it.a();
        a = f;
        properties = new Node();
        value = paramContext;
        l.b(localA);
      }
      return;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  private void b(com.google.android.com.internal.Context paramContext, long paramLong, boolean paramBoolean)
  {
    if (paramBoolean) {}
    for (;;)
    {
      try
      {
        paramBoolean = c;
        if (paramBoolean) {
          return;
        }
        if ((isReady()) && (a == null)) {}
        e = paramContext;
        f = paramLong;
        b(Math.max(0L, Math.min(43200000L, f + 43200000L - i.currentTimeMillis())));
        paramContext = new Container(mContext, v.getDataLayer(), b, paramLong, paramContext);
        if (a == null)
        {
          a = new MethodWriter(v, x, paramContext, d);
          if ((!isReady()) && (r.a(paramContext))) {
            a(a);
          }
        }
        else
        {
          a.a(paramContext);
        }
      }
      catch (Throwable paramContext)
      {
        throw paramContext;
      }
    }
  }
  
  private boolean b()
  {
    a localA = a.a();
    return ((localA.getValue() == cd.a.i) || (localA.getValue() == cd.a.b)) && (b.equals(localA.getContainerId()));
  }
  
  protected ContainerHolder a(Status paramStatus)
  {
    if (a != null) {
      return a;
    }
    if (paramStatus == Status.d) {
      Log.e("timer expired: setting result to failure");
    }
    return new MethodWriter(paramStatus);
  }
  
  public void a()
  {
    Object localObject = l.a(g);
    if (localObject != null)
    {
      localObject = new Container(mContext, v.getDataLayer(), b, 0L, (cq.c)localObject);
      a(new MethodWriter(v, x, (Container)localObject, new NavigationMenuPresenter(this)));
    }
    for (;;)
    {
      o = null;
      l = null;
      return;
      Log.e("Default was requested, but no default container was found");
      a(a(new Status(10, "Default was requested, but no default container was found", null)));
    }
  }
  
  void a(String paramString)
  {
    try
    {
      q = paramString;
      if (o != null) {
        o.a(paramString);
      }
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void c()
  {
    a(true);
  }
  
  String d()
  {
    try
    {
      String str = q;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public void updateMenuView()
  {
    a(false);
  }
}
