package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

class Card
{
  private static h a(h paramH)
  {
    try
    {
      Object localObject = paramH.getObject();
      localObject = (Integer)localObject;
      localObject = encode(Boolean.toString((Integer)localObject));
      localObject = new h(Boolean.add(localObject), paramH.a());
      return localObject;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      Log.e("Escape URI: unsupported encoding", localUnsupportedEncodingException);
    }
    return paramH;
  }
  
  private static h a(h paramH, int paramInt)
  {
    if (!getValue((Integer)paramH.getObject()))
    {
      Log.e("Escaping can only be applied to strings.");
      return paramH;
    }
    switch (paramInt)
    {
    default: 
      Log.e("Unsupported Value Escaping: " + paramInt);
      return paramH;
    }
    return a(paramH);
  }
  
  static h a(h paramH, int... paramVarArgs)
  {
    int j = paramVarArgs.length;
    int i = 0;
    while (i < j)
    {
      paramH = a(paramH, paramVarArgs[i]);
      i += 1;
    }
    return paramH;
  }
  
  static String encode(String paramString)
    throws UnsupportedEncodingException
  {
    return URLEncoder.encode(paramString, "UTF-8").replaceAll("\\+", "%20");
  }
  
  private static boolean getValue(Integer paramInteger)
  {
    return Boolean.get(paramInteger) instanceof String;
  }
}
