package com.google.android.com.tagmanager;

import java.io.IOException;
import java.io.InputStream;

abstract interface HttpConnection
{
  public abstract void close();
  
  public abstract InputStream get(String paramString)
    throws IOException;
}
