package com.google.android.com.tagmanager;

class NavigationMenuPresenter
  implements x
{
  NavigationMenuPresenter(d paramD) {}
  
  public void a()
  {
    Log.append("Refresh ignored: container loaded as default only.");
  }
  
  public void a(String paramString)
  {
    a.a(paramString);
  }
  
  public String c()
  {
    return a.d();
  }
}
