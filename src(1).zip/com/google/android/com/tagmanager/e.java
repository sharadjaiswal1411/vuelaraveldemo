package com.google.android.com.tagmanager;

import com.google.android.com.internal.Context;
import com.google.android.com.internal.Node;
import com.google.android.gms.tagmanager.bg;

class e
  implements bg<com.google.android.gms.internal.it.a>
{
  private e(d paramD) {}
  
  public void a() {}
  
  public void a(bg.a paramA)
  {
    if (!d.a(b)) {
      d.b(b, 0L);
    }
  }
  
  public void b(com.google.android.com.internal.it.a paramA)
  {
    Context localContext;
    if (value != null) {
      localContext = value;
    }
    for (;;)
    {
      d.b(b, localContext, a, true);
      return;
      Node localNode = properties;
      localContext = new Context();
      b = localNode;
      a = null;
      c = id;
    }
  }
}
