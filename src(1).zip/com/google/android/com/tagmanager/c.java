package com.google.android.com.tagmanager;

abstract interface c<T>
{
  public abstract void a();
  
  public abstract void a(bg.a paramA);
  
  public abstract void a(Object paramObject);
}
