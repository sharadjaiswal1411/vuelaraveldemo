package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import java.util.Map;

abstract class Variance
  extends Predicate
{
  public Variance(String paramString)
  {
    super(paramString);
  }
  
  protected abstract boolean apply(String paramString1, String paramString2, Map paramMap);
  
  protected boolean evaluate(Integer paramInteger1, Integer paramInteger2, Map paramMap)
  {
    paramInteger1 = Boolean.toString(paramInteger1);
    paramInteger2 = Boolean.toString(paramInteger2);
    if ((paramInteger1 == Boolean.valueOf()) || (paramInteger2 == Boolean.valueOf())) {
      return false;
    }
    return apply(paramInteger1, paramInteger2, paramMap);
  }
}
