package com.google.android.com.tagmanager;

import android.os.Build.VERSION;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class Language
  extends Message
{
  private static final String DEFAULT_KEYSTORE_PATH = Priority.P.toString();
  
  public Language()
  {
    super(DEFAULT_KEYSTORE_PATH, new String[0]);
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    return Boolean.add(Build.VERSION.RELEASE);
  }
}
