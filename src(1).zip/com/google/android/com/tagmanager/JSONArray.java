package com.google.android.com.tagmanager;

import java.util.Arrays;

class JSONArray
{
  final String data;
  final byte[] id;
  
  JSONArray(String paramString, byte[] paramArrayOfByte)
  {
    data = paramString;
    id = paramArrayOfByte;
  }
  
  public String toString()
  {
    return "KeyAndSerialized: key = " + data + " serialized hash = " + Arrays.hashCode(id);
  }
}
