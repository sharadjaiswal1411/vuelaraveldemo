package com.google.android.com.tagmanager;

abstract interface ClassReader
{
  public abstract boolean a(Container paramContainer);
}
