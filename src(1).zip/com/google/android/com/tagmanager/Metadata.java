package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import com.google.android.com.internal.class_3;
import java.util.Map;

class Metadata
  extends Message
{
  private static final String description = Priority.T.toString();
  private static final String id = class_3.s.toString();
  private static final String title = class_3.P.toString();
  
  public Metadata()
  {
    super(description, new String[0]);
  }
  
  public boolean equals()
  {
    return false;
  }
  
  public Integer evaluate(Map paramMap)
  {
    Object localObject = (Integer)paramMap.get(title);
    paramMap = (Integer)paramMap.get(id);
    double d3;
    double d2;
    if ((localObject != null) && (localObject != Boolean.get()) && (paramMap != null) && (paramMap != Boolean.get()))
    {
      localObject = Boolean.add((Integer)localObject);
      paramMap = Boolean.add(paramMap);
      if ((localObject != Boolean.add()) && (paramMap != Boolean.add()))
      {
        d3 = ((UnsignedInteger)localObject).doubleValue();
        d2 = paramMap.doubleValue();
        d1 = d2;
        if (d3 <= d2) {
          d2 = d1;
        }
      }
    }
    for (double d1 = d3;; d1 = 0.0D)
    {
      return Boolean.add(Long.valueOf(Math.round((d2 - d1) * Math.random() + d1)));
      d2 = 2.147483647E9D;
    }
  }
}
