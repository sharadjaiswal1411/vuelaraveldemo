package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;

class FieldVisitorTee
  implements FieldVisitor
{
  FieldVisitorTee() {}
  
  public AnnotationVisitor visitAnnotation(Integer paramInteger)
  {
    return new MethodVisitor();
  }
}
