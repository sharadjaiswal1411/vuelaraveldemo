package com.google.android.com.tagmanager;

class h<T>
{
  private final boolean a;
  private final T object;
  
  h(Object paramObject, boolean paramBoolean)
  {
    object = paramObject;
    a = paramBoolean;
  }
  
  public boolean a()
  {
    return a;
  }
  
  public Object getObject()
  {
    return object;
  }
}
