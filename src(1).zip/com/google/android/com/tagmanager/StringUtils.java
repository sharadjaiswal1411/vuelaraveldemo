package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import com.google.android.com.internal.class_3;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

class StringUtils
  extends Message
{
  private static final String ARG0 = class_3.FAILURE.toString();
  private static final String ARG1 = class_3.SINGLE.toString();
  private static final String ID = Priority.log.toString();
  private static final String IGNORE_CASE = class_3.i.toString();
  
  public StringUtils()
  {
    super(ID, new String[] { ARG0 });
  }
  
  private byte[] hash(String paramString, byte[] paramArrayOfByte)
    throws NoSuchAlgorithmException
  {
    paramString = MessageDigest.getInstance(paramString);
    paramString.update(paramArrayOfByte);
    return paramString.digest();
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    Object localObject = (Integer)paramMap.get(ARG0);
    if ((localObject == null) || (localObject == Boolean.get())) {
      return Boolean.get();
    }
    String str = Boolean.toString((Integer)localObject);
    localObject = (Integer)paramMap.get(ARG1);
    if (localObject == null)
    {
      localObject = "MD5";
      paramMap = (Integer)paramMap.get(IGNORE_CASE);
      if (paramMap != null) {
        break label110;
      }
      paramMap = "text";
      label73:
      if (!"text".equals(paramMap)) {
        break label118;
      }
      paramMap = str.getBytes();
    }
    for (;;)
    {
      try
      {
        paramMap = Boolean.add(Base16.encode(hash((String)localObject, paramMap)));
        return paramMap;
      }
      catch (NoSuchAlgorithmException paramMap)
      {
        label110:
        label118:
        Log.e("Hash: unknown algorithm: " + (String)localObject);
      }
      localObject = Boolean.toString((Integer)localObject);
      break;
      paramMap = Boolean.toString(paramMap);
      break label73;
      if ("base16".equals(paramMap))
      {
        paramMap = Base16.decode(str);
      }
      else
      {
        Log.e("Hash: unknown input format: " + paramMap);
        return Boolean.get();
      }
    }
    return Boolean.get();
  }
}
