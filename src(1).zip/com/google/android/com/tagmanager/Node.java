package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class Node
  extends Message
{
  private static final String ID = Priority.s.toString();
  private static final Integer PLATFORM = Boolean.add("Android");
  
  public Node()
  {
    super(ID, new String[0]);
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    return PLATFORM;
  }
}
