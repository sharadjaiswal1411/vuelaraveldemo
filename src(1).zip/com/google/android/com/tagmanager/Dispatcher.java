package com.google.android.com.tagmanager;

import java.util.List;

abstract interface Dispatcher
{
  public abstract void dispatchHits(List paramList);
  
  public abstract boolean isConnected();
}
