package com.google.android.com.tagmanager;

import com.google.android.gms.tagmanager.k;
import com.google.android.gms.tagmanager.l.a;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class SimpleCache<K, V>
  implements k<K, V>
{
  private final l.a<K, V> key;
  private final Map<K, V> mHashMap = new HashMap();
  private final int mMaxSize;
  private int mTotalSize;
  
  SimpleCache(int paramInt, LruCache paramLruCache)
  {
    mMaxSize = paramInt;
    key = paramLruCache;
  }
  
  public Object get(Object paramObject)
  {
    try
    {
      paramObject = mHashMap.get(paramObject);
      return paramObject;
    }
    catch (Throwable paramObject)
    {
      throw paramObject;
    }
  }
  
  public void put(Object paramObject1, Object paramObject2)
  {
    if ((paramObject1 == null) || (paramObject2 == null)) {
      try
      {
        throw new NullPointerException("key == null || value == null");
      }
      catch (Throwable paramObject1)
      {
        throw paramObject1;
      }
    }
    mTotalSize += key.sizeOf(paramObject1, paramObject2);
    if (mTotalSize > mMaxSize)
    {
      Iterator localIterator = mHashMap.entrySet().iterator();
      do
      {
        if (!localIterator.hasNext()) {
          break;
        }
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        mTotalSize -= key.sizeOf(localEntry.getKey(), localEntry.getValue());
        localIterator.remove();
      } while (mTotalSize > mMaxSize);
    }
    mHashMap.put(paramObject1, paramObject2);
  }
}
