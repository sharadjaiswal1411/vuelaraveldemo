package com.google.android.com.tagmanager;

import java.util.List;

abstract interface ExtensionData
{
  public abstract void a(List paramList1, List paramList2);
}
