package com.google.android.com.tagmanager;

import com.google.android.com.internal.Clock;

class AnnotationWriter
  implements ClassReader
{
  AnnotationWriter(d paramD, boolean paramBoolean) {}
  
  public boolean a(Container paramContainer)
  {
    if (f) {
      return paramContainer.getLastRefreshTime() + 43200000L >= d.g(a).currentTimeMillis();
    }
    return !paramContainer.isDefault();
  }
}
