package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

abstract class Message
{
  private final Set<String> data;
  private final String resourcePath;
  
  public Message(String paramString, String... paramVarArgs)
  {
    resourcePath = paramString;
    data = new HashSet(paramVarArgs.length);
    int j = paramVarArgs.length;
    int i = 0;
    while (i < j)
    {
      paramString = paramVarArgs[i];
      data.add(paramString);
      i += 1;
    }
  }
  
  boolean add(Set paramSet)
  {
    return paramSet.containsAll(data);
  }
  
  public abstract boolean equals();
  
  public abstract Integer evaluate(Map paramMap);
  
  public String getResourcePath()
  {
    return resourcePath;
  }
  
  public Set getType()
  {
    return data;
  }
}
