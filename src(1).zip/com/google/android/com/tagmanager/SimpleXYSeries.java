package com.google.android.com.tagmanager;

import com.google.android.com.internal.Priority;
import java.util.Map;

class SimpleXYSeries
  extends Variance
{
  private static final String title = Priority.map.toString();
  
  public SimpleXYSeries()
  {
    super(title);
  }
  
  protected boolean apply(String paramString1, String paramString2, Map paramMap)
  {
    return paramString1.endsWith(paramString2);
  }
}
