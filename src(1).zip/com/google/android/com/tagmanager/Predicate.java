package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.class_3;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

abstract class Predicate
  extends Message
{
  private static final String ARG0 = class_3.FAILURE.toString();
  private static final String ARG1 = class_3.SUCCESS.toString();
  
  public Predicate(String paramString)
  {
    super(paramString, new String[] { ARG0, ARG1 });
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    Object localObject = paramMap.values().iterator();
    while (((Iterator)localObject).hasNext()) {
      if ((Integer)((Iterator)localObject).next() == Boolean.get()) {
        return Boolean.add(java.lang.Boolean.valueOf(false));
      }
    }
    localObject = (Integer)paramMap.get(ARG0);
    Integer localInteger = (Integer)paramMap.get(ARG1);
    if ((localObject == null) || (localInteger == null)) {}
    for (boolean bool = false;; bool = evaluate((Integer)localObject, localInteger, paramMap)) {
      return Boolean.add(java.lang.Boolean.valueOf(bool));
    }
  }
  
  protected abstract boolean evaluate(Integer paramInteger1, Integer paramInteger2, Map paramMap);
}
