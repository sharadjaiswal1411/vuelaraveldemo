package com.google.android.com.tagmanager;

import android.os.Build;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class Resource
  extends Message
{
  private static final String directory = Priority.B.toString();
  
  public Resource()
  {
    super(directory, new String[0]);
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    String str2 = Build.MANUFACTURER;
    String str1 = Build.MODEL;
    paramMap = str1;
    if (!str1.startsWith(str2))
    {
      paramMap = str1;
      if (!str2.equals("unknown")) {
        paramMap = str2 + " " + str1;
      }
    }
    return Boolean.add(paramMap);
  }
}
