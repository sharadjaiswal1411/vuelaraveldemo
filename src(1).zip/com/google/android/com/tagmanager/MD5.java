package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class MD5
  extends Message
{
  private static final String DEFAULT_KEYSTORE_PATH = Priority.a.toString();
  
  public MD5()
  {
    super(DEFAULT_KEYSTORE_PATH, new String[0]);
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    return Boolean.add(Long.valueOf(65833898L));
  }
}
