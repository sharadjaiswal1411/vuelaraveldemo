package com.google.android.com.tagmanager;

class Model
  implements k
{
  private final long flags;
  private double mode;
  private final Object msg = new Object();
  private long need;
  private final int wrap;
  
  public Model()
  {
    this(60, 2000L);
  }
  
  public Model(int paramInt, long paramLong)
  {
    wrap = paramInt;
    mode = wrap;
    flags = paramLong;
  }
  
  public boolean inflate()
  {
    Object localObject = msg;
    try
    {
      long l = System.currentTimeMillis();
      if (mode < wrap)
      {
        double d = (l - need) / flags;
        if (d > 0.0D) {
          mode = Math.min(wrap, d + mode);
        }
      }
      need = l;
      if (mode >= 1.0D)
      {
        mode -= 1.0D;
        return true;
      }
      Log.append("No more tokens available.");
      return false;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
}
