package com.google.android.com.tagmanager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataLayer
{
  public static final String EVENT_KEY = "event";
  private static final Pattern HEX_PATTERN = Pattern.compile("(\\d+)\\s*([smhd]?)");
  public static final Object OBJECT_NOT_PRESENT = new Object();
  static final String[] group = "gtm.lifetime".toString().split("\\.");
  private final CountDownLatch current;
  private final c j;
  private final ReentrantLock lock;
  private final ConcurrentHashMap<com.google.android.gms.tagmanager.DataLayer.b, Integer> m;
  private final Map<String, Object> n;
  private final LinkedList<Map<String, Object>> queue;
  
  DataLayer()
  {
    this(new DataLayer.1());
  }
  
  DataLayer(c paramC)
  {
    j = paramC;
    m = new ConcurrentHashMap();
    n = new HashMap();
    lock = new ReentrantLock();
    queue = new LinkedList();
    current = new CountDownLatch(1);
    b();
  }
  
  private void add(Map paramMap)
  {
    Long localLong = get(paramMap);
    if (localLong == null) {
      return;
    }
    paramMap = getEntries(paramMap);
    paramMap.remove("gtm.lifetime");
    j.a(paramMap, localLong.longValue());
  }
  
  private void b()
  {
    j.b(new DataLayer.2(this));
  }
  
  private void copy(Map paramMap)
  {
    Map localMap = n;
    try
    {
      Iterator localIterator = paramMap.keySet().iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        add(get(str, paramMap.get(str)), n);
      }
    }
    catch (Throwable paramMap)
    {
      throw paramMap;
    }
    remove(paramMap);
  }
  
  private void execute()
  {
    int i = 0;
    for (;;)
    {
      Map localMap = (Map)queue.poll();
      if (localMap == null) {
        break;
      }
      copy(localMap);
      i += 1;
      if (i > 500)
      {
        queue.clear();
        throw new RuntimeException("Seems like an infinite loop of pushing to the data layer");
      }
    }
  }
  
  private void execute(Map paramMap)
  {
    lock.lock();
    try
    {
      queue.offer(paramMap);
      int i = lock.getHoldCount();
      if (i == 1) {
        execute();
      }
      add(paramMap);
      lock.unlock();
      return;
    }
    catch (Throwable paramMap)
    {
      lock.unlock();
      throw paramMap;
    }
  }
  
  private void format(Map paramMap, String paramString, Collection paramCollection)
  {
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      StringBuilder localStringBuilder = new StringBuilder().append(paramString);
      if (paramString.length() == 0) {}
      for (paramMap = "";; paramMap = ".")
      {
        paramMap = paramMap + (String)localEntry.getKey();
        if (!(localEntry.getValue() instanceof Map)) {
          break label119;
        }
        format((Map)localEntry.getValue(), paramMap, paramCollection);
        break;
      }
      label119:
      if (!paramMap.equals("gtm.lifetime")) {
        paramCollection.add(new a(paramMap, localEntry.getValue()));
      }
    }
  }
  
  private Long get(Map paramMap)
  {
    paramMap = read(paramMap);
    if (paramMap == null) {
      return null;
    }
    return parse(paramMap.toString());
  }
  
  private List getEntries(Map paramMap)
  {
    ArrayList localArrayList = new ArrayList();
    format(paramMap, "", localArrayList);
    return localArrayList;
  }
  
  public static List listOf(Object... paramVarArgs)
  {
    ArrayList localArrayList = new ArrayList();
    int i = 0;
    while (i < paramVarArgs.length)
    {
      localArrayList.add(paramVarArgs[i]);
      i += 1;
    }
    return localArrayList;
  }
  
  public static Map mapOf(Object... paramVarArgs)
  {
    if (paramVarArgs.length % 2 != 0) {
      throw new IllegalArgumentException("expected even number of key-value pairs");
    }
    HashMap localHashMap = new HashMap();
    int i = 0;
    while (i < paramVarArgs.length)
    {
      if (!(paramVarArgs[i] instanceof String)) {
        throw new IllegalArgumentException("key is not a string: " + paramVarArgs[i]);
      }
      localHashMap.put((String)paramVarArgs[i], paramVarArgs[(i + 1)]);
      i += 2;
    }
    return localHashMap;
  }
  
  static Long parse(String paramString)
  {
    Object localObject = HEX_PATTERN.matcher(paramString);
    if (!((Matcher)localObject).matches())
    {
      Log.i("unknown _lifetime: " + paramString);
      return null;
    }
    long l;
    try
    {
      l = Long.parseLong(((Matcher)localObject).group(1));
      if (l <= 0L)
      {
        Log.i("non-positive _lifetime: " + paramString);
        return null;
      }
    }
    catch (NumberFormatException localNumberFormatException)
    {
      for (;;)
      {
        Log.append("illegal number in _lifetime value: " + paramString);
        l = 0L;
      }
      localObject = ((Matcher)localObject).group(2);
      if (((String)localObject).length() == 0) {
        return Long.valueOf(l);
      }
      switch (((String)localObject).charAt(0))
      {
      default: 
        Log.append("unknown units in _lifetime: " + paramString);
        return null;
      }
    }
    return Long.valueOf(l * 1000L);
    return Long.valueOf(l * 1000L * 60L);
    return Long.valueOf(l * 1000L * 60L * 60L);
    return Long.valueOf(l * 1000L * 60L * 60L * 24L);
  }
  
  private Object read(Map paramMap)
  {
    String[] arrayOfString = group;
    int k = arrayOfString.length;
    int i = 0;
    while (i < k)
    {
      String str = arrayOfString[i];
      if (!(paramMap instanceof Map)) {
        return null;
      }
      paramMap = (Map)paramMap;
      i += 1;
      paramMap = paramMap.get(str);
    }
    return paramMap;
  }
  
  private void remove(Map paramMap)
  {
    Iterator localIterator = m.keySet().iterator();
    while (localIterator.hasNext()) {
      ((b)localIterator.next()).changed(paramMap);
    }
  }
  
  void add(Map paramMap1, Map paramMap2)
  {
    Iterator localIterator = paramMap1.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      Object localObject = paramMap1.get(str);
      if ((localObject instanceof List))
      {
        if (!(paramMap2.get(str) instanceof List)) {
          paramMap2.put(str, new ArrayList());
        }
        render((List)localObject, (List)paramMap2.get(str));
      }
      else if ((localObject instanceof Map))
      {
        if (!(paramMap2.get(str) instanceof Map)) {
          paramMap2.put(str, new HashMap());
        }
        add((Map)localObject, (Map)paramMap2.get(str));
      }
      else
      {
        paramMap2.put(str, localObject);
      }
    }
  }
  
  public Object get(String paramString)
  {
    Map localMap2 = n;
    try
    {
      Map localMap1 = n;
      String[] arrayOfString = paramString.split("\\.");
      int k = arrayOfString.length;
      paramString = localMap1;
      int i = 0;
      while (i < k)
      {
        localMap1 = arrayOfString[i];
        if (!(paramString instanceof Map)) {
          return null;
        }
        paramString = ((Map)paramString).get(localMap1);
        if (paramString == null) {
          return null;
        }
        i += 1;
      }
      return paramString;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  Map get(String paramString, Object paramObject)
  {
    HashMap localHashMap1 = new HashMap();
    String[] arrayOfString = paramString.toString().split("\\.");
    int i = 0;
    HashMap localHashMap2;
    for (paramString = localHashMap1; i < arrayOfString.length - 1; paramString = localHashMap2)
    {
      localHashMap2 = new HashMap();
      paramString.put(arrayOfString[i], localHashMap2);
      i += 1;
    }
    paramString.put(arrayOfString[(arrayOfString.length - 1)], paramObject);
    return localHashMap1;
  }
  
  public void push(String paramString, Object paramObject)
  {
    push(get(paramString, paramObject));
  }
  
  public void push(Map paramMap)
  {
    CountDownLatch localCountDownLatch = current;
    try
    {
      localCountDownLatch.await();
      execute(paramMap);
      return;
    }
    catch (InterruptedException localInterruptedException)
    {
      for (;;)
      {
        Log.append("DataLayer.push: unexpected InterruptedException");
      }
    }
  }
  
  public void pushEvent(String paramString, Map paramMap)
  {
    paramMap = new HashMap(paramMap);
    paramMap.put("event", paramString);
    push(paramMap);
  }
  
  void putAll(b paramB)
  {
    m.put(paramB, Integer.valueOf(0));
  }
  
  void remove(String paramString)
  {
    push(paramString, null);
    j.remove(paramString);
  }
  
  void render(List paramList1, List paramList2)
  {
    while (paramList2.size() < paramList1.size()) {
      paramList2.add(null);
    }
    int i = 0;
    if (i < paramList1.size())
    {
      Object localObject = paramList1.get(i);
      if ((localObject instanceof List))
      {
        if (!(paramList2.get(i) instanceof List)) {
          paramList2.set(i, new ArrayList());
        }
        render((List)localObject, (List)paramList2.get(i));
      }
      for (;;)
      {
        i += 1;
        break;
        if ((localObject instanceof Map))
        {
          if (!(paramList2.get(i) instanceof Map)) {
            paramList2.set(i, new HashMap());
          }
          add((Map)localObject, (Map)paramList2.get(i));
        }
        else if (localObject != OBJECT_NOT_PRESENT)
        {
          paramList2.set(i, localObject);
        }
      }
    }
  }
  
  final class a
  {
    public final Object v;
    
    a(Object paramObject)
    {
      v = paramObject;
    }
    
    public boolean equals(Object paramObject)
    {
      if (!(paramObject instanceof a)) {
        return false;
      }
      paramObject = (a)paramObject;
      return (DataLayer.this.equals(a)) && (v.equals(v));
    }
    
    public int hashCode()
    {
      return Arrays.hashCode(new Integer[] { Integer.valueOf(DataLayer.this.hashCode()), Integer.valueOf(v.hashCode()) });
    }
    
    public String toString()
    {
      return "Key: " + DataLayer.this + " value: " + v.toString();
    }
  }
  
  abstract interface b
  {
    public abstract void changed(Map paramMap);
  }
  
  abstract interface c
  {
    public abstract void a(List paramList, long paramLong);
    
    public abstract void b(a paramA);
    
    public abstract void remove(String paramString);
    
    public abstract interface a
    {
      public abstract void a(List paramList);
    }
  }
}
