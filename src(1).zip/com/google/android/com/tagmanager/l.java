package com.google.android.com.tagmanager;

class l
  implements q
{
  l() {}
  
  public i.a a(String paramString)
  {
    return new Configurator();
  }
  
  public i.a b(String paramString)
  {
    return new Configurator();
  }
  
  public boolean b()
  {
    return false;
  }
}
