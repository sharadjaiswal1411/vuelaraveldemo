package com.google.android.com.tagmanager;

import android.content.Context;
import android.provider.Settings.Secure;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class Util
  extends Message
{
  private static final String pattern = Priority.UNDEFINED.toString();
  private final Context mContext;
  
  public Util(Context paramContext)
  {
    super(pattern, new String[0]);
    mContext = paramContext;
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    paramMap = getAndroidId(mContext);
    if (paramMap == null) {
      return Boolean.get();
    }
    return Boolean.add(paramMap);
  }
  
  protected String getAndroidId(Context paramContext)
  {
    return Settings.Secure.getString(paramContext.getContentResolver(), "android_id");
  }
}
