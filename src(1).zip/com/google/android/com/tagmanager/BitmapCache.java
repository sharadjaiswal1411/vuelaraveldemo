package com.google.android.com.tagmanager;

import com.google.android.com.internal.Attribute;
import com.google.android.com.internal.Buffer;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Point;
import java.util.Map;

class BitmapCache
{
  private static void add(DataLayer paramDataLayer, Point paramPoint)
  {
    Buffer[] arrayOfBuffer = data;
    int j = arrayOfBuffer.length;
    int i = 0;
    while (i < j)
    {
      Buffer localBuffer = arrayOfBuffer[i];
      if (value == null)
      {
        Log.append("GaExperimentRandom: No key");
        i += 1;
      }
      else
      {
        Object localObject = paramDataLayer.get(value);
        paramPoint = (Point)localObject;
        if (!(localObject instanceof Number))
        {
          localObject = null;
          label68:
          long l1 = bytes;
          long l2 = size;
          if ((!type) || (localObject == null) || (((Long)localObject).longValue() < l1) || (((Long)localObject).longValue() > l2))
          {
            if (l1 > l2) {
              break label243;
            }
            paramPoint = Long.valueOf(Math.round(Math.random() * (l2 - l1) + l1));
          }
          paramDataLayer.remove(value);
          paramPoint = paramDataLayer.get(value, paramPoint);
          if (length > 0L)
          {
            if (paramPoint.containsKey("gtm")) {
              break label251;
            }
            paramPoint.put("gtm", DataLayer.mapOf(new Object[] { "lifetime", Long.valueOf(length) }));
          }
        }
        for (;;)
        {
          paramDataLayer.push(paramPoint);
          break;
          localObject = Long.valueOf(((Number)localObject).longValue());
          break label68;
          label243:
          Log.append("GaExperimentRandom: random range invalid");
          break;
          label251:
          localObject = paramPoint.get("gtm");
          if ((localObject instanceof Map)) {
            ((Map)localObject).put("lifetime", Long.valueOf(length));
          } else {
            Log.append("GaExperimentRandom: gtm not a map");
          }
        }
      }
    }
  }
  
  private static void apply(DataLayer paramDataLayer, Point paramPoint)
  {
    paramPoint = fields;
    int j = paramPoint.length;
    int i = 0;
    while (i < j)
    {
      Map localMap = get(paramPoint[i]);
      if (localMap != null) {
        paramDataLayer.push(localMap);
      }
      i += 1;
    }
  }
  
  private static Map get(Integer paramInteger)
  {
    paramInteger = Boolean.get(paramInteger);
    if (!(paramInteger instanceof Map))
    {
      Log.append("value: " + paramInteger + " is not a map value, ignored.");
      return null;
    }
    return (Map)paramInteger;
  }
  
  public static void put(DataLayer paramDataLayer, Attribute paramAttribute)
  {
    if (result == null)
    {
      Log.append("supplemental missing experimentSupplemental");
      return;
    }
    write(paramDataLayer, result);
    apply(paramDataLayer, result);
    add(paramDataLayer, result);
  }
  
  private static void write(DataLayer paramDataLayer, Point paramPoint)
  {
    paramPoint = name;
    int j = paramPoint.length;
    int i = 0;
    while (i < j)
    {
      paramDataLayer.remove(Boolean.toString(paramPoint[i]));
      i += 1;
    }
  }
}
