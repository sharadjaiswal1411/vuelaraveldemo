package com.google.android.com.tagmanager;

import android.content.Context;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import com.google.android.com.internal.class_3;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class Tracker
  extends Operator
{
  private static final String host;
  private static Map<String, String> item;
  private static final String marker;
  private static final String msg = Priority.Off.toString();
  private static final String name;
  private static final String path = class_3.FALSE.toString();
  private static final String prefix = class_3.INTEGER.toString();
  private static Map<String, String> result;
  private static final String url;
  private final DataLayer components;
  private final Set<String> flags;
  private final EasyTracker this$0;
  
  static
  {
    marker = class_3.BEGIN.toString();
    host = class_3.STOPPED.toString();
    name = class_3.ERROR.toString();
    url = class_3.NIL.toString();
  }
  
  public Tracker(Context paramContext, DataLayer paramDataLayer)
  {
    this(paramContext, paramDataLayer, new EasyTracker(paramContext));
  }
  
  Tracker(Context paramContext, DataLayer paramDataLayer, EasyTracker paramEasyTracker)
  {
    super(msg, new String[0]);
    components = paramDataLayer;
    this$0 = paramEasyTracker;
    flags = new HashSet();
    flags.add("");
    flags.add("0");
    flags.add("false");
  }
  
  private boolean connect(Map paramMap, String paramString)
  {
    paramMap = (Integer)paramMap.get(paramString);
    if (paramMap == null) {
      return false;
    }
    return Boolean.valueOf(paramMap).booleanValue();
  }
  
  private Map createItem(Map paramMap)
  {
    paramMap = (Integer)paramMap.get(prefix);
    if (paramMap != null) {
      return set(paramMap);
    }
    if (item == null)
    {
      paramMap = new HashMap();
      paramMap.put("name", "&in");
      paramMap.put("sku", "&ic");
      paramMap.put("category", "&iv");
      paramMap.put("price", "&ip");
      paramMap.put("quantity", "&iq");
      paramMap.put("currency", "&cu");
      item = paramMap;
    }
    return item;
  }
  
  private String get(String paramString)
  {
    paramString = components.get(paramString);
    if (paramString == null) {
      return null;
    }
    return paramString.toString();
  }
  
  private List get()
  {
    Object localObject = components.get("transactionProducts");
    if (localObject == null) {
      return null;
    }
    if (!(localObject instanceof List)) {
      throw new IllegalArgumentException("transactionProducts should be of type List.");
    }
    Iterator localIterator = ((List)localObject).iterator();
    while (localIterator.hasNext()) {
      if (!(localIterator.next() instanceof Map)) {
        throw new IllegalArgumentException("Each element of transactionProducts should be of type Map.");
      }
    }
    return (List)localObject;
  }
  
  private Map get(Integer paramInteger)
  {
    if (paramInteger == null) {
      return new HashMap();
    }
    paramInteger = set(paramInteger);
    if (paramInteger == null) {
      return new HashMap();
    }
    String str = (String)paramInteger.get("&aip");
    if ((str != null) && (flags.contains(str.toLowerCase()))) {
      paramInteger.remove("&aip");
    }
    return paramInteger;
  }
  
  private Map get(Map paramMap)
  {
    paramMap = (Integer)paramMap.get(path);
    if (paramMap != null) {
      return set(paramMap);
    }
    if (result == null)
    {
      paramMap = new HashMap();
      paramMap.put("transactionId", "&ti");
      paramMap.put("transactionAffiliation", "&ta");
      paramMap.put("transactionTax", "&tt");
      paramMap.put("transactionShipping", "&ts");
      paramMap.put("transactionTotal", "&tr");
      paramMap.put("transactionCurrency", "&cu");
      result = paramMap;
    }
    return result;
  }
  
  private void put(Map paramMap, String paramString1, String paramString2)
  {
    if (paramString2 != null) {
      paramMap.put(paramString1, paramString2);
    }
  }
  
  private void sendTransaction(com.google.android.com.analytics.Tracker paramTracker, Map paramMap)
  {
    Object localObject1 = get("transactionId");
    if (localObject1 == null)
    {
      Log.e("Cannot find transactionId in data layer.");
      return;
    }
    LinkedList localLinkedList = new LinkedList();
    Object localObject2 = name;
    Object localObject3;
    boolean bool;
    Object localObject4;
    Object localObject5;
    try
    {
      localObject2 = paramMap.get(localObject2);
      localObject2 = (Integer)localObject2;
      localObject2 = get((Integer)localObject2);
      ((Map)localObject2).put("&t", "transaction");
      localObject3 = get(paramMap).entrySet().iterator();
      for (;;)
      {
        bool = ((Iterator)localObject3).hasNext();
        if (!bool) {
          break;
        }
        localObject4 = ((Iterator)localObject3).next();
        localObject5 = (Map.Entry)localObject4;
        localObject4 = ((Map.Entry)localObject5).getValue();
        localObject4 = (String)localObject4;
        localObject5 = ((Map.Entry)localObject5).getKey();
        localObject5 = (String)localObject5;
        put((Map)localObject2, (String)localObject4, get((String)localObject5));
      }
      localLinkedList.add(localObject2);
    }
    catch (IllegalArgumentException paramTracker)
    {
      Log.e("Unable to send transaction", paramTracker);
      return;
    }
    localObject2 = get();
    if (localObject2 != null)
    {
      localObject2 = ((List)localObject2).iterator();
      for (;;)
      {
        bool = ((Iterator)localObject2).hasNext();
        if (!bool) {
          break;
        }
        localObject3 = ((Iterator)localObject2).next();
        localObject3 = (Map)localObject3;
        localObject4 = ((Map)localObject3).get("name");
        if (localObject4 == null)
        {
          Log.e("Unable to send transaction item hit due to missing 'name' field.");
          return;
        }
        localObject4 = name;
        localObject4 = paramMap.get(localObject4);
        localObject4 = (Integer)localObject4;
        localObject4 = get((Integer)localObject4);
        ((Map)localObject4).put("&t", "item");
        ((Map)localObject4).put("&ti", localObject1);
        localObject5 = createItem(paramMap).entrySet().iterator();
        for (;;)
        {
          bool = ((Iterator)localObject5).hasNext();
          if (!bool) {
            break;
          }
          Object localObject6 = ((Iterator)localObject5).next();
          Object localObject7 = (Map.Entry)localObject6;
          localObject6 = ((Map.Entry)localObject7).getValue();
          localObject6 = (String)localObject6;
          localObject7 = ((Map)localObject3).get(((Map.Entry)localObject7).getKey());
          localObject7 = (String)localObject7;
          put((Map)localObject4, (String)localObject6, (String)localObject7);
        }
        localLinkedList.add(localObject4);
      }
    }
    paramMap = localLinkedList.iterator();
    for (;;)
    {
      bool = paramMap.hasNext();
      if (!bool) {
        break;
      }
      localObject1 = paramMap.next();
      localObject1 = (Map)localObject1;
      paramTracker.send((Map)localObject1);
    }
  }
  
  private Map set(Integer paramInteger)
  {
    paramInteger = Boolean.get(paramInteger);
    if (!(paramInteger instanceof Map)) {
      return null;
    }
    Object localObject = (Map)paramInteger;
    paramInteger = new LinkedHashMap();
    localObject = ((Map)localObject).entrySet().iterator();
    while (((Iterator)localObject).hasNext())
    {
      Map.Entry localEntry = (Map.Entry)((Iterator)localObject).next();
      paramInteger.put(localEntry.getKey().toString(), localEntry.getValue().toString());
    }
    return paramInteger;
  }
  
  public void run(Map paramMap)
  {
    com.google.android.com.analytics.Tracker localTracker = this$0.getTracker("_GTM_DEFAULT_TRACKER_");
    if (connect(paramMap, host))
    {
      localTracker.send(get((Integer)paramMap.get(name)));
      return;
    }
    if (connect(paramMap, url))
    {
      sendTransaction(localTracker, paramMap);
      return;
    }
    Log.append("Ignoring unknown tag.");
  }
}
