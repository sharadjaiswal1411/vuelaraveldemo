package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Locale;
import java.util.Map;

class Section
  extends Message
{
  private static final String AUTHORITY = Priority.A.toString();
  
  public Section()
  {
    super(AUTHORITY, new String[0]);
  }
  
  public boolean equals()
  {
    return false;
  }
  
  public Integer evaluate(Map paramMap)
  {
    paramMap = Locale.getDefault();
    if (paramMap == null) {
      return Boolean.get();
    }
    paramMap = paramMap.getLanguage();
    if (paramMap == null) {
      return Boolean.get();
    }
    return Boolean.add(paramMap.toLowerCase());
  }
}
