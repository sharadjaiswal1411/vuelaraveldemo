package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class Logic
  extends Message
{
  private static final String mode = Priority.V.toString();
  private final ClassWriter ctx;
  
  public Logic(ClassWriter paramClassWriter)
  {
    super(mode, new String[0]);
    ctx = paramClassWriter;
  }
  
  public boolean equals()
  {
    return false;
  }
  
  public Integer evaluate(Map paramMap)
  {
    paramMap = ctx.get();
    if (paramMap == null) {
      return Boolean.get();
    }
    return Boolean.add(paramMap);
  }
}
