package com.google.android.com.tagmanager;

import java.util.Map;

public abstract interface Point
{
  public abstract Object set(String paramString, Map paramMap);
}
