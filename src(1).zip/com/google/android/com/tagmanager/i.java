package com.google.android.com.tagmanager;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.net.Uri.Builder;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import com.google.android.com.internal.class_3;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class i
  extends Operator
{
  private static final String a;
  private static final String b = Priority.Z.toString();
  private static final String c;
  static final String id = "gtm_" + b + "_unrepeatable";
  private static final String p;
  private static final Set<String> s = new HashSet();
  private final Context mContext;
  private final Target t;
  
  static
  {
    a = class_3.bottom.toString();
    c = class_3.BOTTOM.toString();
    p = class_3.top.toString();
  }
  
  public i(Context paramContext)
  {
    this(paramContext, new NumberPicker.TwoDigitFormatter(paramContext));
  }
  
  i(Context paramContext, Target paramTarget)
  {
    super(b, new String[] { a });
    t = paramTarget;
    mContext = paramContext;
  }
  
  private boolean a(String paramString)
  {
    boolean bool1 = true;
    for (;;)
    {
      try
      {
        boolean bool2 = isVisible(paramString);
        if (bool2) {
          return bool1;
        }
        if (isEnabled(paramString)) {
          s.add(paramString);
        } else {
          bool1 = false;
        }
      }
      catch (Throwable paramString)
      {
        throw paramString;
      }
    }
  }
  
  boolean isEnabled(String paramString)
  {
    return mContext.getSharedPreferences(id, 0).contains(paramString);
  }
  
  boolean isVisible(String paramString)
  {
    return s.contains(paramString);
  }
  
  public void run(Map paramMap)
  {
    if (paramMap.get(p) != null) {}
    for (String str = Boolean.toString((Integer)paramMap.get(p)); (str != null) && (a(str)); str = null) {
      return;
    }
    Uri.Builder localBuilder = Uri.parse(Boolean.toString((Integer)paramMap.get(a))).buildUpon();
    paramMap = (Integer)paramMap.get(c);
    if (paramMap != null)
    {
      paramMap = Boolean.get(paramMap);
      if (!(paramMap instanceof List))
      {
        Log.e("ArbitraryPixel: additional params not a list: not sending partial hit: " + localBuilder.build().toString());
        return;
      }
      paramMap = ((List)paramMap).iterator();
      while (paramMap.hasNext())
      {
        Object localObject = paramMap.next();
        if (!(localObject instanceof Map))
        {
          Log.e("ArbitraryPixel: additional params contains non-map: not sending partial hit: " + localBuilder.build().toString());
          return;
        }
        localObject = ((Map)localObject).entrySet().iterator();
        while (((Iterator)localObject).hasNext())
        {
          Map.Entry localEntry = (Map.Entry)((Iterator)localObject).next();
          localBuilder.appendQueryParameter(localEntry.getKey().toString(), localEntry.getValue().toString());
        }
      }
    }
    paramMap = localBuilder.build().toString();
    t.init().a(paramMap);
    Log.w("ArbitraryPixel: url = " + paramMap);
    if (str != null) {
      try
      {
        s.add(str);
        ImageManager.put(mContext, id, str, "true");
        return;
      }
      catch (Throwable paramMap)
      {
        throw paramMap;
      }
    }
  }
}
