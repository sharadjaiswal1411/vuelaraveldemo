package com.google.android.com.tagmanager;

import com.google.android.com.internal.Clock;

class Inflate
  implements k
{
  private final long flags;
  private final Object method = new Object();
  private double mode;
  private final String msg;
  private long need;
  private final int type;
  private final Clock wrap;
  private final long z;
  
  public Inflate(int paramInt, long paramLong1, long paramLong2, String paramString, Clock paramClock)
  {
    type = paramInt;
    mode = type;
    flags = paramLong1;
    z = paramLong2;
    msg = paramString;
    wrap = paramClock;
  }
  
  public boolean inflate()
  {
    Object localObject = method;
    try
    {
      long l = wrap.currentTimeMillis();
      if (l - need < z)
      {
        Log.append("Excessive " + msg + " detected; call ignored.");
        return false;
      }
      if (mode < type)
      {
        double d = (l - need) / flags;
        if (d > 0.0D) {
          mode = Math.min(type, d + mode);
        }
      }
      need = l;
      if (mode >= 1.0D)
      {
        mode -= 1.0D;
        return true;
      }
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
    Log.append("Excessive " + msg + " detected; call ignored.");
    return false;
  }
}
