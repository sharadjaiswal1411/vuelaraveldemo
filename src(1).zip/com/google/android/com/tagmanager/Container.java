package com.google.android.com.tagmanager;

import com.google.android.com.internal.Attribute;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Node;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Container
{
  private ClassWriter a;
  private volatile long cmd;
  private final DataLayer items;
  private Map<String, com.google.android.gms.tagmanager.Container.FunctionCallTagCallback> locks = new HashMap();
  private final String mContainerId;
  private final android.content.Context mContext;
  private volatile String t = "";
  private Map<String, com.google.android.gms.tagmanager.Container.FunctionCallMacroCallback> table = new HashMap();
  
  Container(android.content.Context paramContext, DataLayer paramDataLayer, String paramString, long paramLong, com.google.android.com.internal.Context paramContext1)
  {
    mContext = paramContext;
    items = paramDataLayer;
    mContainerId = paramString;
    cmd = paramLong;
    update(b);
    if (a != null) {
      init(a);
    }
  }
  
  Container(android.content.Context paramContext, DataLayer paramDataLayer, String paramString, long paramLong, cq.c paramC)
  {
    mContext = paramContext;
    items = paramDataLayer;
    mContainerId = paramString;
    cmd = paramLong;
    close(paramC);
  }
  
  private void close(ClassWriter paramClassWriter)
  {
    try
    {
      a = paramClassWriter;
      return;
    }
    catch (Throwable paramClassWriter)
    {
      throw paramClassWriter;
    }
  }
  
  private void close(cq.c paramC)
  {
    t = paramC.getVersion();
    q localQ = a(t);
    close(new ClassWriter(mContext, paramC, items, new a(null), new b(null), localQ));
  }
  
  private ClassWriter get()
  {
    try
    {
      ClassWriter localClassWriter = a;
      return localClassWriter;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  private void init(Attribute[] paramArrayOfAttribute)
  {
    ArrayList localArrayList = new ArrayList();
    int j = paramArrayOfAttribute.length;
    int i = 0;
    while (i < j)
    {
      localArrayList.add(paramArrayOfAttribute[i]);
      i += 1;
    }
    get().read(localArrayList);
  }
  
  private void update(Node paramNode)
  {
    if (paramNode == null) {
      throw new NullPointerException();
    }
    try
    {
      cq.c localC = ByteVector.run(paramNode);
      close(localC);
      return;
    }
    catch (cq.g localG)
    {
      Log.e("Not loading resource: " + paramNode + " because it is invalid: " + localG.toString());
    }
  }
  
  q a(String paramString)
  {
    if (a.a().getValue().equals(cd.a.b)) {}
    return new l();
  }
  
  String close()
  {
    return t;
  }
  
  void f(String paramString)
  {
    get().a(paramString);
  }
  
  FunctionCallTagCallback get(String paramString)
  {
    Map localMap = locks;
    try
    {
      paramString = (FunctionCallTagCallback)locks.get(paramString);
      return paramString;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public boolean getBoolean(String paramString)
  {
    ClassWriter localClassWriter = get();
    if (localClassWriter == null)
    {
      Log.e("getBoolean called for closed container.");
      return Boolean.getBoolean().booleanValue();
    }
    try
    {
      paramString = localClassWriter.c(paramString).getObject();
      paramString = (Integer)paramString;
      boolean bool = Boolean.valueOf(paramString).booleanValue();
      return bool;
    }
    catch (Exception paramString)
    {
      Log.e("Calling getBoolean() threw an exception: " + paramString.getMessage() + " Returning default value.");
    }
    return Boolean.getBoolean().booleanValue();
  }
  
  public String getContainerId()
  {
    return mContainerId;
  }
  
  public double getDouble(String paramString)
  {
    ClassWriter localClassWriter = get();
    if (localClassWriter == null)
    {
      Log.e("getDouble called for closed container.");
      return Boolean.getValue().doubleValue();
    }
    try
    {
      paramString = localClassWriter.c(paramString).getObject();
      paramString = (Integer)paramString;
      double d = Boolean.getNumber(paramString).doubleValue();
      return d;
    }
    catch (Exception paramString)
    {
      Log.e("Calling getDouble() threw an exception: " + paramString.getMessage() + " Returning default value.");
    }
    return Boolean.getValue().doubleValue();
  }
  
  public long getLastRefreshTime()
  {
    return cmd;
  }
  
  public long getLong(String paramString)
  {
    ClassWriter localClassWriter = get();
    if (localClassWriter == null)
    {
      Log.e("getLong called for closed container.");
      return Boolean.size().longValue();
    }
    try
    {
      paramString = localClassWriter.c(paramString).getObject();
      paramString = (Integer)paramString;
      long l = Boolean.getValue(paramString).longValue();
      return l;
    }
    catch (Exception paramString)
    {
      Log.e("Calling getLong() threw an exception: " + paramString.getMessage() + " Returning default value.");
    }
    return Boolean.size().longValue();
  }
  
  public String getString(String paramString)
  {
    ClassWriter localClassWriter = get();
    if (localClassWriter == null)
    {
      Log.e("getString called for closed container.");
      return Boolean.valueOf();
    }
    try
    {
      paramString = localClassWriter.c(paramString).getObject();
      paramString = (Integer)paramString;
      paramString = Boolean.toString(paramString);
      return paramString;
    }
    catch (Exception paramString)
    {
      Log.e("Calling getString() threw an exception: " + paramString.getMessage() + " Returning default value.");
    }
    return Boolean.valueOf();
  }
  
  public boolean isDefault()
  {
    return getLastRefreshTime() == 0L;
  }
  
  public void registerFunctionCallMacroCallback(String paramString, FunctionCallMacroCallback paramFunctionCallMacroCallback)
  {
    if (paramFunctionCallMacroCallback == null) {
      throw new NullPointerException("Macro handler must be non-null");
    }
    Map localMap = table;
    try
    {
      table.put(paramString, paramFunctionCallMacroCallback);
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void registerFunctionCallTagCallback(String paramString, FunctionCallTagCallback paramFunctionCallTagCallback)
  {
    if (paramFunctionCallTagCallback == null) {
      throw new NullPointerException("Tag callback must be non-null");
    }
    Map localMap = locks;
    try
    {
      locks.put(paramString, paramFunctionCallTagCallback);
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  void release()
  {
    a = null;
  }
  
  FunctionCallMacroCallback remove(String paramString)
  {
    Map localMap = table;
    try
    {
      paramString = (FunctionCallMacroCallback)table.get(paramString);
      return paramString;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void unregisterFunctionCallMacroCallback(String paramString)
  {
    Map localMap = table;
    try
    {
      table.remove(paramString);
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void unregisterFunctionCallTagCallback(String paramString)
  {
    Map localMap = locks;
    try
    {
      locks.remove(paramString);
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public abstract interface FunctionCallMacroCallback
  {
    public abstract Object getValue(String paramString, Map paramMap);
  }
  
  public abstract interface FunctionCallTagCallback
  {
    public abstract void execute(String paramString, Map paramMap);
  }
  
  class a
    implements Point
  {
    private a() {}
    
    public Object set(String paramString, Map paramMap)
    {
      Container.FunctionCallMacroCallback localFunctionCallMacroCallback = remove(paramString);
      if (localFunctionCallMacroCallback == null) {
        return null;
      }
      return localFunctionCallMacroCallback.getValue(paramString, paramMap);
    }
  }
  
  class b
    implements Point
  {
    private b() {}
    
    public Object set(String paramString, Map paramMap)
    {
      Container.FunctionCallTagCallback localFunctionCallTagCallback = get(paramString);
      if (localFunctionCallTagCallback != null) {
        localFunctionCallTagCallback.execute(paramString, paramMap);
      }
      return Boolean.valueOf();
    }
  }
}
