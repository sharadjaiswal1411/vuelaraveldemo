package com.google.android.com.tagmanager;

import android.os.Build.VERSION;
import com.google.android.gms.tagmanager.l.a;

class CacheFactory<K, V>
{
  final l.a<K, V> mCache = new SearchActivity.3(this);
  
  public CacheFactory() {}
  
  public Cache createCache(int paramInt, LruCache paramLruCache)
  {
    if (paramInt <= 0) {
      throw new IllegalArgumentException("maxSize <= 0");
    }
    if (getSdkVersion() < 12) {
      return new SimpleCache(paramInt, paramLruCache);
    }
    return new LRUCache(paramInt, paramLruCache);
  }
  
  int getSdkVersion()
  {
    return Build.VERSION.SDK_INT;
  }
}
