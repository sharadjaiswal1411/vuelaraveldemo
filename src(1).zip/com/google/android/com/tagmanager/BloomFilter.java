package com.google.android.com.tagmanager;

import android.content.Context;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class BloomFilter
  extends Message
{
  private static final String data = Priority.IMMEDIATE.toString();
  private final Dictionary this$0;
  
  public BloomFilter(Context paramContext)
  {
    this(Dictionary.close(paramContext));
  }
  
  BloomFilter(Dictionary paramDictionary)
  {
    super(data, new String[0]);
    this$0 = paramDictionary;
  }
  
  public boolean equals()
  {
    return false;
  }
  
  public Integer evaluate(Map paramMap)
  {
    paramMap = this$0.get();
    if (paramMap == null) {
      return Boolean.get();
    }
    return Boolean.add(paramMap);
  }
}
