package com.google.android.com.tagmanager;

import com.google.android.com.internal.Priority;
import java.util.Map;

class ModuleInformation
  extends Variance
{
  private static final String DEFAULT_KEYSTORE_PATH = Priority.noscript.toString();
  
  public ModuleInformation()
  {
    super(DEFAULT_KEYSTORE_PATH);
  }
  
  protected boolean apply(String paramString1, String paramString2, Map paramMap)
  {
    return paramString1.equals(paramString2);
  }
}
