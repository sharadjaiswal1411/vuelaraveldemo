package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import com.google.android.com.internal.class_3;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

class Attribute
  extends Operator
{
  private static final String ID = Priority.AUTH.toString();
  private static final String NAME = class_3.WAIT.toString();
  private static final String VALUE = class_3.undefined_condition.toString();
  private final DataLayer b;
  
  public Attribute(DataLayer paramDataLayer)
  {
    super(ID, new String[] { VALUE });
    b = paramDataLayer;
  }
  
  private void read(Integer paramInteger)
  {
    if (paramInteger != null)
    {
      if (paramInteger == Boolean.setValue()) {
        return;
      }
      paramInteger = Boolean.toString(paramInteger);
      if (paramInteger != Boolean.valueOf()) {
        b.remove(paramInteger);
      }
    }
  }
  
  private void write(Integer paramInteger)
  {
    if (paramInteger != null)
    {
      if (paramInteger == Boolean.setValue()) {
        return;
      }
      paramInteger = Boolean.get(paramInteger);
      if ((paramInteger instanceof List))
      {
        paramInteger = ((List)paramInteger).iterator();
        while (paramInteger.hasNext())
        {
          Object localObject = paramInteger.next();
          if ((localObject instanceof Map))
          {
            localObject = (Map)localObject;
            b.push((Map)localObject);
          }
        }
      }
    }
  }
  
  public void run(Map paramMap)
  {
    write((Integer)paramMap.get(VALUE));
    read((Integer)paramMap.get(NAME));
  }
}
