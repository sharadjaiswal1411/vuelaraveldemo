package com.google.android.com.tagmanager;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;
import com.google.android.com.internal.Clock;
import com.google.android.com.internal.SystemClock;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

class Context
  implements DataLayer.c
{
  private static final String CREATE_HITS_TABLE = String.format("CREATE TABLE IF NOT EXISTS %s ( '%s' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, '%s' STRING NOT NULL, '%s' BLOB NOT NULL, '%s' INTEGER NOT NULL);", new Object[] { "datalayer", "ID", "key", "value", "expires" });
  private final Executor c;
  private Clock mClock;
  private final android.content.Context mContext;
  private int s;
  private Database this$0;
  
  public Context(android.content.Context paramContext)
  {
    this(paramContext, SystemClock.get(), "google_tagmanager.db", 2000, Executors.newSingleThreadExecutor());
  }
  
  Context(android.content.Context paramContext, Clock paramClock, String paramString, int paramInt, Executor paramExecutor)
  {
    mContext = paramContext;
    mClock = paramClock;
    s = paramInt;
    c = paramExecutor;
    this$0 = new Database(this, mContext, paramString);
  }
  
  private List a(List paramList)
  {
    ArrayList localArrayList = new ArrayList();
    paramList = paramList.iterator();
    while (paramList.hasNext())
    {
      DataLayer.a localA = (DataLayer.a)paramList.next();
      localArrayList.add(new JSONArray(a, toByteArray(v)));
    }
    return localArrayList;
  }
  
  private void add(String paramString)
  {
    SQLiteDatabase localSQLiteDatabase = get("Error opening database for clearKeysWithPrefix.");
    if (localSQLiteDatabase == null) {
      return;
    }
    try
    {
      String str = paramString + ".%";
      int i = localSQLiteDatabase.delete("datalayer", "key = ? OR key LIKE ?", new String[] { paramString, str });
      Log.w("Cleared " + i + " items");
      cacheValues();
      return;
    }
    catch (SQLiteException localSQLiteException)
    {
      Log.append("Error deleting entries with key prefix: " + paramString + " (" + localSQLiteException + ").");
      cacheValues();
      return;
    }
    catch (Throwable paramString)
    {
      cacheValues();
      throw paramString;
    }
  }
  
  private void cacheValues()
  {
    Database localDatabase = this$0;
    try
    {
      localDatabase.close();
      return;
    }
    catch (SQLiteException localSQLiteException) {}
  }
  
  private void deleteEntries(String[] paramArrayOfString)
  {
    if (paramArrayOfString != null)
    {
      if (paramArrayOfString.length == 0) {
        return;
      }
      SQLiteDatabase localSQLiteDatabase = get("Error opening database for deleteEntries.");
      if (localSQLiteDatabase != null)
      {
        String str = String.format("%s in (%s)", new Object[] { "ID", TextUtils.join(",", Collections.nCopies(paramArrayOfString.length, "?")) });
        try
        {
          localSQLiteDatabase.delete("datalayer", str, paramArrayOfString);
          return;
        }
        catch (SQLiteException localSQLiteException)
        {
          Log.append("Error deleting entries " + Arrays.toString(paramArrayOfString));
        }
      }
    }
  }
  
  private void execute(long paramLong)
  {
    SQLiteDatabase localSQLiteDatabase = get("Error opening database for deleteOlderThan.");
    if (localSQLiteDatabase == null) {
      return;
    }
    try
    {
      String str = Long.toString(paramLong);
      int i = localSQLiteDatabase.delete("datalayer", "expires <= ?", new String[] { str });
      Log.w("Deleted " + i + " expired items");
      return;
    }
    catch (SQLiteException localSQLiteException)
    {
      Log.append("Error deleting old entries.");
    }
  }
  
  private SQLiteDatabase get(String paramString)
  {
    Object localObject = this$0;
    try
    {
      localObject = ((Database)localObject).getWritableDatabase();
      return localObject;
    }
    catch (SQLiteException localSQLiteException)
    {
      Log.append(paramString);
    }
    return null;
  }
  
  private void get(int paramInt)
  {
    paramInt = getTile() - s + paramInt;
    if (paramInt > 0)
    {
      List localList = parse(paramInt);
      Log.i("DataLayer store full, deleting " + localList.size() + " entries to make room.");
      deleteEntries((String[])localList.toArray(new String[0]));
    }
  }
  
  private List getMessages()
  {
    Object localObject = get("Error opening database for loadSerialized.");
    ArrayList localArrayList = new ArrayList();
    if (localObject == null) {
      return localArrayList;
    }
    localObject = ((SQLiteDatabase)localObject).query("datalayer", new String[] { "key", "value" }, null, null, null, null, "ID", null);
    try
    {
      for (;;)
      {
        boolean bool = ((Cursor)localObject).moveToNext();
        if (!bool) {
          break;
        }
        localArrayList.add(new JSONArray(((Cursor)localObject).getString(0), ((Cursor)localObject).getBlob(1)));
      }
      ((Cursor)localObject).close();
    }
    catch (Throwable localThrowable)
    {
      ((Cursor)localObject).close();
      throw localThrowable;
    }
    return localThrowable;
  }
  
  /* Error */
  private Object getObject(byte[] paramArrayOfByte)
  {
    // Byte code:
    //   0: new 296	java/io/ByteArrayInputStream
    //   3: dup
    //   4: aload_1
    //   5: invokespecial 299	java/io/ByteArrayInputStream:<init>	([B)V
    //   8: astore 4
    //   10: new 301	java/io/ObjectInputStream
    //   13: dup
    //   14: aload 4
    //   16: invokespecial 304	java/io/ObjectInputStream:<init>	(Ljava/io/InputStream;)V
    //   19: astore_1
    //   20: aload_1
    //   21: invokevirtual 307	java/io/ObjectInputStream:readObject	()Ljava/lang/Object;
    //   24: astore_2
    //   25: aload_1
    //   26: ifnull +7 -> 33
    //   29: aload_1
    //   30: invokevirtual 308	java/io/ObjectInputStream:close	()V
    //   33: aload 4
    //   35: invokevirtual 309	java/io/ByteArrayInputStream:close	()V
    //   38: aload_2
    //   39: areturn
    //   40: astore_1
    //   41: aconst_null
    //   42: astore_1
    //   43: aload_1
    //   44: ifnull +7 -> 51
    //   47: aload_1
    //   48: invokevirtual 308	java/io/ObjectInputStream:close	()V
    //   51: aload 4
    //   53: invokevirtual 309	java/io/ByteArrayInputStream:close	()V
    //   56: aconst_null
    //   57: areturn
    //   58: astore_1
    //   59: aconst_null
    //   60: areturn
    //   61: astore_1
    //   62: aconst_null
    //   63: astore_1
    //   64: aload_1
    //   65: ifnull +7 -> 72
    //   68: aload_1
    //   69: invokevirtual 308	java/io/ObjectInputStream:close	()V
    //   72: aload 4
    //   74: invokevirtual 309	java/io/ByteArrayInputStream:close	()V
    //   77: aconst_null
    //   78: areturn
    //   79: astore_1
    //   80: aconst_null
    //   81: areturn
    //   82: astore_1
    //   83: aconst_null
    //   84: astore_2
    //   85: aload_2
    //   86: ifnull +7 -> 93
    //   89: aload_2
    //   90: invokevirtual 308	java/io/ObjectInputStream:close	()V
    //   93: aload 4
    //   95: invokevirtual 309	java/io/ByteArrayInputStream:close	()V
    //   98: aload_1
    //   99: athrow
    //   100: astore_2
    //   101: goto -3 -> 98
    //   104: astore_3
    //   105: aload_1
    //   106: astore_2
    //   107: aload_3
    //   108: astore_1
    //   109: goto -24 -> 85
    //   112: astore_2
    //   113: goto -49 -> 64
    //   116: astore_2
    //   117: goto -74 -> 43
    //   120: astore_1
    //   121: aload_2
    //   122: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	123	0	this	Context
    //   0	123	1	paramArrayOfByte	byte[]
    //   24	66	2	localObject	Object
    //   100	1	2	localIOException1	IOException
    //   106	1	2	arrayOfByte	byte[]
    //   112	1	2	localClassNotFoundException	ClassNotFoundException
    //   116	6	2	localIOException2	IOException
    //   104	4	3	localThrowable	Throwable
    //   8	86	4	localByteArrayInputStream	java.io.ByteArrayInputStream
    // Exception table:
    //   from	to	target	type
    //   10	20	40	java/io/IOException
    //   47	51	58	java/io/IOException
    //   51	56	58	java/io/IOException
    //   10	20	61	java/lang/ClassNotFoundException
    //   68	72	79	java/io/IOException
    //   72	77	79	java/io/IOException
    //   10	20	82	java/lang/Throwable
    //   89	93	100	java/io/IOException
    //   93	98	100	java/io/IOException
    //   20	25	104	java/lang/Throwable
    //   20	25	112	java/lang/ClassNotFoundException
    //   20	25	116	java/io/IOException
    //   29	33	120	java/io/IOException
    //   33	38	120	java/io/IOException
  }
  
  private int getTile()
  {
    Object localObject2 = null;
    Object localObject1 = null;
    int i = 0;
    Object localObject4 = get("Error opening database for getNumStoredEntries.");
    if (localObject4 == null) {
      return 0;
    }
    try
    {
      Cursor localCursor = ((SQLiteDatabase)localObject4).rawQuery("SELECT COUNT(*) from datalayer", null);
      localObject4 = localCursor;
      localObject1 = localObject4;
      localObject2 = localObject4;
      boolean bool = localCursor.moveToFirst();
      if (bool)
      {
        localObject1 = localObject4;
        localObject2 = localObject4;
        long l = localCursor.getLong(0);
        i = (int)l;
      }
      if (localCursor != null)
      {
        localCursor.close();
        return i;
      }
    }
    catch (SQLiteException localSQLiteException)
    {
      localObject3 = localObject1;
      Log.append("Error getting numStoredEntries");
      if (localObject1 == null) {
        break label138;
      }
      localObject1.close();
      return 0;
    }
    catch (Throwable localThrowable)
    {
      Object localObject3;
      if (localObject3 != null) {
        localObject3.close();
      }
      throw localThrowable;
    }
    return i;
    label138:
    return 0;
  }
  
  /* Error */
  private void init(List paramList, long paramLong)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 70	com/google/android/com/tagmanager/Context:mClock	Lcom/google/android/com/internal/Clock;
    //   6: invokeinterface 334 1 0
    //   11: lstore 4
    //   13: aload_0
    //   14: lload 4
    //   16: invokespecial 336	com/google/android/com/tagmanager/Context:execute	(J)V
    //   19: aload_0
    //   20: aload_1
    //   21: invokeinterface 254 1 0
    //   26: invokespecial 338	com/google/android/com/tagmanager/Context:get	(I)V
    //   29: aload_0
    //   30: aload_1
    //   31: lload 4
    //   33: lload_2
    //   34: ladd
    //   35: invokespecial 341	com/google/android/com/tagmanager/Context:put	(Ljava/util/List;J)V
    //   38: aload_0
    //   39: invokespecial 168	com/google/android/com/tagmanager/Context:cacheValues	()V
    //   42: aload_0
    //   43: monitorexit
    //   44: return
    //   45: astore_1
    //   46: aload_0
    //   47: invokespecial 168	com/google/android/com/tagmanager/Context:cacheValues	()V
    //   50: aload_1
    //   51: athrow
    //   52: astore_1
    //   53: aload_0
    //   54: monitorexit
    //   55: aload_1
    //   56: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	57	0	this	Context
    //   0	57	1	paramList	List
    //   0	57	2	paramLong	long
    //   11	21	4	l	long
    // Exception table:
    //   from	to	target	type
    //   2	38	45	java/lang/Throwable
    //   38	42	52	java/lang/Throwable
    //   46	52	52	java/lang/Throwable
  }
  
  /* Error */
  private List parse(int paramInt)
  {
    // Byte code:
    //   0: new 83	java/util/ArrayList
    //   3: dup
    //   4: invokespecial 84	java/util/ArrayList:<init>	()V
    //   7: astore 6
    //   9: iload_1
    //   10: ifgt +12 -> 22
    //   13: ldc_w 343
    //   16: invokestatic 179	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   19: aload 6
    //   21: areturn
    //   22: aload_0
    //   23: ldc_w 345
    //   26: invokespecial 133	com/google/android/com/tagmanager/Context:get	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteDatabase;
    //   29: astore_3
    //   30: aload_3
    //   31: ifnonnull +6 -> 37
    //   34: aload 6
    //   36: areturn
    //   37: ldc_w 347
    //   40: iconst_1
    //   41: anewarray 4	java/lang/Object
    //   44: dup
    //   45: iconst_0
    //   46: ldc 30
    //   48: aastore
    //   49: invokestatic 42	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   52: astore 4
    //   54: iload_1
    //   55: invokestatic 351	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   58: astore 5
    //   60: aload_3
    //   61: ldc 28
    //   63: iconst_1
    //   64: anewarray 38	java/lang/String
    //   67: dup
    //   68: iconst_0
    //   69: ldc 30
    //   71: aastore
    //   72: aconst_null
    //   73: aconst_null
    //   74: aconst_null
    //   75: aconst_null
    //   76: aload 4
    //   78: aload 5
    //   80: invokevirtual 274	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   83: astore 5
    //   85: aload 5
    //   87: astore 4
    //   89: aload 4
    //   91: astore_3
    //   92: aload 5
    //   94: invokeinterface 320 1 0
    //   99: istore_2
    //   100: iload_2
    //   101: ifeq +40 -> 141
    //   104: aload 4
    //   106: astore_3
    //   107: aload 6
    //   109: aload 5
    //   111: iconst_0
    //   112: invokeinterface 324 2 0
    //   117: invokestatic 354	java/lang/String:valueOf	(J)Ljava/lang/String;
    //   120: invokeinterface 119 2 0
    //   125: pop
    //   126: aload 4
    //   128: astore_3
    //   129: aload 5
    //   131: invokeinterface 279 1 0
    //   136: istore_2
    //   137: iload_2
    //   138: ifne -34 -> 104
    //   141: aload 5
    //   143: ifnull +10 -> 153
    //   146: aload 5
    //   148: invokeinterface 288 1 0
    //   153: aload 6
    //   155: areturn
    //   156: astore 5
    //   158: aconst_null
    //   159: astore 4
    //   161: aload 4
    //   163: astore_3
    //   164: new 135	java/lang/StringBuilder
    //   167: dup
    //   168: invokespecial 136	java/lang/StringBuilder:<init>	()V
    //   171: ldc_w 356
    //   174: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   177: aload 5
    //   179: invokevirtual 361	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   182: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   185: invokevirtual 145	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   188: invokestatic 179	com/google/android/com/tagmanager/Log:append	(Ljava/lang/String;)V
    //   191: aload 4
    //   193: ifnull -40 -> 153
    //   196: aload 4
    //   198: invokeinterface 288 1 0
    //   203: aload 6
    //   205: areturn
    //   206: astore 4
    //   208: aconst_null
    //   209: astore_3
    //   210: aload_3
    //   211: ifnull +9 -> 220
    //   214: aload_3
    //   215: invokeinterface 288 1 0
    //   220: aload 4
    //   222: athrow
    //   223: astore 4
    //   225: goto -15 -> 210
    //   228: astore 5
    //   230: goto -69 -> 161
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	233	0	this	Context
    //   0	233	1	paramInt	int
    //   99	39	2	bool	boolean
    //   29	186	3	localObject1	Object
    //   52	145	4	localObject2	Object
    //   206	15	4	localThrowable1	Throwable
    //   223	1	4	localThrowable2	Throwable
    //   58	89	5	localObject3	Object
    //   156	22	5	localSQLiteException1	SQLiteException
    //   228	1	5	localSQLiteException2	SQLiteException
    //   7	197	6	localArrayList	ArrayList
    // Exception table:
    //   from	to	target	type
    //   37	85	156	android/database/sqlite/SQLiteException
    //   37	85	206	java/lang/Throwable
    //   92	100	223	java/lang/Throwable
    //   107	126	223	java/lang/Throwable
    //   129	137	223	java/lang/Throwable
    //   164	191	223	java/lang/Throwable
    //   92	100	228	android/database/sqlite/SQLiteException
    //   107	126	228	android/database/sqlite/SQLiteException
    //   129	137	228	android/database/sqlite/SQLiteException
  }
  
  private void put(List paramList, long paramLong)
  {
    SQLiteDatabase localSQLiteDatabase = get("Error opening database for writeEntryToDatabase.");
    if (localSQLiteDatabase == null) {
      return;
    }
    paramList = paramList.iterator();
    while (paramList.hasNext())
    {
      JSONArray localJSONArray = (JSONArray)paramList.next();
      ContentValues localContentValues = new ContentValues();
      localContentValues.put("expires", Long.valueOf(paramLong));
      localContentValues.put("key", data);
      localContentValues.put("value", id);
      localSQLiteDatabase.insert("datalayer", null, localContentValues);
    }
  }
  
  private List render()
  {
    try
    {
      execute(mClock.currentTimeMillis());
      List localList = write(getMessages());
      cacheValues();
      return localList;
    }
    catch (Throwable localThrowable)
    {
      cacheValues();
      throw localThrowable;
    }
  }
  
  private byte[] toByteArray(Object paramObject)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    try
    {
      ObjectOutputStream localObjectOutputStream = new ObjectOutputStream(localByteArrayOutputStream);
      return paramObject;
    }
    catch (IOException paramObject)
    {
      try
      {
        localObjectOutputStream.writeObject(paramObject);
        paramObject = localByteArrayOutputStream.toByteArray();
        if (localObjectOutputStream == null) {}
      }
      catch (Throwable paramObject)
      {
        for (;;) {}
      }
      catch (IOException paramObject)
      {
        for (;;) {}
      }
      try
      {
        localObjectOutputStream.close();
        localByteArrayOutputStream.close();
        return paramObject;
      }
      catch (IOException localIOException2) {}
      paramObject = paramObject;
      localObjectOutputStream = null;
      if (localObjectOutputStream != null) {}
      try
      {
        localObjectOutputStream.close();
        localByteArrayOutputStream.close();
        return null;
      }
      catch (IOException paramObject)
      {
        return null;
      }
    }
    catch (Throwable paramObject)
    {
      localObjectOutputStream = null;
      if (localObjectOutputStream != null) {}
      try
      {
        localObjectOutputStream.close();
        localByteArrayOutputStream.close();
      }
      catch (IOException localIOException1)
      {
        for (;;) {}
      }
      throw paramObject;
    }
  }
  
  private List write(List paramList)
  {
    ArrayList localArrayList = new ArrayList();
    paramList = paramList.iterator();
    while (paramList.hasNext())
    {
      JSONArray localJSONArray = (JSONArray)paramList.next();
      localArrayList.add(new DataLayer.a(data, getObject(id)));
    }
    return localArrayList;
  }
  
  public void a(List paramList, long paramLong)
  {
    paramList = a(paramList);
    c.execute(new Plot.a(this, paramList, paramLong));
  }
  
  public void b(DataLayer.c.a paramA)
  {
    c.execute(new NumberPicker.BeginSoftInputOnLongPressCommand(this, paramA));
  }
  
  public void remove(String paramString)
  {
    c.execute(new NumberPicker.PressedStateHelper(this, paramString));
  }
}
