package com.google.android.com.tagmanager;

abstract interface App
{
  public abstract void remove(boolean paramBoolean);
}
