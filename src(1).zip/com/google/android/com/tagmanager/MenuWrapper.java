package com.google.android.com.tagmanager;

import java.util.Set;

class MenuWrapper
  implements Menu
{
  MenuWrapper() {}
  
  public void add(Set paramSet) {}
  
  public ad getItem()
  {
    return new o();
  }
}
