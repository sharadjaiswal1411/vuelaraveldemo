package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import com.google.android.com.internal.class_3;
import java.util.Map;

class Method
  extends Message
{
  private static final String VALUE = class_3.undefined_condition.toString();
  private static final String value = Priority.MEDIUM.toString();
  
  public Method()
  {
    super(value, new String[] { VALUE });
  }
  
  public static String getDescriptor()
  {
    return VALUE;
  }
  
  public static String getValue()
  {
    return value;
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    return (Integer)paramMap.get(VALUE);
  }
}
