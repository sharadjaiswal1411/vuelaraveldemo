package com.google.android.com.tagmanager;

import android.content.Context;
import com.google.android.com.internal.Frame;
import com.google.android.com.internal.class_3;
import com.google.android.gms.internal.d.a;
import com.google.android.gms.tagmanager.aj;
import com.google.android.gms.tagmanager.by;
import com.google.android.gms.tagmanager.k;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class ClassWriter
{
  private static final by<d.a> a = new h(Boolean.get(), true);
  private final Map<String, aj> A;
  private final Set<com.google.android.gms.tagmanager.cq.e> B;
  private final DataLayer b;
  private volatile String c;
  private final cq.c d;
  private final Map<String, aj> f;
  private final k<String, com.google.android.gms.tagmanager.cs.b> g;
  private int j;
  private final q l;
  private final k<com.google.android.gms.tagmanager.cq.a, by<d.a>> m;
  private final Map<String, com.google.android.gms.tagmanager.cs.c> o;
  private final Map<String, aj> r;
  
  public ClassWriter(Context paramContext, cq.c paramC, DataLayer paramDataLayer, Point paramPoint1, Point paramPoint2, q paramQ)
  {
    if (paramC == null) {
      throw new NullPointerException("resource cannot be null");
    }
    d = paramC;
    B = new HashSet(paramC.copy());
    b = paramDataLayer;
    l = paramQ;
    paramC = new cs.1(this);
    m = new CacheFactory().createCache(1048576, paramC);
    paramC = new cs.2(this);
    g = new CacheFactory().createCache(1048576, paramC);
    f = new HashMap();
    b(new i(paramContext));
    b(new Stop(paramPoint2));
    b(new Attribute(paramDataLayer));
    b(new Tracker(paramContext, paramDataLayer));
    r = new HashMap();
    a(new SslContextFactory());
    a(new SimpleXYSeries());
    a(new ModuleInformation());
    a(new ImageLoader());
    a(new PdfPRow());
    a(new BeanMetaData());
    a(new DeltaBaseCache());
    a(new Config());
    a(new DataFilterIDLookup());
    A = new HashMap();
    toByteArray(new BloomFilter(paramContext));
    toByteArray(new Contact(paramContext));
    toByteArray(new Command(paramContext));
    toByteArray(new Chunk(paramContext));
    toByteArray(new Block(paramContext));
    toByteArray(new MessageHeader(paramContext));
    toByteArray(new Method());
    toByteArray(new SimpleNode(d.getVersion()));
    toByteArray(new Stop(paramPoint1));
    toByteArray(new Token(paramDataLayer));
    toByteArray(new Util(paramContext));
    toByteArray(new Resource());
    toByteArray(new Request());
    toByteArray(new Logic(this));
    toByteArray(new DataTypeIDLookup());
    toByteArray(new StringUtils());
    toByteArray(new Update(paramContext));
    toByteArray(new XML());
    toByteArray(new Section());
    toByteArray(new Transform(paramContext));
    toByteArray(new Language());
    toByteArray(new Node());
    toByteArray(new Metadata());
    toByteArray(new Key());
    toByteArray(new Format(paramContext));
    toByteArray(new MD5());
    toByteArray(new Line());
    toByteArray(new Response());
    o = new HashMap();
    paramDataLayer = B.iterator();
    while (paramDataLayer.hasNext())
    {
      paramPoint1 = (cq.e)paramDataLayer.next();
      if (paramQ.b())
      {
        append(paramPoint1.getFields(), paramPoint1.getStructure(), "add macro");
        append(paramPoint1.getTerm(), paramPoint1.urls(), "remove macro");
        append(paramPoint1.get(), paramPoint1.list(), "add tag");
        append(paramPoint1.getText(), paramPoint1.getId(), "remove tag");
      }
      int i = 0;
      while (i < paramPoint1.getFields().size())
      {
        paramPoint2 = (cq.a)paramPoint1.getFields().get(i);
        paramC = "Unknown";
        paramContext = paramC;
        if (paramQ.b())
        {
          paramContext = paramC;
          if (i < paramPoint1.getStructure().size()) {
            paramContext = (String)paramPoint1.getStructure().get(i);
          }
        }
        paramC = a(o, a(paramPoint2));
        paramC.a(paramPoint1);
        paramC.a(paramPoint1, paramPoint2);
        paramC.add(paramPoint1, paramContext);
        i += 1;
      }
      i = 0;
      while (i < paramPoint1.getTerm().size())
      {
        paramPoint2 = (cq.a)paramPoint1.getTerm().get(i);
        paramC = "Unknown";
        paramContext = paramC;
        if (paramQ.b())
        {
          paramContext = paramC;
          if (i < paramPoint1.urls().size()) {
            paramContext = (String)paramPoint1.urls().get(i);
          }
        }
        paramC = a(o, a(paramPoint2));
        paramC.a(paramPoint1);
        paramC.addEntry(paramPoint1, paramPoint2);
        paramC.a(paramPoint1, paramContext);
        i += 1;
      }
    }
    paramContext = d.get().entrySet().iterator();
    while (paramContext.hasNext())
    {
      paramC = (Map.Entry)paramContext.next();
      paramDataLayer = ((List)paramC.getValue()).iterator();
      while (paramDataLayer.hasNext())
      {
        paramPoint1 = (cq.a)paramDataLayer.next();
        if (!Boolean.valueOf((com.google.android.com.internal.Integer)paramPoint1.getAttributes().get(class_3.o.toString())).booleanValue()) {
          a(o, (String)paramC.getKey()).b(paramPoint1);
        }
      }
    }
  }
  
  private static cs.c a(Map paramMap, String paramString)
  {
    cs.c localC2 = (cs.c)paramMap.get(paramString);
    cs.c localC1 = localC2;
    if (localC2 == null)
    {
      localC1 = new cs.c();
      paramMap.put(paramString, localC1);
    }
    return localC1;
  }
  
  private h a(com.google.android.com.internal.Integer paramInteger, Set paramSet, AnnotationVisitor paramAnnotationVisitor)
  {
    if (!size) {
      return new h(paramInteger, true);
    }
    h localH1;
    switch (type)
    {
    default: 
      break;
    case 5: 
    case 6: 
      Log.e("Unknown type: " + type);
      return a;
    case 2: 
      localInteger = ByteVector.read(paramInteger);
      value = new com.google.android.com.internal.Integer[value.length];
      i = 0;
      while (i < value.length)
      {
        localH1 = a(value[i], paramSet, paramAnnotationVisitor.visitAnnotation(i));
        if (localH1 == a) {
          return a;
        }
        value[i] = ((com.google.android.com.internal.Integer)localH1.getObject());
        i += 1;
      }
      return new h(localInteger, false);
    case 3: 
      localInteger = ByteVector.read(paramInteger);
      if (n.length != i.length)
      {
        Log.e("Invalid serving value: " + paramInteger.toString());
        return a;
      }
      n = new com.google.android.com.internal.Integer[n.length];
      i = new com.google.android.com.internal.Integer[n.length];
      i = 0;
      while (i < n.length)
      {
        localH1 = a(n[i], paramSet, paramAnnotationVisitor.visitParameterAnnotation(i));
        h localH2 = a(i[i], paramSet, paramAnnotationVisitor.visitTypeAnnotation(i));
        if ((localH1 == a) || (localH2 == a)) {
          return a;
        }
        n[i] = ((com.google.android.com.internal.Integer)localH1.getObject());
        i[i] = ((com.google.android.com.internal.Integer)localH2.getObject());
        i += 1;
      }
      return new h(localInteger, false);
    case 4: 
      if (paramSet.contains(q))
      {
        Log.e("Macro cycle detected.  Current macro reference: " + q + "." + "  Previous macro references: " + paramSet.toString() + ".");
        return a;
      }
      paramSet.add(q);
      paramAnnotationVisitor = Card.a(a(q, paramSet, paramAnnotationVisitor.visitAnnotation()), key);
      paramSet.remove(q);
      return paramAnnotationVisitor;
    }
    com.google.android.com.internal.Integer localInteger = ByteVector.read(paramInteger);
    s = new com.google.android.com.internal.Integer[s.length];
    int i = 0;
    while (i < s.length)
    {
      localH1 = a(s[i], paramSet, paramAnnotationVisitor.visitLocalVariableAnnotation(i));
      if (localH1 == a) {
        return a;
      }
      s[i] = ((com.google.android.com.internal.Integer)localH1.getObject());
      i += 1;
    }
    return new h(localInteger, false);
  }
  
  private h a(String paramString, Set paramSet, m.a paramA)
  {
    j += 1;
    Object localObject = (cs.b)g.get(paramString);
    if ((localObject != null) && (!l.b()))
    {
      a(((cs.b)localObject).getValue(), paramSet);
      j -= 1;
      return ((cs.b)localObject).c();
    }
    localObject = (cs.c)o.get(paramString);
    if (localObject == null)
    {
      Log.e(a() + "Invalid macro: " + paramString);
      j -= 1;
      return a;
    }
    h localH = a(paramString, ((cs.c)localObject).b(), ((cs.c)localObject).getValue(), ((cs.c)localObject).get(), ((cs.c)localObject).getEntries(), ((cs.c)localObject).read(), paramSet, paramA.add());
    if (((Set)localH.getObject()).isEmpty()) {}
    for (localObject = ((cs.c)localObject).getSlot(); localObject == null; localObject = (cq.a)((Set)localH.getObject()).iterator().next())
    {
      j -= 1;
      return a;
      if (((Set)localH.getObject()).size() > 1) {
        Log.append(a() + "Multiple macros active for macroName " + paramString);
      }
    }
    paramA = a(A, (cq.a)localObject, paramSet, paramA.a());
    boolean bool;
    if ((localH.a()) && (paramA.a()))
    {
      bool = true;
      if (paramA != a) {
        break label392;
      }
    }
    label392:
    for (paramA = a;; paramA = new h(paramA.getObject(), bool))
    {
      localObject = ((cq.a)localObject).getValue();
      if (paramA.a()) {
        g.put(paramString, new cs.b(paramA, (com.google.android.com.internal.Integer)localObject));
      }
      a((com.google.android.com.internal.Integer)localObject, paramSet);
      j -= 1;
      return paramA;
      bool = false;
      break;
    }
  }
  
  private h a(Map paramMap, cq.a paramA, Set paramSet, aa paramAa)
  {
    boolean bool = true;
    Object localObject1 = (com.google.android.com.internal.Integer)paramA.getAttributes().get(class_3.b.toString());
    if (localObject1 == null)
    {
      Log.e("No function id in properties");
      return a;
    }
    localObject1 = a;
    paramMap = (Message)paramMap.get(localObject1);
    if (paramMap == null)
    {
      Log.e((String)localObject1 + " has no backing implementation.");
      return a;
    }
    Object localObject2 = (h)m.get(paramA);
    if ((localObject2 == null) || (l.b()))
    {
      localObject2 = new HashMap();
      Iterator localIterator = paramA.getAttributes().entrySet().iterator();
      int i = 1;
      if (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        Object localObject3 = paramAa.a((String)localEntry.getKey());
        localObject3 = a((com.google.android.com.internal.Integer)localEntry.getValue(), paramSet, ((FieldVisitor)localObject3).visitAnnotation((com.google.android.com.internal.Integer)localEntry.getValue()));
        if (localObject3 == a) {
          return a;
        }
        if (((h)localObject3).a()) {
          paramA.add((String)localEntry.getKey(), (com.google.android.com.internal.Integer)((h)localObject3).getObject());
        }
        for (;;)
        {
          ((Map)localObject2).put(localEntry.getKey(), ((h)localObject3).getObject());
          break;
          i = 0;
        }
      }
      if (!paramMap.add(((Map)localObject2).keySet()))
      {
        Log.e("Incorrect keys for function " + (String)localObject1 + " required " + paramMap.getType() + " had " + ((Map)localObject2).keySet());
        return a;
      }
      if ((i != 0) && (paramMap.equals())) {}
      for (;;)
      {
        paramMap = new h(paramMap.evaluate((Map)localObject2), bool);
        if (bool) {
          m.put(paramA, paramMap);
        }
        paramAa.a((com.google.android.com.internal.Integer)paramMap.getObject());
        return paramMap;
        bool = false;
      }
    }
    return localObject2;
  }
  
  private h a(Set paramSet1, Set paramSet2, cs.a paramA, Menu paramMenu)
  {
    HashSet localHashSet1 = new HashSet();
    HashSet localHashSet2 = new HashSet();
    paramSet1 = paramSet1.iterator();
    boolean bool = true;
    if (paramSet1.hasNext())
    {
      cq.e localE = (cq.e)paramSet1.next();
      ad localAd = paramMenu.getItem();
      h localH = a(localE, paramSet2, localAd);
      if (((java.lang.Boolean)localH.getObject()).booleanValue()) {
        paramA.a(localE, localHashSet1, localHashSet2, localAd);
      }
      if ((bool) && (localH.a())) {}
      for (bool = true;; bool = false) {
        break;
      }
    }
    localHashSet1.removeAll(localHashSet2);
    paramMenu.add(localHashSet1);
    return new h(localHashSet1, bool);
  }
  
  private String a()
  {
    if (j <= 1) {
      return "";
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(Integer.toString(j));
    int i = 2;
    while (i < j)
    {
      localStringBuilder.append(' ');
      i += 1;
    }
    localStringBuilder.append(": ");
    return localStringBuilder.toString();
  }
  
  private static String a(cq.a paramA)
  {
    return Boolean.toString((com.google.android.com.internal.Integer)paramA.getAttributes().get(class_3.a.toString()));
  }
  
  private void a(com.google.android.com.internal.Integer paramInteger, Set paramSet)
  {
    if (paramInteger == null) {
      return;
    }
    paramInteger = a(paramInteger, paramSet, new MethodVisitor());
    if (paramInteger != a)
    {
      paramInteger = Boolean.get((com.google.android.com.internal.Integer)paramInteger.getObject());
      if ((paramInteger instanceof Map))
      {
        paramInteger = (Map)paramInteger;
        b.push(paramInteger);
        return;
      }
      if ((paramInteger instanceof List))
      {
        paramInteger = ((List)paramInteger).iterator();
        while (paramInteger.hasNext())
        {
          paramSet = paramInteger.next();
          if ((paramSet instanceof Map))
          {
            paramSet = (Map)paramSet;
            b.push(paramSet);
          }
          else
          {
            Log.append("pushAfterEvaluate: value not a Map");
          }
        }
      }
      Log.append("pushAfterEvaluate: value not a Map or List");
    }
  }
  
  private static void a(Map paramMap, Message paramMessage)
  {
    if (paramMap.containsKey(paramMessage.getResourcePath())) {
      throw new IllegalArgumentException("Duplicate function type name: " + paramMessage.getResourcePath());
    }
    paramMap.put(paramMessage.getResourcePath(), paramMessage);
  }
  
  private static void append(List paramList1, List paramList2, String paramString)
  {
    if (paramList1.size() != paramList2.size()) {
      Log.i("Invalid resource: imbalance of rule names of functions for " + paramString + " operation. Using default rule name instead");
    }
  }
  
  h a(cq.a paramA, Set paramSet, aa paramAa)
  {
    paramA = a(r, paramA, paramSet, paramAa);
    paramSet = Boolean.valueOf((com.google.android.com.internal.Integer)paramA.getObject());
    paramAa.a(Boolean.add(paramSet));
    return new h(paramSet, paramA.a());
  }
  
  h a(cq.e paramE, Set paramSet, ad paramAd)
  {
    Object localObject = paramE.getResultString().iterator();
    boolean bool = true;
    if (((Iterator)localObject).hasNext())
    {
      h localH = a((cq.a)((Iterator)localObject).next(), paramSet, paramAd.a());
      if (((java.lang.Boolean)localH.getObject()).booleanValue())
      {
        paramAd.a(Boolean.add(java.lang.Boolean.valueOf(false)));
        return new h(java.lang.Boolean.valueOf(false), localH.a());
      }
      if ((bool) && (localH.a())) {}
      for (bool = true;; bool = false) {
        break;
      }
    }
    paramE = paramE.getStep().iterator();
    while (paramE.hasNext())
    {
      localObject = a((cq.a)paramE.next(), paramSet, paramAd.getItem());
      if (!((java.lang.Boolean)((h)localObject).getObject()).booleanValue())
      {
        paramAd.a(Boolean.add(java.lang.Boolean.valueOf(false)));
        return new h(java.lang.Boolean.valueOf(false), ((h)localObject).a());
      }
      if ((bool) && (((h)localObject).a())) {
        bool = true;
      } else {
        bool = false;
      }
    }
    paramAd.a(Boolean.add(java.lang.Boolean.valueOf(true)));
    return new h(java.lang.Boolean.valueOf(true), bool);
  }
  
  h a(String paramString, Set paramSet1, Map paramMap1, Map paramMap2, Map paramMap3, Map paramMap4, Set paramSet2, Menu paramMenu)
  {
    return a(paramSet1, paramSet2, new cs.3(this, paramMap1, paramMap2, paramMap3, paramMap4), paramMenu);
  }
  
  h a(Set paramSet, Menu paramMenu)
  {
    return a(paramSet, new HashSet(), new cs.4(this), paramMenu);
  }
  
  void a(Message paramMessage)
  {
    a(r, paramMessage);
  }
  
  public void a(String paramString)
  {
    try
    {
      b(paramString);
      paramString = l.b(paramString);
      ac localAc = paramString.a();
      Iterator localIterator = ((Set)a(B, localAc.add()).getObject()).iterator();
      while (localIterator.hasNext())
      {
        cq.a localA = (cq.a)localIterator.next();
        a(f, localA, new HashSet(), localAc.a());
      }
      paramString.c();
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
    b(null);
  }
  
  void b(Message paramMessage)
  {
    a(f, paramMessage);
  }
  
  void b(String paramString)
  {
    try
    {
      c = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public h c(String paramString)
  {
    j = 0;
    i.a localA = l.a(paramString);
    paramString = a(paramString, new HashSet(), localA.b());
    localA.c();
    return paramString;
  }
  
  String get()
  {
    try
    {
      String str = c;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public void read(List paramList)
  {
    for (;;)
    {
      try
      {
        paramList = paramList.iterator();
        if (!paramList.hasNext()) {
          break;
        }
        com.google.android.com.internal.Attribute localAttribute = (com.google.android.com.internal.Attribute)paramList.next();
        if ((name == null) || (!name.startsWith("gaExperiment:"))) {
          Log.w("Ignored supplemental: " + localAttribute);
        } else {
          BitmapCache.put(b, localAttribute);
        }
      }
      catch (Throwable paramList)
      {
        throw paramList;
      }
    }
  }
  
  void toByteArray(Message paramMessage)
  {
    a(A, paramMessage);
  }
}
