package com.google.android.com.tagmanager;

import com.google.android.com.ads.identifier.AdvertisingIdClient;
import com.google.android.com.ads.identifier.AdvertisingIdClient.Info;
import com.google.android.com.common.GooglePlayServicesNotAvailableException;
import com.google.android.com.common.GooglePlayServicesRepairableException;
import java.io.IOException;

class FileHandle
  implements DataSource
{
  FileHandle(Dictionary paramDictionary) {}
  
  public AdvertisingIdClient.Info getProgress()
  {
    Object localObject = meta;
    try
    {
      localObject = AdvertisingIdClient.getAdvertisingIdInfo(Dictionary.add((Dictionary)localObject));
      return localObject;
    }
    catch (IllegalStateException localIllegalStateException)
    {
      Log.append("IllegalStateException getting Advertising Id Info");
      return null;
    }
    catch (GooglePlayServicesRepairableException localGooglePlayServicesRepairableException)
    {
      Log.append("GooglePlayServicesRepairableException getting Advertising Id Info");
      return null;
    }
    catch (IOException localIOException)
    {
      Log.append("IOException getting Ad Id Info");
      return null;
    }
    catch (GooglePlayServicesNotAvailableException localGooglePlayServicesNotAvailableException)
    {
      Log.append("GooglePlayServicesNotAvailableException getting Advertising Id Info");
      return null;
    }
    catch (Exception localException)
    {
      Log.append("Unknown exception. Could not get the Advertising Id Info.");
    }
    return null;
  }
}
