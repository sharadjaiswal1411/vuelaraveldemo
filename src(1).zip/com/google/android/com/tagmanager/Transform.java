package com.google.android.com.tagmanager;

import android.content.Context;
import android.provider.Settings.Secure;
import com.google.android.com.internal.Integer;
import com.google.android.com.internal.Priority;
import java.util.Map;

class Transform
  extends Message
{
  private static final String locale = Priority.CHALLENGED.toString();
  private final Context mContext;
  
  public Transform(Context paramContext)
  {
    super(locale, new String[0]);
    mContext = paramContext;
  }
  
  public boolean equals()
  {
    return true;
  }
  
  public Integer evaluate(Map paramMap)
  {
    paramMap = getAndroidId(mContext);
    if (paramMap == null) {
      return Boolean.get();
    }
    return Boolean.add(paramMap);
  }
  
  protected String getAndroidId(Context paramContext)
  {
    return Settings.Secure.getString(paramContext.getContentResolver(), "android_id");
  }
}
