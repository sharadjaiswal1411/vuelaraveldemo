package com.google.android.com.tagmanager;

import com.google.android.com.internal.Integer;

abstract interface FieldVisitor
{
  public abstract AnnotationVisitor visitAnnotation(Integer paramInteger);
}
