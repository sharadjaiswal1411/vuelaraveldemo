package com.google.android.com.tagmanager;

import com.google.android.com.internal.Block;
import com.google.android.com.internal.Message;
import com.google.android.com.internal.Node;
import com.google.android.com.internal.Subscription;
import com.google.android.com.internal.Token;
import com.google.android.com.internal.Vector2D;
import com.google.android.com.internal.class_3;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

class ByteVector
{
  private static Vector2D add(com.google.android.com.internal.Integer paramInteger)
    throws cq.g
  {
    if ((Vector2D)paramInteger.add(Vector2D.next) == null) {
      add("Expected a ServingValue and didn't get one. Value is: " + paramInteger);
    }
    return (Vector2D)paramInteger.add(Vector2D.next);
  }
  
  private static void add(String paramString)
    throws cq.g
  {
    Log.e(paramString);
    throw new cq.g(paramString);
  }
  
  private static Object get(Object[] paramArrayOfObject, int paramInt, String paramString)
    throws cq.g
  {
    if ((paramInt < 0) || (paramInt >= paramArrayOfObject.length)) {
      add("Index out of bounds detected: " + paramInt + " in " + paramString);
    }
    return paramArrayOfObject[paramInt];
  }
  
  private static com.google.android.com.internal.Integer read(int paramInt, Node paramNode, com.google.android.com.internal.Integer[] paramArrayOfInteger, Set paramSet)
    throws cq.g
  {
    int k = 0;
    int m = 0;
    int j = 0;
    if (paramSet.contains(Integer.valueOf(paramInt))) {
      add("Value cycle detected.  Current value reference: " + paramInt + "." + "  Previous value references: " + paramSet + ".");
    }
    com.google.android.com.internal.Integer localInteger2 = (com.google.android.com.internal.Integer)get(type, paramInt, "values");
    if (paramArrayOfInteger[paramInt] != null) {
      return paramArrayOfInteger[paramInt];
    }
    Object localObject = null;
    paramSet.add(Integer.valueOf(paramInt));
    switch (type)
    {
    default: 
      break;
    }
    for (;;)
    {
      if (localObject == null) {
        add("Invalid value: " + localInteger2);
      }
      paramArrayOfInteger[paramInt] = localObject;
      paramSet.remove(Integer.valueOf(paramInt));
      return localObject;
      localObject = add(localInteger2);
      com.google.android.com.internal.Integer localInteger3 = read(localInteger2);
      com.google.android.com.internal.Integer localInteger1 = localInteger3;
      value = new com.google.android.com.internal.Integer[name.length];
      int[] arrayOfInt = name;
      k = arrayOfInt.length;
      int i = 0;
      for (;;)
      {
        localObject = localInteger1;
        if (j >= k) {
          break;
        }
        m = arrayOfInt[j];
        value[i] = read(m, paramNode, paramArrayOfInteger, paramSet);
        j += 1;
        i += 1;
      }
      localInteger3 = read(localInteger2);
      localInteger1 = localInteger3;
      localObject = add(localInteger2);
      if (data.length != value.length) {
        add("Uneven map keys (" + data.length + ") and map values (" + value.length + ")");
      }
      n = new com.google.android.com.internal.Integer[data.length];
      i = new com.google.android.com.internal.Integer[data.length];
      arrayOfInt = data;
      m = arrayOfInt.length;
      j = 0;
      i = 0;
      while (j < m)
      {
        int n = arrayOfInt[j];
        n[i] = read(n, paramNode, paramArrayOfInteger, paramSet);
        j += 1;
        i += 1;
      }
      arrayOfInt = value;
      m = arrayOfInt.length;
      i = 0;
      j = k;
      for (;;)
      {
        localObject = localInteger1;
        if (j >= m) {
          break;
        }
        k = arrayOfInt[j];
        i[i] = read(k, paramNode, paramArrayOfInteger, paramSet);
        j += 1;
        i += 1;
      }
      localInteger1 = read(localInteger2);
      localObject = localInteger1;
      q = Boolean.toString(read(addtype, paramNode, paramArrayOfInteger, paramSet));
      continue;
      localInteger3 = read(localInteger2);
      localInteger1 = localInteger3;
      localObject = add(localInteger2);
      s = new com.google.android.com.internal.Integer[key.length];
      arrayOfInt = key;
      k = arrayOfInt.length;
      i = 0;
      j = m;
      for (;;)
      {
        localObject = localInteger1;
        if (j >= k) {
          break;
        }
        m = arrayOfInt[j];
        s[i] = read(m, paramNode, paramArrayOfInteger, paramSet);
        j += 1;
        i += 1;
      }
      localObject = localInteger2;
    }
  }
  
  public static com.google.android.com.internal.Integer read(com.google.android.com.internal.Integer paramInteger)
  {
    com.google.android.com.internal.Integer localInteger = new com.google.android.com.internal.Integer();
    type = type;
    key = ((int[])key.clone());
    if (size) {
      size = size;
    }
    return localInteger;
  }
  
  private static cq.e read(Block paramBlock, List paramList1, List paramList2, List paramList3, Node paramNode)
  {
    cq.f localF = cq.e.getDelegate();
    int[] arrayOfInt = key;
    int j = arrayOfInt.length;
    int i = 0;
    while (i < j)
    {
      localF.position((cq.a)paramList3.get(Integer.valueOf(arrayOfInt[i]).intValue()));
      i += 1;
    }
    arrayOfInt = next;
    j = arrayOfInt.length;
    i = 0;
    while (i < j)
    {
      localF.a((cq.a)paramList3.get(Integer.valueOf(arrayOfInt[i]).intValue()));
      i += 1;
    }
    paramList3 = value;
    j = paramList3.length;
    i = 0;
    while (i < j)
    {
      localF.set((cq.a)paramList1.get(Integer.valueOf(paramList3[i]).intValue()));
      i += 1;
    }
    paramList3 = size;
    j = paramList3.length;
    i = 0;
    int k;
    while (i < j)
    {
      k = paramList3[i];
      localF.close(type[Integer.valueOf(k).intValue()].data);
      i += 1;
    }
    paramList3 = name;
    j = paramList3.length;
    i = 0;
    while (i < j)
    {
      localF.close((cq.a)paramList1.get(Integer.valueOf(paramList3[i]).intValue()));
      i += 1;
    }
    paramList1 = buf;
    j = paramList1.length;
    i = 0;
    while (i < j)
    {
      k = paramList1[i];
      localF.remove(type[Integer.valueOf(k).intValue()].data);
      i += 1;
    }
    paramList1 = data;
    j = paramList1.length;
    i = 0;
    while (i < j)
    {
      localF.add((cq.a)paramList2.get(Integer.valueOf(paramList1[i]).intValue()));
      i += 1;
    }
    paramList1 = type;
    j = paramList1.length;
    i = 0;
    while (i < j)
    {
      k = paramList1[i];
      localF.set(type[Integer.valueOf(k).intValue()].data);
      i += 1;
    }
    paramList1 = state;
    j = paramList1.length;
    i = 0;
    while (i < j)
    {
      localF.remove((cq.a)paramList2.get(Integer.valueOf(paramList1[i]).intValue()));
      i += 1;
    }
    paramBlock = fields;
    j = paramBlock.length;
    i = 0;
    while (i < j)
    {
      k = paramBlock[i];
      localF.add(type[Integer.valueOf(k).intValue()].data);
      i += 1;
    }
    return localF.add();
  }
  
  public static cq.c run(Node paramNode)
    throws cq.g
  {
    int j = 0;
    Object localObject = new com.google.android.com.internal.Integer[type.length];
    int i = 0;
    while (i < type.length)
    {
      read(i, paramNode, (com.google.android.com.internal.Integer[])localObject, new HashSet(0));
      i += 1;
    }
    cq.d localD = cq.c.putByte();
    ArrayList localArrayList1 = new ArrayList();
    i = 0;
    while (i < data.length)
    {
      localArrayList1.add(write(data[i], paramNode, (com.google.android.com.internal.Integer[])localObject, i));
      i += 1;
    }
    ArrayList localArrayList2 = new ArrayList();
    i = 0;
    while (i < offset.length)
    {
      localArrayList2.add(write(offset[i], paramNode, (com.google.android.com.internal.Integer[])localObject, i));
      i += 1;
    }
    ArrayList localArrayList3 = new ArrayList();
    i = 0;
    while (i < name.length)
    {
      cq.a localA = write(name[i], paramNode, (com.google.android.com.internal.Integer[])localObject, i);
      localD.a(localA);
      localArrayList3.add(localA);
      i += 1;
    }
    localObject = size;
    int k = localObject.length;
    i = j;
    while (i < k)
    {
      localD.a(read(localObject[i], localArrayList1, localArrayList3, localArrayList2, paramNode));
      i += 1;
    }
    localD.a(id);
    localD.putInt(state);
    return localD.b();
  }
  
  private static cq.a write(Subscription paramSubscription, Node paramNode, com.google.android.com.internal.Integer[] paramArrayOfInteger, int paramInt)
    throws cq.g
  {
    cq.b localB = cq.a.a();
    paramSubscription = key;
    int i = paramSubscription.length;
    paramInt = 0;
    if (paramInt < i)
    {
      int j = paramSubscription[paramInt];
      Object localObject = (Token)get(fields, Integer.valueOf(j).intValue(), "properties");
      String str = (String)get(key, name, "keys");
      localObject = (com.google.android.com.internal.Integer)get(paramArrayOfInteger, value, "values");
      if (class_3.NULL.toString().equals(str)) {
        localB.a((com.google.android.com.internal.Integer)localObject);
      }
      for (;;)
      {
        paramInt += 1;
        break;
        localB.a(str, (com.google.android.com.internal.Integer)localObject);
      }
    }
    return localB.a();
  }
  
  public static void write(InputStream paramInputStream, OutputStream paramOutputStream)
    throws IOException
  {
    byte[] arrayOfByte = new byte['?'];
    for (;;)
    {
      int i = paramInputStream.read(arrayOfByte);
      if (i == -1) {
        return;
      }
      paramOutputStream.write(arrayOfByte, 0, i);
    }
  }
}
