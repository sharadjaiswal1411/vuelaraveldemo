package com.google.android.com.tagmanager;

class Widget
  implements ac
{
  Widget() {}
  
  public aa a()
  {
    return new w();
  }
  
  public Menu add()
  {
    return new MenuWrapper();
  }
}
