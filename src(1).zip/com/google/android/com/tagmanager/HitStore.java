package com.google.android.com.tagmanager;

abstract interface HitStore
{
  public abstract void close(long paramLong, String paramString);
  
  public abstract void dispatch();
}
