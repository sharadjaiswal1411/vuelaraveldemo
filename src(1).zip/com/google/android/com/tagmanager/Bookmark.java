package com.google.android.com.tagmanager;

import android.content.Context;
import android.net.Uri;
import java.util.Map;

class Bookmark
  implements DataLayer.b
{
  private final Context context;
  
  public Bookmark(Context paramContext)
  {
    context = paramContext;
  }
  
  public void changed(Map paramMap)
  {
    Object localObject = paramMap.get("gtm.url");
    if (localObject == null)
    {
      paramMap = paramMap.get("gtm");
      if ((paramMap == null) || (!(paramMap instanceof Map))) {}
    }
    for (paramMap = ((Map)paramMap).get("url"); paramMap != null; paramMap = localObject)
    {
      if (!(paramMap instanceof String)) {
        return;
      }
      paramMap = Uri.parse((String)paramMap).getQueryParameter("referrer");
      if (paramMap == null) {
        break;
      }
      Tools.init(context, paramMap);
      return;
    }
  }
}
