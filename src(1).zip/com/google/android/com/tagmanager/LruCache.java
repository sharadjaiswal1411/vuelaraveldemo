package com.google.android.com.tagmanager;

public abstract interface LruCache<K, V>
{
  public abstract int sizeOf(Object paramObject1, Object paramObject2);
}
