package com.google.android.com.tagmanager;

import java.util.Set;

abstract interface Menu
{
  public abstract void add(Set paramSet);
  
  public abstract ad getItem();
}
