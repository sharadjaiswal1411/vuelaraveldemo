package com.google.android.com.tagmanager;

abstract class ServiceManager
{
  ServiceManager() {}
  
  abstract void initialize(boolean paramBoolean);
  
  abstract void write();
}
