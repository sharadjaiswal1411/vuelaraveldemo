package com.google.android.com.dynamic;

class FragmentManagerImpl
  implements Object
{
  FragmentManagerImpl(Fragment paramFragment) {}
  
  public int getState()
  {
    return 4;
  }
  
  public void moveToState(LifecycleDelegate paramLifecycleDelegate)
  {
    Fragment.append(mParent).onStart();
  }
}
