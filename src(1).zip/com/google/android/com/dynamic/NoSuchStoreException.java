package com.google.android.com.dynamic;

public class NoSuchStoreException
  extends Exception
{
  public NoSuchStoreException(String paramString)
  {
    super(paramString);
  }
  
  public NoSuchStoreException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}
