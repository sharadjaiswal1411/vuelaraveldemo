package com.google.android.com.dynamic;

import android.app.Activity;
import android.os.Bundle;

class FragmentState
  implements Object
{
  FragmentState(Fragment paramFragment, Activity paramActivity, Bundle paramBundle1, Bundle paramBundle2) {}
  
  public int getState()
  {
    return 0;
  }
  
  public void moveToState(LifecycleDelegate paramLifecycleDelegate)
  {
    Fragment.append(mContainerId).onInflate(mActivity, mSavedFragmentState, mFromLayout);
  }
}
