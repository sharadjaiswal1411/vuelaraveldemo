package com.google.android.com.dynamic;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.com.common.GooglePlayServicesUtil;
import com.google.android.gms.dynamic.a.a;
import com.google.android.gms.dynamic.f;
import java.util.LinkedList;

public abstract class Fragment<T extends com.google.android.gms.dynamic.LifecycleDelegate>
{
  private final f<T> m = new x(this);
  private T mView;
  private LinkedList<a.a> stack;
  private Bundle values;
  
  public Fragment() {}
  
  private void add(Bundle paramBundle, Object paramObject)
  {
    if (mView != null)
    {
      paramObject.moveToState(mView);
      return;
    }
    if (stack == null) {
      stack = new LinkedList();
    }
    stack.add(paramObject);
    if (paramBundle != null)
    {
      if (values != null) {
        break label76;
      }
      values = ((Bundle)paramBundle.clone());
    }
    for (;;)
    {
      a(m);
      return;
      label76:
      values.putAll(paramBundle);
    }
  }
  
  public static void getView(FrameLayout paramFrameLayout)
  {
    Context localContext = paramFrameLayout.getContext();
    int i = GooglePlayServicesUtil.isGooglePlayServicesAvailable(localContext);
    String str2 = GooglePlayServicesUtil.getVersionName(localContext, i);
    String str1 = GooglePlayServicesUtil.getText(localContext, i);
    LinearLayout localLinearLayout = new LinearLayout(paramFrameLayout.getContext());
    localLinearLayout.setOrientation(1);
    localLinearLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
    paramFrameLayout.addView(localLinearLayout);
    paramFrameLayout = new TextView(paramFrameLayout.getContext());
    paramFrameLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
    paramFrameLayout.setText(str2);
    localLinearLayout.addView(paramFrameLayout);
    if (str1 != null)
    {
      paramFrameLayout = new Button(localContext);
      paramFrameLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
      paramFrameLayout.setText(str1);
      localLinearLayout.addView(paramFrameLayout);
      paramFrameLayout.setOnClickListener(new ArtistAdapter.1(localContext, i));
    }
  }
  
  private void next(int paramInt)
  {
    while ((!stack.isEmpty()) && (((Object)stack.getLast()).getState() >= paramInt)) {
      stack.removeLast();
    }
  }
  
  protected abstract void a(i paramI);
  
  protected void init(FrameLayout paramFrameLayout)
  {
    getView(paramFrameLayout);
  }
  
  public void onCreate(Bundle paramBundle)
  {
    add(paramBundle, new EditorActivity.3(this, paramBundle));
  }
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle)
  {
    FrameLayout localFrameLayout = new FrameLayout(paramLayoutInflater.getContext());
    add(paramBundle, new Folder(this, localFrameLayout, paramLayoutInflater, paramViewGroup, paramBundle));
    if (mView == null) {
      init(localFrameLayout);
    }
    return localFrameLayout;
  }
  
  public void onDestroy()
  {
    if (mView != null)
    {
      mView.onDestroy();
      return;
    }
    next(1);
  }
  
  public void onDestroyView()
  {
    if (mView != null)
    {
      mView.onDestroyView();
      return;
    }
    next(2);
  }
  
  public void onInflate(Activity paramActivity, Bundle paramBundle1, Bundle paramBundle2)
  {
    add(paramBundle2, new FragmentState(this, paramActivity, paramBundle1, paramBundle2));
  }
  
  public void onLowMemory()
  {
    if (mView != null) {
      mView.onLowMemory();
    }
  }
  
  public void onPause()
  {
    if (mView != null)
    {
      mView.onPause();
      return;
    }
    next(5);
  }
  
  public void onResume()
  {
    add(null, new Timer(this));
  }
  
  public void onSaveInstanceState(Bundle paramBundle)
  {
    if (mView != null)
    {
      mView.onSaveInstanceState(paramBundle);
      return;
    }
    if (values != null) {
      paramBundle.putAll(values);
    }
  }
  
  public void onStart()
  {
    add(null, new FragmentManagerImpl(this));
  }
  
  public void onStop()
  {
    if (mView != null)
    {
      mView.onStop();
      return;
    }
    next(4);
  }
  
  public LifecycleDelegate post()
  {
    return mView;
  }
}
