package com.google.android.com.dynamic;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface c
  extends IInterface
{
  public abstract c a()
    throws RemoteException;
  
  public abstract Bundle getArguments()
    throws RemoteException;
  
  public abstract c getCount()
    throws RemoteException;
  
  public abstract int getId()
    throws RemoteException;
  
  public abstract boolean getRetainInstance()
    throws RemoteException;
  
  public abstract String getTag()
    throws RemoteException;
  
  public abstract int getTargetRequestCode()
    throws RemoteException;
  
  public abstract boolean getUserVisibleHint()
    throws RemoteException;
  
  public abstract Item getView()
    throws RemoteException;
  
  public abstract boolean isAdded()
    throws RemoteException;
  
  public abstract boolean isDetached()
    throws RemoteException;
  
  public abstract boolean isHidden()
    throws RemoteException;
  
  public abstract boolean isInLayout()
    throws RemoteException;
  
  public abstract boolean isRemoving()
    throws RemoteException;
  
  public abstract boolean isResumed()
    throws RemoteException;
  
  public abstract boolean isVisible()
    throws RemoteException;
  
  public abstract void register(Item paramItem)
    throws RemoteException;
  
  public abstract void rename(Item paramItem)
    throws RemoteException;
  
  public abstract void setHasOptionsMenu(boolean paramBoolean)
    throws RemoteException;
  
  public abstract void setMenuVisibility(boolean paramBoolean)
    throws RemoteException;
  
  public abstract void setRetainInstance(boolean paramBoolean)
    throws RemoteException;
  
  public abstract void setUserVisibleHint(boolean paramBoolean)
    throws RemoteException;
  
  public abstract Item setValue()
    throws RemoteException;
  
  public abstract void startActivity(Intent paramIntent)
    throws RemoteException;
  
  public abstract void startActivityForResult(Intent paramIntent, int paramInt)
    throws RemoteException;
  
  public abstract Item update()
    throws RemoteException;
  
  class a$a
    implements c
  {
    a$a() {}
    
    public c a()
      throws RemoteException
    {
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(9, localParcel1, localParcel2, 0);
        localParcel2.readException();
        c localC = e.a(localParcel2.readStrongBinder());
        localParcel2.recycle();
        localParcel1.recycle();
        return localC;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public IBinder asBinder()
    {
      return c.this;
    }
    
    /* Error */
    public Bundle getArguments()
      throws RemoteException
    {
      // Byte code:
      //   0: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore_3
      //   4: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   7: astore 4
      //   9: aload_3
      //   10: ldc 32
      //   12: invokevirtual 36	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   15: aload_0
      //   16: getfield 17	com/google/android/com/dynamic/c$a$a:mRemote	Landroid/os/IBinder;
      //   19: iconst_3
      //   20: aload_3
      //   21: aload 4
      //   23: iconst_0
      //   24: invokeinterface 42 5 0
      //   29: pop
      //   30: aload 4
      //   32: invokevirtual 45	android/os/Parcel:readException	()V
      //   35: aload 4
      //   37: invokevirtual 63	android/os/Parcel:readInt	()I
      //   40: istore_1
      //   41: iload_1
      //   42: ifeq +28 -> 70
      //   45: getstatic 69	android/os/Bundle:CREATOR	Landroid/os/Parcelable$Creator;
      //   48: aload 4
      //   50: invokeinterface 75 2 0
      //   55: checkcast 65	android/os/Bundle
      //   58: astore_2
      //   59: aload 4
      //   61: invokevirtual 55	android/os/Parcel:recycle	()V
      //   64: aload_3
      //   65: invokevirtual 55	android/os/Parcel:recycle	()V
      //   68: aload_2
      //   69: areturn
      //   70: aconst_null
      //   71: astore_2
      //   72: goto -13 -> 59
      //   75: astore_2
      //   76: aload 4
      //   78: invokevirtual 55	android/os/Parcel:recycle	()V
      //   81: aload_3
      //   82: invokevirtual 55	android/os/Parcel:recycle	()V
      //   85: aload_2
      //   86: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	87	0	this	a
      //   40	2	1	i	int
      //   58	14	2	localBundle	Bundle
      //   75	11	2	localThrowable	Throwable
      //   3	79	3	localParcel1	Parcel
      //   7	70	4	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   9	41	75	java/lang/Throwable
      //   45	59	75	java/lang/Throwable
    }
    
    public c getCount()
      throws RemoteException
    {
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(5, localParcel1, localParcel2, 0);
        localParcel2.readException();
        c localC = e.a(localParcel2.readStrongBinder());
        localParcel2.recycle();
        localParcel1.recycle();
        return localC;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public int getId()
      throws RemoteException
    {
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(4, localParcel1, localParcel2, 0);
        localParcel2.readException();
        int i = localParcel2.readInt();
        localParcel2.recycle();
        localParcel1.recycle();
        return i;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public boolean getRetainInstance()
      throws RemoteException
    {
      boolean bool = false;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(7, localParcel1, localParcel2, 0);
        localParcel2.readException();
        int i = localParcel2.readInt();
        if (i != 0) {
          bool = true;
        }
        localParcel2.recycle();
        localParcel1.recycle();
        return bool;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public String getTag()
      throws RemoteException
    {
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(8, localParcel1, localParcel2, 0);
        localParcel2.readException();
        String str = localParcel2.readString();
        localParcel2.recycle();
        localParcel1.recycle();
        return str;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public int getTargetRequestCode()
      throws RemoteException
    {
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(10, localParcel1, localParcel2, 0);
        localParcel2.readException();
        int i = localParcel2.readInt();
        localParcel2.recycle();
        localParcel1.recycle();
        return i;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public boolean getUserVisibleHint()
      throws RemoteException
    {
      boolean bool = false;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(11, localParcel1, localParcel2, 0);
        localParcel2.readException();
        int i = localParcel2.readInt();
        if (i != 0) {
          bool = true;
        }
        localParcel2.recycle();
        localParcel1.recycle();
        return bool;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public Item getView()
      throws RemoteException
    {
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(12, localParcel1, localParcel2, 0);
        localParcel2.readException();
        Item localItem = Log.toString(localParcel2.readStrongBinder());
        localParcel2.recycle();
        localParcel1.recycle();
        return localItem;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public boolean isAdded()
      throws RemoteException
    {
      boolean bool = false;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(13, localParcel1, localParcel2, 0);
        localParcel2.readException();
        int i = localParcel2.readInt();
        if (i != 0) {
          bool = true;
        }
        localParcel2.recycle();
        localParcel1.recycle();
        return bool;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public boolean isDetached()
      throws RemoteException
    {
      boolean bool = false;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(14, localParcel1, localParcel2, 0);
        localParcel2.readException();
        int i = localParcel2.readInt();
        if (i != 0) {
          bool = true;
        }
        localParcel2.recycle();
        localParcel1.recycle();
        return bool;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public boolean isHidden()
      throws RemoteException
    {
      boolean bool = false;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(15, localParcel1, localParcel2, 0);
        localParcel2.readException();
        int i = localParcel2.readInt();
        if (i != 0) {
          bool = true;
        }
        localParcel2.recycle();
        localParcel1.recycle();
        return bool;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public boolean isInLayout()
      throws RemoteException
    {
      boolean bool = false;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(16, localParcel1, localParcel2, 0);
        localParcel2.readException();
        int i = localParcel2.readInt();
        if (i != 0) {
          bool = true;
        }
        localParcel2.recycle();
        localParcel1.recycle();
        return bool;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public boolean isRemoving()
      throws RemoteException
    {
      boolean bool = false;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(17, localParcel1, localParcel2, 0);
        localParcel2.readException();
        int i = localParcel2.readInt();
        if (i != 0) {
          bool = true;
        }
        localParcel2.recycle();
        localParcel1.recycle();
        return bool;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public boolean isResumed()
      throws RemoteException
    {
      boolean bool = false;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(18, localParcel1, localParcel2, 0);
        localParcel2.readException();
        int i = localParcel2.readInt();
        if (i != 0) {
          bool = true;
        }
        localParcel2.recycle();
        localParcel1.recycle();
        return bool;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public boolean isVisible()
      throws RemoteException
    {
      boolean bool = false;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(19, localParcel1, localParcel2, 0);
        localParcel2.readException();
        int i = localParcel2.readInt();
        if (i != 0) {
          bool = true;
        }
        localParcel2.recycle();
        localParcel1.recycle();
        return bool;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    /* Error */
    public void register(Item paramItem)
      throws RemoteException
    {
      // Byte code:
      //   0: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore_2
      //   4: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   7: astore_3
      //   8: aload_2
      //   9: ldc 32
      //   11: invokevirtual 36	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   14: aload_1
      //   15: ifnull +43 -> 58
      //   18: aload_1
      //   19: invokeinterface 107 1 0
      //   24: astore_1
      //   25: aload_2
      //   26: aload_1
      //   27: invokevirtual 110	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
      //   30: aload_0
      //   31: getfield 17	com/google/android/com/dynamic/c$a$a:mRemote	Landroid/os/IBinder;
      //   34: bipush 20
      //   36: aload_2
      //   37: aload_3
      //   38: iconst_0
      //   39: invokeinterface 42 5 0
      //   44: pop
      //   45: aload_3
      //   46: invokevirtual 45	android/os/Parcel:readException	()V
      //   49: aload_3
      //   50: invokevirtual 55	android/os/Parcel:recycle	()V
      //   53: aload_2
      //   54: invokevirtual 55	android/os/Parcel:recycle	()V
      //   57: return
      //   58: aconst_null
      //   59: astore_1
      //   60: goto -35 -> 25
      //   63: astore_1
      //   64: aload_3
      //   65: invokevirtual 55	android/os/Parcel:recycle	()V
      //   68: aload_2
      //   69: invokevirtual 55	android/os/Parcel:recycle	()V
      //   72: aload_1
      //   73: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	74	0	this	a
      //   0	74	1	paramItem	Item
      //   3	66	2	localParcel1	Parcel
      //   7	58	3	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   8	14	63	java/lang/Throwable
      //   18	25	63	java/lang/Throwable
      //   25	49	63	java/lang/Throwable
    }
    
    /* Error */
    public void rename(Item paramItem)
      throws RemoteException
    {
      // Byte code:
      //   0: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore_2
      //   4: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   7: astore_3
      //   8: aload_2
      //   9: ldc 32
      //   11: invokevirtual 36	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   14: aload_1
      //   15: ifnull +43 -> 58
      //   18: aload_1
      //   19: invokeinterface 107 1 0
      //   24: astore_1
      //   25: aload_2
      //   26: aload_1
      //   27: invokevirtual 110	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
      //   30: aload_0
      //   31: getfield 17	com/google/android/com/dynamic/c$a$a:mRemote	Landroid/os/IBinder;
      //   34: bipush 27
      //   36: aload_2
      //   37: aload_3
      //   38: iconst_0
      //   39: invokeinterface 42 5 0
      //   44: pop
      //   45: aload_3
      //   46: invokevirtual 45	android/os/Parcel:readException	()V
      //   49: aload_3
      //   50: invokevirtual 55	android/os/Parcel:recycle	()V
      //   53: aload_2
      //   54: invokevirtual 55	android/os/Parcel:recycle	()V
      //   57: return
      //   58: aconst_null
      //   59: astore_1
      //   60: goto -35 -> 25
      //   63: astore_1
      //   64: aload_3
      //   65: invokevirtual 55	android/os/Parcel:recycle	()V
      //   68: aload_2
      //   69: invokevirtual 55	android/os/Parcel:recycle	()V
      //   72: aload_1
      //   73: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	74	0	this	a
      //   0	74	1	paramItem	Item
      //   3	66	2	localParcel1	Parcel
      //   7	58	3	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   8	14	63	java/lang/Throwable
      //   18	25	63	java/lang/Throwable
      //   25	49	63	java/lang/Throwable
    }
    
    public void setHasOptionsMenu(boolean paramBoolean)
      throws RemoteException
    {
      int i = 0;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        if (paramBoolean) {
          i = 1;
        }
        localParcel1.writeInt(i);
        transact(21, localParcel1, localParcel2, 0);
        localParcel2.readException();
        localParcel2.recycle();
        localParcel1.recycle();
        return;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public void setMenuVisibility(boolean paramBoolean)
      throws RemoteException
    {
      int i = 0;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        if (paramBoolean) {
          i = 1;
        }
        localParcel1.writeInt(i);
        transact(22, localParcel1, localParcel2, 0);
        localParcel2.readException();
        localParcel2.recycle();
        localParcel1.recycle();
        return;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public void setRetainInstance(boolean paramBoolean)
      throws RemoteException
    {
      int i = 0;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        if (paramBoolean) {
          i = 1;
        }
        localParcel1.writeInt(i);
        transact(23, localParcel1, localParcel2, 0);
        localParcel2.readException();
        localParcel2.recycle();
        localParcel1.recycle();
        return;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public void setUserVisibleHint(boolean paramBoolean)
      throws RemoteException
    {
      int i = 0;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        if (paramBoolean) {
          i = 1;
        }
        localParcel1.writeInt(i);
        transact(24, localParcel1, localParcel2, 0);
        localParcel2.readException();
        localParcel2.recycle();
        localParcel1.recycle();
        return;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    public Item setValue()
      throws RemoteException
    {
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(2, localParcel1, localParcel2, 0);
        localParcel2.readException();
        Item localItem = Log.toString(localParcel2.readStrongBinder());
        localParcel2.recycle();
        localParcel1.recycle();
        return localItem;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
    
    /* Error */
    public void startActivity(Intent paramIntent)
      throws RemoteException
    {
      // Byte code:
      //   0: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore_2
      //   4: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   7: astore_3
      //   8: aload_2
      //   9: ldc 32
      //   11: invokevirtual 36	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   14: aload_1
      //   15: ifnull +42 -> 57
      //   18: aload_2
      //   19: iconst_1
      //   20: invokevirtual 117	android/os/Parcel:writeInt	(I)V
      //   23: aload_1
      //   24: aload_2
      //   25: iconst_0
      //   26: invokevirtual 129	android/content/Intent:writeToParcel	(Landroid/os/Parcel;I)V
      //   29: aload_0
      //   30: getfield 17	com/google/android/com/dynamic/c$a$a:mRemote	Landroid/os/IBinder;
      //   33: bipush 25
      //   35: aload_2
      //   36: aload_3
      //   37: iconst_0
      //   38: invokeinterface 42 5 0
      //   43: pop
      //   44: aload_3
      //   45: invokevirtual 45	android/os/Parcel:readException	()V
      //   48: aload_3
      //   49: invokevirtual 55	android/os/Parcel:recycle	()V
      //   52: aload_2
      //   53: invokevirtual 55	android/os/Parcel:recycle	()V
      //   56: return
      //   57: aload_2
      //   58: iconst_0
      //   59: invokevirtual 117	android/os/Parcel:writeInt	(I)V
      //   62: goto -33 -> 29
      //   65: astore_1
      //   66: aload_3
      //   67: invokevirtual 55	android/os/Parcel:recycle	()V
      //   70: aload_2
      //   71: invokevirtual 55	android/os/Parcel:recycle	()V
      //   74: aload_1
      //   75: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	76	0	this	a
      //   0	76	1	paramIntent	Intent
      //   3	68	2	localParcel1	Parcel
      //   7	60	3	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   8	14	65	java/lang/Throwable
      //   18	29	65	java/lang/Throwable
      //   29	48	65	java/lang/Throwable
      //   57	62	65	java/lang/Throwable
    }
    
    /* Error */
    public void startActivityForResult(Intent paramIntent, int paramInt)
      throws RemoteException
    {
      // Byte code:
      //   0: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore_3
      //   4: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   7: astore 4
      //   9: aload_3
      //   10: ldc 32
      //   12: invokevirtual 36	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   15: aload_1
      //   16: ifnull +50 -> 66
      //   19: aload_3
      //   20: iconst_1
      //   21: invokevirtual 117	android/os/Parcel:writeInt	(I)V
      //   24: aload_1
      //   25: aload_3
      //   26: iconst_0
      //   27: invokevirtual 129	android/content/Intent:writeToParcel	(Landroid/os/Parcel;I)V
      //   30: aload_3
      //   31: iload_2
      //   32: invokevirtual 117	android/os/Parcel:writeInt	(I)V
      //   35: aload_0
      //   36: getfield 17	com/google/android/com/dynamic/c$a$a:mRemote	Landroid/os/IBinder;
      //   39: bipush 26
      //   41: aload_3
      //   42: aload 4
      //   44: iconst_0
      //   45: invokeinterface 42 5 0
      //   50: pop
      //   51: aload 4
      //   53: invokevirtual 45	android/os/Parcel:readException	()V
      //   56: aload 4
      //   58: invokevirtual 55	android/os/Parcel:recycle	()V
      //   61: aload_3
      //   62: invokevirtual 55	android/os/Parcel:recycle	()V
      //   65: return
      //   66: aload_3
      //   67: iconst_0
      //   68: invokevirtual 117	android/os/Parcel:writeInt	(I)V
      //   71: goto -41 -> 30
      //   74: astore_1
      //   75: aload 4
      //   77: invokevirtual 55	android/os/Parcel:recycle	()V
      //   80: aload_3
      //   81: invokevirtual 55	android/os/Parcel:recycle	()V
      //   84: aload_1
      //   85: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	86	0	this	a
      //   0	86	1	paramIntent	Intent
      //   0	86	2	paramInt	int
      //   3	78	3	localParcel1	Parcel
      //   7	69	4	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   9	15	74	java/lang/Throwable
      //   19	30	74	java/lang/Throwable
      //   30	56	74	java/lang/Throwable
      //   66	71	74	java/lang/Throwable
    }
    
    public Item update()
      throws RemoteException
    {
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.google.android.gms.dynamic.IFragmentWrapper");
        transact(6, localParcel1, localParcel2, 0);
        localParcel2.readException();
        Item localItem = Log.toString(localParcel2.readStrongBinder());
        localParcel2.recycle();
        localParcel1.recycle();
        return localItem;
      }
      catch (Throwable localThrowable)
      {
        localParcel2.recycle();
        localParcel1.recycle();
        throw localThrowable;
      }
    }
  }
}
