package com.google.android.com.dynamic;

import android.os.IInterface;

public abstract interface Item
  extends IInterface
{}
