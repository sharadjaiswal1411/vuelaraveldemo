package com.google.android.com.dynamic;

abstract interface Object
{
  public abstract int getState();
  
  public abstract void moveToState(LifecycleDelegate paramLifecycleDelegate);
}
