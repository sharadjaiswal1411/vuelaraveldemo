package com.google.android.com.dynamic;

import com.google.android.gms.dynamic.f;
import java.util.Iterator;
import java.util.LinkedList;

class x
  implements f<T>
{
  x(Fragment paramFragment) {}
  
  public void a(LifecycleDelegate paramLifecycleDelegate)
  {
    Fragment.remove(a, paramLifecycleDelegate);
    paramLifecycleDelegate = Fragment.get(a).iterator();
    while (paramLifecycleDelegate.hasNext()) {
      ((Object)paramLifecycleDelegate.next()).moveToState(Fragment.append(a));
    }
    Fragment.get(a).clear();
    Fragment.remove(a, null);
  }
}
