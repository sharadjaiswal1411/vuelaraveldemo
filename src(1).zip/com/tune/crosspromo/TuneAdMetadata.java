package com.tune.crosspromo;

import android.location.Location;
import com.mobileapptracker.MATGender;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

public class TuneAdMetadata
{
  private Date mBirthDate = null;
  private Map<String, String> mCustomTargets = null;
  private boolean mDebugMode = false;
  private MATGender mGender = MATGender.UNKNOWN;
  private Set<String> mKeywords = null;
  private double mLatitude;
  private Location mLocation = null;
  private double mLongitude;
  
  public TuneAdMetadata() {}
  
  public boolean addKeyword(String paramString)
  {
    if (mKeywords == null) {
      mKeywords = new HashSet();
    }
    return mKeywords.add(paramString);
  }
  
  public Date getBirthDate()
  {
    return mBirthDate;
  }
  
  public Map getCustomTargets()
  {
    return mCustomTargets;
  }
  
  public MATGender getGender()
  {
    return mGender;
  }
  
  public Set getKeywords()
  {
    return mKeywords;
  }
  
  public double getLatitude()
  {
    return mLatitude;
  }
  
  public Location getLocation()
  {
    return mLocation;
  }
  
  public double getLongitude()
  {
    return mLongitude;
  }
  
  public boolean isInDebugMode()
  {
    return mDebugMode;
  }
  
  public boolean removeKeyword(String paramString)
  {
    if (mKeywords == null)
    {
      mKeywords = new HashSet();
      return false;
    }
    return mKeywords.remove(paramString);
  }
  
  public TuneAdMetadata withBirthDate(int paramInt1, int paramInt2, int paramInt3)
  {
    GregorianCalendar localGregorianCalendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    localGregorianCalendar.clear();
    localGregorianCalendar.set(paramInt1, paramInt2 - 1, paramInt3);
    mBirthDate = localGregorianCalendar.getTime();
    return this;
  }
  
  public TuneAdMetadata withBirthDate(Date paramDate)
  {
    mBirthDate = paramDate;
    return this;
  }
  
  public TuneAdMetadata withCustomTargets(Map paramMap)
  {
    mCustomTargets = paramMap;
    return this;
  }
  
  public TuneAdMetadata withDebugMode(boolean paramBoolean)
  {
    mDebugMode = paramBoolean;
    return this;
  }
  
  public TuneAdMetadata withGender(MATGender paramMATGender)
  {
    mGender = paramMATGender;
    return this;
  }
  
  public TuneAdMetadata withKeywords(Set paramSet)
  {
    mKeywords = paramSet;
    return this;
  }
  
  public TuneAdMetadata withLocation(double paramDouble1, double paramDouble2)
  {
    mLatitude = paramDouble1;
    mLongitude = paramDouble2;
    return this;
  }
  
  public TuneAdMetadata withLocation(Location paramLocation)
  {
    mLocation = paramLocation;
    return this;
  }
}
