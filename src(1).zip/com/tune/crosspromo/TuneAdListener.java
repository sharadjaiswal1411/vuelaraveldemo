package com.tune.crosspromo;

public abstract interface TuneAdListener
{
  public abstract void onAdClick(TuneAd paramTuneAd);
  
  public abstract void onAdLoad(TuneAd paramTuneAd);
  
  public abstract void onAdLoadFailed(TuneAd paramTuneAd, String paramString);
  
  public abstract void onAdShown(TuneAd paramTuneAd);
}
