package com.tune.crosspromo;

public enum TuneBannerPosition
{
  BOTTOM_CENTER,  TOP_CENTER;
}
