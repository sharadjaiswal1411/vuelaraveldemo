package com.tune.crosspromo;

class TuneAdViewSet
{
  public String placement;
  public boolean showView1;
  public TuneAdView view1;
  public TuneAdView view2;
  
  public TuneAdViewSet(String paramString, TuneAdView paramTuneAdView1, TuneAdView paramTuneAdView2)
  {
    placement = paramString;
    view1 = paramTuneAdView1;
    view2 = paramTuneAdView2;
    showView1 = true;
  }
  
  protected void changeView()
  {
    if (showView1) {}
    for (boolean bool = false;; bool = true)
    {
      showView1 = bool;
      return;
    }
  }
  
  protected void destroy()
  {
    view1.destroy();
    view2.destroy();
  }
  
  protected TuneAdView getCurrentView()
  {
    if (showView1) {
      return view1;
    }
    return view2;
  }
  
  protected TuneAdView getPreviousView()
  {
    if (showView1) {
      return view2;
    }
    return view1;
  }
}
