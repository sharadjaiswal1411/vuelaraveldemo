package com.tune.crosspromo;

import android.location.Location;
import com.mobileapptracker.MATGender;
import com.mobileapptracker.MATParameters;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TuneAdParams
{
  public int adHeightLandscape;
  public int adHeightPortrait;
  public int adWidthLandscape;
  public int adWidthPortrait;
  private String advertiserId;
  private String altitude;
  private String androidId;
  private String appName;
  private String appVersion;
  private Date birthDate;
  private String connectionType;
  private String countryCode;
  private String currentOrientation;
  private JSONObject customTargets;
  public boolean debugMode;
  private String deviceBrand;
  private String deviceCarrier;
  private String deviceCpuType;
  private String deviceModel;
  private String facebookUserId;
  private MATGender gender;
  private String googleAdId;
  private boolean googleIsLATEnabled;
  private String googleUserId;
  private String installDate;
  private String installReferrer;
  private String installer;
  private String keyCheck;
  private Set<String> keywords;
  private String language;
  private String lastOpenLogId;
  private String latitude;
  private Location location;
  private String longitude;
  private TuneAdOrientation mOrientation;
  private String mPlacement;
  private String matId;
  private String mcc;
  private String mnc;
  private String osVersion;
  private String packageName;
  private boolean payingUser;
  private String pluginName;
  private String referralSource;
  private String referralUrl;
  private JSONObject refs;
  private float screenDensity;
  private int screenHeight;
  private int screenWidth;
  private String sdkVersion;
  private String timeZone;
  private String twitterUserId;
  private String userAgent;
  private String userEmailMd5;
  private String userEmailSha1;
  private String userEmailSha256;
  private String userId;
  private String userNameMd5;
  private String userNameSha1;
  private String userNameSha256;
  private String userPhoneMd5;
  private String userPhoneSha1;
  private String userPhoneSha256;
  
  public TuneAdParams(String paramString, MATParameters paramMATParameters, TuneAdMetadata paramTuneAdMetadata, TuneAdOrientation paramTuneAdOrientation, int paramInt)
  {
    mPlacement = paramString;
    mOrientation = paramTuneAdOrientation;
    boolean bool;
    if (paramInt == 2)
    {
      currentOrientation = "landscape";
      advertiserId = paramMATParameters.getAdvertiserId();
      androidId = paramMATParameters.getAndroidId();
      appName = paramMATParameters.getAppName();
      appVersion = paramMATParameters.getAppVersion();
      connectionType = paramMATParameters.getConnectionType();
      countryCode = paramMATParameters.getCountryCode();
      debugMode = paramMATParameters.getDebugMode();
      deviceBrand = paramMATParameters.getDeviceBrand();
      deviceCarrier = paramMATParameters.getDeviceCarrier();
      deviceCpuType = paramMATParameters.getDeviceCpuType();
      deviceModel = paramMATParameters.getDeviceModel();
      googleAdId = paramMATParameters.getGoogleAdvertisingId();
      if ((paramMATParameters.getGoogleAdTrackingLimited() == null) || (!paramMATParameters.getGoogleAdTrackingLimited().equals("1"))) {
        break label723;
      }
      bool = true;
      label145:
      googleIsLATEnabled = bool;
      installDate = paramMATParameters.getInstallDate();
      installReferrer = paramMATParameters.getInstallReferrer();
      installer = paramMATParameters.getInstaller();
      paramString = paramMATParameters.getConversionKey();
      keyCheck = paramString.substring(Math.max(0, paramString.length() - 4));
      language = paramMATParameters.getLanguage();
      lastOpenLogId = paramMATParameters.getLastOpenLogId();
      matId = paramMATParameters.getMatId();
      mcc = paramMATParameters.getMCC();
      mnc = paramMATParameters.getMNC();
      osVersion = paramMATParameters.getOsVersion();
      packageName = paramMATParameters.getPackageName();
      pluginName = paramMATParameters.getPluginName();
      referralSource = paramMATParameters.getReferralSource();
      referralUrl = paramMATParameters.getReferralUrl();
      screenDensity = Float.parseFloat(paramMATParameters.getScreenDensity());
      screenHeight = Integer.parseInt(paramMATParameters.getScreenHeight());
      screenWidth = Integer.parseInt(paramMATParameters.getScreenWidth());
      sdkVersion = paramMATParameters.getSdkVersion();
      timeZone = paramMATParameters.getTimeZone();
      userAgent = paramMATParameters.getUserAgent();
      gender = MATGender.UNKNOWN;
      paramString = paramMATParameters.getGender();
      if (paramString != null)
      {
        if (!paramString.equals("0")) {
          break label729;
        }
        gender = MATGender.MALE;
      }
      label368:
      facebookUserId = paramMATParameters.getFacebookUserId();
      googleUserId = paramMATParameters.getGoogleUserId();
      twitterUserId = paramMATParameters.getTwitterUserId();
      if (!paramMATParameters.getIsPayingUser().equals("1")) {
        break label748;
      }
      payingUser = true;
      label409:
      userEmailMd5 = paramMATParameters.getUserEmailMd5();
      userEmailSha1 = paramMATParameters.getUserEmailSha1();
      userEmailSha256 = paramMATParameters.getUserEmailSha256();
      userId = paramMATParameters.getUserId();
      userNameMd5 = paramMATParameters.getUserNameMd5();
      userNameSha1 = paramMATParameters.getUserNameSha1();
      userNameSha256 = paramMATParameters.getUserNameSha256();
      userPhoneMd5 = paramMATParameters.getPhoneNumberMd5();
      userPhoneSha1 = paramMATParameters.getPhoneNumberSha1();
      userPhoneSha256 = paramMATParameters.getPhoneNumberSha256();
      if (paramInt != 2) {
        break label756;
      }
      adWidthLandscape = screenWidth;
      adHeightLandscape = screenHeight;
      adWidthPortrait = screenHeight;
      adHeightPortrait = screenWidth;
    }
    for (;;)
    {
      if (paramTuneAdMetadata == null) {
        return;
      }
      birthDate = paramTuneAdMetadata.getBirthDate();
      gender = paramTuneAdMetadata.getGender();
      keywords = paramTuneAdMetadata.getKeywords();
      location = paramTuneAdMetadata.getLocation();
      if (location != null)
      {
        altitude = String.valueOf(location.getAltitude());
        latitude = String.valueOf(location.getLatitude());
        longitude = String.valueOf(location.getLongitude());
      }
      if ((paramTuneAdMetadata.getLatitude() != 0.0D) && (paramTuneAdMetadata.getLongitude() != 0.0D))
      {
        latitude = String.valueOf(paramTuneAdMetadata.getLatitude());
        longitude = String.valueOf(paramTuneAdMetadata.getLongitude());
      }
      if (paramTuneAdMetadata.getCustomTargets() != null) {
        customTargets = new JSONObject(paramTuneAdMetadata.getCustomTargets());
      }
      if (paramTuneAdMetadata.isInDebugMode()) {
        debugMode = paramTuneAdMetadata.isInDebugMode();
      }
      paramMATParameters.setGender(gender);
      if (location == null) {
        return;
      }
      paramMATParameters.setLocation(location);
      return;
      currentOrientation = "portrait";
      break;
      label723:
      bool = false;
      break label145;
      label729:
      if (!paramString.equals("1")) {
        break label368;
      }
      gender = MATGender.FEMALE;
      break label368;
      label748:
      payingUser = false;
      break label409;
      label756:
      adWidthPortrait = screenWidth;
      adHeightPortrait = screenHeight;
      adWidthLandscape = screenHeight;
      adHeightLandscape = screenWidth;
    }
  }
  
  public JSONObject getRefs()
  {
    return refs;
  }
  
  public void setRefs(JSONObject paramJSONObject)
  {
    refs = paramJSONObject;
  }
  
  public JSONObject toJSON()
  {
    JSONObject localJSONObject1 = new JSONObject();
    for (;;)
    {
      int i;
      JSONObject localJSONObject2;
      Object localObject5;
      Object localObject7;
      try
      {
        Object localObject1 = new JSONObject();
        Object localObject2 = advertiserId;
        localObject1 = ((JSONObject)localObject1).put("advertiserId", localObject2);
        localObject2 = keyCheck;
        localObject1 = ((JSONObject)localObject1).put("keyCheck", localObject2);
        localObject2 = appName;
        localObject1 = ((JSONObject)localObject1).put("name", localObject2);
        localObject2 = appVersion;
        localObject1 = ((JSONObject)localObject1).put("version", localObject2);
        localObject2 = installDate;
        localObject1 = ((JSONObject)localObject1).put("installDate", localObject2);
        localObject2 = installReferrer;
        localObject1 = ((JSONObject)localObject1).put("installReferrer", localObject2);
        localObject2 = installer;
        localObject1 = ((JSONObject)localObject1).put("installer", localObject2);
        localObject2 = referralSource;
        localObject1 = ((JSONObject)localObject1).put("referralSource", localObject2);
        localObject2 = referralUrl;
        localObject1 = ((JSONObject)localObject1).put("referralUrl", localObject2);
        localObject2 = packageName;
        localObject1 = ((JSONObject)localObject1).put("package", localObject2);
        localObject2 = new JSONObject();
        Object localObject3 = altitude;
        localObject2 = ((JSONObject)localObject2).put("altitude", localObject3);
        localObject3 = connectionType;
        localObject2 = ((JSONObject)localObject2).put("connectionType", localObject3);
        localObject3 = countryCode;
        localObject2 = ((JSONObject)localObject2).put("country", localObject3);
        localObject3 = deviceBrand;
        localObject2 = ((JSONObject)localObject2).put("deviceBrand", localObject3);
        localObject3 = deviceCarrier;
        localObject2 = ((JSONObject)localObject2).put("deviceCarrier", localObject3);
        localObject3 = deviceCpuType;
        localObject2 = ((JSONObject)localObject2).put("deviceCpuType", localObject3);
        localObject3 = deviceModel;
        localObject2 = ((JSONObject)localObject2).put("deviceModel", localObject3);
        localObject3 = language;
        localObject2 = ((JSONObject)localObject2).put("language", localObject3);
        localObject3 = latitude;
        localObject2 = ((JSONObject)localObject2).put("latitude", localObject3);
        localObject3 = longitude;
        localObject2 = ((JSONObject)localObject2).put("longitude", localObject3);
        localObject3 = mcc;
        localObject2 = ((JSONObject)localObject2).put("mcc", localObject3);
        localObject3 = mnc;
        localObject2 = ((JSONObject)localObject2).put("mnc", localObject3).put("os", "Android");
        localObject3 = osVersion;
        localObject2 = ((JSONObject)localObject2).put("osVersion", localObject3);
        localObject3 = timeZone;
        localObject2 = ((JSONObject)localObject2).put("timezone", localObject3);
        localObject3 = userAgent;
        localObject2 = ((JSONObject)localObject2).put("userAgent", localObject3);
        localObject3 = new JSONObject();
        Object localObject4 = androidId;
        ((JSONObject)localObject3).put("androidId", localObject4);
        localObject4 = googleAdId;
        ((JSONObject)localObject3).put("gaid", localObject4);
        bool = googleIsLATEnabled;
        ((JSONObject)localObject3).put("googleAdTrackingDisabled", bool);
        localObject4 = matId;
        ((JSONObject)localObject3).put("matId", localObject4);
        localObject4 = new JSONObject();
        double d = screenDensity;
        localObject4 = ((JSONObject)localObject4).put("density", d);
        i = screenHeight;
        localObject4 = ((JSONObject)localObject4).put("height", i);
        i = screenWidth;
        localObject4 = ((JSONObject)localObject4).put("width", i);
        localJSONObject2 = new JSONObject();
        localObject5 = mOrientation;
        localObject6 = TuneAdOrientation.HORIZONTAL;
        bool = ((Enum)localObject5).equals(localObject6);
        if (bool)
        {
          localObject5 = new JSONObject();
          i = adWidthPortrait;
          localObject5 = ((JSONObject)localObject5).put("width", i);
          i = adHeightPortrait;
          localObject5 = ((JSONObject)localObject5).put("height", i);
          localObject6 = new JSONObject();
          i = adWidthLandscape;
          localObject6 = ((JSONObject)localObject6).put("width", i);
          i = adHeightLandscape;
          localObject6 = ((JSONObject)localObject6).put("height", i);
          localJSONObject2.put("portrait", localObject5).put("landscape", localObject6);
          localObject5 = new JSONObject();
          if (birthDate != null)
          {
            localObject6 = birthDate;
            long l = ((Date)localObject6).getTime();
            l /= 1000L;
            ((JSONObject)localObject5).put("birthDate", Long.toString(l));
          }
          localObject6 = facebookUserId;
          ((JSONObject)localObject5).put("facebookUserId", localObject6);
          localObject6 = gender;
          ((JSONObject)localObject5).put("gender", localObject6);
          localObject6 = googleUserId;
          ((JSONObject)localObject5).put("googleUserId", localObject6);
          if (keywords != null)
          {
            localObject6 = new JSONArray();
            localObject7 = keywords;
            localObject7 = ((Set)localObject7).iterator();
            bool = ((Iterator)localObject7).hasNext();
            if (bool) {
              break label1506;
            }
            ((JSONObject)localObject5).put("keywords", localObject6);
          }
          bool = payingUser;
          ((JSONObject)localObject5).put("payingUser", bool);
          localObject6 = twitterUserId;
          ((JSONObject)localObject5).put("twitterUserId", localObject6);
          localObject6 = userEmailMd5;
          ((JSONObject)localObject5).put("userEmailMd5", localObject6);
          localObject6 = userEmailSha1;
          ((JSONObject)localObject5).put("userEmailSha1", localObject6);
          localObject6 = userEmailSha256;
          ((JSONObject)localObject5).put("userEmailSha256", localObject6);
          if (userId != null)
          {
            localObject6 = userId;
            i = ((String)localObject6).length();
            if (i != 0)
            {
              localObject6 = userId;
              ((JSONObject)localObject5).put("userId", localObject6);
            }
          }
          localObject6 = userNameMd5;
          ((JSONObject)localObject5).put("userNameMd5", localObject6);
          localObject6 = userNameSha1;
          ((JSONObject)localObject5).put("userNameSha1", localObject6);
          localObject6 = userNameSha256;
          ((JSONObject)localObject5).put("userNameSha256", localObject6);
          localObject6 = userPhoneMd5;
          ((JSONObject)localObject5).put("userPhoneMd5", localObject6);
          localObject6 = userPhoneSha1;
          ((JSONObject)localObject5).put("userPhoneSha1", localObject6);
          localObject6 = userPhoneSha256;
          ((JSONObject)localObject5).put("userPhoneSha256", localObject6);
          localObject6 = currentOrientation;
          localJSONObject1.put("currentOrientation", localObject6);
          bool = debugMode;
          localJSONObject1.put("debugMode", bool);
          localObject6 = sdkVersion;
          localJSONObject1.put("sdkVersion", localObject6);
          localObject6 = pluginName;
          localJSONObject1.put("plugin", localObject6);
          localObject6 = lastOpenLogId;
          localJSONObject1.put("lastOpenLogId", localObject6);
          localJSONObject1.put("app", localObject1);
          localJSONObject1.put("device", localObject2);
          localJSONObject1.put("ids", localObject3);
          localJSONObject1.put("screen", localObject4);
          localJSONObject1.put("sizes", localJSONObject2);
          localJSONObject1.put("user", localObject5);
          localObject1 = customTargets;
          localJSONObject1.put("targets", localObject1);
          localObject1 = refs;
          localJSONObject1.put("refs", localObject1);
          localObject1 = mPlacement;
          localJSONObject1.put("placement", localObject1);
          return localJSONObject1;
        }
        localObject5 = mOrientation;
        localObject6 = TuneAdOrientation.PORTRAIT_ONLY;
        bool = ((Enum)localObject5).equals(localObject6);
        if (bool)
        {
          localObject5 = new JSONObject();
          i = adWidthPortrait;
          localObject5 = ((JSONObject)localObject5).put("width", i);
          i = adHeightPortrait;
          localJSONObject2.put("portrait", ((JSONObject)localObject5).put("height", i));
          continue;
        }
        localObject5 = mOrientation;
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
        return localJSONObject1;
      }
      Object localObject6 = TuneAdOrientation.LANDSCAPE_ONLY;
      boolean bool = ((Enum)localObject5).equals(localObject6);
      if (bool)
      {
        localObject5 = new JSONObject();
        i = adWidthLandscape;
        localObject5 = ((JSONObject)localObject5).put("width", i);
        i = adHeightLandscape;
        localJSONObject2.put("landscape", ((JSONObject)localObject5).put("height", i));
        continue;
        label1506:
        Object localObject8 = ((Iterator)localObject7).next();
        localObject8 = (String)localObject8;
        ((JSONArray)localObject6).put(localObject8);
      }
    }
  }
}
