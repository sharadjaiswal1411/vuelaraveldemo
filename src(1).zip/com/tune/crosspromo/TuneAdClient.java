package com.tune.crosspromo;

import android.net.Uri;
import android.net.Uri.Builder;
import com.mobileapptracker.MobileAppTracker;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.ExecutorService;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.json.JSONObject;

public class TuneAdClient
{
  private static final String API_URL_PROD = "api.cp.tune.com/api/v1/ads";
  private static final String API_URL_STAGE = "api.cp.stage.tune.com/api/v1/ads";
  private static final int TIMEOUT = 60000;
  private static String advertiserId;
  private static String apiUrl;
  private static boolean customMode;
  private static TuneAdUtils utils;
  
  public TuneAdClient() {}
  
  private static void checkStatusCode(int paramInt, String paramString)
    throws TuneBadRequestException, TuneServerErrorException
  {
    if ((paramInt >= 400) && (paramInt < 500)) {
      throw new TuneBadRequestException(paramString);
    }
    if (paramInt >= 500) {
      throw new TuneServerErrorException(paramString);
    }
  }
  
  private static void disableSSLCertificateChecking()
  {
    Object localObject = new X509TrustManager()
    {
      public void checkClientTrusted(X509Certificate[] paramAnonymousArrayOfX509Certificate, String paramAnonymousString)
        throws CertificateException
      {}
      
      public void checkServerTrusted(X509Certificate[] paramAnonymousArrayOfX509Certificate, String paramAnonymousString)
        throws CertificateException
      {}
      
      public X509Certificate[] getAcceptedIssuers()
      {
        return null;
      }
    };
    try
    {
      HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier()
      {
        public boolean verify(String paramAnonymousString, SSLSession paramAnonymousSSLSession)
        {
          return true;
        }
      });
      SSLContext localSSLContext = SSLContext.getInstance("TLS");
      SecureRandom localSecureRandom = new SecureRandom();
      localObject = (TrustManager[])new TrustManager[] { localObject };
      localSSLContext.init(null, (TrustManager[])localObject, localSecureRandom);
      HttpsURLConnection.setDefaultSSLSocketFactory(localSSLContext.getSocketFactory());
      return;
    }
    catch (KeyManagementException localKeyManagementException)
    {
      localKeyManagementException.printStackTrace();
      return;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      localNoSuchAlgorithmException.printStackTrace();
    }
  }
  
  public static void init(String paramString)
  {
    apiUrl = "api.cp.tune.com/api/v1/ads";
    utils = TuneAdUtils.getInstance();
    advertiserId = paramString;
  }
  
  public static void logClick(TuneAdView paramTuneAdView, final JSONObject paramJSONObject)
  {
    if (MobileAppTracker.isOnline(utils.getContext())) {
      utils.getLogThread().execute(new Runnable()
      {
        public void run()
        {
          if (TuneAdClient.customMode) {}
          for (Uri.Builder localBuilder = Uri.parse("http://" + TuneAdClient.apiUrl + "/api/v1/ads/click").buildUpon();; localBuilder = Uri.parse("https://" + TuneAdClient.advertiserId + ".click." + TuneAdClient.apiUrl + "/click").buildUpon())
          {
            localBuilder.appendQueryParameter("requestId", requestId);
            TuneAdClient.logEvent(localBuilder.build().toString(), paramJSONObject);
            return;
          }
        }
      });
    }
  }
  
  public static void logClose(TuneAdView paramTuneAdView, final JSONObject paramJSONObject)
  {
    if (MobileAppTracker.isOnline(utils.getContext())) {
      utils.getLogThread().execute(new Runnable()
      {
        public void run()
        {
          if (TuneAdClient.customMode) {}
          for (Uri.Builder localBuilder = Uri.parse("http://" + TuneAdClient.apiUrl + "/api/v1/ads/close").buildUpon();; localBuilder = Uri.parse("https://" + TuneAdClient.advertiserId + ".event." + TuneAdClient.apiUrl + "/close").buildUpon())
          {
            localBuilder.appendQueryParameter("requestId", requestId);
            TuneAdClient.logEvent(localBuilder.build().toString(), paramJSONObject);
            return;
          }
        }
      });
    }
  }
  
  private static void logEvent(String paramString, JSONObject paramJSONObject)
  {
    try
    {
      paramString = new URL(paramString).openConnection();
      paramString = (HttpURLConnection)paramString;
      paramString.setReadTimeout(60000);
      paramString.setConnectTimeout(60000);
      paramString.setDoOutput(true);
      paramString.setRequestProperty("Content-Type", "application/json");
      paramString.setRequestProperty("Accept", "application/json");
      paramString.setRequestMethod("POST");
      OutputStream localOutputStream = paramString.getOutputStream();
      localOutputStream.write(paramJSONObject.toString().getBytes("UTF-8"));
      localOutputStream.close();
      paramString.connect();
      return;
    }
    catch (IOException paramString)
    {
      paramString.printStackTrace();
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public static void logView(TuneAdView paramTuneAdView, final JSONObject paramJSONObject)
  {
    if (MobileAppTracker.isOnline(utils.getContext())) {
      utils.getLogThread().execute(new Runnable()
      {
        public void run()
        {
          if (TuneAdClient.customMode) {}
          for (Uri.Builder localBuilder = Uri.parse("http://" + TuneAdClient.apiUrl + "/api/v1/ads/view").buildUpon();; localBuilder = Uri.parse("https://" + TuneAdClient.advertiserId + ".event." + TuneAdClient.apiUrl + "/view").buildUpon())
          {
            localBuilder.appendQueryParameter("requestId", requestId);
            TuneAdClient.logEvent(localBuilder.build().toString(), paramJSONObject);
            return;
          }
        }
      });
    }
  }
  
  /* Error */
  public static String requestAd(String paramString, JSONObject paramJSONObject)
    throws TuneBadRequestException, TuneServerErrorException, ConnectException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 7
    //   3: aconst_null
    //   4: astore 8
    //   6: aconst_null
    //   7: astore 6
    //   9: aload 6
    //   11: astore 4
    //   13: aload 7
    //   15: astore_3
    //   16: aload 8
    //   18: astore 5
    //   20: new 145	java/net/URL
    //   23: dup
    //   24: aload_0
    //   25: invokespecial 146	java/net/URL:<init>	(Ljava/lang/String;)V
    //   28: invokevirtual 150	java/net/URL:openConnection	()Ljava/net/URLConnection;
    //   31: astore_0
    //   32: aload_0
    //   33: checkcast 152	java/net/HttpURLConnection
    //   36: astore 9
    //   38: aload 6
    //   40: astore 4
    //   42: aload 7
    //   44: astore_3
    //   45: aload 8
    //   47: astore 5
    //   49: aload 9
    //   51: ldc 24
    //   53: invokevirtual 156	java/net/HttpURLConnection:setReadTimeout	(I)V
    //   56: aload 6
    //   58: astore 4
    //   60: aload 7
    //   62: astore_3
    //   63: aload 8
    //   65: astore 5
    //   67: aload 9
    //   69: ldc 24
    //   71: invokevirtual 159	java/net/HttpURLConnection:setConnectTimeout	(I)V
    //   74: aload 6
    //   76: astore 4
    //   78: aload 7
    //   80: astore_3
    //   81: aload 8
    //   83: astore 5
    //   85: aload 9
    //   87: iconst_1
    //   88: invokevirtual 217	java/net/HttpURLConnection:setDoInput	(Z)V
    //   91: aload 6
    //   93: astore 4
    //   95: aload 7
    //   97: astore_3
    //   98: aload 8
    //   100: astore 5
    //   102: aload 9
    //   104: iconst_1
    //   105: invokevirtual 163	java/net/HttpURLConnection:setDoOutput	(Z)V
    //   108: aload 6
    //   110: astore 4
    //   112: aload 7
    //   114: astore_3
    //   115: aload 8
    //   117: astore 5
    //   119: aload 9
    //   121: ldc -91
    //   123: ldc -89
    //   125: invokevirtual 171	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   128: aload 6
    //   130: astore 4
    //   132: aload 7
    //   134: astore_3
    //   135: aload 8
    //   137: astore 5
    //   139: aload 9
    //   141: ldc -83
    //   143: ldc -89
    //   145: invokevirtual 171	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   148: aload 6
    //   150: astore 4
    //   152: aload 7
    //   154: astore_3
    //   155: aload 8
    //   157: astore 5
    //   159: aload 9
    //   161: ldc -81
    //   163: invokevirtual 178	java/net/HttpURLConnection:setRequestMethod	(Ljava/lang/String;)V
    //   166: aload 6
    //   168: astore 4
    //   170: aload 7
    //   172: astore_3
    //   173: aload 8
    //   175: astore 5
    //   177: aload 9
    //   179: invokevirtual 182	java/net/HttpURLConnection:getOutputStream	()Ljava/io/OutputStream;
    //   182: astore_0
    //   183: aload 6
    //   185: astore 4
    //   187: aload 7
    //   189: astore_3
    //   190: aload 8
    //   192: astore 5
    //   194: aload_0
    //   195: aload_1
    //   196: invokevirtual 187	org/json/JSONObject:toString	()Ljava/lang/String;
    //   199: ldc -67
    //   201: invokevirtual 195	java/lang/String:getBytes	(Ljava/lang/String;)[B
    //   204: invokevirtual 201	java/io/OutputStream:write	([B)V
    //   207: aload 6
    //   209: astore 4
    //   211: aload 7
    //   213: astore_3
    //   214: aload 8
    //   216: astore 5
    //   218: aload_0
    //   219: invokevirtual 204	java/io/OutputStream:close	()V
    //   222: aload 6
    //   224: astore 4
    //   226: aload 7
    //   228: astore_3
    //   229: aload 8
    //   231: astore 5
    //   233: aload 9
    //   235: invokevirtual 207	java/net/HttpURLConnection:connect	()V
    //   238: aload 6
    //   240: astore 4
    //   242: aload 7
    //   244: astore_3
    //   245: aload 8
    //   247: astore 5
    //   249: aload 9
    //   251: invokevirtual 221	java/net/HttpURLConnection:getResponseCode	()I
    //   254: istore_2
    //   255: iload_2
    //   256: sipush 200
    //   259: if_icmpne +56 -> 315
    //   262: aload 6
    //   264: astore 4
    //   266: aload 7
    //   268: astore_3
    //   269: aload 8
    //   271: astore 5
    //   273: aload 9
    //   275: invokevirtual 225	java/net/HttpURLConnection:getInputStream	()Ljava/io/InputStream;
    //   278: astore_0
    //   279: aload_0
    //   280: astore 5
    //   282: aload 5
    //   284: astore 4
    //   286: aload 5
    //   288: astore_3
    //   289: aload 9
    //   291: invokevirtual 225	java/net/HttpURLConnection:getInputStream	()Ljava/io/InputStream;
    //   294: invokestatic 231	com/mobileapptracker/MATUtils:readStream	(Ljava/io/InputStream;)Ljava/lang/String;
    //   297: astore_1
    //   298: aload_0
    //   299: ifnull +142 -> 441
    //   302: aload_0
    //   303: invokevirtual 234	java/io/InputStream:close	()V
    //   306: aload_1
    //   307: areturn
    //   308: astore_0
    //   309: aload_0
    //   310: invokevirtual 208	java/io/IOException:printStackTrace	()V
    //   313: aload_1
    //   314: areturn
    //   315: aload 6
    //   317: astore 4
    //   319: aload 7
    //   321: astore_3
    //   322: aload 8
    //   324: astore 5
    //   326: aload 9
    //   328: invokevirtual 237	java/net/HttpURLConnection:getErrorStream	()Ljava/io/InputStream;
    //   331: astore_0
    //   332: aload_0
    //   333: astore 5
    //   335: aload 5
    //   337: astore 4
    //   339: aload 5
    //   341: astore_3
    //   342: iload_2
    //   343: aload_0
    //   344: invokestatic 231	com/mobileapptracker/MATUtils:readStream	(Ljava/io/InputStream;)Ljava/lang/String;
    //   347: invokestatic 239	com/tune/crosspromo/TuneAdClient:checkStatusCode	(ILjava/lang/String;)V
    //   350: aload_0
    //   351: ifnull +7 -> 358
    //   354: aload_0
    //   355: invokevirtual 234	java/io/InputStream:close	()V
    //   358: aconst_null
    //   359: areturn
    //   360: astore_0
    //   361: aload 4
    //   363: astore_3
    //   364: aload_0
    //   365: checkcast 214	java/net/ConnectException
    //   368: invokevirtual 240	java/net/ConnectException:printStackTrace	()V
    //   371: aload 4
    //   373: astore_3
    //   374: new 214	java/net/ConnectException
    //   377: dup
    //   378: invokespecial 241	java/net/ConnectException:<init>	()V
    //   381: athrow
    //   382: astore_0
    //   383: aload_3
    //   384: ifnull +7 -> 391
    //   387: aload_3
    //   388: invokevirtual 234	java/io/InputStream:close	()V
    //   391: aload_0
    //   392: athrow
    //   393: astore_0
    //   394: aload 5
    //   396: astore_3
    //   397: aload_0
    //   398: checkcast 141	java/io/IOException
    //   401: invokevirtual 208	java/io/IOException:printStackTrace	()V
    //   404: aload 5
    //   406: ifnull -48 -> 358
    //   409: aload 5
    //   411: invokevirtual 234	java/io/InputStream:close	()V
    //   414: goto -56 -> 358
    //   417: astore_0
    //   418: aload_0
    //   419: invokevirtual 208	java/io/IOException:printStackTrace	()V
    //   422: goto -64 -> 358
    //   425: astore_1
    //   426: aload_1
    //   427: invokevirtual 208	java/io/IOException:printStackTrace	()V
    //   430: goto -39 -> 391
    //   433: astore_0
    //   434: aload_0
    //   435: invokevirtual 208	java/io/IOException:printStackTrace	()V
    //   438: goto -80 -> 358
    //   441: aload_1
    //   442: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	443	0	paramString	String
    //   0	443	1	paramJSONObject	JSONObject
    //   254	89	2	i	int
    //   15	382	3	localObject1	Object
    //   11	361	4	localObject2	Object
    //   18	392	5	localObject3	Object
    //   7	309	6	localObject4	Object
    //   1	319	7	localObject5	Object
    //   4	319	8	localObject6	Object
    //   36	291	9	localHttpURLConnection	HttpURLConnection
    // Exception table:
    //   from	to	target	type
    //   302	306	308	java/io/IOException
    //   20	32	360	java/net/ConnectException
    //   49	56	360	java/net/ConnectException
    //   67	74	360	java/net/ConnectException
    //   85	91	360	java/net/ConnectException
    //   102	108	360	java/net/ConnectException
    //   119	128	360	java/net/ConnectException
    //   139	148	360	java/net/ConnectException
    //   159	166	360	java/net/ConnectException
    //   177	183	360	java/net/ConnectException
    //   194	207	360	java/net/ConnectException
    //   218	222	360	java/net/ConnectException
    //   233	238	360	java/net/ConnectException
    //   249	255	360	java/net/ConnectException
    //   273	279	360	java/net/ConnectException
    //   289	298	360	java/net/ConnectException
    //   326	332	360	java/net/ConnectException
    //   342	350	360	java/net/ConnectException
    //   20	32	382	java/lang/Throwable
    //   49	56	382	java/lang/Throwable
    //   67	74	382	java/lang/Throwable
    //   85	91	382	java/lang/Throwable
    //   102	108	382	java/lang/Throwable
    //   119	128	382	java/lang/Throwable
    //   139	148	382	java/lang/Throwable
    //   159	166	382	java/lang/Throwable
    //   177	183	382	java/lang/Throwable
    //   194	207	382	java/lang/Throwable
    //   218	222	382	java/lang/Throwable
    //   233	238	382	java/lang/Throwable
    //   249	255	382	java/lang/Throwable
    //   273	279	382	java/lang/Throwable
    //   289	298	382	java/lang/Throwable
    //   326	332	382	java/lang/Throwable
    //   342	350	382	java/lang/Throwable
    //   364	371	382	java/lang/Throwable
    //   374	382	382	java/lang/Throwable
    //   397	404	382	java/lang/Throwable
    //   20	32	393	java/io/IOException
    //   49	56	393	java/io/IOException
    //   67	74	393	java/io/IOException
    //   85	91	393	java/io/IOException
    //   102	108	393	java/io/IOException
    //   119	128	393	java/io/IOException
    //   139	148	393	java/io/IOException
    //   159	166	393	java/io/IOException
    //   177	183	393	java/io/IOException
    //   194	207	393	java/io/IOException
    //   218	222	393	java/io/IOException
    //   233	238	393	java/io/IOException
    //   249	255	393	java/io/IOException
    //   273	279	393	java/io/IOException
    //   289	298	393	java/io/IOException
    //   326	332	393	java/io/IOException
    //   342	350	393	java/io/IOException
    //   409	414	417	java/io/IOException
    //   387	391	425	java/io/IOException
    //   354	358	433	java/io/IOException
  }
  
  public static String requestAdOfType(String paramString, TuneAdParams paramTuneAdParams)
    throws TuneBadRequestException, TuneServerErrorException, ConnectException
  {
    if (MobileAppTracker.isOnline(utils.getContext()))
    {
      if (customMode) {}
      for (Uri.Builder localBuilder = Uri.parse("http://" + apiUrl + "/api/v1/ads/request").buildUpon();; localBuilder = Uri.parse("https://" + advertiserId + ".request." + apiUrl + "/request").buildUpon())
      {
        localBuilder.appendQueryParameter("context[type]", paramString);
        return requestAd(localBuilder.build().toString(), paramTuneAdParams.toJSON());
      }
    }
    return null;
  }
  
  public static String requestBannerAd(TuneAdParams paramTuneAdParams)
    throws TuneBadRequestException, TuneServerErrorException, ConnectException
  {
    return requestAdOfType("banner", paramTuneAdParams);
  }
  
  public static String requestInterstitialAd(TuneAdParams paramTuneAdParams)
    throws TuneBadRequestException, TuneServerErrorException, ConnectException
  {
    return requestAdOfType("interstitial", paramTuneAdParams);
  }
  
  public static String requestNativeAd(TuneAdParams paramTuneAdParams)
    throws TuneBadRequestException, TuneServerErrorException, ConnectException
  {
    return requestAdOfType("native", paramTuneAdParams);
  }
  
  public static void setAddress(String paramString)
  {
    customMode = true;
    apiUrl = paramString;
  }
  
  public static void setStaging(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      apiUrl = "api.cp.stage.tune.com/api/v1/ads";
      disableSSLCertificateChecking();
      return;
    }
    apiUrl = "api.cp.tune.com/api/v1/ads";
  }
}
