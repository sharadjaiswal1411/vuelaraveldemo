package com.tune.crosspromo;

class TuneBadRequestException
  extends Exception
{
  private static final long serialVersionUID = -7430171594303814521L;
  
  public TuneBadRequestException(String paramString)
  {
    super(paramString);
  }
}
