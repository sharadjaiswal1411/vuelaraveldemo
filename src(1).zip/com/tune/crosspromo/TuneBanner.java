package com.tune.crosspromo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.ViewAnimator;
import android.widget.ViewSwitcher;
import com.mobileapptracker.MATParameters;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.URLEncoder;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;

public class TuneBanner
  extends FrameLayout
  implements TuneAd
{
  private static final int DEFAULT_REFRESH_DURATION_SEC = 60;
  private static final String PAGE_KEY = "TUNE";
  private ScheduledFuture<?> loadFuture;
  private TuneAdParams mAdParams;
  private TuneAdView mAdView;
  private Context mContext;
  private int mDuration;
  private Handler mHandler;
  private int mLastOrientation;
  private TuneAdListener mListener;
  private TuneAdMetadata mMetadata;
  private TuneAdOrientation mOrientation;
  private String mPlacement;
  private TuneBannerPosition mPosition;
  private ScheduledThreadPoolExecutor mScheduler;
  private ViewSwitcher mViewSwitcher;
  private WebView mWebView1;
  private WebView mWebView2;
  private TuneAdUtils utils;
  private WebViewClient webViewClient;
  
  public TuneBanner(Context paramContext)
  {
    super(paramContext);
    init(paramContext, null, null);
  }
  
  public TuneBanner(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    String str = paramAttributeSet.getAttributeValue(null, "advertiserId");
    paramAttributeSet = paramAttributeSet.getAttributeValue(null, "conversionKey");
    if ((str != null) && (paramAttributeSet != null))
    {
      init(paramContext, str, paramAttributeSet);
      return;
    }
    Log.e("TUNE", "TuneBanner XML requires advertiserId and conversionKey");
  }
  
  private void buildViewSwitcher()
  {
    mWebView1 = buildWebView(mContext);
    mWebView2 = buildWebView(mContext);
    mViewSwitcher = new ViewSwitcher(mContext);
    mViewSwitcher.setVisibility(8);
    FrameLayout.LayoutParams localLayoutParams = new FrameLayout.LayoutParams(-1, -1);
    mViewSwitcher.addView(mWebView1, localLayoutParams);
    mViewSwitcher.addView(mWebView2, localLayoutParams);
    localLayoutParams = new FrameLayout.LayoutParams(-1, -1);
    addView(mViewSwitcher, localLayoutParams);
  }
  
  private WebView buildWebView(Context paramContext)
  {
    paramContext = new WebView(paramContext);
    paramContext.setWebViewClient(webViewClient);
    paramContext.setBackgroundColor(0);
    paramContext.setScrollBarStyle(0);
    paramContext.setVerticalScrollBarEnabled(false);
    paramContext.setHorizontalScrollBarEnabled(false);
    WebSettings localWebSettings = paramContext.getSettings();
    localWebSettings.setJavaScriptEnabled(true);
    localWebSettings.setLoadWithOverviewMode(true);
    localWebSettings.setUseWideViewPort(true);
    return paramContext;
  }
  
  private void init(Context paramContext, String paramString1, String paramString2)
  {
    mContext = paramContext;
    mHandler = new Handler(paramContext.getMainLooper());
    mLastOrientation = getResourcesgetConfigurationorientation;
    mOrientation = TuneAdOrientation.HORIZONTAL;
    int i = ((Activity)paramContext).getRequestedOrientation();
    if (i == 1) {
      mOrientation = TuneAdOrientation.PORTRAIT_ONLY;
    }
    for (;;)
    {
      utils = TuneAdUtils.getInstance();
      utils.init(paramContext, paramString1, paramString2);
      mDuration = 60;
      mPosition = TuneBannerPosition.BOTTOM_CENTER;
      mScheduler = new ScheduledThreadPoolExecutor(1);
      webViewClient = new WebViewClient()
      {
        public void onPageFinished(WebView paramAnonymousWebView, String paramAnonymousString)
        {
          TuneBanner.this.notifyOnLoad();
          if (mViewSwitcher != null)
          {
            mViewSwitcher.setVisibility(0);
            if (mViewSwitcher.getCurrentView() == mWebView1) {
              mHandler.postDelayed(new Runnable()
              {
                public void run()
                {
                  if (mViewSwitcher != null) {
                    mViewSwitcher.showNext();
                  }
                }
              }, 50L);
            }
            for (;;)
            {
              TuneAdClient.logView(mAdView, mAdParams.toJSON());
              TuneBanner.this.positionAd();
              TuneBanner.this.notifyOnShow();
              return;
              mHandler.postDelayed(new Runnable()
              {
                public void run()
                {
                  if (mViewSwitcher != null) {
                    mViewSwitcher.showPrevious();
                  }
                }
              }, 50L);
            }
          }
        }
        
        public boolean shouldOverrideUrlLoading(WebView paramAnonymousWebView, String paramAnonymousString)
        {
          TuneBanner.this.processClick(paramAnonymousString);
          return true;
        }
      };
      buildViewSwitcher();
      bringToFront();
      return;
      if (i == 0) {
        mOrientation = TuneAdOrientation.LANDSCAPE_ONLY;
      }
    }
  }
  
  private void loadAd()
  {
    long l = System.currentTimeMillis();
    for (;;)
    {
      label30:
      int i;
      Object localObject1;
      if ((utils.getParams().getGoogleAdvertisingId() != null) || (utils.getParams().getAndroidId() != null))
      {
        mAdParams = new TuneAdParams(mPlacement, utils.getParams(), mMetadata, mOrientation, mLastOrientation);
        i = getResourcesgetConfigurationorientation;
        mAdParams.adWidthPortrait = TuneBannerSize.getScreenWidthPixelsPortrait(mContext, i);
        mAdParams.adHeightPortrait = TuneBannerSize.getBannerHeightPixelsPortrait(mContext, i);
        mAdParams.adWidthLandscape = TuneBannerSize.getScreenWidthPixelsLandscape(mContext, i);
        mAdParams.adHeightLandscape = TuneBannerSize.getBannerHeightPixelsLandscape(mContext, i);
        if (mAdParams.debugMode) {
          Log.d("TUNE", "Requesting banner with: " + mAdParams.toJSON().toString());
        }
        localObject1 = mAdParams;
      }
      try
      {
        localObject1 = TuneAdClient.requestBannerAd((TuneAdParams)localObject1);
        if (localObject1 != null)
        {
          boolean bool = ((String)localObject1).equals("");
          if (!bool) {
            try
            {
              localObject1 = new JSONObject((String)localObject1);
              bool = ((JSONObject)localObject1).has("error");
              if (bool)
              {
                bool = ((JSONObject)localObject1).has("message");
                if (bool)
                {
                  Log.d("TUNE", ((JSONObject)localObject1).optString("error") + ": " + ((JSONObject)localObject1).optString("message"));
                  if (mAdParams.debugMode) {
                    Log.d("TUNE", "Debug request url: " + ((JSONObject)localObject1).optString("requestUrl"));
                  }
                  notifyOnFailed(((JSONObject)localObject1).optString("message"));
                  return;
                  if (System.currentTimeMillis() - l > 500L) {
                    break label30;
                  }
                  try
                  {
                    Thread.sleep(50L);
                  }
                  catch (InterruptedException localInterruptedException)
                  {
                    localInterruptedException.printStackTrace();
                  }
                  continue;
                }
              }
              String str1 = localInterruptedException.optString("html");
              bool = str1.equals("");
              if (!bool)
              {
                i = Integer.parseInt(localInterruptedException.getString("duration"));
                if (i != mDuration)
                {
                  mDuration = i;
                  restartWithDuration(i);
                }
                Object localObject2 = mAdView;
                String str2 = localInterruptedException.optString("requestId");
                requestId = str2;
                localObject2 = mAdParams;
                ((TuneAdParams)localObject2).setRefs(localInterruptedException.optJSONObject("refs"));
                loadWebView(str1);
                return;
              }
            }
            catch (JSONException localJSONException)
            {
              localJSONException.printStackTrace();
              return;
            }
          }
        }
        notifyOnFailed("Network error");
      }
      catch (TuneBadRequestException localTuneBadRequestException)
      {
        notifyOnFailed("Bad request");
        return;
        notifyOnFailed("Unknown error");
        return;
      }
      catch (TuneServerErrorException localTuneServerErrorException)
      {
        notifyOnFailed("Server error");
        return;
        notifyOnFailed("Unknown error");
        return;
      }
      catch (ConnectException localConnectException)
      {
        notifyOnFailed("Request timed out");
        return;
      }
    }
  }
  
  private void loadWebView(final String paramString)
  {
    mHandler.post(new Runnable()
    {
      public void run()
      {
        if (mViewSwitcher != null)
        {
          if (mViewSwitcher.getCurrentView() == mWebView1) {}
          for (WebView localWebView = mWebView2;; localWebView = mWebView1)
          {
            String str = paramString;
            try
            {
              localWebView.loadData(URLEncoder.encode(str, "utf-8").replaceAll("\\+", " "), "text/html", "utf-8");
              return;
            }
            catch (UnsupportedEncodingException localUnsupportedEncodingException)
            {
              localUnsupportedEncodingException.printStackTrace();
            }
          }
        }
      }
    });
  }
  
  private void notifyOnClick()
  {
    mHandler.post(new Runnable()
    {
      public void run()
      {
        if (mListener != null) {
          mListener.onAdClick(TuneBanner.this);
        }
      }
    });
  }
  
  private void notifyOnFailed(final String paramString)
  {
    if (mAdParams.debugMode) {
      Log.d("TUNE", "Request failed with error: " + paramString);
    }
    mHandler.post(new Runnable()
    {
      public void run()
      {
        if (mListener != null) {
          mListener.onAdLoadFailed(TuneBanner.this, paramString);
        }
      }
    });
  }
  
  private void notifyOnLoad()
  {
    mHandler.post(new Runnable()
    {
      public void run()
      {
        if (mListener != null) {
          mListener.onAdLoad(TuneBanner.this);
        }
      }
    });
  }
  
  private void notifyOnShow()
  {
    mHandler.post(new Runnable()
    {
      public void run()
      {
        if (mListener != null) {
          mListener.onAdShown(TuneBanner.this);
        }
      }
    });
  }
  
  private void positionAd()
  {
    ViewGroup.LayoutParams localLayoutParams = getLayoutParams();
    Object localObject = localLayoutParams;
    if (localLayoutParams != null)
    {
      width = TuneBannerSize.getScreenWidthPixels(mContext);
      height = TuneBannerSize.getBannerHeightPixels(mContext, getResourcesgetConfigurationorientation);
    }
    if ((localLayoutParams instanceof FrameLayout.LayoutParams))
    {
      localObject = new FrameLayout.LayoutParams(width, height);
      switch ($SWITCH_TABLE$com$tune$crosspromo$TuneBannerPosition()[mPosition.ordinal()])
      {
      default: 
        gravity = 81;
      }
    }
    while (!(localLayoutParams instanceof RelativeLayout.LayoutParams)) {
      for (;;)
      {
        setLayoutParams((ViewGroup.LayoutParams)localObject);
        return;
        gravity = 49;
      }
    }
    localObject = new RelativeLayout.LayoutParams(width, height);
    switch ($SWITCH_TABLE$com$tune$crosspromo$TuneBannerPosition()[mPosition.ordinal()])
    {
    default: 
      ((RelativeLayout.LayoutParams)localObject).addRule(12);
      ((RelativeLayout.LayoutParams)localObject).addRule(14);
    }
    for (;;)
    {
      break;
      ((RelativeLayout.LayoutParams)localObject).addRule(10);
      ((RelativeLayout.LayoutParams)localObject).addRule(14);
    }
  }
  
  private void processClick(String paramString)
  {
    Intent localIntent = new Intent(getContext(), TuneAdActivity.class);
    localIntent.putExtra("INTERSTITIAL", false);
    localIntent.putExtra("REDIRECT_URI", paramString);
    ((Activity)getContext()).startActivity(localIntent);
    notifyOnClick();
    TuneAdClient.logClick(mAdView, mAdParams.toJSON());
  }
  
  private void restartWithDuration(int paramInt)
  {
    if (loadFuture != null) {
      loadFuture.cancel(false);
    }
    if (paramInt > 0) {
      loadFuture = mScheduler.scheduleAtFixedRate(new RefreshTask(null), paramInt, paramInt, TimeUnit.SECONDS);
    }
  }
  
  public void destroy()
  {
    pause();
    mScheduler.shutdown();
    setListener(null);
    if (mViewSwitcher != null)
    {
      mViewSwitcher.removeAllViews();
      removeView(mViewSwitcher);
    }
    mViewSwitcher = null;
    if (mWebView1 != null) {
      mWebView1.destroy();
    }
    if (mWebView2 != null) {
      mWebView2.destroy();
    }
    mWebView1 = null;
    mWebView2 = null;
    utils.destroyAdViews();
    utils = null;
    mOrientation = null;
    mMetadata = null;
  }
  
  public TuneAdView getCurrentAd()
  {
    return mAdView;
  }
  
  public TuneAdParams getParams()
  {
    return mAdParams;
  }
  
  public TuneBannerPosition getPosition()
  {
    return mPosition;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, paramInt2);
    paramInt2 = getResourcesgetConfigurationorientation;
    if (paramInt2 != mLastOrientation)
    {
      mLastOrientation = paramInt2;
      paramInt1 = TuneBannerSize.getScreenWidthPixels(mContext);
      paramInt2 = TuneBannerSize.getBannerHeightPixels(mContext, paramInt2);
      paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      paramInt2 = View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824);
      super.onMeasure(paramInt1, paramInt2);
      measureChildren(paramInt1, paramInt2);
    }
  }
  
  public void pause()
  {
    if (loadFuture != null) {
      loadFuture.cancel(true);
    }
  }
  
  public void resume()
  {
    if ((loadFuture != null) && (loadFuture.isCancelled()) && (mDuration > 0)) {
      loadFuture = mScheduler.scheduleAtFixedRate(new RefreshTask(null), 0L, mDuration, TimeUnit.SECONDS);
    }
  }
  
  public void setListener(TuneAdListener paramTuneAdListener)
  {
    mListener = paramTuneAdListener;
  }
  
  public void setPosition(TuneBannerPosition paramTuneBannerPosition)
  {
    mPosition = paramTuneBannerPosition;
  }
  
  public void show(String paramString)
  {
    if (mMetadata == null) {
      mMetadata = new TuneAdMetadata();
    }
    show(paramString, mMetadata);
  }
  
  public void show(String paramString, TuneAdMetadata paramTuneAdMetadata)
  {
    if ((paramString == null) || (paramString.isEmpty()) || (paramString.equals("null"))) {
      throw new IllegalArgumentException("Placement must not be null or empty");
    }
    if (mAdView == null) {
      mAdView = new TuneAdView(paramString, paramTuneAdMetadata, (WebView)mViewSwitcher.getCurrentView());
    }
    mPlacement = paramString;
    mMetadata = paramTuneAdMetadata;
    if (loadFuture != null) {
      loadFuture.cancel(true);
    }
    if (mDuration > 0) {
      loadFuture = mScheduler.scheduleAtFixedRate(new RefreshTask(null), 0L, mDuration, TimeUnit.SECONDS);
    }
  }
  
  private class RefreshTask
    implements Runnable
  {
    private RefreshTask() {}
    
    public void run()
    {
      TuneBanner.this.loadAd();
    }
  }
}
