package com.tune.crosspromo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout.LayoutParams;
import com.mobileapptracker.MATParameters;
import java.net.SocketException;
import java.util.concurrent.ExecutorService;
import org.json.JSONException;
import org.json.JSONObject;

public class TuneInterstitial
  implements TuneAd
{
  private static final String PAGE_KEY = "TUNE";
  private TuneAdParams mAdParams;
  private Context mContext;
  private Handler mHandler;
  private int mLastOrientation;
  private TuneAdListener mListener;
  private TuneAdOrientation mOrientation;
  private boolean mShowOnLoad;
  private boolean nativeCloseButton;
  private TuneAdUtils utils;
  
  public TuneInterstitial(Context paramContext)
  {
    this(paramContext, TuneAdOrientation.HORIZONTAL);
  }
  
  public TuneInterstitial(Context paramContext, TuneAdOrientation paramTuneAdOrientation)
  {
    mContext = paramContext;
    mHandler = new Handler(mContext.getMainLooper());
    utils = TuneAdUtils.getInstance();
    utils.init(paramContext, null, null);
    mOrientation = paramTuneAdOrientation;
    mLastOrientation = getWindowgetDecorViewgetResourcesgetConfigurationorientation;
    if (mOrientation == TuneAdOrientation.HORIZONTAL)
    {
      int i = ((Activity)paramContext).getRequestedOrientation();
      if (i == 1)
      {
        mOrientation = TuneAdOrientation.PORTRAIT_ONLY;
        return;
      }
      if (i == 0) {
        mOrientation = TuneAdOrientation.LANDSCAPE_ONLY;
      }
    }
  }
  
  private void displayInterstitial(TuneAdView paramTuneAdView)
  {
    Activity localActivity = (Activity)mContext;
    Intent localIntent = new Intent(mContext, TuneAdActivity.class);
    localIntent.putExtra("INTERSTITIAL", true);
    localIntent.putExtra("REQUESTID", requestId);
    localIntent.putExtra("ADPARAMS", mAdParams.toJSON().toString());
    localIntent.putExtra("NATIVECLOSEBUTTON", nativeCloseButton);
    localIntent.putExtra("PLACEMENT", placement);
    localIntent.putExtra("ORIENTATION", mOrientation.value());
    localActivity.startActivity(localIntent);
    localActivity.overridePendingTransition(17432576, 17432577);
    TuneAdClient.logView(paramTuneAdView, mAdParams.toJSON());
    utils.changeView(placement);
    notifyOnShow();
    cache(placement, metadata);
  }
  
  private TuneAdView getCurrentAd(String paramString)
  {
    return utils.getCurrentView(paramString);
  }
  
  private void initAdViewSet(String paramString, TuneAdMetadata paramTuneAdMetadata)
  {
    paramString = new TuneAdViewSet(paramString, new TuneAdView(paramString, paramTuneAdMetadata, initializeWebView(mContext, paramString)), new TuneAdView(paramString, paramTuneAdMetadata, initializeWebView(mContext, paramString)));
    utils.addViewSet(paramString);
  }
  
  private WebView initializeWebView(Context paramContext, final String paramString)
  {
    paramContext = new WebView(paramContext);
    Object localObject = new FrameLayout.LayoutParams(-1, -1);
    gravity = 17;
    paramContext.setLayoutParams((ViewGroup.LayoutParams)localObject);
    paramContext.setBackgroundColor(0);
    paramContext.setScrollBarStyle(0);
    localObject = paramContext.getSettings();
    ((WebSettings)localObject).setJavaScriptEnabled(true);
    ((WebSettings)localObject).setLoadWithOverviewMode(true);
    ((WebSettings)localObject).setUseWideViewPort(true);
    paramContext.setWebViewClient(new WebViewClient()
    {
      public void onPageFinished(WebView paramAnonymousWebView, String paramAnonymousString)
      {
        if (!paramAnonymousString.equals("about:blank")) {
          TuneInterstitial.this.notifyOnLoad(paramString);
        }
      }
      
      public boolean shouldOverrideUrlLoading(WebView paramAnonymousWebView, String paramAnonymousString)
      {
        ((ViewGroup)paramAnonymousWebView.getParent()).removeView(paramAnonymousWebView);
        TuneInterstitial.this.processClick(paramAnonymousString, paramString);
        ((Activity)utils.getAdContext()).finish();
        return true;
      }
    });
    return paramContext;
  }
  
  private void loadAd(String paramString, TuneAdMetadata paramTuneAdMetadata)
  {
    long l = System.currentTimeMillis();
    for (;;)
    {
      if ((utils.getParams().getGoogleAdvertisingId() != null) && (utils.getParams().getAndroidId() != null)) {}
      while (System.currentTimeMillis() - l > 500L)
      {
        mAdParams = new TuneAdParams(paramString, utils.getParams(), paramTuneAdMetadata, mOrientation, mLastOrientation);
        requestAd(paramString, 0);
        return;
      }
      try
      {
        Thread.sleep(50L);
      }
      catch (InterruptedException localInterruptedException)
      {
        localInterruptedException.printStackTrace();
      }
    }
  }
  
  private void loadWebView(final String paramString1, final String paramString2)
  {
    mHandler.post(new Runnable()
    {
      public void run()
      {
        TuneInterstitial.this.getCurrentAd(paramString1).loadView(paramString2);
      }
    });
  }
  
  private void notifyOnClick()
  {
    mHandler.post(new Runnable()
    {
      public void run()
      {
        if (mListener != null) {
          mListener.onAdClick(TuneInterstitial.this);
        }
      }
    });
  }
  
  private void notifyOnFailed(String paramString1, final String paramString2)
  {
    getCurrentAdloading = false;
    mShowOnLoad = false;
    if (mAdParams.debugMode) {
      Log.d("TUNE", "Request failed with error: " + paramString2);
    }
    mHandler.post(new Runnable()
    {
      public void run()
      {
        if (mListener != null) {
          mListener.onAdLoadFailed(TuneInterstitial.this, paramString2);
        }
      }
    });
  }
  
  private void notifyOnLoad(String paramString)
  {
    paramString = getCurrentAd(paramString);
    loaded = true;
    loading = false;
    if (mShowOnLoad)
    {
      mShowOnLoad = false;
      displayInterstitial(paramString);
    }
    mHandler.post(new Runnable()
    {
      public void run()
      {
        if (mListener != null) {
          mListener.onAdLoad(TuneInterstitial.this);
        }
      }
    });
  }
  
  private void notifyOnShow()
  {
    mHandler.post(new Runnable()
    {
      public void run()
      {
        if (mListener != null) {
          mListener.onAdShown(TuneInterstitial.this);
        }
      }
    });
  }
  
  private void processClick(String paramString1, String paramString2)
  {
    paramString2 = utils.getPreviousView(paramString2);
    if (paramString1.contains("#close"))
    {
      TuneAdClient.logClose(paramString2, mAdParams.toJSON());
      return;
    }
    Intent localIntent = new Intent(mContext, TuneAdActivity.class);
    localIntent.putExtra("INTERSTITIAL", false);
    localIntent.putExtra("REDIRECT_URI", paramString1);
    ((Activity)mContext).startActivity(localIntent);
    notifyOnClick();
    TuneAdClient.logClick(paramString2, mAdParams.toJSON());
  }
  
  private void requestAd(String paramString, int paramInt)
  {
    if (mAdParams.debugMode) {
      Log.d("TUNE", "Requesting interstitial with: " + mAdParams.toJSON().toString());
    }
    Object localObject1 = mAdParams;
    try
    {
      localObject1 = TuneAdClient.requestInterstitialAd((TuneAdParams)localObject1);
      if (localObject1 != null)
      {
        boolean bool = ((String)localObject1).equals("");
        if (!bool) {
          try
          {
            localObject1 = new JSONObject((String)localObject1);
            bool = ((JSONObject)localObject1).has("error");
            if (bool)
            {
              bool = ((JSONObject)localObject1).has("message");
              if (bool)
              {
                Log.d("TUNE", ((JSONObject)localObject1).optString("error") + ": " + ((JSONObject)localObject1).optString("message"));
                if (mAdParams.debugMode) {
                  Log.d("TUNE", "Debug request url: " + ((JSONObject)localObject1).optString("requestUrl"));
                }
                notifyOnFailed(paramString, ((JSONObject)localObject1).optString("message"));
                return;
              }
            }
            String str1 = ((JSONObject)localObject1).optString("html");
            bool = str1.equals("");
            if (!bool)
            {
              Object localObject2 = getCurrentAd(paramString);
              String str2 = ((JSONObject)localObject1).optString("requestId");
              requestId = str2;
              localObject2 = mAdParams;
              ((TuneAdParams)localObject2).setRefs(((JSONObject)localObject1).optJSONObject("refs"));
              bool = ((JSONObject)localObject1).has("close");
              if (bool)
              {
                bool = ((JSONObject)localObject1).optString("close").equals("native");
                nativeCloseButton = bool;
              }
              loadWebView(paramString, str1);
              return;
            }
          }
          catch (JSONException localJSONException)
          {
            localJSONException.printStackTrace();
            return;
          }
        }
      }
      return;
    }
    catch (TuneBadRequestException localTuneBadRequestException)
    {
      if (paramInt == 4)
      {
        notifyOnFailed(paramString, "Bad request");
        return;
        notifyOnFailed(paramString, "Unknown error");
        return;
      }
    }
    catch (TuneServerErrorException localTuneServerErrorException)
    {
      if (paramInt == 4)
      {
        notifyOnFailed(paramString, "Server error");
        return;
        notifyOnFailed(paramString, "Unknown error");
        return;
      }
    }
    catch (SocketException localSocketException)
    {
      if (paramInt == 4)
      {
        notifyOnFailed(paramString, "Request timed out");
        return;
        notifyOnFailed(paramString, "Network error");
        return;
        requestAd(paramString, paramInt + 1);
        return;
        requestAd(paramString, paramInt + 1);
        return;
      }
      requestAd(paramString, paramInt + 1);
    }
  }
  
  public void cache(String paramString)
  {
    cache(paramString, new TuneAdMetadata());
  }
  
  public void cache(final String paramString, final TuneAdMetadata paramTuneAdMetadata)
  {
    if ((paramString == null) || (paramString.isEmpty()) || (paramString.equals("null"))) {
      throw new IllegalArgumentException("Placement must not be null or empty");
    }
    if (!utils.hasViewSet(paramString)) {
      initAdViewSet(paramString, paramTuneAdMetadata);
    }
    TuneAdView localTuneAdView = getCurrentAd(paramString);
    metadata = paramTuneAdMetadata;
    loaded = false;
    loading = true;
    utils.getAdThread().execute(new Runnable()
    {
      public void run()
      {
        TuneInterstitial.this.loadAd(paramString, paramTuneAdMetadata);
      }
    });
  }
  
  public void destroy()
  {
    utils.destroyAdViews();
    utils = null;
    mListener = null;
    mContext = null;
    mOrientation = null;
    mHandler = null;
  }
  
  public TuneAdParams getParams()
  {
    return mAdParams;
  }
  
  public void setListener(TuneAdListener paramTuneAdListener)
  {
    mListener = paramTuneAdListener;
  }
  
  public void show(String paramString)
  {
    show(paramString, new TuneAdMetadata());
  }
  
  public void show(String paramString, TuneAdMetadata paramTuneAdMetadata)
  {
    if ((paramString == null) || (paramString.isEmpty()) || (paramString.equals("null"))) {
      throw new IllegalArgumentException("Placement must not be null or empty");
    }
    if (!utils.hasViewSet(paramString)) {
      initAdViewSet(paramString, paramTuneAdMetadata);
    }
    TuneAdView localTuneAdView = getCurrentAd(paramString);
    metadata = paramTuneAdMetadata;
    if (loaded)
    {
      displayInterstitial(localTuneAdView);
      return;
    }
    if (!loading)
    {
      cache(paramString, paramTuneAdMetadata);
      mShowOnLoad = true;
    }
  }
}
