package com.tune.crosspromo;

class TuneServerErrorException
  extends Exception
{
  private static final long serialVersionUID = -1190389199072822921L;
  
  public TuneServerErrorException(String paramString)
  {
    super(paramString);
  }
}
