package com.tune.crosspromo;

public abstract interface TuneAd
{
  public abstract void destroy();
  
  public abstract void setListener(TuneAdListener paramTuneAdListener);
  
  public abstract void show(String paramString);
  
  public abstract void show(String paramString, TuneAdMetadata paramTuneAdMetadata);
}
