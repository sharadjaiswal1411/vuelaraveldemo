package com.mobileapptracker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;
import java.net.URLDecoder;

public class Tracker
  extends BroadcastReceiver
{
  public Tracker() {}
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    if (paramIntent != null) {
      try
      {
        boolean bool = paramIntent.getAction().equals("com.android.vending.INSTALL_REFERRER");
        if (bool)
        {
          paramIntent = paramIntent.getStringExtra("referrer");
          if (paramIntent != null)
          {
            paramIntent = URLDecoder.decode(paramIntent, "UTF-8");
            Log.d("MobileAppTracker", "TUNE received referrer " + paramIntent);
            paramContext.getSharedPreferences("com.mobileapptracking", 0).edit().putString("mat_referrer", paramIntent).commit();
            paramContext = MobileAppTracker.getInstance();
            if (paramContext != null)
            {
              paramContext.setInstallReferrer(paramIntent);
              if ((gotGaid) && (!notifiedPool))
              {
                paramIntent = pool;
                try
                {
                  pool.notifyAll();
                  notifiedPool = true;
                  return;
                }
                catch (Throwable paramContext)
                {
                  throw paramContext;
                }
              }
            }
          }
        }
        return;
      }
      catch (Exception paramContext)
      {
        ((Exception)paramContext).printStackTrace();
      }
    }
  }
}
