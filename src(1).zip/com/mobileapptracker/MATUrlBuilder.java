package com.mobileapptracker;

import android.util.Log;
import java.util.Date;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class MATUrlBuilder
{
  private static MATParameters params;
  
  MATUrlBuilder() {}
  
  public static JSONObject buildBody(JSONArray paramJSONArray1, String paramString1, String paramString2, JSONArray paramJSONArray2)
  {
    try
    {
      JSONObject localJSONObject = new JSONObject();
      if (paramJSONArray1 != null) {}
      try
      {
        localJSONObject.put("data", paramJSONArray1);
        if (paramString1 != null) {
          localJSONObject.put("store_iap_data", paramString1);
        }
        if (paramString2 != null) {
          localJSONObject.put("store_iap_signature", paramString2);
        }
        if (paramJSONArray2 != null) {
          localJSONObject.put("user_emails", paramJSONArray2);
        }
      }
      catch (JSONException paramJSONArray1)
      {
        for (;;)
        {
          Log.d("MobileAppTracker", "Could not build JSON body of request");
          paramJSONArray1.printStackTrace();
        }
      }
      return localJSONObject;
    }
    catch (Throwable paramJSONArray1)
    {
      throw paramJSONArray1;
    }
  }
  
  /* Error */
  public static String buildDataUnencrypted(MATEvent paramMATEvent)
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: invokestatic 55	com/mobileapptracker/MATParameters:getInstance	()Lcom/mobileapptracker/MATParameters;
    //   6: putstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   9: new 59	java/lang/StringBuilder
    //   12: dup
    //   13: invokespecial 60	java/lang/StringBuilder:<init>	()V
    //   16: astore_1
    //   17: aload_1
    //   18: new 59	java/lang/StringBuilder
    //   21: dup
    //   22: ldc 62
    //   24: invokespecial 65	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   27: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   30: invokevirtual 69	com/mobileapptracker/MATParameters:getConnectionType	()Ljava/lang/String;
    //   33: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   36: invokevirtual 76	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   39: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   42: pop
    //   43: aload_1
    //   44: ldc 78
    //   46: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   49: invokevirtual 81	com/mobileapptracker/MATParameters:getAltitude	()Ljava/lang/String;
    //   52: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   55: aload_1
    //   56: ldc 87
    //   58: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   61: invokevirtual 90	com/mobileapptracker/MATParameters:getAndroidId	()Ljava/lang/String;
    //   64: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   67: aload_1
    //   68: ldc 92
    //   70: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   73: invokevirtual 95	com/mobileapptracker/MATParameters:getAndroidIdMd5	()Ljava/lang/String;
    //   76: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   79: aload_1
    //   80: ldc 97
    //   82: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   85: invokevirtual 100	com/mobileapptracker/MATParameters:getAndroidIdSha1	()Ljava/lang/String;
    //   88: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   91: aload_1
    //   92: ldc 102
    //   94: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   97: invokevirtual 105	com/mobileapptracker/MATParameters:getAndroidIdSha256	()Ljava/lang/String;
    //   100: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   103: aload_1
    //   104: ldc 107
    //   106: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   109: invokevirtual 110	com/mobileapptracker/MATParameters:getAppAdTrackingEnabled	()Ljava/lang/String;
    //   112: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   115: aload_1
    //   116: ldc 112
    //   118: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   121: invokevirtual 115	com/mobileapptracker/MATParameters:getAppName	()Ljava/lang/String;
    //   124: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   127: aload_1
    //   128: ldc 117
    //   130: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   133: invokevirtual 120	com/mobileapptracker/MATParameters:getAppVersion	()Ljava/lang/String;
    //   136: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   139: aload_1
    //   140: ldc 122
    //   142: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   145: invokevirtual 125	com/mobileapptracker/MATParameters:getAppVersionName	()Ljava/lang/String;
    //   148: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   151: aload_1
    //   152: ldc 127
    //   154: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   157: invokevirtual 130	com/mobileapptracker/MATParameters:getCountryCode	()Ljava/lang/String;
    //   160: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   163: aload_1
    //   164: ldc -124
    //   166: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   169: invokevirtual 135	com/mobileapptracker/MATParameters:getDeviceBrand	()Ljava/lang/String;
    //   172: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   175: aload_1
    //   176: ldc -119
    //   178: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   181: invokevirtual 140	com/mobileapptracker/MATParameters:getDeviceCarrier	()Ljava/lang/String;
    //   184: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   187: aload_1
    //   188: ldc -114
    //   190: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   193: invokevirtual 145	com/mobileapptracker/MATParameters:getDeviceCpuType	()Ljava/lang/String;
    //   196: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   199: aload_1
    //   200: ldc -109
    //   202: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   205: invokevirtual 150	com/mobileapptracker/MATParameters:getDeviceCpuSubtype	()Ljava/lang/String;
    //   208: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   211: aload_1
    //   212: ldc -104
    //   214: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   217: invokevirtual 155	com/mobileapptracker/MATParameters:getDeviceModel	()Ljava/lang/String;
    //   220: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   223: aload_1
    //   224: ldc -99
    //   226: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   229: invokevirtual 160	com/mobileapptracker/MATParameters:getDeviceId	()Ljava/lang/String;
    //   232: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   235: aload_1
    //   236: ldc -94
    //   238: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   241: invokevirtual 165	com/mobileapptracker/MATParameters:getGoogleAdvertisingId	()Ljava/lang/String;
    //   244: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   247: aload_1
    //   248: ldc -89
    //   250: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   253: invokevirtual 170	com/mobileapptracker/MATParameters:getGoogleAdTrackingLimited	()Ljava/lang/String;
    //   256: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   259: aload_1
    //   260: ldc -84
    //   262: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   265: invokevirtual 175	com/mobileapptracker/MATParameters:getInstallDate	()Ljava/lang/String;
    //   268: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   271: aload_1
    //   272: ldc -79
    //   274: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   277: invokevirtual 180	com/mobileapptracker/MATParameters:getInstaller	()Ljava/lang/String;
    //   280: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   283: aload_1
    //   284: ldc -74
    //   286: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   289: invokevirtual 185	com/mobileapptracker/MATParameters:getInstallReferrer	()Ljava/lang/String;
    //   292: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   295: aload_1
    //   296: ldc -69
    //   298: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   301: invokevirtual 190	com/mobileapptracker/MATParameters:getLanguage	()Ljava/lang/String;
    //   304: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   307: aload_1
    //   308: ldc -64
    //   310: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   313: invokevirtual 195	com/mobileapptracker/MATParameters:getLastOpenLogId	()Ljava/lang/String;
    //   316: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   319: aload_1
    //   320: ldc -59
    //   322: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   325: invokevirtual 200	com/mobileapptracker/MATParameters:getLatitude	()Ljava/lang/String;
    //   328: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   331: aload_1
    //   332: ldc -54
    //   334: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   337: invokevirtual 205	com/mobileapptracker/MATParameters:getLongitude	()Ljava/lang/String;
    //   340: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   343: aload_1
    //   344: ldc -49
    //   346: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   349: invokevirtual 210	com/mobileapptracker/MATParameters:getMacAddress	()Ljava/lang/String;
    //   352: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   355: aload_1
    //   356: ldc -44
    //   358: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   361: invokevirtual 215	com/mobileapptracker/MATParameters:getMatId	()Ljava/lang/String;
    //   364: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   367: aload_1
    //   368: ldc -39
    //   370: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   373: invokevirtual 220	com/mobileapptracker/MATParameters:getMCC	()Ljava/lang/String;
    //   376: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   379: aload_1
    //   380: ldc -34
    //   382: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   385: invokevirtual 225	com/mobileapptracker/MATParameters:getMNC	()Ljava/lang/String;
    //   388: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   391: aload_1
    //   392: ldc -29
    //   394: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   397: invokevirtual 230	com/mobileapptracker/MATParameters:getOpenLogId	()Ljava/lang/String;
    //   400: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   403: aload_1
    //   404: ldc -24
    //   406: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   409: invokevirtual 235	com/mobileapptracker/MATParameters:getOsVersion	()Ljava/lang/String;
    //   412: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   415: aload_1
    //   416: ldc -19
    //   418: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   421: invokevirtual 240	com/mobileapptracker/MATParameters:getPluginName	()Ljava/lang/String;
    //   424: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   427: aload_1
    //   428: ldc -14
    //   430: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   433: invokevirtual 245	com/mobileapptracker/MATParameters:getPurchaseStatus	()Ljava/lang/String;
    //   436: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   439: aload_1
    //   440: ldc -9
    //   442: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   445: invokevirtual 250	com/mobileapptracker/MATParameters:getReferrerDelay	()Ljava/lang/String;
    //   448: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   451: aload_1
    //   452: ldc -4
    //   454: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   457: invokevirtual 255	com/mobileapptracker/MATParameters:getScreenDensity	()Ljava/lang/String;
    //   460: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   463: aload_1
    //   464: ldc_w 257
    //   467: new 59	java/lang/StringBuilder
    //   470: dup
    //   471: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   474: invokevirtual 260	com/mobileapptracker/MATParameters:getScreenWidth	()Ljava/lang/String;
    //   477: invokestatic 266	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   480: invokespecial 65	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   483: ldc_w 268
    //   486: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   489: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   492: invokevirtual 271	com/mobileapptracker/MATParameters:getScreenHeight	()Ljava/lang/String;
    //   495: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   498: invokevirtual 76	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   501: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   504: aload_1
    //   505: ldc_w 273
    //   508: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   511: invokevirtual 276	com/mobileapptracker/MATParameters:getSdkVersion	()Ljava/lang/String;
    //   514: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   517: aload_1
    //   518: ldc_w 278
    //   521: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   524: invokevirtual 281	com/mobileapptracker/MATParameters:getTRUSTeId	()Ljava/lang/String;
    //   527: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   530: aload_1
    //   531: ldc_w 283
    //   534: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   537: invokevirtual 286	com/mobileapptracker/MATParameters:getUserAgent	()Ljava/lang/String;
    //   540: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   543: aload_1
    //   544: ldc_w 288
    //   547: aload_0
    //   548: invokevirtual 293	com/mobileapptracker/MATEvent:getAttribute1	()Ljava/lang/String;
    //   551: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   554: aload_1
    //   555: ldc_w 295
    //   558: aload_0
    //   559: invokevirtual 298	com/mobileapptracker/MATEvent:getAttribute2	()Ljava/lang/String;
    //   562: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   565: aload_1
    //   566: ldc_w 300
    //   569: aload_0
    //   570: invokevirtual 303	com/mobileapptracker/MATEvent:getAttribute3	()Ljava/lang/String;
    //   573: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   576: aload_1
    //   577: ldc_w 305
    //   580: aload_0
    //   581: invokevirtual 308	com/mobileapptracker/MATEvent:getAttribute4	()Ljava/lang/String;
    //   584: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   587: aload_1
    //   588: ldc_w 310
    //   591: aload_0
    //   592: invokevirtual 313	com/mobileapptracker/MATEvent:getAttribute5	()Ljava/lang/String;
    //   595: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   598: aload_1
    //   599: ldc_w 315
    //   602: aload_0
    //   603: invokevirtual 318	com/mobileapptracker/MATEvent:getContentId	()Ljava/lang/String;
    //   606: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   609: aload_1
    //   610: ldc_w 320
    //   613: aload_0
    //   614: invokevirtual 323	com/mobileapptracker/MATEvent:getContentType	()Ljava/lang/String;
    //   617: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   620: aload_0
    //   621: invokevirtual 326	com/mobileapptracker/MATEvent:getCurrencyCode	()Ljava/lang/String;
    //   624: ifnull +420 -> 1044
    //   627: aload_1
    //   628: ldc_w 328
    //   631: aload_0
    //   632: invokevirtual 326	com/mobileapptracker/MATEvent:getCurrencyCode	()Ljava/lang/String;
    //   635: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   638: aload_0
    //   639: invokevirtual 332	com/mobileapptracker/MATEvent:getDate1	()Ljava/util/Date;
    //   642: ifnull +24 -> 666
    //   645: aload_1
    //   646: ldc_w 334
    //   649: aload_0
    //   650: invokevirtual 332	com/mobileapptracker/MATEvent:getDate1	()Ljava/util/Date;
    //   653: invokevirtual 340	java/util/Date:getTime	()J
    //   656: ldc2_w 341
    //   659: ldiv
    //   660: invokestatic 347	java/lang/Long:toString	(J)Ljava/lang/String;
    //   663: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   666: aload_0
    //   667: invokevirtual 350	com/mobileapptracker/MATEvent:getDate2	()Ljava/util/Date;
    //   670: ifnull +24 -> 694
    //   673: aload_1
    //   674: ldc_w 352
    //   677: aload_0
    //   678: invokevirtual 350	com/mobileapptracker/MATEvent:getDate2	()Ljava/util/Date;
    //   681: invokevirtual 340	java/util/Date:getTime	()J
    //   684: ldc2_w 341
    //   687: ldiv
    //   688: invokestatic 347	java/lang/Long:toString	(J)Ljava/lang/String;
    //   691: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   694: aload_0
    //   695: invokevirtual 356	com/mobileapptracker/MATEvent:getLevel	()I
    //   698: ifeq +17 -> 715
    //   701: aload_1
    //   702: ldc_w 358
    //   705: aload_0
    //   706: invokevirtual 356	com/mobileapptracker/MATEvent:getLevel	()I
    //   709: invokestatic 363	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   712: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   715: aload_0
    //   716: invokevirtual 366	com/mobileapptracker/MATEvent:getQuantity	()I
    //   719: ifeq +17 -> 736
    //   722: aload_1
    //   723: ldc_w 368
    //   726: aload_0
    //   727: invokevirtual 366	com/mobileapptracker/MATEvent:getQuantity	()I
    //   730: invokestatic 363	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   733: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   736: aload_0
    //   737: invokevirtual 372	com/mobileapptracker/MATEvent:getRating	()D
    //   740: dconst_0
    //   741: dcmpl
    //   742: ifeq +17 -> 759
    //   745: aload_1
    //   746: ldc_w 374
    //   749: aload_0
    //   750: invokevirtual 372	com/mobileapptracker/MATEvent:getRating	()D
    //   753: invokestatic 379	java/lang/Double:toString	(D)Ljava/lang/String;
    //   756: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   759: aload_1
    //   760: ldc_w 381
    //   763: aload_0
    //   764: invokevirtual 384	com/mobileapptracker/MATEvent:getSearchString	()Ljava/lang/String;
    //   767: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   770: aload_1
    //   771: ldc_w 386
    //   774: aload_0
    //   775: invokevirtual 389	com/mobileapptracker/MATEvent:getRefId	()Ljava/lang/String;
    //   778: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   781: aload_1
    //   782: ldc_w 391
    //   785: aload_0
    //   786: invokevirtual 394	com/mobileapptracker/MATEvent:getRevenue	()D
    //   789: invokestatic 379	java/lang/Double:toString	(D)Ljava/lang/String;
    //   792: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   795: aload_0
    //   796: invokevirtual 397	com/mobileapptracker/MATEvent:getDeviceForm	()Ljava/lang/String;
    //   799: ifnull +14 -> 813
    //   802: aload_1
    //   803: ldc_w 399
    //   806: aload_0
    //   807: invokevirtual 397	com/mobileapptracker/MATEvent:getDeviceForm	()Ljava/lang/String;
    //   810: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   813: aload_1
    //   814: ldc_w 401
    //   817: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   820: invokevirtual 404	com/mobileapptracker/MATParameters:getAge	()Ljava/lang/String;
    //   823: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   826: aload_1
    //   827: ldc_w 406
    //   830: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   833: invokevirtual 409	com/mobileapptracker/MATParameters:getExistingUser	()Ljava/lang/String;
    //   836: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   839: aload_1
    //   840: ldc_w 411
    //   843: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   846: invokevirtual 414	com/mobileapptracker/MATParameters:getFacebookUserId	()Ljava/lang/String;
    //   849: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   852: aload_1
    //   853: ldc_w 416
    //   856: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   859: invokevirtual 419	com/mobileapptracker/MATParameters:getGender	()Ljava/lang/String;
    //   862: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   865: aload_1
    //   866: ldc_w 421
    //   869: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   872: invokevirtual 424	com/mobileapptracker/MATParameters:getGoogleUserId	()Ljava/lang/String;
    //   875: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   878: aload_1
    //   879: ldc_w 426
    //   882: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   885: invokevirtual 429	com/mobileapptracker/MATParameters:getIsPayingUser	()Ljava/lang/String;
    //   888: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   891: aload_1
    //   892: ldc_w 431
    //   895: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   898: invokevirtual 434	com/mobileapptracker/MATParameters:getTwitterUserId	()Ljava/lang/String;
    //   901: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   904: aload_1
    //   905: ldc_w 436
    //   908: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   911: invokevirtual 439	com/mobileapptracker/MATParameters:getUserEmailMd5	()Ljava/lang/String;
    //   914: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   917: aload_1
    //   918: ldc_w 441
    //   921: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   924: invokevirtual 444	com/mobileapptracker/MATParameters:getUserEmailSha1	()Ljava/lang/String;
    //   927: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   930: aload_1
    //   931: ldc_w 446
    //   934: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   937: invokevirtual 449	com/mobileapptracker/MATParameters:getUserEmailSha256	()Ljava/lang/String;
    //   940: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   943: aload_1
    //   944: ldc_w 451
    //   947: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   950: invokevirtual 454	com/mobileapptracker/MATParameters:getUserId	()Ljava/lang/String;
    //   953: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   956: aload_1
    //   957: ldc_w 456
    //   960: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   963: invokevirtual 459	com/mobileapptracker/MATParameters:getUserNameMd5	()Ljava/lang/String;
    //   966: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   969: aload_1
    //   970: ldc_w 461
    //   973: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   976: invokevirtual 464	com/mobileapptracker/MATParameters:getUserNameSha1	()Ljava/lang/String;
    //   979: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   982: aload_1
    //   983: ldc_w 466
    //   986: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   989: invokevirtual 469	com/mobileapptracker/MATParameters:getUserNameSha256	()Ljava/lang/String;
    //   992: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   995: aload_1
    //   996: ldc_w 471
    //   999: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   1002: invokevirtual 474	com/mobileapptracker/MATParameters:getPhoneNumberMd5	()Ljava/lang/String;
    //   1005: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   1008: aload_1
    //   1009: ldc_w 476
    //   1012: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   1015: invokevirtual 479	com/mobileapptracker/MATParameters:getPhoneNumberSha1	()Ljava/lang/String;
    //   1018: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   1021: aload_1
    //   1022: ldc_w 481
    //   1025: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   1028: invokevirtual 484	com/mobileapptracker/MATParameters:getPhoneNumberSha256	()Ljava/lang/String;
    //   1031: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   1034: aload_1
    //   1035: invokevirtual 76	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1038: astore_0
    //   1039: ldc 2
    //   1041: monitorexit
    //   1042: aload_0
    //   1043: areturn
    //   1044: aload_1
    //   1045: ldc_w 328
    //   1048: getstatic 57	com/mobileapptracker/MATUrlBuilder:params	Lcom/mobileapptracker/MATParameters;
    //   1051: invokevirtual 485	com/mobileapptracker/MATParameters:getCurrencyCode	()Ljava/lang/String;
    //   1054: invokestatic 85	com/mobileapptracker/MATUrlBuilder:safeAppend	(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    //   1057: goto -419 -> 638
    //   1060: astore_0
    //   1061: ldc 2
    //   1063: monitorexit
    //   1064: aload_0
    //   1065: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	1066	0	paramMATEvent	MATEvent
    //   16	1029	1	localStringBuilder	StringBuilder
    // Exception table:
    //   from	to	target	type
    //   3	638	1060	java/lang/Throwable
    //   638	666	1060	java/lang/Throwable
    //   666	694	1060	java/lang/Throwable
    //   694	715	1060	java/lang/Throwable
    //   715	736	1060	java/lang/Throwable
    //   736	759	1060	java/lang/Throwable
    //   759	813	1060	java/lang/Throwable
    //   813	1039	1060	java/lang/Throwable
    //   1044	1057	1060	java/lang/Throwable
  }
  
  public static String buildLink(MATEvent paramMATEvent, MATPreloadData paramMATPreloadData, boolean paramBoolean)
  {
    params = MATParameters.getInstance();
    StringBuilder localStringBuilder = new StringBuilder("https://").append(params.getAdvertiserId()).append(".");
    if (paramBoolean) {
      localStringBuilder.append("debug.engine.mobileapptracking.com");
    }
    for (;;)
    {
      localStringBuilder.append("/serve?ver=").append(params.getSdkVersion());
      localStringBuilder.append("&transaction_id=").append(UUID.randomUUID().toString());
      safeAppend(localStringBuilder, "sdk", "android");
      safeAppend(localStringBuilder, "action", params.getAction());
      safeAppend(localStringBuilder, "advertiser_id", params.getAdvertiserId());
      safeAppend(localStringBuilder, "package_name", params.getPackageName());
      safeAppend(localStringBuilder, "referral_source", params.getReferralSource());
      safeAppend(localStringBuilder, "referral_url", params.getReferralUrl());
      safeAppend(localStringBuilder, "site_id", params.getSiteId());
      safeAppend(localStringBuilder, "tracking_id", params.getTrackingId());
      if (paramMATEvent.getEventId() != 0) {
        safeAppend(localStringBuilder, "site_event_id", Integer.toString(paramMATEvent.getEventId()));
      }
      if (!params.getAction().equals("session")) {
        safeAppend(localStringBuilder, "site_event_name", paramMATEvent.getEventName());
      }
      if (paramMATPreloadData != null)
      {
        localStringBuilder.append("&attr_set=1");
        safeAppend(localStringBuilder, "publisher_id", publisherId);
        safeAppend(localStringBuilder, "offer_id", offerId);
        safeAppend(localStringBuilder, "agency_id", agencyId);
        safeAppend(localStringBuilder, "publisher_ref_id", publisherReferenceId);
        safeAppend(localStringBuilder, "publisher_sub_publisher", publisherSubPublisher);
        safeAppend(localStringBuilder, "publisher_sub_site", publisherSubSite);
        safeAppend(localStringBuilder, "publisher_sub_campaign", publisherSubCampaign);
        safeAppend(localStringBuilder, "publisher_sub_adgroup", publisherSubAdgroup);
        safeAppend(localStringBuilder, "publisher_sub_ad", publisherSubAd);
        safeAppend(localStringBuilder, "publisher_sub_keyword", publisherSubKeyword);
        safeAppend(localStringBuilder, "advertiser_sub_publisher", advertiserSubPublisher);
        safeAppend(localStringBuilder, "advertiser_sub_site", advertiserSubSite);
        safeAppend(localStringBuilder, "advertiser_sub_campaign", advertiserSubCampaign);
        safeAppend(localStringBuilder, "advertiser_sub_adgroup", advertiserSubAdgroup);
        safeAppend(localStringBuilder, "advertiser_sub_ad", advertiserSubAd);
        safeAppend(localStringBuilder, "advertiser_sub_keyword", advertiserSubKeyword);
        safeAppend(localStringBuilder, "publisher_sub1", publisherSub1);
        safeAppend(localStringBuilder, "publisher_sub2", publisherSub2);
        safeAppend(localStringBuilder, "publisher_sub3", publisherSub3);
        safeAppend(localStringBuilder, "publisher_sub4", publisherSub4);
        safeAppend(localStringBuilder, "publisher_sub5", publisherSub5);
      }
      paramMATEvent = params.getAllowDuplicates();
      if ((paramMATEvent != null) && (Integer.parseInt(paramMATEvent) == 1)) {
        localStringBuilder.append("&skip_dup=1");
      }
      if (paramBoolean) {
        localStringBuilder.append("&debug=1");
      }
      return localStringBuilder.toString();
      localStringBuilder.append("engine.mobileapptracking.com");
    }
  }
  
  /* Error */
  private static void safeAppend(StringBuilder paramStringBuilder, String paramString1, String paramString2)
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: aload_2
    //   4: ifnull +53 -> 57
    //   7: aload_2
    //   8: ldc_w 686
    //   11: invokevirtual 554	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   14: istore_3
    //   15: iload_3
    //   16: ifne +41 -> 57
    //   19: aload_0
    //   20: new 59	java/lang/StringBuilder
    //   23: dup
    //   24: ldc_w 688
    //   27: invokespecial 65	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   30: aload_1
    //   31: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   34: ldc_w 690
    //   37: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   40: aload_2
    //   41: ldc_w 692
    //   44: invokestatic 698	java/net/URLEncoder:encode	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   47: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   50: invokevirtual 76	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   53: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: pop
    //   57: ldc 2
    //   59: monitorexit
    //   60: return
    //   61: astore_0
    //   62: ldc 34
    //   64: new 59	java/lang/StringBuilder
    //   67: dup
    //   68: ldc_w 700
    //   71: invokespecial 65	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   74: aload_2
    //   75: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   78: ldc_w 702
    //   81: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   84: aload_1
    //   85: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   88: invokevirtual 76	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   91: invokestatic 705	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   94: pop
    //   95: aload_0
    //   96: invokevirtual 706	java/io/UnsupportedEncodingException:printStackTrace	()V
    //   99: goto -42 -> 57
    //   102: astore_0
    //   103: ldc 2
    //   105: monitorexit
    //   106: aload_0
    //   107: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	108	0	paramStringBuilder	StringBuilder
    //   0	108	1	paramString1	String
    //   0	108	2	paramString2	String
    //   14	2	3	bool	boolean
    // Exception table:
    //   from	to	target	type
    //   19	57	61	java/io/UnsupportedEncodingException
    //   7	15	102	java/lang/Throwable
    //   19	57	102	java/lang/Throwable
    //   62	99	102	java/lang/Throwable
  }
  
  public static String updateAndEncryptData(String paramString, MATEncryption paramMATEncryption)
  {
    try
    {
      Object localObject = new StringBuilder(paramString);
      params = MATParameters.getInstance();
      if (params != null)
      {
        String str = params.getGoogleAdvertisingId();
        if ((str != null) && (!paramString.contains("&google_aid=")))
        {
          safeAppend((StringBuilder)localObject, "google_aid", str);
          safeAppend((StringBuilder)localObject, "google_ad_tracking_disabled", params.getGoogleAdTrackingLimited());
        }
        str = params.getAndroidId();
        if ((str != null) && (!paramString.contains("&android_id="))) {
          safeAppend((StringBuilder)localObject, "android_id", str);
        }
        str = params.getInstallReferrer();
        if ((str != null) && (!paramString.contains("&install_referrer="))) {
          safeAppend((StringBuilder)localObject, "install_referrer", str);
        }
        str = params.getReferralSource();
        if ((str != null) && (!paramString.contains("&referral_source="))) {
          safeAppend((StringBuilder)localObject, "referral_source", str);
        }
        str = params.getReferralUrl();
        if ((str != null) && (!paramString.contains("&referral_url="))) {
          safeAppend((StringBuilder)localObject, "referral_url", str);
        }
        str = params.getUserAgent();
        if ((str != null) && (!paramString.contains("&conversion_user_agent="))) {
          safeAppend((StringBuilder)localObject, "conversion_user_agent", str);
        }
        str = params.getFacebookUserId();
        if ((str != null) && (!paramString.contains("&facebook_user_id="))) {
          safeAppend((StringBuilder)localObject, "facebook_user_id", str);
        }
      }
      if (!paramString.contains("&system_date=")) {
        safeAppend((StringBuilder)localObject, "system_date", Long.toString(new Date().getTime() / 1000L));
      }
      localObject = ((StringBuilder)localObject).toString();
      paramString = (String)localObject;
      try
      {
        paramMATEncryption = MATUtils.bytesToHex(paramMATEncryption.encrypt((String)localObject));
        paramString = paramMATEncryption;
      }
      catch (Exception paramMATEncryption)
      {
        for (;;)
        {
          paramMATEncryption.printStackTrace();
        }
      }
      return paramString;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
}
