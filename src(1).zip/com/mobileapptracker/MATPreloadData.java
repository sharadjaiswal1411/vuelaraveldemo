package com.mobileapptracker;

public class MATPreloadData
{
  public String advertiserSubAd;
  public String advertiserSubAdgroup;
  public String advertiserSubCampaign;
  public String advertiserSubKeyword;
  public String advertiserSubPublisher;
  public String advertiserSubSite;
  public String agencyId;
  public String offerId;
  public String publisherId;
  public String publisherReferenceId;
  public String publisherSub1;
  public String publisherSub2;
  public String publisherSub3;
  public String publisherSub4;
  public String publisherSub5;
  public String publisherSubAd;
  public String publisherSubAdgroup;
  public String publisherSubCampaign;
  public String publisherSubKeyword;
  public String publisherSubPublisher;
  public String publisherSubSite;
  
  public MATPreloadData(String paramString)
  {
    publisherId = paramString;
  }
  
  public MATPreloadData withAdvertiserSubAd(String paramString)
  {
    advertiserSubAd = paramString;
    return this;
  }
  
  public MATPreloadData withAdvertiserSubAdgroup(String paramString)
  {
    advertiserSubAdgroup = paramString;
    return this;
  }
  
  public MATPreloadData withAdvertiserSubCampaign(String paramString)
  {
    advertiserSubCampaign = paramString;
    return this;
  }
  
  public MATPreloadData withAdvertiserSubKeyword(String paramString)
  {
    advertiserSubKeyword = paramString;
    return this;
  }
  
  public MATPreloadData withAdvertiserSubPublisher(String paramString)
  {
    advertiserSubPublisher = paramString;
    return this;
  }
  
  public MATPreloadData withAdvertiserSubSite(String paramString)
  {
    advertiserSubSite = paramString;
    return this;
  }
  
  public MATPreloadData withAgencyId(String paramString)
  {
    agencyId = paramString;
    return this;
  }
  
  public MATPreloadData withOfferId(String paramString)
  {
    offerId = paramString;
    return this;
  }
  
  public MATPreloadData withPublisherReferenceId(String paramString)
  {
    publisherReferenceId = paramString;
    return this;
  }
  
  public MATPreloadData withPublisherSub1(String paramString)
  {
    publisherSub1 = paramString;
    return this;
  }
  
  public MATPreloadData withPublisherSub2(String paramString)
  {
    publisherSub2 = paramString;
    return this;
  }
  
  public MATPreloadData withPublisherSub3(String paramString)
  {
    publisherSub3 = paramString;
    return this;
  }
  
  public MATPreloadData withPublisherSub4(String paramString)
  {
    publisherSub4 = paramString;
    return this;
  }
  
  public MATPreloadData withPublisherSub5(String paramString)
  {
    publisherSub5 = paramString;
    return this;
  }
  
  public MATPreloadData withPublisherSubAd(String paramString)
  {
    publisherSubAd = paramString;
    return this;
  }
  
  public MATPreloadData withPublisherSubAdgroup(String paramString)
  {
    publisherSubAdgroup = paramString;
    return this;
  }
  
  public MATPreloadData withPublisherSubCampaign(String paramString)
  {
    publisherSubCampaign = paramString;
    return this;
  }
  
  public MATPreloadData withPublisherSubKeyword(String paramString)
  {
    publisherSubKeyword = paramString;
    return this;
  }
  
  public MATPreloadData withPublisherSubPublisher(String paramString)
  {
    publisherSubPublisher = paramString;
    return this;
  }
  
  public MATPreloadData withPublisherSubSite(String paramString)
  {
    publisherSubSite = paramString;
    return this;
  }
}
