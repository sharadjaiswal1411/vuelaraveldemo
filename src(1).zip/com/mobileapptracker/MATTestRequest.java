package com.mobileapptracker;

import org.json.JSONObject;

public abstract interface MATTestRequest
{
  public abstract void constructedRequest(String paramString1, String paramString2, JSONObject paramJSONObject);
}
