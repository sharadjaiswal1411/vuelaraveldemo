package com.mobileapptracker;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;
import java.util.concurrent.Semaphore;
import org.json.JSONException;
import org.json.JSONObject;

public class MATEventQueue
{
  private static long retryTimeout = 0L;
  private SharedPreferences eventQueue;
  private Semaphore queueAvailable;
  private MobileAppTracker tune;
  
  public MATEventQueue(Context paramContext, MobileAppTracker paramMobileAppTracker)
  {
    eventQueue = paramContext.getSharedPreferences("mat_queue", 0);
    queueAvailable = new Semaphore(1, true);
    tune = paramMobileAppTracker;
  }
  
  protected String getKeyFromQueue(String paramString)
  {
    try
    {
      paramString = eventQueue.getString(paramString, null);
      return paramString;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  protected int getQueueSize()
  {
    try
    {
      int i = eventQueue.getInt("queuesize", 0);
      return i;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  protected void removeKeyFromQueue(String paramString)
  {
    try
    {
      setQueueSize(getQueueSize() - 1);
      SharedPreferences.Editor localEditor = eventQueue.edit();
      localEditor.remove(paramString);
      localEditor.commit();
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  protected void setQueueItemForKey(JSONObject paramJSONObject, String paramString)
  {
    try
    {
      SharedPreferences.Editor localEditor = eventQueue.edit();
      localEditor.putString(paramString, paramJSONObject.toString());
      localEditor.commit();
      return;
    }
    catch (Throwable paramJSONObject)
    {
      throw paramJSONObject;
    }
  }
  
  protected void setQueueSize(int paramInt)
  {
    try
    {
      SharedPreferences.Editor localEditor = eventQueue.edit();
      int i = paramInt;
      if (paramInt < 0) {
        i = 0;
      }
      localEditor.putInt("queuesize", i);
      localEditor.commit();
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  protected class Add
    implements Runnable
  {
    private String data = null;
    private boolean firstSession = false;
    private String link = null;
    private JSONObject postBody = null;
    
    protected Add(String paramString1, String paramString2, JSONObject paramJSONObject, boolean paramBoolean)
    {
      link = paramString1;
      data = paramString2;
      postBody = paramJSONObject;
      firstSession = paramBoolean;
    }
    
    /* Error */
    public void run()
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 22	com/mobileapptracker/MATEventQueue$Add:this$0	Lcom/mobileapptracker/MATEventQueue;
      //   4: astore_3
      //   5: aload_3
      //   6: invokestatic 45	com/mobileapptracker/MATEventQueue:access$0	(Lcom/mobileapptracker/MATEventQueue;)Ljava/util/concurrent/Semaphore;
      //   9: invokevirtual 50	java/util/concurrent/Semaphore:acquire	()V
      //   12: new 52	org/json/JSONObject
      //   15: dup
      //   16: invokespecial 53	org/json/JSONObject:<init>	()V
      //   19: astore_3
      //   20: aload_0
      //   21: getfield 27	com/mobileapptracker/MATEventQueue$Add:link	Ljava/lang/String;
      //   24: astore 4
      //   26: aload_3
      //   27: ldc 54
      //   29: aload 4
      //   31: invokevirtual 58	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   34: pop
      //   35: aload_0
      //   36: getfield 29	com/mobileapptracker/MATEventQueue$Add:data	Ljava/lang/String;
      //   39: astore 4
      //   41: aload_3
      //   42: ldc 59
      //   44: aload 4
      //   46: invokevirtual 58	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   49: pop
      //   50: aload_0
      //   51: getfield 31	com/mobileapptracker/MATEventQueue$Add:postBody	Lorg/json/JSONObject;
      //   54: astore 4
      //   56: aload_3
      //   57: ldc 61
      //   59: aload 4
      //   61: invokevirtual 58	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   64: pop
      //   65: aload_0
      //   66: getfield 33	com/mobileapptracker/MATEventQueue$Add:firstSession	Z
      //   69: istore_2
      //   70: aload_3
      //   71: ldc 63
      //   73: iload_2
      //   74: invokevirtual 66	org/json/JSONObject:put	(Ljava/lang/String;Z)Lorg/json/JSONObject;
      //   77: pop
      //   78: aload_0
      //   79: getfield 22	com/mobileapptracker/MATEventQueue$Add:this$0	Lcom/mobileapptracker/MATEventQueue;
      //   82: astore 4
      //   84: aload 4
      //   86: invokevirtual 70	com/mobileapptracker/MATEventQueue:getQueueSize	()I
      //   89: istore_1
      //   90: iload_1
      //   91: iconst_1
      //   92: iadd
      //   93: istore_1
      //   94: aload_0
      //   95: getfield 22	com/mobileapptracker/MATEventQueue$Add:this$0	Lcom/mobileapptracker/MATEventQueue;
      //   98: astore 4
      //   100: aload 4
      //   102: iload_1
      //   103: invokevirtual 74	com/mobileapptracker/MATEventQueue:setQueueSize	(I)V
      //   106: iload_1
      //   107: invokestatic 80	java/lang/Integer:toString	(I)Ljava/lang/String;
      //   110: astore 4
      //   112: aload_0
      //   113: getfield 22	com/mobileapptracker/MATEventQueue$Add:this$0	Lcom/mobileapptracker/MATEventQueue;
      //   116: astore 5
      //   118: aload 5
      //   120: aload_3
      //   121: aload 4
      //   123: invokevirtual 84	com/mobileapptracker/MATEventQueue:setQueueItemForKey	(Lorg/json/JSONObject;Ljava/lang/String;)V
      //   126: aload_0
      //   127: getfield 22	com/mobileapptracker/MATEventQueue$Add:this$0	Lcom/mobileapptracker/MATEventQueue;
      //   130: invokestatic 45	com/mobileapptracker/MATEventQueue:access$0	(Lcom/mobileapptracker/MATEventQueue;)Ljava/util/concurrent/Semaphore;
      //   133: invokevirtual 87	java/util/concurrent/Semaphore:release	()V
      //   136: return
      //   137: astore_3
      //   138: ldc 89
      //   140: ldc 91
      //   142: invokestatic 97	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
      //   145: pop
      //   146: aload_3
      //   147: invokevirtual 102	java/lang/Exception:printStackTrace	()V
      //   150: aload_0
      //   151: getfield 22	com/mobileapptracker/MATEventQueue$Add:this$0	Lcom/mobileapptracker/MATEventQueue;
      //   154: invokestatic 45	com/mobileapptracker/MATEventQueue:access$0	(Lcom/mobileapptracker/MATEventQueue;)Ljava/util/concurrent/Semaphore;
      //   157: invokevirtual 87	java/util/concurrent/Semaphore:release	()V
      //   160: return
      //   161: astore_3
      //   162: ldc 89
      //   164: ldc 104
      //   166: invokestatic 97	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
      //   169: pop
      //   170: aload_3
      //   171: checkcast 39	java/lang/InterruptedException
      //   174: invokevirtual 105	java/lang/InterruptedException:printStackTrace	()V
      //   177: aload_0
      //   178: getfield 22	com/mobileapptracker/MATEventQueue$Add:this$0	Lcom/mobileapptracker/MATEventQueue;
      //   181: invokestatic 45	com/mobileapptracker/MATEventQueue:access$0	(Lcom/mobileapptracker/MATEventQueue;)Ljava/util/concurrent/Semaphore;
      //   184: invokevirtual 87	java/util/concurrent/Semaphore:release	()V
      //   187: return
      //   188: astore_3
      //   189: aload_0
      //   190: getfield 22	com/mobileapptracker/MATEventQueue$Add:this$0	Lcom/mobileapptracker/MATEventQueue;
      //   193: invokestatic 45	com/mobileapptracker/MATEventQueue:access$0	(Lcom/mobileapptracker/MATEventQueue;)Ljava/util/concurrent/Semaphore;
      //   196: invokevirtual 87	java/util/concurrent/Semaphore:release	()V
      //   199: aload_3
      //   200: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	201	0	this	Add
      //   89	18	1	i	int
      //   69	5	2	bool	boolean
      //   4	117	3	localObject1	Object
      //   137	10	3	localJSONException	JSONException
      //   161	10	3	localInterruptedException	InterruptedException
      //   188	12	3	localThrowable	Throwable
      //   24	98	4	localObject2	Object
      //   116	3	5	localMATEventQueue	MATEventQueue
      // Exception table:
      //   from	to	target	type
      //   26	35	137	org/json/JSONException
      //   41	50	137	org/json/JSONException
      //   56	65	137	org/json/JSONException
      //   70	78	137	org/json/JSONException
      //   5	12	161	java/lang/InterruptedException
      //   12	20	161	java/lang/InterruptedException
      //   26	35	161	java/lang/InterruptedException
      //   41	50	161	java/lang/InterruptedException
      //   56	65	161	java/lang/InterruptedException
      //   70	78	161	java/lang/InterruptedException
      //   84	90	161	java/lang/InterruptedException
      //   100	112	161	java/lang/InterruptedException
      //   118	126	161	java/lang/InterruptedException
      //   138	150	161	java/lang/InterruptedException
      //   0	5	188	java/lang/Throwable
      //   5	12	188	java/lang/Throwable
      //   12	20	188	java/lang/Throwable
      //   20	26	188	java/lang/Throwable
      //   26	35	188	java/lang/Throwable
      //   35	41	188	java/lang/Throwable
      //   41	50	188	java/lang/Throwable
      //   50	56	188	java/lang/Throwable
      //   56	65	188	java/lang/Throwable
      //   70	78	188	java/lang/Throwable
      //   84	90	188	java/lang/Throwable
      //   94	100	188	java/lang/Throwable
      //   100	112	188	java/lang/Throwable
      //   118	126	188	java/lang/Throwable
      //   138	150	188	java/lang/Throwable
      //   162	177	188	java/lang/Throwable
    }
  }
  
  protected class Dump
    implements Runnable
  {
    protected Dump() {}
    
    public void run()
    {
      int n = getQueueSize();
      if (n == 0) {
        return;
      }
      Object localObject1 = MATEventQueue.this;
      for (;;)
      {
        Object localObject3;
        try
        {
          queueAvailable.acquire();
          i = 1;
          if (n > 50) {
            i = n - 50 + 1;
          }
          if (i > n)
          {
            queueAvailable.release();
            return;
          }
          localObject1 = Integer.toString(i);
          localObject2 = MATEventQueue.this;
          localObject2 = ((MATEventQueue)localObject2).getKeyFromQueue((String)localObject1);
          if (localObject2 == null) {
            break label662;
          }
        }
        catch (InterruptedException localInterruptedException1)
        {
          Object localObject2;
          Object localObject5;
          String str;
          JSONObject localJSONObject;
          boolean bool;
          ((InterruptedException)localInterruptedException1).printStackTrace();
          queueAvailable.release();
          return;
          int k = i - 1;
          int j = ((String)localObject4).indexOf("&sdk_retry_attempt=");
          if (j <= 0) {
            continue;
          }
          int i = -1;
          int m = "&sdk_retry_attempt=".length();
          int i1 = j + m;
          j = i1 + 1;
          m = i;
          try
          {
            str = ((String)localObject4).substring(i1, j);
          }
          catch (StringIndexOutOfBoundsException localStringIndexOutOfBoundsException)
          {
            try
            {
              i = Integer.parseInt(str);
              j += 1;
            }
            catch (NumberFormatException localNumberFormatException)
            {
              long l;
              continue;
            }
            localStringIndexOutOfBoundsException = localStringIndexOutOfBoundsException;
          }
          Object localObject4 = ((String)localObject4).replaceFirst("&sdk_retry_attempt=\\d+", "&sdk_retry_attempt=" + (m + 1));
          try
          {
            localObject3 = new JSONObject((String)localObject3);
            ((JSONObject)localObject3).put("link", localObject4);
            localObject4 = MATEventQueue.this;
            ((MATEventQueue)localObject4).setQueueItemForKey((JSONObject)localObject3, localInterruptedException1);
          }
          catch (JSONException localJSONException1)
          {
            double d;
            localJSONException1.printStackTrace();
            continue;
          }
          l = MATEventQueue.retryTimeout;
          if (l != 0L) {
            break label537;
          }
          MATEventQueue.retryTimeout = 30L;
          d = Math.random();
          l = MATEventQueue.retryTimeout;
          l = ((1.0D + 0.1D * d) * l * 1000.0D);
          try
          {
            Thread.sleep(l);
            i = k;
          }
          catch (InterruptedException localInterruptedException2)
          {
            i = k;
          }
          continue;
        }
        catch (Throwable localThrowable2)
        {
          queueAvailable.release();
          throw localThrowable2;
        }
        try
        {
          localObject5 = new JSONObject((String)localObject2);
          localObject4 = ((JSONObject)localObject5).getString("link");
          str = ((JSONObject)localObject5).getString("data");
          localJSONObject = ((JSONObject)localObject5).getJSONObject("post_body");
          bool = ((JSONObject)localObject5).getBoolean("first_session");
          if (bool)
          {
            localObject5 = MATEventQueue.this;
            localObject5 = tune;
            localObject5 = pool;
          }
        }
        catch (JSONException localJSONException2)
        {
          try
          {
            tune.pool.wait(60000L);
            localObject5 = MATEventQueue.this;
            localObject5 = tune;
            if (localObject5 == null) {
              break label638;
            }
            localObject5 = MATEventQueue.this;
            bool = tune.makeRequest((String)localObject4, str, localJSONObject);
            if (!bool) {
              continue;
            }
            localObject2 = MATEventQueue.this;
            ((MATEventQueue)localObject2).removeKeyFromQueue((String)localObject1);
            MATEventQueue.retryTimeout = 0L;
            i += 1;
          }
          catch (Throwable localThrowable1)
          {
            throw localThrowable1;
          }
          localJSONException2 = localJSONException2;
          localJSONException2.printStackTrace();
          localObject3 = MATEventQueue.this;
          ((MATEventQueue)localObject3).removeKeyFromQueue((String)localObject1);
          queueAvailable.release();
          return;
        }
        label537:
        l = MATEventQueue.retryTimeout;
        if (l <= 30L)
        {
          MATEventQueue.retryTimeout = 90L;
        }
        else
        {
          l = MATEventQueue.retryTimeout;
          if (l <= 90L)
          {
            MATEventQueue.retryTimeout = 600L;
          }
          else
          {
            l = MATEventQueue.retryTimeout;
            if (l <= 600L)
            {
              MATEventQueue.retryTimeout = 3600L;
            }
            else
            {
              l = MATEventQueue.retryTimeout;
              if (l <= 3600L)
              {
                MATEventQueue.retryTimeout = 21600L;
              }
              else
              {
                MATEventQueue.retryTimeout = 86400L;
                continue;
                label638:
                Log.d("MobileAppTracker", "Dropping queued request because no MAT object was found");
                localObject3 = MATEventQueue.this;
                ((MATEventQueue)localObject3).removeKeyFromQueue(localThrowable2);
                continue;
                label662:
                Log.d("MobileAppTracker", "Null request skipped from queue");
                localObject3 = MATEventQueue.this;
                ((MATEventQueue)localObject3).removeKeyFromQueue(localThrowable2);
              }
            }
          }
        }
      }
    }
  }
}
