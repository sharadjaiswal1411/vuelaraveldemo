package com.mobileapptracker;

import android.content.Context;
import android.location.Location;
import android.provider.Settings.Secure;
import android.util.Log;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import org.json.JSONArray;

public class MATParameters
{
  private static MATParameters INSTANCE = null;
  private String mAction = null;
  private String mAdvertiserId = null;
  private String mAge = null;
  private String mAllowDups = null;
  private String mAltitude = null;
  private String mAndroidId = null;
  private String mAndroidIdMd5 = null;
  private String mAndroidIdSha1 = null;
  private String mAndroidIdSha256 = null;
  private String mAppAdTracking = null;
  private String mAppName = null;
  private String mAppVersion = null;
  private String mAppVersionName = null;
  private String mConnectionType = null;
  private Context mContext;
  private String mConversionKey = null;
  private String mCountryCode = null;
  private String mCurrencyCode = null;
  private boolean mDebugMode = false;
  private String mDeviceBrand = null;
  private String mDeviceCarrier = null;
  private String mDeviceCpuSubtype = null;
  private String mDeviceCpuType = null;
  private String mDeviceId = null;
  private String mDeviceModel = null;
  private String mExistingUser = null;
  private String mFbUserId = null;
  private String mGaid = null;
  private String mGaidLimited = null;
  private String mGender = null;
  private String mGgUserId = null;
  private String mInstallDate = null;
  private String mInstallerPackage = null;
  private String mLanguage = null;
  private String mLatitude = null;
  private Location mLocation = null;
  private String mLongitude = null;
  private String mMCC = null;
  private String mMNC = null;
  private String mMacAddress = null;
  private String mOsVersion = null;
  private String mPackageName = null;
  private String mPhoneNumberMd5;
  private String mPhoneNumberSha1;
  private String mPhoneNumberSha256;
  private String mPluginName = null;
  private String mPurchaseStatus = null;
  private String mRefId = null;
  private String mReferralSource = null;
  private String mReferralUrl = null;
  private String mReferrerDelay = null;
  private String mRevenue = null;
  private String mScreenDensity = null;
  private String mScreenHeight = null;
  private String mScreenWidth = null;
  private String mSiteId = null;
  private String mTimeZone = null;
  private String mTrackingId = null;
  private String mTrusteId = null;
  private MobileAppTracker mTune;
  private String mTwUserId = null;
  private String mUserAgent = null;
  private String mUserEmailMd5;
  private String mUserEmailSha1;
  private String mUserEmailSha256;
  private JSONArray mUserEmails = null;
  private String mUserNameMd5;
  private String mUserNameSha1;
  private String mUserNameSha256;
  
  public MATParameters() {}
  
  public static MATParameters getInstance()
  {
    return INSTANCE;
  }
  
  public static MATParameters init(MobileAppTracker paramMobileAppTracker, Context paramContext, String paramString1, String paramString2)
  {
    if (INSTANCE == null)
    {
      INSTANCE = new MATParameters();
      INSTANCEmTune = paramMobileAppTracker;
      INSTANCEmContext = paramContext;
      INSTANCE.populateParams(paramContext, paramString1, paramString2);
    }
    return INSTANCE;
  }
  
  /* Error */
  private boolean populateParams(Context paramContext, String paramString1, String paramString2)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_2
    //   4: invokevirtual 246	java/lang/String:trim	()Ljava/lang/String;
    //   7: invokevirtual 249	com/mobileapptracker/MATParameters:setAdvertiserId	(Ljava/lang/String;)V
    //   10: aload_0
    //   11: aload_3
    //   12: invokevirtual 246	java/lang/String:trim	()Ljava/lang/String;
    //   15: invokevirtual 252	com/mobileapptracker/MATParameters:setConversionKey	(Ljava/lang/String;)V
    //   18: aload_0
    //   19: ldc -2
    //   21: invokevirtual 257	com/mobileapptracker/MATParameters:setCurrencyCode	(Ljava/lang/String;)V
    //   24: new 259	java/lang/Thread
    //   27: dup
    //   28: new 6	com/mobileapptracker/MATParameters$GetGAID
    //   31: dup
    //   32: aload_0
    //   33: aload_1
    //   34: invokespecial 262	com/mobileapptracker/MATParameters$GetGAID:<init>	(Lcom/mobileapptracker/MATParameters;Landroid/content/Context;)V
    //   37: invokespecial 265	java/lang/Thread:<init>	(Ljava/lang/Runnable;)V
    //   40: invokevirtual 268	java/lang/Thread:start	()V
    //   43: new 270	android/os/Handler
    //   46: dup
    //   47: invokestatic 276	android/os/Looper:getMainLooper	()Landroid/os/Looper;
    //   50: invokespecial 279	android/os/Handler:<init>	(Landroid/os/Looper;)V
    //   53: astore_2
    //   54: aload_0
    //   55: getfield 228	com/mobileapptracker/MATParameters:mContext	Landroid/content/Context;
    //   58: astore_3
    //   59: aload_2
    //   60: new 9	com/mobileapptracker/MATParameters$GetUserAgent
    //   63: dup
    //   64: aload_0
    //   65: aload_3
    //   66: invokespecial 280	com/mobileapptracker/MATParameters$GetUserAgent:<init>	(Lcom/mobileapptracker/MATParameters;Landroid/content/Context;)V
    //   69: invokevirtual 284	android/os/Handler:post	(Ljava/lang/Runnable;)Z
    //   72: pop
    //   73: aload_0
    //   74: getfield 228	com/mobileapptracker/MATParameters:mContext	Landroid/content/Context;
    //   77: astore_2
    //   78: aload_2
    //   79: invokevirtual 289	android/content/Context:getPackageName	()Ljava/lang/String;
    //   82: astore_2
    //   83: aload_0
    //   84: aload_2
    //   85: invokevirtual 292	com/mobileapptracker/MATParameters:setPackageName	(Ljava/lang/String;)V
    //   88: aload_0
    //   89: getfield 228	com/mobileapptracker/MATParameters:mContext	Landroid/content/Context;
    //   92: astore_3
    //   93: aload_3
    //   94: invokevirtual 296	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
    //   97: astore_3
    //   98: aload_0
    //   99: aload_3
    //   100: aload_3
    //   101: aload_2
    //   102: iconst_0
    //   103: invokevirtual 302	android/content/pm/PackageManager:getApplicationInfo	(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    //   106: invokevirtual 306	android/content/pm/PackageManager:getApplicationLabel	(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;
    //   109: invokeinterface 311 1 0
    //   114: invokevirtual 314	com/mobileapptracker/MATParameters:setAppName	(Ljava/lang/String;)V
    //   117: aload_3
    //   118: aload_2
    //   119: iconst_0
    //   120: invokevirtual 302	android/content/pm/PackageManager:getApplicationInfo	(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    //   123: astore 10
    //   125: aload 10
    //   127: getfield 319	android/content/pm/ApplicationInfo:sourceDir	Ljava/lang/String;
    //   130: astore 10
    //   132: new 321	java/io/File
    //   135: dup
    //   136: aload 10
    //   138: invokespecial 323	java/io/File:<init>	(Ljava/lang/String;)V
    //   141: invokevirtual 327	java/io/File:lastModified	()J
    //   144: lstore 7
    //   146: new 329	java/util/Date
    //   149: dup
    //   150: lload 7
    //   152: invokespecial 332	java/util/Date:<init>	(J)V
    //   155: invokevirtual 335	java/util/Date:getTime	()J
    //   158: lstore 7
    //   160: lload 7
    //   162: ldc2_w 336
    //   165: ldiv
    //   166: lstore 7
    //   168: aload_0
    //   169: lload 7
    //   171: invokestatic 342	java/lang/Long:toString	(J)Ljava/lang/String;
    //   174: invokevirtual 345	com/mobileapptracker/MATParameters:setInstallDate	(Ljava/lang/String;)V
    //   177: aload_3
    //   178: aload_2
    //   179: iconst_0
    //   180: invokevirtual 349	android/content/pm/PackageManager:getPackageInfo	(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   183: astore 10
    //   185: aload 10
    //   187: getfield 355	android/content/pm/PackageInfo:versionCode	I
    //   190: istore 5
    //   192: aload_0
    //   193: iload 5
    //   195: invokestatic 360	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   198: invokevirtual 363	com/mobileapptracker/MATParameters:setAppVersion	(Ljava/lang/String;)V
    //   201: aload 10
    //   203: getfield 366	android/content/pm/PackageInfo:versionName	Ljava/lang/String;
    //   206: astore 10
    //   208: aload_0
    //   209: aload 10
    //   211: invokevirtual 369	com/mobileapptracker/MATParameters:setAppVersionName	(Ljava/lang/String;)V
    //   214: aload_0
    //   215: aload_3
    //   216: aload_2
    //   217: invokevirtual 373	android/content/pm/PackageManager:getInstallerPackageName	(Ljava/lang/String;)Ljava/lang/String;
    //   220: invokevirtual 376	com/mobileapptracker/MATParameters:setInstaller	(Ljava/lang/String;)V
    //   223: getstatic 381	android/os/Build:MODEL	Ljava/lang/String;
    //   226: astore_2
    //   227: aload_0
    //   228: aload_2
    //   229: invokevirtual 384	com/mobileapptracker/MATParameters:setDeviceModel	(Ljava/lang/String;)V
    //   232: getstatic 387	android/os/Build:MANUFACTURER	Ljava/lang/String;
    //   235: astore_2
    //   236: aload_0
    //   237: aload_2
    //   238: invokevirtual 390	com/mobileapptracker/MATParameters:setDeviceBrand	(Ljava/lang/String;)V
    //   241: aload_0
    //   242: ldc_w 392
    //   245: invokestatic 397	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   248: invokevirtual 400	com/mobileapptracker/MATParameters:setDeviceCpuType	(Ljava/lang/String;)V
    //   251: getstatic 405	android/os/Build$VERSION:RELEASE	Ljava/lang/String;
    //   254: astore_2
    //   255: aload_0
    //   256: aload_2
    //   257: invokevirtual 408	com/mobileapptracker/MATParameters:setOsVersion	(Ljava/lang/String;)V
    //   260: aload_1
    //   261: invokevirtual 412	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   264: invokevirtual 418	android/content/res/Resources:getDisplayMetrics	()Landroid/util/DisplayMetrics;
    //   267: astore_2
    //   268: aload_2
    //   269: getfield 424	android/util/DisplayMetrics:density	F
    //   272: fstore 4
    //   274: aload_0
    //   275: fload 4
    //   277: invokestatic 429	java/lang/Float:toString	(F)Ljava/lang/String;
    //   280: invokevirtual 432	com/mobileapptracker/MATParameters:setScreenDensity	(Ljava/lang/String;)V
    //   283: aload_1
    //   284: ldc_w 434
    //   287: invokevirtual 438	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   290: astore_2
    //   291: aload_2
    //   292: checkcast 440	android/view/WindowManager
    //   295: astore_2
    //   296: aload_2
    //   297: invokeinterface 444 1 0
    //   302: astore_2
    //   303: new 446	android/graphics/Point
    //   306: dup
    //   307: invokespecial 447	android/graphics/Point:<init>	()V
    //   310: astore_3
    //   311: getstatic 450	android/os/Build$VERSION:SDK_INT	I
    //   314: bipush 17
    //   316: if_icmplt +265 -> 581
    //   319: aload_2
    //   320: aload_3
    //   321: invokevirtual 456	android/view/Display:getRealSize	(Landroid/graphics/Point;)V
    //   324: aload_3
    //   325: getfield 459	android/graphics/Point:x	I
    //   328: istore 5
    //   330: aload_3
    //   331: getfield 462	android/graphics/Point:y	I
    //   334: istore 6
    //   336: aload_0
    //   337: iload 5
    //   339: invokestatic 360	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   342: invokevirtual 465	com/mobileapptracker/MATParameters:setScreenWidth	(Ljava/lang/String;)V
    //   345: aload_0
    //   346: iload 6
    //   348: invokestatic 360	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   351: invokevirtual 468	com/mobileapptracker/MATParameters:setScreenHeight	(Ljava/lang/String;)V
    //   354: aload_0
    //   355: getfield 228	com/mobileapptracker/MATParameters:mContext	Landroid/content/Context;
    //   358: astore_2
    //   359: aload_2
    //   360: ldc_w 470
    //   363: invokevirtual 438	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   366: astore_2
    //   367: aload_2
    //   368: checkcast 472	android/net/ConnectivityManager
    //   371: astore_2
    //   372: aload_2
    //   373: iconst_1
    //   374: invokevirtual 476	android/net/ConnectivityManager:getNetworkInfo	(I)Landroid/net/NetworkInfo;
    //   377: invokevirtual 482	android/net/NetworkInfo:isConnected	()Z
    //   380: istore 9
    //   382: iload 9
    //   384: ifeq +240 -> 624
    //   387: aload_0
    //   388: ldc_w 484
    //   391: invokevirtual 487	com/mobileapptracker/MATParameters:setConnectionType	(Ljava/lang/String;)V
    //   394: aload_0
    //   395: invokestatic 493	java/util/Locale:getDefault	()Ljava/util/Locale;
    //   398: invokevirtual 496	java/util/Locale:getLanguage	()Ljava/lang/String;
    //   401: invokevirtual 499	com/mobileapptracker/MATParameters:setLanguage	(Ljava/lang/String;)V
    //   404: aload_0
    //   405: invokestatic 493	java/util/Locale:getDefault	()Ljava/util/Locale;
    //   408: invokevirtual 502	java/util/Locale:getCountry	()Ljava/lang/String;
    //   411: invokevirtual 505	com/mobileapptracker/MATParameters:setCountryCode	(Ljava/lang/String;)V
    //   414: invokestatic 510	java/util/TimeZone:getDefault	()Ljava/util/TimeZone;
    //   417: astore_2
    //   418: getstatic 514	java/util/Locale:US	Ljava/util/Locale;
    //   421: astore_3
    //   422: aload_0
    //   423: aload_2
    //   424: iconst_0
    //   425: iconst_0
    //   426: aload_3
    //   427: invokevirtual 518	java/util/TimeZone:getDisplayName	(ZILjava/util/Locale;)Ljava/lang/String;
    //   430: invokevirtual 521	com/mobileapptracker/MATParameters:setTimeZone	(Ljava/lang/String;)V
    //   433: aload_1
    //   434: ldc_w 523
    //   437: invokevirtual 438	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   440: astore_1
    //   441: aload_1
    //   442: checkcast 525	android/telephony/TelephonyManager
    //   445: astore_1
    //   446: aload_1
    //   447: ifnull +192 -> 639
    //   450: aload_1
    //   451: invokevirtual 528	android/telephony/TelephonyManager:getNetworkCountryIso	()Ljava/lang/String;
    //   454: astore_2
    //   455: aload_2
    //   456: ifnull +11 -> 467
    //   459: aload_0
    //   460: aload_1
    //   461: invokevirtual 528	android/telephony/TelephonyManager:getNetworkCountryIso	()Ljava/lang/String;
    //   464: invokevirtual 505	com/mobileapptracker/MATParameters:setCountryCode	(Ljava/lang/String;)V
    //   467: aload_0
    //   468: aload_1
    //   469: invokevirtual 531	android/telephony/TelephonyManager:getNetworkOperatorName	()Ljava/lang/String;
    //   472: invokevirtual 534	com/mobileapptracker/MATParameters:setDeviceCarrier	(Ljava/lang/String;)V
    //   475: aload_1
    //   476: invokevirtual 537	android/telephony/TelephonyManager:getNetworkOperator	()Ljava/lang/String;
    //   479: astore_2
    //   480: aload_2
    //   481: ifnull +26 -> 507
    //   484: aload_2
    //   485: iconst_0
    //   486: iconst_3
    //   487: invokevirtual 541	java/lang/String:substring	(II)Ljava/lang/String;
    //   490: astore_1
    //   491: aload_2
    //   492: iconst_3
    //   493: invokevirtual 543	java/lang/String:substring	(I)Ljava/lang/String;
    //   496: astore_2
    //   497: aload_0
    //   498: aload_1
    //   499: invokevirtual 546	com/mobileapptracker/MATParameters:setMCC	(Ljava/lang/String;)V
    //   502: aload_0
    //   503: aload_2
    //   504: invokevirtual 549	com/mobileapptracker/MATParameters:setMNC	(Ljava/lang/String;)V
    //   507: aload_0
    //   508: invokevirtual 552	com/mobileapptracker/MATParameters:getMatId	()Ljava/lang/String;
    //   511: astore_1
    //   512: aload_1
    //   513: ifnull +14 -> 527
    //   516: aload_1
    //   517: invokevirtual 556	java/lang/String:length	()I
    //   520: istore 5
    //   522: iload 5
    //   524: ifne +13 -> 537
    //   527: aload_0
    //   528: invokestatic 562	java/util/UUID:randomUUID	()Ljava/util/UUID;
    //   531: invokevirtual 563	java/util/UUID:toString	()Ljava/lang/String;
    //   534: invokevirtual 566	com/mobileapptracker/MATParameters:setMatId	(Ljava/lang/String;)V
    //   537: iconst_1
    //   538: istore 9
    //   540: aload_0
    //   541: monitorexit
    //   542: iload 9
    //   544: ireturn
    //   545: astore 10
    //   547: aload_0
    //   548: ldc_w 568
    //   551: invokevirtual 363	com/mobileapptracker/MATParameters:setAppVersion	(Ljava/lang/String;)V
    //   554: goto -340 -> 214
    //   557: astore_1
    //   558: ldc_w 570
    //   561: ldc_w 572
    //   564: invokestatic 578	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   567: pop
    //   568: aload_1
    //   569: checkcast 234	java/lang/Exception
    //   572: invokevirtual 581	java/lang/Exception:printStackTrace	()V
    //   575: iconst_0
    //   576: istore 9
    //   578: goto -38 -> 540
    //   581: getstatic 450	android/os/Build$VERSION:SDK_INT	I
    //   584: bipush 13
    //   586: if_icmplt +23 -> 609
    //   589: aload_2
    //   590: aload_3
    //   591: invokevirtual 584	android/view/Display:getSize	(Landroid/graphics/Point;)V
    //   594: aload_3
    //   595: getfield 459	android/graphics/Point:x	I
    //   598: istore 5
    //   600: aload_3
    //   601: getfield 462	android/graphics/Point:y	I
    //   604: istore 6
    //   606: goto -270 -> 336
    //   609: aload_2
    //   610: invokevirtual 587	android/view/Display:getWidth	()I
    //   613: istore 5
    //   615: aload_2
    //   616: invokevirtual 590	android/view/Display:getHeight	()I
    //   619: istore 6
    //   621: goto -285 -> 336
    //   624: aload_0
    //   625: ldc_w 592
    //   628: invokevirtual 487	com/mobileapptracker/MATParameters:setConnectionType	(Ljava/lang/String;)V
    //   631: goto -237 -> 394
    //   634: astore_1
    //   635: aload_0
    //   636: monitorexit
    //   637: aload_1
    //   638: athrow
    //   639: aload_0
    //   640: invokestatic 493	java/util/Locale:getDefault	()Ljava/util/Locale;
    //   643: invokevirtual 502	java/util/Locale:getCountry	()Ljava/lang/String;
    //   646: invokevirtual 505	com/mobileapptracker/MATParameters:setCountryCode	(Ljava/lang/String;)V
    //   649: goto -142 -> 507
    //   652: astore_1
    //   653: goto -146 -> 507
    //   656: astore 10
    //   658: goto -481 -> 177
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	661	0	this	MATParameters
    //   0	661	1	paramContext	Context
    //   0	661	2	paramString1	String
    //   0	661	3	paramString2	String
    //   272	4	4	f	float
    //   190	424	5	i	int
    //   334	286	6	j	int
    //   144	26	7	l	long
    //   380	197	9	bool	boolean
    //   123	87	10	localObject	Object
    //   545	1	10	localNameNotFoundException1	android.content.pm.PackageManager.NameNotFoundException
    //   656	1	10	localNameNotFoundException2	android.content.pm.PackageManager.NameNotFoundException
    // Exception table:
    //   from	to	target	type
    //   177	185	545	android/content/pm/PackageManager$NameNotFoundException
    //   192	201	545	android/content/pm/PackageManager$NameNotFoundException
    //   208	214	545	android/content/pm/PackageManager$NameNotFoundException
    //   2	24	557	java/lang/Exception
    //   24	43	557	java/lang/Exception
    //   43	54	557	java/lang/Exception
    //   59	73	557	java/lang/Exception
    //   78	88	557	java/lang/Exception
    //   93	98	557	java/lang/Exception
    //   98	125	557	java/lang/Exception
    //   132	146	557	java/lang/Exception
    //   146	160	557	java/lang/Exception
    //   168	177	557	java/lang/Exception
    //   177	185	557	java/lang/Exception
    //   192	201	557	java/lang/Exception
    //   208	214	557	java/lang/Exception
    //   214	223	557	java/lang/Exception
    //   227	232	557	java/lang/Exception
    //   236	251	557	java/lang/Exception
    //   255	268	557	java/lang/Exception
    //   274	291	557	java/lang/Exception
    //   296	303	557	java/lang/Exception
    //   303	311	557	java/lang/Exception
    //   319	324	557	java/lang/Exception
    //   336	354	557	java/lang/Exception
    //   359	367	557	java/lang/Exception
    //   372	382	557	java/lang/Exception
    //   387	394	557	java/lang/Exception
    //   394	418	557	java/lang/Exception
    //   422	441	557	java/lang/Exception
    //   450	455	557	java/lang/Exception
    //   459	467	557	java/lang/Exception
    //   467	480	557	java/lang/Exception
    //   484	507	557	java/lang/Exception
    //   507	512	557	java/lang/Exception
    //   516	522	557	java/lang/Exception
    //   527	537	557	java/lang/Exception
    //   547	554	557	java/lang/Exception
    //   589	594	557	java/lang/Exception
    //   609	621	557	java/lang/Exception
    //   624	631	557	java/lang/Exception
    //   639	649	557	java/lang/Exception
    //   2	24	634	java/lang/Throwable
    //   24	43	634	java/lang/Throwable
    //   43	54	634	java/lang/Throwable
    //   54	59	634	java/lang/Throwable
    //   59	73	634	java/lang/Throwable
    //   73	78	634	java/lang/Throwable
    //   78	88	634	java/lang/Throwable
    //   93	98	634	java/lang/Throwable
    //   98	125	634	java/lang/Throwable
    //   125	132	634	java/lang/Throwable
    //   132	146	634	java/lang/Throwable
    //   146	160	634	java/lang/Throwable
    //   168	177	634	java/lang/Throwable
    //   177	185	634	java/lang/Throwable
    //   185	192	634	java/lang/Throwable
    //   192	201	634	java/lang/Throwable
    //   208	214	634	java/lang/Throwable
    //   214	223	634	java/lang/Throwable
    //   223	227	634	java/lang/Throwable
    //   227	232	634	java/lang/Throwable
    //   232	236	634	java/lang/Throwable
    //   236	251	634	java/lang/Throwable
    //   251	255	634	java/lang/Throwable
    //   255	268	634	java/lang/Throwable
    //   268	274	634	java/lang/Throwable
    //   274	291	634	java/lang/Throwable
    //   291	296	634	java/lang/Throwable
    //   296	303	634	java/lang/Throwable
    //   303	311	634	java/lang/Throwable
    //   311	319	634	java/lang/Throwable
    //   319	324	634	java/lang/Throwable
    //   324	336	634	java/lang/Throwable
    //   336	354	634	java/lang/Throwable
    //   354	359	634	java/lang/Throwable
    //   359	367	634	java/lang/Throwable
    //   367	372	634	java/lang/Throwable
    //   372	382	634	java/lang/Throwable
    //   387	394	634	java/lang/Throwable
    //   394	418	634	java/lang/Throwable
    //   418	422	634	java/lang/Throwable
    //   422	441	634	java/lang/Throwable
    //   441	446	634	java/lang/Throwable
    //   450	455	634	java/lang/Throwable
    //   459	467	634	java/lang/Throwable
    //   467	480	634	java/lang/Throwable
    //   484	507	634	java/lang/Throwable
    //   507	512	634	java/lang/Throwable
    //   516	522	634	java/lang/Throwable
    //   527	537	634	java/lang/Throwable
    //   547	554	634	java/lang/Throwable
    //   558	575	634	java/lang/Throwable
    //   581	589	634	java/lang/Throwable
    //   589	594	634	java/lang/Throwable
    //   594	606	634	java/lang/Throwable
    //   609	621	634	java/lang/Throwable
    //   624	631	634	java/lang/Throwable
    //   639	649	634	java/lang/Throwable
    //   484	507	652	java/lang/IndexOutOfBoundsException
    //   98	125	656	android/content/pm/PackageManager$NameNotFoundException
    //   132	146	656	android/content/pm/PackageManager$NameNotFoundException
    //   146	160	656	android/content/pm/PackageManager$NameNotFoundException
    //   168	177	656	android/content/pm/PackageManager$NameNotFoundException
  }
  
  private void setUserAgent(String paramString)
  {
    mUserAgent = paramString;
  }
  
  public void clear()
  {
    INSTANCE = null;
  }
  
  public String getAction()
  {
    try
    {
      String str = mAction;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getAdvertiserId()
  {
    try
    {
      String str = mAdvertiserId;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getAge()
  {
    try
    {
      String str = mAge;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getAllowDuplicates()
  {
    try
    {
      String str = mAllowDups;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getAltitude()
  {
    try
    {
      String str = mAltitude;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getAndroidId()
  {
    try
    {
      String str = mAndroidId;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getAndroidIdMd5()
  {
    try
    {
      String str = mAndroidIdMd5;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getAndroidIdSha1()
  {
    try
    {
      String str = mAndroidIdSha1;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getAndroidIdSha256()
  {
    try
    {
      String str = mAndroidIdSha256;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getAppAdTrackingEnabled()
  {
    try
    {
      String str = mAppAdTracking;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getAppName()
  {
    try
    {
      String str = mAppName;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getAppVersion()
  {
    try
    {
      String str = mAppVersion;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getAppVersionName()
  {
    try
    {
      String str = mAppVersionName;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getConnectionType()
  {
    try
    {
      String str = mConnectionType;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getConversionKey()
  {
    try
    {
      String str = mConversionKey;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getCountryCode()
  {
    try
    {
      String str = mCountryCode;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getCurrencyCode()
  {
    try
    {
      String str = mCurrencyCode;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public boolean getDebugMode()
  {
    try
    {
      boolean bool = mDebugMode;
      return bool;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getDeviceBrand()
  {
    try
    {
      String str = mDeviceBrand;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getDeviceCarrier()
  {
    try
    {
      String str = mDeviceCarrier;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getDeviceCpuSubtype()
  {
    try
    {
      String str = mDeviceCpuSubtype;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getDeviceCpuType()
  {
    try
    {
      String str = mDeviceCpuType;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getDeviceId()
  {
    try
    {
      String str = mDeviceId;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getDeviceModel()
  {
    try
    {
      String str = mDeviceModel;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getExistingUser()
  {
    try
    {
      String str = mExistingUser;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getFacebookUserId()
  {
    try
    {
      String str = mFbUserId;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getGender()
  {
    try
    {
      String str = mGender;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getGoogleAdTrackingLimited()
  {
    try
    {
      String str = mGaidLimited;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getGoogleAdvertisingId()
  {
    try
    {
      String str = mGaid;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getGoogleUserId()
  {
    try
    {
      String str = mGgUserId;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getInstallDate()
  {
    try
    {
      String str = mInstallDate;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getInstallReferrer()
  {
    try
    {
      String str = MATUtils.getStringFromSharedPreferences(mContext, "mat_referrer");
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getInstaller()
  {
    try
    {
      String str = mInstallerPackage;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getIsPayingUser()
  {
    try
    {
      String str = MATUtils.getStringFromSharedPreferences(mContext, "mat_is_paying_user");
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getLanguage()
  {
    try
    {
      String str = mLanguage;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getLastOpenLogId()
  {
    try
    {
      String str = MATUtils.getStringFromSharedPreferences(mContext, "mat_log_id_last_open");
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getLatitude()
  {
    try
    {
      String str = mLatitude;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public Location getLocation()
  {
    try
    {
      Location localLocation = mLocation;
      return localLocation;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getLongitude()
  {
    try
    {
      String str = mLongitude;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getMCC()
  {
    try
    {
      String str = mMCC;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getMNC()
  {
    try
    {
      String str = mMNC;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getMacAddress()
  {
    try
    {
      String str = mMacAddress;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  /* Error */
  public String getMatId()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 228	com/mobileapptracker/MATParameters:mContext	Landroid/content/Context;
    //   6: ldc_w 649
    //   9: iconst_0
    //   10: invokevirtual 653	android/content/Context:getSharedPreferences	(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   13: ldc_w 649
    //   16: invokeinterface 659 2 0
    //   21: ifeq +30 -> 51
    //   24: aload_0
    //   25: getfield 228	com/mobileapptracker/MATParameters:mContext	Landroid/content/Context;
    //   28: ldc_w 649
    //   31: iconst_0
    //   32: invokevirtual 653	android/content/Context:getSharedPreferences	(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   35: ldc_w 649
    //   38: ldc_w 661
    //   41: invokeinterface 665 3 0
    //   46: astore_1
    //   47: aload_0
    //   48: monitorexit
    //   49: aload_1
    //   50: areturn
    //   51: aload_0
    //   52: getfield 228	com/mobileapptracker/MATParameters:mContext	Landroid/content/Context;
    //   55: ldc_w 649
    //   58: invokestatic 633	com/mobileapptracker/MATUtils:getStringFromSharedPreferences	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   61: astore_1
    //   62: goto -15 -> 47
    //   65: astore_1
    //   66: aload_0
    //   67: monitorexit
    //   68: aload_1
    //   69: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	70	0	this	MATParameters
    //   46	16	1	str	String
    //   65	4	1	localThrowable	Throwable
    // Exception table:
    //   from	to	target	type
    //   2	47	65	java/lang/Throwable
    //   51	62	65	java/lang/Throwable
  }
  
  public String getOpenLogId()
  {
    try
    {
      String str = MATUtils.getStringFromSharedPreferences(mContext, "mat_log_id_open");
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getOsVersion()
  {
    try
    {
      String str = mOsVersion;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getPackageName()
  {
    try
    {
      String str = mPackageName;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getPhoneNumber()
  {
    try
    {
      String str = MATUtils.getStringFromSharedPreferences(mContext, "mat_phone_number");
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getPhoneNumberMd5()
  {
    try
    {
      String str = mPhoneNumberMd5;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getPhoneNumberSha1()
  {
    try
    {
      String str = mPhoneNumberSha1;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getPhoneNumberSha256()
  {
    try
    {
      String str = mPhoneNumberSha256;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getPluginName()
  {
    try
    {
      String str = mPluginName;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getPurchaseStatus()
  {
    try
    {
      String str = mPurchaseStatus;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getRefId()
  {
    try
    {
      String str = mRefId;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getReferralSource()
  {
    try
    {
      String str = mReferralSource;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getReferralUrl()
  {
    try
    {
      String str = mReferralUrl;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getReferrerDelay()
  {
    try
    {
      String str = mReferrerDelay;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getRevenue()
  {
    try
    {
      String str = mRevenue;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getScreenDensity()
  {
    try
    {
      String str = mScreenDensity;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getScreenHeight()
  {
    try
    {
      String str = mScreenHeight;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getScreenWidth()
  {
    try
    {
      String str = mScreenWidth;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getSdkVersion()
  {
    return "3.11.0";
  }
  
  public String getSiteId()
  {
    try
    {
      String str = mSiteId;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getTRUSTeId()
  {
    try
    {
      String str = mTrusteId;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getTimeZone()
  {
    try
    {
      String str = mTimeZone;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getTrackingId()
  {
    try
    {
      String str = mTrackingId;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getTwitterUserId()
  {
    try
    {
      String str = mTwUserId;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getUserAgent()
  {
    try
    {
      String str = mUserAgent;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getUserEmail()
  {
    try
    {
      String str = MATUtils.getStringFromSharedPreferences(mContext, "mat_user_email");
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getUserEmailMd5()
  {
    try
    {
      String str = mUserEmailMd5;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getUserEmailSha1()
  {
    try
    {
      String str = mUserEmailSha1;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getUserEmailSha256()
  {
    try
    {
      String str = mUserEmailSha256;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public JSONArray getUserEmails()
  {
    try
    {
      JSONArray localJSONArray = mUserEmails;
      return localJSONArray;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getUserId()
  {
    try
    {
      String str = MATUtils.getStringFromSharedPreferences(mContext, "mat_user_id");
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getUserName()
  {
    try
    {
      String str = MATUtils.getStringFromSharedPreferences(mContext, "mat_user_name");
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getUserNameMd5()
  {
    try
    {
      String str = mUserNameMd5;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getUserNameSha1()
  {
    try
    {
      String str = mUserNameSha1;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public String getUserNameSha256()
  {
    try
    {
      String str = mUserNameSha256;
      return str;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public void setAction(String paramString)
  {
    try
    {
      mAction = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setAdvertiserId(String paramString)
  {
    try
    {
      mAdvertiserId = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setAge(String paramString)
  {
    try
    {
      mAge = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setAllowDuplicates(String paramString)
  {
    try
    {
      mAllowDups = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setAltitude(String paramString)
  {
    try
    {
      mAltitude = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setAndroidId(String paramString)
  {
    try
    {
      mAndroidId = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setAndroidIdMd5(String paramString)
  {
    try
    {
      mAndroidIdMd5 = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setAndroidIdSha1(String paramString)
  {
    try
    {
      mAndroidIdSha1 = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setAndroidIdSha256(String paramString)
  {
    try
    {
      mAndroidIdSha256 = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setAppAdTrackingEnabled(String paramString)
  {
    try
    {
      mAppAdTracking = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setAppName(String paramString)
  {
    try
    {
      mAppName = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setAppVersion(String paramString)
  {
    try
    {
      mAppVersion = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setAppVersionName(String paramString)
  {
    try
    {
      mAppVersionName = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setConnectionType(String paramString)
  {
    try
    {
      mConnectionType = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setConversionKey(String paramString)
  {
    try
    {
      mConversionKey = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setCountryCode(String paramString)
  {
    try
    {
      mCountryCode = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setCurrencyCode(String paramString)
  {
    try
    {
      mCurrencyCode = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setDebugMode(boolean paramBoolean)
  {
    try
    {
      mDebugMode = paramBoolean;
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public void setDeviceBrand(String paramString)
  {
    try
    {
      mDeviceBrand = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setDeviceCarrier(String paramString)
  {
    try
    {
      mDeviceCarrier = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setDeviceCpuSubtype(String paramString)
  {
    try
    {
      mDeviceCpuSubtype = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setDeviceCpuType(String paramString)
  {
    try
    {
      mDeviceCpuType = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setDeviceId(String paramString)
  {
    try
    {
      mDeviceId = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setDeviceModel(String paramString)
  {
    try
    {
      mDeviceModel = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setExistingUser(String paramString)
  {
    try
    {
      mExistingUser = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setFacebookUserId(String paramString)
  {
    try
    {
      mFbUserId = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setGender(MATGender paramMATGender)
  {
    for (;;)
    {
      try
      {
        if (paramMATGender == MATGender.MALE)
        {
          mGender = "0";
          return;
        }
        if (paramMATGender == MATGender.FEMALE) {
          mGender = "1";
        } else {
          mGender = "";
        }
      }
      catch (Throwable paramMATGender)
      {
        throw paramMATGender;
      }
    }
  }
  
  public void setGoogleAdTrackingLimited(String paramString)
  {
    try
    {
      mGaidLimited = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setGoogleAdvertisingId(String paramString)
  {
    try
    {
      mGaid = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setGoogleUserId(String paramString)
  {
    try
    {
      mGgUserId = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setInstallDate(String paramString)
  {
    try
    {
      mInstallDate = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setInstallReferrer(String paramString)
  {
    try
    {
      MATUtils.saveToSharedPreferences(mContext, "mat_referrer", paramString);
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setInstaller(String paramString)
  {
    try
    {
      mInstallerPackage = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setIsPayingUser(String paramString)
  {
    try
    {
      MATUtils.saveToSharedPreferences(mContext, "mat_is_paying_user", paramString);
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setLanguage(String paramString)
  {
    try
    {
      mLanguage = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setLastOpenLogId(String paramString)
  {
    try
    {
      MATUtils.saveToSharedPreferences(mContext, "mat_log_id_last_open", paramString);
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setLatitude(String paramString)
  {
    try
    {
      mLatitude = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setLocation(Location paramLocation)
  {
    try
    {
      mLocation = paramLocation;
      return;
    }
    catch (Throwable paramLocation)
    {
      throw paramLocation;
    }
  }
  
  public void setLongitude(String paramString)
  {
    try
    {
      mLongitude = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setMCC(String paramString)
  {
    try
    {
      mMCC = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setMNC(String paramString)
  {
    try
    {
      mMNC = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setMacAddress(String paramString)
  {
    try
    {
      mMacAddress = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setMatId(String paramString)
  {
    try
    {
      MATUtils.saveToSharedPreferences(mContext, "mat_id", paramString);
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setOpenLogId(String paramString)
  {
    try
    {
      MATUtils.saveToSharedPreferences(mContext, "mat_log_id_open", paramString);
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setOsVersion(String paramString)
  {
    try
    {
      mOsVersion = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setPackageName(String paramString)
  {
    try
    {
      mPackageName = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setPhoneNumber(String paramString)
  {
    try
    {
      MATUtils.saveToSharedPreferences(mContext, "mat_phone_number", paramString);
      setPhoneNumberMd5(MATUtils.md5(paramString));
      setPhoneNumberSha1(MATUtils.sha1(paramString));
      setPhoneNumberSha256(MATUtils.sha256(paramString));
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setPhoneNumberMd5(String paramString)
  {
    try
    {
      mPhoneNumberMd5 = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setPhoneNumberSha1(String paramString)
  {
    try
    {
      mPhoneNumberSha1 = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setPhoneNumberSha256(String paramString)
  {
    try
    {
      mPhoneNumberSha256 = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setPluginName(String paramString)
  {
    try
    {
      mPluginName = null;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setPurchaseStatus(String paramString)
  {
    try
    {
      mPurchaseStatus = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setRefId(String paramString)
  {
    try
    {
      mRefId = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setReferralSource(String paramString)
  {
    try
    {
      mReferralSource = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setReferralUrl(String paramString)
  {
    try
    {
      mReferralUrl = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setReferrerDelay(long paramLong)
  {
    try
    {
      mReferrerDelay = Long.toString(paramLong);
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public void setRevenue(String paramString)
  {
    try
    {
      mRevenue = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setScreenDensity(String paramString)
  {
    try
    {
      mScreenDensity = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setScreenHeight(String paramString)
  {
    try
    {
      mScreenHeight = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setScreenWidth(String paramString)
  {
    try
    {
      mScreenWidth = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setSiteId(String paramString)
  {
    try
    {
      mSiteId = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setTRUSTeId(String paramString)
  {
    try
    {
      mTrusteId = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setTimeZone(String paramString)
  {
    try
    {
      mTimeZone = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setTrackingId(String paramString)
  {
    try
    {
      mTrackingId = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setTwitterUserId(String paramString)
  {
    try
    {
      mTwUserId = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setUserEmail(String paramString)
  {
    try
    {
      MATUtils.saveToSharedPreferences(mContext, "mat_user_email", paramString);
      setUserEmailMd5(MATUtils.md5(paramString));
      setUserEmailSha1(MATUtils.sha1(paramString));
      setUserEmailSha256(MATUtils.sha256(paramString));
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setUserEmailMd5(String paramString)
  {
    try
    {
      mUserEmailMd5 = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setUserEmailSha1(String paramString)
  {
    try
    {
      mUserEmailSha1 = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setUserEmailSha256(String paramString)
  {
    try
    {
      mUserEmailSha256 = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  /* Error */
  public void setUserEmails(String[] paramArrayOfString)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: new 817	org/json/JSONArray
    //   6: dup
    //   7: invokespecial 818	org/json/JSONArray:<init>	()V
    //   10: putfield 211	com/mobileapptracker/MATParameters:mUserEmails	Lorg/json/JSONArray;
    //   13: iconst_0
    //   14: istore_2
    //   15: aload_1
    //   16: arraylength
    //   17: istore_3
    //   18: iload_2
    //   19: iload_3
    //   20: if_icmplt +6 -> 26
    //   23: aload_0
    //   24: monitorexit
    //   25: return
    //   26: aload_0
    //   27: getfield 211	com/mobileapptracker/MATParameters:mUserEmails	Lorg/json/JSONArray;
    //   30: aload_1
    //   31: iload_2
    //   32: aaload
    //   33: invokevirtual 822	org/json/JSONArray:put	(Ljava/lang/Object;)Lorg/json/JSONArray;
    //   36: pop
    //   37: iload_2
    //   38: iconst_1
    //   39: iadd
    //   40: istore_2
    //   41: goto -26 -> 15
    //   44: astore_1
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	49	0	this	MATParameters
    //   0	49	1	paramArrayOfString	String[]
    //   14	27	2	i	int
    //   17	4	3	j	int
    // Exception table:
    //   from	to	target	type
    //   2	13	44	java/lang/Throwable
    //   15	18	44	java/lang/Throwable
    //   26	37	44	java/lang/Throwable
  }
  
  public void setUserId(String paramString)
  {
    try
    {
      MATUtils.saveToSharedPreferences(mContext, "mat_user_id", paramString);
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setUserName(String paramString)
  {
    try
    {
      MATUtils.saveToSharedPreferences(mContext, "mat_user_name", paramString);
      setUserNameMd5(MATUtils.md5(paramString));
      setUserNameSha1(MATUtils.sha1(paramString));
      setUserNameSha256(MATUtils.sha256(paramString));
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setUserNameMd5(String paramString)
  {
    try
    {
      mUserNameMd5 = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setUserNameSha1(String paramString)
  {
    try
    {
      mUserNameSha1 = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  public void setUserNameSha256(String paramString)
  {
    try
    {
      mUserNameSha256 = paramString;
      return;
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
  }
  
  private class GetGAID
    implements Runnable
  {
    private final WeakReference<Context> weakContext;
    
    public GetGAID(Context paramContext)
    {
      weakContext = new WeakReference(paramContext);
    }
    
    public void run()
    {
      int i = 1;
      try
      {
        Object localObject1 = Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient");
        localObject1 = ((Class)localObject1).getDeclaredMethod("getAdvertisingIdInfo", new Class[] { Context.class });
        Object localObject2 = weakContext;
        localObject2 = ((WeakReference)localObject2).get();
        localObject2 = ((Method)localObject1).invoke(null, new Object[] { localObject2 });
        localObject1 = Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient$Info");
        localObject1 = ((Class)localObject1).getDeclaredMethod("getId", new Class[0]);
        localObject1 = ((Method)localObject1).invoke(localObject2, new Object[0]);
        localObject1 = (String)localObject1;
        Object localObject3 = Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient$Info");
        localObject3 = ((Class)localObject3).getDeclaredMethod("isLimitAdTrackingEnabled", new Class[0]);
        localObject2 = ((Method)localObject3).invoke(localObject2, new Object[0]);
        localObject2 = (Boolean)localObject2;
        boolean bool = ((Boolean)localObject2).booleanValue();
        localObject2 = MATParameters.this;
        localObject2 = mTune;
        if (params == null)
        {
          localObject2 = MATParameters.this;
          ((MATParameters)localObject2).setGoogleAdvertisingId((String)localObject1);
          if (!bool) {
            break label201;
          }
        }
        for (;;)
        {
          localObject2 = MATParameters.this;
          ((MATParameters)localObject2).setGoogleAdTrackingLimited(Integer.toString(i));
          localObject2 = MATParameters.this;
          mTune.setGoogleAdvertisingId((String)localObject1, bool);
          return;
          label201:
          i = 0;
        }
        return;
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        Log.d("MobileAppTracker", "MAT SDK failed to get Google Advertising Id, collecting ANDROID_ID instead");
        if (mTune.params == null) {
          setAndroidId(Settings.Secure.getString(((Context)weakContext.get()).getContentResolver(), "android_id"));
        }
        mTune.setAndroidId(Settings.Secure.getString(((Context)weakContext.get()).getContentResolver(), "android_id"));
      }
    }
  }
  
  private class GetUserAgent
    implements Runnable
  {
    private final WeakReference<Context> weakContext;
    
    public GetUserAgent(Context paramContext)
    {
      weakContext = new WeakReference(paramContext);
    }
    
    public void run()
    {
      try
      {
        Object localObject1 = weakContext;
        Object localObject2;
        return;
      }
      catch (VerifyError localVerifyError)
      {
        try
        {
          localObject1 = ((WeakReference)localObject1).get();
          localObject1 = (Context)localObject1;
          localObject2 = new WebView((Context)localObject1);
          localObject1 = ((WebView)localObject2).getSettings().getUserAgentString();
          ((WebView)localObject2).destroy();
          localObject2 = MATParameters.this;
          ((MATParameters)localObject2).setUserAgent((String)localObject1);
          return;
        }
        catch (Exception localException) {}
        localVerifyError = localVerifyError;
        return;
      }
    }
  }
}
