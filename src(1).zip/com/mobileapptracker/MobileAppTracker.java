package com.mobileapptracker;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.Patterns;
import android.widget.Toast;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MobileAppTracker
{
  private static volatile MobileAppTracker tune = null;
  private final String SAVEFILE = "heF9BATUfWuISyO8";
  private boolean debugMode;
  private MATDeferredDplinkr dplinkr;
  private MATEncryption encryption;
  protected MATEventQueue eventQueue;
  private boolean fbLogging;
  private boolean firstSession;
  boolean gotGaid;
  boolean gotReferrer;
  private long initTime;
  protected boolean initialized;
  protected boolean isRegistered;
  protected Context mContext;
  private MATPreloadData mPreloadData;
  protected BroadcastReceiver networkStateReceiver;
  boolean notifiedPool;
  protected MATParameters params;
  ExecutorService pool;
  protected ExecutorService pubQueue;
  private long referrerTime;
  private MATResponse tuneListener;
  protected MATTestRequest tuneRequest;
  private MATUrlRequester urlRequester;
  
  protected MobileAppTracker() {}
  
  private boolean firstInstall()
  {
    SharedPreferences localSharedPreferences = mContext.getSharedPreferences("com.mobileapptracking", 0);
    if (localSharedPreferences.contains("mat_installed")) {
      return false;
    }
    localSharedPreferences.edit().putBoolean("mat_installed", true).commit();
    return true;
  }
  
  public static MobileAppTracker getInstance()
  {
    try
    {
      MobileAppTracker localMobileAppTracker = tune;
      return localMobileAppTracker;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public static MobileAppTracker init(Context paramContext, String paramString1, String paramString2)
  {
    try
    {
      if (tune == null)
      {
        tune = new MobileAppTracker();
        tunemContext = paramContext.getApplicationContext();
        tunepubQueue = Executors.newSingleThreadExecutor();
        tune.initAll(paramString1, paramString2);
      }
      paramContext = tune;
      return paramContext;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  private void initLocalVariables(String paramString)
  {
    pool = Executors.newSingleThreadExecutor();
    urlRequester = new MATUrlRequester();
    encryption = new MATEncryption(paramString.trim(), "heF9BATUfWuISyO8");
    initTime = System.currentTimeMillis();
    if (mContext.getSharedPreferences("com.mobileapptracking", 0).getString("mat_referrer", "").equals("")) {}
    for (boolean bool = false;; bool = true)
    {
      gotReferrer = bool;
      firstSession = true;
      initialized = false;
      isRegistered = false;
      debugMode = false;
      fbLogging = false;
      return;
    }
  }
  
  public static boolean isOnline(Context paramContext)
  {
    paramContext = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getActiveNetworkInfo();
    return (paramContext != null) && (paramContext.isConnected());
  }
  
  private void measure(MATEvent paramMATEvent)
  {
    for (;;)
    {
      int i;
      try
      {
        boolean bool = initialized;
        if (!bool) {
          return;
        }
        dumpQueue();
        params.setAction("conversion");
        Object localObject1 = new Date();
        if (paramMATEvent.getEventName() != null)
        {
          str = paramMATEvent.getEventName();
          if (fbLogging) {
            MATFBBridge.logEvent(paramMATEvent);
          }
          if (str.equals("close")) {
            continue;
          }
          if ((str.equals("open")) || (str.equals("install")) || (str.equals("update")) || (str.equals("session")))
          {
            params.setAction("session");
            new Date(((Date)localObject1).getTime() + 60000L);
          }
        }
        if (paramMATEvent.getRevenue() > 0.0D) {
          params.setIsPayingUser("1");
        }
        localObject1 = MATUrlBuilder.buildLink(paramMATEvent, mPreloadData, debugMode);
        String str = MATUrlBuilder.buildDataUnencrypted(paramMATEvent);
        Object localObject2 = new JSONArray();
        if (paramMATEvent.getEventItems() != null)
        {
          i = 0;
          if (i < paramMATEvent.getEventItems().size()) {}
        }
        else
        {
          localObject2 = MATUrlBuilder.buildBody((JSONArray)localObject2, paramMATEvent.getReceiptData(), paramMATEvent.getReceiptSignature(), params.getUserEmails());
          if (tuneRequest != null) {
            tuneRequest.constructedRequest((String)localObject1, str, (JSONObject)localObject2);
          }
          addEventToQueue((String)localObject1, str, (JSONObject)localObject2, firstSession);
          firstSession = false;
          dumpQueue();
          if (tuneListener == null) {
            continue;
          }
          tuneListener.enqueuedActionWithRefId(paramMATEvent.getRefId());
          continue;
        }
        ((JSONArray)localObject2).put(((MATEventItem)paramMATEvent.getEventItems().get(i)).toJSON());
      }
      catch (Throwable paramMATEvent)
      {
        throw paramMATEvent;
      }
      i += 1;
    }
  }
  
  private void requestDeeplink()
  {
    if (dplinkr.isEnabled())
    {
      dplinkr.setUserAgent(params.getUserAgent());
      dplinkr.checkForDeferredDeeplink(mContext, urlRequester);
    }
  }
  
  protected void addEventToQueue(String paramString1, String paramString2, JSONObject paramJSONObject, boolean paramBoolean)
  {
    ExecutorService localExecutorService = pool;
    MATEventQueue localMATEventQueue = eventQueue;
    localMATEventQueue.getClass();
    localExecutorService.execute(new MATEventQueue.Add(localMATEventQueue, paramString1, paramString2, paramJSONObject, paramBoolean));
  }
  
  public void checkForDeferredDeeplink(MATDeeplinkListener paramMATDeeplinkListener)
  {
    setDeeplinkListener(paramMATDeeplinkListener);
    if (firstInstall()) {
      dplinkr.enable(true);
    }
    while ((dplinkr.getGoogleAdvertisingId() != null) || (dplinkr.getAndroidId() != null))
    {
      requestDeeplink();
      return;
      dplinkr.enable(false);
    }
  }
  
  protected void dumpQueue()
  {
    if (!isOnline(mContext)) {
      return;
    }
    ExecutorService localExecutorService = pool;
    MATEventQueue localMATEventQueue = eventQueue;
    localMATEventQueue.getClass();
    localExecutorService.execute(new MATEventQueue.Dump(localMATEventQueue));
  }
  
  public String getAction()
  {
    return params.getAction();
  }
  
  public String getAdvertiserId()
  {
    return params.getAdvertiserId();
  }
  
  public int getAge()
  {
    return Integer.parseInt(params.getAge());
  }
  
  public double getAltitude()
  {
    return Double.parseDouble(params.getAltitude());
  }
  
  public String getAndroidId()
  {
    return params.getAndroidId();
  }
  
  public boolean getAppAdTrackingEnabled()
  {
    return Integer.parseInt(params.getAppAdTrackingEnabled()) == 1;
  }
  
  public String getAppName()
  {
    return params.getAppName();
  }
  
  public int getAppVersion()
  {
    return Integer.parseInt(params.getAppVersion());
  }
  
  public String getConnectionType()
  {
    return params.getConnectionType();
  }
  
  public String getCountryCode()
  {
    return params.getCountryCode();
  }
  
  public String getCurrencyCode()
  {
    return params.getCurrencyCode();
  }
  
  public String getDeviceBrand()
  {
    return params.getDeviceBrand();
  }
  
  public String getDeviceCarrier()
  {
    return params.getDeviceCarrier();
  }
  
  public String getDeviceId()
  {
    return params.getDeviceId();
  }
  
  public String getDeviceModel()
  {
    return params.getDeviceModel();
  }
  
  public boolean getExistingUser()
  {
    return Integer.parseInt(params.getExistingUser()) == 1;
  }
  
  public String getFacebookUserId()
  {
    return params.getFacebookUserId();
  }
  
  public int getGender()
  {
    return Integer.parseInt(params.getGender());
  }
  
  public boolean getGoogleAdTrackingLimited()
  {
    return Integer.parseInt(params.getGoogleAdTrackingLimited()) != 0;
  }
  
  public String getGoogleAdvertisingId()
  {
    return params.getGoogleAdvertisingId();
  }
  
  public String getGoogleUserId()
  {
    return params.getGoogleUserId();
  }
  
  public long getInstallDate()
  {
    return Long.parseLong(params.getInstallDate());
  }
  
  public String getInstallReferrer()
  {
    return params.getInstallReferrer();
  }
  
  public boolean getIsPayingUser()
  {
    return params.getIsPayingUser().equals("1");
  }
  
  public String getLanguage()
  {
    return params.getLanguage();
  }
  
  public String getLastOpenLogId()
  {
    return params.getLastOpenLogId();
  }
  
  public double getLatitude()
  {
    return Double.parseDouble(params.getLatitude());
  }
  
  public double getLongitude()
  {
    return Double.parseDouble(params.getLongitude());
  }
  
  public String getMCC()
  {
    return params.getMCC();
  }
  
  public String getMNC()
  {
    return params.getMNC();
  }
  
  public String getMacAddress()
  {
    return params.getMacAddress();
  }
  
  public String getMatId()
  {
    return params.getMatId();
  }
  
  public String getOpenLogId()
  {
    return params.getOpenLogId();
  }
  
  public String getOsVersion()
  {
    return params.getOsVersion();
  }
  
  public String getPackageName()
  {
    return params.getPackageName();
  }
  
  public String getPluginName()
  {
    return params.getPluginName();
  }
  
  public String getRefId()
  {
    return params.getRefId();
  }
  
  public String getReferralSource()
  {
    return params.getReferralSource();
  }
  
  public String getReferralUrl()
  {
    return params.getReferralUrl();
  }
  
  public Double getRevenue()
  {
    return Double.valueOf(Double.parseDouble(params.getRevenue()));
  }
  
  public String getSDKVersion()
  {
    return params.getSdkVersion();
  }
  
  public String getScreenDensity()
  {
    return params.getScreenDensity();
  }
  
  public String getScreenHeight()
  {
    return params.getScreenHeight();
  }
  
  public String getScreenWidth()
  {
    return params.getScreenWidth();
  }
  
  public String getSiteId()
  {
    return params.getSiteId();
  }
  
  public String getTRUSTeId()
  {
    return params.getTRUSTeId();
  }
  
  public String getTwitterUserId()
  {
    return params.getTwitterUserId();
  }
  
  public String getUserAgent()
  {
    return params.getUserAgent();
  }
  
  public String getUserEmail()
  {
    return params.getUserEmail();
  }
  
  public String getUserId()
  {
    return params.getUserId();
  }
  
  public String getUserName()
  {
    return params.getUserName();
  }
  
  protected void initAll(String paramString1, String paramString2)
  {
    dplinkr = MATDeferredDplinkr.initialize(paramString1, paramString2, mContext.getPackageName());
    params = MATParameters.init(this, mContext, paramString1, paramString2);
    initLocalVariables(paramString2);
    eventQueue = new MATEventQueue(mContext, this);
    dumpQueue();
    networkStateReceiver = new BroadcastReceiver()
    {
      public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
      {
        if (isRegistered) {
          dumpQueue();
        }
      }
    };
    if (isRegistered)
    {
      paramString1 = mContext;
      paramString2 = networkStateReceiver;
    }
    try
    {
      paramString1.unregisterReceiver(paramString2);
      isRegistered = false;
      paramString1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
      mContext.registerReceiver(networkStateReceiver, paramString1);
      isRegistered = true;
      initialized = true;
      return;
    }
    catch (IllegalArgumentException paramString1)
    {
      for (;;) {}
    }
  }
  
  protected boolean makeRequest(String paramString1, String paramString2, JSONObject paramJSONObject)
  {
    if (debugMode) {
      Log.d("MobileAppTracker", "Sending event to server...");
    }
    paramString2 = MATUrlBuilder.updateAndEncryptData(paramString2, encryption);
    paramString1 = MATUrlRequester.requestUrl(paramString1 + "&data=" + paramString2, paramJSONObject, debugMode);
    if (paramString1 == null)
    {
      if (tuneListener != null)
      {
        tuneListener.didFailWithError(paramString1);
        return true;
      }
    }
    else
    {
      if (!paramString1.has("success"))
      {
        if (debugMode) {
          Log.d("MobileAppTracker", "Request failed, event will remain in queue");
        }
        return false;
      }
      int i;
      if (tuneListener != null) {
        i = 0;
      }
      for (;;)
      {
        try
        {
          boolean bool = paramString1.getString("success").equals("true");
          if (bool) {
            i = 1;
          }
          if (i != 0)
          {
            tuneListener.didSucceedWithData(paramString1);
            try
            {
              bool = paramString1.getString("site_event_type").equals("open");
              if (!bool) {
                break;
              }
              paramString1 = paramString1.getString("log_id");
              bool = getOpenLogId().equals("");
              if (bool)
              {
                paramString2 = params;
                paramString2.setOpenLogId(paramString1);
              }
              paramString2 = params;
              paramString2.setLastOpenLogId(paramString1);
              return true;
            }
            catch (JSONException paramString1)
            {
              return true;
            }
          }
          tuneListener.didFailWithError(paramString1);
        }
        catch (JSONException paramString1)
        {
          paramString1.printStackTrace();
          return false;
        }
      }
    }
    return true;
  }
  
  public void measureEvent(int paramInt)
  {
    measureEvent(new MATEvent(paramInt));
  }
  
  public void measureEvent(final MATEvent paramMATEvent)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        MobileAppTracker.this.measure(paramMATEvent);
      }
    });
  }
  
  public void measureEvent(String paramString)
  {
    measureEvent(new MATEvent(paramString));
  }
  
  public void measureSession()
  {
    notifiedPool = false;
    measureEvent(new MATEvent("session"));
  }
  
  public void setAdvertiserId(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setAdvertiserId(paramString);
      }
    });
  }
  
  public void setAge(final int paramInt)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setAge(Integer.toString(paramInt));
      }
    });
  }
  
  public void setAllowDuplicates(final boolean paramBoolean)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        if (paramBoolean)
        {
          params.setAllowDuplicates(Integer.toString(1));
          return;
        }
        params.setAllowDuplicates(Integer.toString(0));
      }
    });
    if (paramBoolean) {
      new Handler(Looper.getMainLooper()).post(new Runnable()
      {
        public void run()
        {
          Toast.makeText(mContext, "TUNE Allow Duplicate Requests Enabled, do not release with this enabled!!", 1).show();
        }
      });
    }
  }
  
  public void setAltitude(final double paramDouble)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setAltitude(Double.toString(paramDouble));
      }
    });
  }
  
  public void setAndroidId(String paramString)
  {
    if (dplinkr != null)
    {
      dplinkr.setAndroidId(paramString);
      requestDeeplink();
    }
    if (params != null) {
      params.setAndroidId(paramString);
    }
  }
  
  public void setAndroidIdMd5(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setAndroidIdMd5(paramString);
      }
    });
  }
  
  public void setAndroidIdSha1(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setAndroidIdSha1(paramString);
      }
    });
  }
  
  public void setAndroidIdSha256(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setAndroidIdSha256(paramString);
      }
    });
  }
  
  public void setAppAdTrackingEnabled(final boolean paramBoolean)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        if (paramBoolean)
        {
          params.setAppAdTrackingEnabled(Integer.toString(1));
          return;
        }
        params.setAppAdTrackingEnabled(Integer.toString(0));
      }
    });
  }
  
  public void setConversionKey(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setConversionKey(paramString);
      }
    });
  }
  
  public void setCurrencyCode(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        if ((paramString == null) || (paramString.equals("")))
        {
          params.setCurrencyCode("USD");
          return;
        }
        params.setCurrencyCode(paramString);
      }
    });
  }
  
  public void setDebugMode(final boolean paramBoolean)
  {
    debugMode = paramBoolean;
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setDebugMode(paramBoolean);
      }
    });
    if (paramBoolean) {
      new Handler(Looper.getMainLooper()).post(new Runnable()
      {
        public void run()
        {
          Toast.makeText(mContext, "TUNE Debug Mode Enabled, do not release with this enabled!!", 1).show();
        }
      });
    }
  }
  
  public void setDeeplinkListener(MATDeeplinkListener paramMATDeeplinkListener)
  {
    dplinkr.setListener(paramMATDeeplinkListener);
  }
  
  public void setDeviceBrand(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setDeviceBrand(paramString);
      }
    });
  }
  
  public void setDeviceId(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setDeviceId(paramString);
      }
    });
  }
  
  public void setDeviceModel(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setDeviceModel(paramString);
      }
    });
  }
  
  public void setEmailCollection(final boolean paramBoolean)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        int j = 0;
        int i;
        Object localObject;
        Account[] arrayOfAccount;
        int k;
        if (mContext.checkCallingOrSelfPermission("android.permission.GET_ACCOUNTS") == 0)
        {
          i = 1;
          if ((paramBoolean) && (i != 0))
          {
            localObject = AccountManager.get(mContext).getAccountsByType("com.google");
            if (localObject.length > 0) {
              params.setUserEmail(0name);
            }
            localObject = new HashMap();
            arrayOfAccount = AccountManager.get(mContext).getAccounts();
            k = arrayOfAccount.length;
            i = j;
          }
        }
        else
        {
          for (;;)
          {
            if (i >= k)
            {
              localObject = ((HashMap)localObject).keySet();
              localObject = (String[])((Set)localObject).toArray(new String[((Set)localObject).size()]);
              params.setUserEmails((String[])localObject);
              return;
              i = 0;
              break;
            }
            Account localAccount = arrayOfAccount[i];
            if (Patterns.EMAIL_ADDRESS.matcher(name).matches()) {
              ((HashMap)localObject).put(name, type);
            }
            i += 1;
          }
        }
      }
    });
  }
  
  public void setExistingUser(final boolean paramBoolean)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        if (paramBoolean)
        {
          params.setExistingUser(Integer.toString(1));
          return;
        }
        params.setExistingUser(Integer.toString(0));
      }
    });
  }
  
  public void setFacebookEventLogging(boolean paramBoolean1, Context paramContext, boolean paramBoolean2)
  {
    fbLogging = paramBoolean1;
    if (paramBoolean1) {
      MATFBBridge.startLogger(paramContext, paramBoolean2);
    }
  }
  
  public void setFacebookUserId(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setFacebookUserId(paramString);
      }
    });
  }
  
  public void setGender(final MATGender paramMATGender)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setGender(paramMATGender);
      }
    });
  }
  
  public void setGoogleAdvertisingId(String paramString, boolean paramBoolean)
  {
    if (paramBoolean) {}
    for (int i = 1;; i = 0)
    {
      if (dplinkr != null)
      {
        dplinkr.setGoogleAdvertisingId(paramString, i);
        requestDeeplink();
      }
      if (params != null)
      {
        params.setGoogleAdvertisingId(paramString);
        params.setGoogleAdTrackingLimited(Integer.toString(i));
      }
      gotGaid = true;
      if ((!gotReferrer) || (notifiedPool)) {
        break;
      }
      paramString = pool;
      try
      {
        pool.notifyAll();
        notifiedPool = true;
        return;
      }
      catch (Throwable localThrowable)
      {
        throw localThrowable;
      }
    }
  }
  
  public void setGoogleUserId(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setGoogleUserId(paramString);
      }
    });
  }
  
  public void setInstallReferrer(final String paramString)
  {
    gotReferrer = true;
    referrerTime = System.currentTimeMillis();
    if (params != null) {
      params.setReferrerDelay(referrerTime - initTime);
    }
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setInstallReferrer(paramString);
      }
    });
  }
  
  public void setIsPayingUser(final boolean paramBoolean)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        if (paramBoolean)
        {
          params.setIsPayingUser(Integer.toString(1));
          return;
        }
        params.setIsPayingUser(Integer.toString(0));
      }
    });
  }
  
  public void setLatitude(final double paramDouble)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setLatitude(Double.toString(paramDouble));
      }
    });
  }
  
  public void setLocation(final Location paramLocation)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setLocation(paramLocation);
      }
    });
  }
  
  public void setLongitude(final double paramDouble)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setLongitude(Double.toString(paramDouble));
      }
    });
  }
  
  public void setMATResponse(MATResponse paramMATResponse)
  {
    tuneListener = paramMATResponse;
  }
  
  public void setMacAddress(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setMacAddress(paramString);
      }
    });
  }
  
  public void setOsVersion(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setOsVersion(paramString);
      }
    });
  }
  
  public void setPackageName(final String paramString)
  {
    dplinkr.setPackageName(paramString);
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        if ((paramString == null) || (paramString.equals("")))
        {
          params.setPackageName(mContext.getPackageName());
          return;
        }
        params.setPackageName(paramString);
      }
    });
  }
  
  public void setPhoneNumber(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        String str = paramString.replaceAll("\\D+", "");
        StringBuilder localStringBuilder = new StringBuilder();
        int i = 0;
        for (;;)
        {
          if (i >= str.length())
          {
            params.setPhoneNumber(localStringBuilder.toString());
            return;
          }
          localStringBuilder.append(Integer.parseInt(String.valueOf(str.charAt(i))));
          i += 1;
        }
      }
    });
  }
  
  public void setPluginName(final String paramString)
  {
    if (Arrays.asList(MATConstants.PLUGIN_NAMES).contains(paramString))
    {
      pubQueue.execute(new Runnable()
      {
        public void run()
        {
          params.setPluginName(paramString);
        }
      });
      return;
    }
    if (debugMode) {
      throw new IllegalArgumentException("Plugin name not acceptable");
    }
  }
  
  public void setPreloadedApp(MATPreloadData paramMATPreloadData)
  {
    mPreloadData = paramMATPreloadData;
  }
  
  public void setReferralSources(final Activity paramActivity)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setReferralSource(paramActivity.getCallingPackage());
        Object localObject = paramActivity.getIntent();
        if (localObject != null)
        {
          localObject = ((Intent)localObject).getData();
          if (localObject != null) {
            params.setReferralUrl(((Uri)localObject).toString());
          }
        }
      }
    });
  }
  
  public void setSiteId(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setSiteId(paramString);
      }
    });
  }
  
  public void setTRUSTeId(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setTRUSTeId(paramString);
      }
    });
  }
  
  public void setTwitterUserId(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setTwitterUserId(paramString);
      }
    });
  }
  
  public void setUserEmail(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setUserEmail(paramString);
      }
    });
  }
  
  public void setUserId(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setUserId(paramString);
      }
    });
  }
  
  public void setUserName(final String paramString)
  {
    pubQueue.execute(new Runnable()
    {
      public void run()
      {
        params.setUserName(paramString);
      }
    });
  }
}
