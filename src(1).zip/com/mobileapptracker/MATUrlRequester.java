package com.mobileapptracker;

import android.net.Uri;
import android.net.Uri.Builder;
import android.util.Log;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class MATUrlRequester
{
  MATUrlRequester() {}
  
  private static void logResponse(JSONObject paramJSONObject)
  {
    if (paramJSONObject.length() > 0)
    {
      try
      {
        bool = paramJSONObject.has("errors");
        if (bool)
        {
          int i = paramJSONObject.getJSONArray("errors").length();
          if (i != 0)
          {
            paramJSONObject = paramJSONObject.getJSONArray("errors").getString(0);
            Log.d("MobileAppTracker", "Event was rejected by server with error: " + paramJSONObject);
            return;
          }
        }
        bool = paramJSONObject.has("log_action");
        if (!bool) {
          break label230;
        }
        bool = paramJSONObject.getString("log_action").equals("null");
        if (bool) {
          break label230;
        }
        bool = paramJSONObject.getString("log_action").equals("false");
        if (bool) {
          break label230;
        }
        bool = paramJSONObject.getString("log_action").equals("true");
        if (bool) {
          break label230;
        }
        paramJSONObject = paramJSONObject.getJSONObject("log_action");
        bool = paramJSONObject.has("conversion");
        if (!bool) {
          return;
        }
        paramJSONObject = paramJSONObject.getJSONObject("conversion");
        bool = paramJSONObject.has("status");
        if (!bool) {
          return;
        }
        bool = paramJSONObject.getString("status").equals("rejected");
        if (bool)
        {
          paramJSONObject = paramJSONObject.getString("status_code");
          Log.d("MobileAppTracker", "Event was rejected by server: status code " + paramJSONObject);
          return;
        }
      }
      catch (JSONException paramJSONObject)
      {
        Log.d("MobileAppTracker", "Server response status could not be parsed");
        paramJSONObject.printStackTrace();
        return;
      }
      Log.d("MobileAppTracker", "Event was accepted by server");
      return;
      label230:
      boolean bool = paramJSONObject.has("options");
      if (bool)
      {
        paramJSONObject = paramJSONObject.getJSONObject("options");
        bool = paramJSONObject.has("conversion_status");
        if (bool)
        {
          paramJSONObject = paramJSONObject.getString("conversion_status");
          Log.d("MobileAppTracker", "Event was " + paramJSONObject + " by server");
        }
      }
    }
  }
  
  protected static JSONObject requestUrl(String paramString, JSONObject paramJSONObject, boolean paramBoolean)
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a12 = a11\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
  }
  
  public void requestDeeplink(MATDeferredDplinkr paramMATDeferredDplinkr)
  {
    Object localObject4 = null;
    String str = null;
    Uri.Builder localBuilder = new Uri.Builder();
    Object localObject2 = localBuilder.scheme("https").authority(paramMATDeferredDplinkr.getAdvertiserId() + "." + "deeplink.mobileapptracking.com").appendPath("v1").appendPath("link.txt").appendQueryParameter("platform", "android").appendQueryParameter("advertiser_id", paramMATDeferredDplinkr.getAdvertiserId()).appendQueryParameter("ver", "3.11.0").appendQueryParameter("package_name", paramMATDeferredDplinkr.getPackageName());
    Object localObject1;
    Object localObject3;
    if (paramMATDeferredDplinkr.getGoogleAdvertisingId() != null)
    {
      localObject1 = paramMATDeferredDplinkr.getGoogleAdvertisingId();
      ((Uri.Builder)localObject2).appendQueryParameter("ad_id", (String)localObject1).appendQueryParameter("user_agent", paramMATDeferredDplinkr.getUserAgent());
      if (paramMATDeferredDplinkr.getGoogleAdvertisingId() != null) {
        localBuilder.appendQueryParameter("google_ad_tracking_disabled", Integer.toString(paramMATDeferredDplinkr.getGoogleAdTrackingLimited()));
      }
      localObject3 = str;
      localObject2 = localObject4;
    }
    for (;;)
    {
      try
      {
        localObject1 = new URL(localBuilder.build().toString()).openConnection();
        localObject1 = (HttpURLConnection)localObject1;
        localObject3 = str;
        localObject2 = localObject4;
        ((HttpURLConnection)localObject1).setRequestProperty("X-MAT-Key", paramMATDeferredDplinkr.getConversionKey());
        localObject3 = str;
        localObject2 = localObject4;
        ((HttpURLConnection)localObject1).setRequestMethod("GET");
        localObject3 = str;
        localObject2 = localObject4;
        ((HttpURLConnection)localObject1).setDoInput(true);
        localObject3 = str;
        localObject2 = localObject4;
        ((HttpURLConnection)localObject1).connect();
        i = 0;
        localObject3 = str;
        localObject2 = localObject4;
        int j = ((HttpURLConnection)localObject1).getResponseCode();
        if (j == 200)
        {
          localObject3 = str;
          localObject2 = localObject4;
          localObject1 = ((HttpURLConnection)localObject1).getInputStream();
          localObject3 = localObject1;
          localObject2 = localObject1;
          str = MATUtils.readStream((InputStream)localObject1);
          localObject3 = localObject1;
          localObject2 = localObject1;
          paramMATDeferredDplinkr = paramMATDeferredDplinkr.getListener();
          if (paramMATDeferredDplinkr != null)
          {
            if (i == 0) {
              continue;
            }
            localObject3 = localObject1;
            localObject2 = localObject1;
            paramMATDeferredDplinkr.didFailDeeplink(str);
          }
        }
      }
      catch (Exception paramMATDeferredDplinkr)
      {
        int i;
        localObject2 = localObject3;
        ((Exception)paramMATDeferredDplinkr).printStackTrace();
        try
        {
          ((InputStream)localObject3).close();
          return;
        }
        catch (Exception paramMATDeferredDplinkr)
        {
          paramMATDeferredDplinkr.printStackTrace();
          return;
        }
      }
      catch (Throwable paramMATDeferredDplinkr)
      {
        try
        {
          ((InputStream)localObject2).close();
          throw paramMATDeferredDplinkr;
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
          continue;
        }
      }
      try
      {
        ((InputStream)localObject1).close();
        return;
      }
      catch (Exception paramMATDeferredDplinkr)
      {
        paramMATDeferredDplinkr.printStackTrace();
      }
      localObject1 = paramMATDeferredDplinkr.getAndroidId();
      break;
      i = 1;
      localObject3 = str;
      localObject2 = localObject4;
      localObject1 = ((HttpURLConnection)localObject1).getErrorStream();
      continue;
      localObject3 = localObject1;
      localObject2 = localObject1;
      paramMATDeferredDplinkr.didReceiveDeeplink(str);
    }
  }
}
