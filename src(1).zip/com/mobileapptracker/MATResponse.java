package com.mobileapptracker;

import org.json.JSONObject;

public abstract interface MATResponse
{
  public abstract void didFailWithError(JSONObject paramJSONObject);
  
  public abstract void didSucceedWithData(JSONObject paramJSONObject);
  
  public abstract void enqueuedActionWithRefId(String paramString);
}
