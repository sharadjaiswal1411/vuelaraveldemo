package com.mobileapptracker;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class MATEvent
  implements Serializable
{
  public static final String ACHIEVEMENT_UNLOCKED = "achievement_unlocked";
  public static final String ADDED_PAYMENT_INFO = "added_payment_info";
  public static final String ADD_TO_CART = "add_to_cart";
  public static final String ADD_TO_WISHLIST = "add_to_wishlist";
  public static final String CHECKOUT_INITIATED = "checkout_initiated";
  public static final String CONTENT_VIEW = "content_view";
  public static final String DEVICE_FORM_WEARABLE = "wearable";
  public static final String INVITE = "invite";
  public static final String LEVEL_ACHIEVED = "level_achieved";
  public static final String LOGIN = "login";
  public static final String PURCHASE = "purchase";
  public static final String RATED = "rated";
  public static final String REGISTRATION = "registration";
  public static final String RESERVATION = "reservation";
  public static final String SEARCH = "search";
  public static final String SHARE = "share";
  public static final String SPENT_CREDITS = "spent_credits";
  public static final String TUTORIAL_COMPLETE = "tutorial_complete";
  private static final long serialVersionUID = -7616393848331704848L;
  private String attribute1;
  private String attribute2;
  private String attribute3;
  private String attribute4;
  private String attribute5;
  private String contentId;
  private String contentType;
  private String currencyCode;
  private Date date1;
  private Date date2;
  private String deviceForm;
  private int eventId;
  private List<MATEventItem> eventItems;
  private String eventName;
  private int level;
  private int quantity;
  private double rating;
  private String receiptData;
  private String receiptSignature;
  private String refId;
  private double revenue;
  private String searchString;
  
  public MATEvent(int paramInt)
  {
    eventId = paramInt;
  }
  
  public MATEvent(String paramString)
  {
    eventName = paramString;
  }
  
  public String getAttribute1()
  {
    return attribute1;
  }
  
  public String getAttribute2()
  {
    return attribute2;
  }
  
  public String getAttribute3()
  {
    return attribute3;
  }
  
  public String getAttribute4()
  {
    return attribute4;
  }
  
  public String getAttribute5()
  {
    return attribute5;
  }
  
  public String getContentId()
  {
    return contentId;
  }
  
  public String getContentType()
  {
    return contentType;
  }
  
  public String getCurrencyCode()
  {
    return currencyCode;
  }
  
  public Date getDate1()
  {
    return date1;
  }
  
  public Date getDate2()
  {
    return date2;
  }
  
  public String getDeviceForm()
  {
    return deviceForm;
  }
  
  public int getEventId()
  {
    return eventId;
  }
  
  public List getEventItems()
  {
    return eventItems;
  }
  
  public String getEventName()
  {
    return eventName;
  }
  
  public int getLevel()
  {
    return level;
  }
  
  public int getQuantity()
  {
    return quantity;
  }
  
  public double getRating()
  {
    return rating;
  }
  
  public String getReceiptData()
  {
    return receiptData;
  }
  
  public String getReceiptSignature()
  {
    return receiptSignature;
  }
  
  public String getRefId()
  {
    return refId;
  }
  
  public double getRevenue()
  {
    return revenue;
  }
  
  public String getSearchString()
  {
    return searchString;
  }
  
  public MATEvent withAdvertiserRefId(String paramString)
  {
    refId = paramString;
    return this;
  }
  
  public MATEvent withAttribute1(String paramString)
  {
    attribute1 = paramString;
    return this;
  }
  
  public MATEvent withAttribute2(String paramString)
  {
    attribute2 = paramString;
    return this;
  }
  
  public MATEvent withAttribute3(String paramString)
  {
    attribute3 = paramString;
    return this;
  }
  
  public MATEvent withAttribute4(String paramString)
  {
    attribute4 = paramString;
    return this;
  }
  
  public MATEvent withAttribute5(String paramString)
  {
    attribute5 = paramString;
    return this;
  }
  
  public MATEvent withContentId(String paramString)
  {
    contentId = paramString;
    return this;
  }
  
  public MATEvent withContentType(String paramString)
  {
    contentType = paramString;
    return this;
  }
  
  public MATEvent withCurrencyCode(String paramString)
  {
    currencyCode = paramString;
    return this;
  }
  
  public MATEvent withDate1(Date paramDate)
  {
    date1 = paramDate;
    return this;
  }
  
  public MATEvent withDate2(Date paramDate)
  {
    date2 = paramDate;
    return this;
  }
  
  public MATEvent withDeviceForm(String paramString)
  {
    deviceForm = paramString;
    return this;
  }
  
  public MATEvent withEventItems(List paramList)
  {
    eventItems = paramList;
    return this;
  }
  
  public MATEvent withLevel(int paramInt)
  {
    level = paramInt;
    return this;
  }
  
  public MATEvent withQuantity(int paramInt)
  {
    quantity = paramInt;
    return this;
  }
  
  public MATEvent withRating(double paramDouble)
  {
    rating = paramDouble;
    return this;
  }
  
  public MATEvent withReceipt(String paramString1, String paramString2)
  {
    receiptData = paramString1;
    receiptSignature = paramString2;
    return this;
  }
  
  public MATEvent withRevenue(double paramDouble)
  {
    revenue = paramDouble;
    return this;
  }
  
  public MATEvent withSearchString(String paramString)
  {
    searchString = paramString;
    return this;
  }
}
