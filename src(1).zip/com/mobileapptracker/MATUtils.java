package com.mobileapptracker;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MATUtils
{
  public MATUtils() {}
  
  public static String bytesToHex(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null) {
      return null;
    }
    int j = paramArrayOfByte.length;
    String str = "";
    int i = 0;
    if (i < j)
    {
      if ((paramArrayOfByte[i] & 0xFF) < 16) {}
      for (str = str + "0" + Integer.toHexString(paramArrayOfByte[i] & 0xFF);; str = str + Integer.toHexString(paramArrayOfByte[i] & 0xFF))
      {
        i += 1;
        break;
      }
    }
    return str;
  }
  
  public static boolean getBooleanFromSharedPreferences(Context paramContext, String paramString)
  {
    boolean bool1 = false;
    try
    {
      boolean bool2 = paramContext.getSharedPreferences("com.mobileapptracking", 0).getBoolean(paramString, false);
      bool1 = bool2;
    }
    catch (ClassCastException paramContext)
    {
      for (;;) {}
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
    return bool1;
  }
  
  public static String getStringFromSharedPreferences(Context paramContext, String paramString)
  {
    try
    {
      paramContext = paramContext.getSharedPreferences("com.mobileapptracking", 0).getString(paramString, "");
      return paramContext;
    }
    catch (ClassCastException paramContext)
    {
      for (;;)
      {
        paramContext = "";
      }
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public static byte[] hexToBytes(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    byte[] arrayOfByte;
    if (paramString.length() >= 2)
    {
      int j = paramString.length() / 2;
      arrayOfByte = new byte[j];
      int i = 0;
      while (i < j)
      {
        arrayOfByte[i] = ((byte)Integer.parseInt(paramString.substring(i * 2, i * 2 + 2), 16));
        i += 1;
      }
    }
    return null;
    return arrayOfByte;
  }
  
  public static String md5(String paramString)
  {
    if (paramString == null) {
      return "";
    }
    try
    {
      MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
      localMessageDigest.update(paramString.getBytes());
      paramString = bytesToHex(localMessageDigest.digest());
      return paramString;
    }
    catch (NoSuchAlgorithmException paramString)
    {
      paramString.printStackTrace();
    }
    return "";
  }
  
  public static String readStream(InputStream paramInputStream)
    throws IOException, UnsupportedEncodingException
  {
    if (paramInputStream != null)
    {
      paramInputStream = new BufferedReader(new InputStreamReader(paramInputStream, "UTF-8"));
      StringBuilder localStringBuilder = new StringBuilder();
      for (;;)
      {
        String str = paramInputStream.readLine();
        if (str == null)
        {
          paramInputStream.close();
          return localStringBuilder.toString();
        }
        localStringBuilder.append(str).append("\n");
      }
    }
    return "";
  }
  
  public static void saveToSharedPreferences(Context paramContext, String paramString1, String paramString2)
  {
    try
    {
      paramContext.getSharedPreferences("com.mobileapptracking", 0).edit().putString(paramString1, paramString2).commit();
      return;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public static void saveToSharedPreferences(Context paramContext, String paramString, boolean paramBoolean)
  {
    try
    {
      paramContext.getSharedPreferences("com.mobileapptracking", 0).edit().putBoolean(paramString, paramBoolean).commit();
      return;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public static String sha1(String paramString)
  {
    if (paramString == null) {
      return "";
    }
    try
    {
      MessageDigest localMessageDigest = MessageDigest.getInstance("SHA-1");
      localMessageDigest.update(paramString.getBytes());
      paramString = bytesToHex(localMessageDigest.digest());
      return paramString;
    }
    catch (NoSuchAlgorithmException paramString)
    {
      paramString.printStackTrace();
    }
    return "";
  }
  
  public static String sha256(String paramString)
  {
    if (paramString == null) {
      return "";
    }
    try
    {
      MessageDigest localMessageDigest = MessageDigest.getInstance("SHA-256");
      localMessageDigest.update(paramString.getBytes());
      paramString = bytesToHex(localMessageDigest.digest());
      return paramString;
    }
    catch (NoSuchAlgorithmException paramString)
    {
      paramString.printStackTrace();
    }
    return "";
  }
}
