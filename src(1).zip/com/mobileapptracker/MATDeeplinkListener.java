package com.mobileapptracker;

public abstract interface MATDeeplinkListener
{
  public abstract void didFailDeeplink(String paramString);
  
  public abstract void didReceiveDeeplink(String paramString);
}
