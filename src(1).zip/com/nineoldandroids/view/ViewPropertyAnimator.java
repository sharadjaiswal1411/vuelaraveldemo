package com.nineoldandroids.view;

import android.view.View;
import android.view.animation.Interpolator;
import com.nineoldandroids.animation.Animator.AnimatorListener;
import java.util.WeakHashMap;

public abstract class ViewPropertyAnimator
{
  private static final WeakHashMap<View, ViewPropertyAnimator> ANIMATORS = new WeakHashMap(0);
  
  public ViewPropertyAnimator() {}
  
  public static ViewPropertyAnimator animate(View paramView)
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a4 = a3\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
  }
  
  public abstract ViewPropertyAnimator alpha(float paramFloat);
  
  public abstract ViewPropertyAnimator alphaBy(float paramFloat);
  
  public abstract void cancel();
  
  public abstract long getDuration();
  
  public abstract long getStartDelay();
  
  public abstract ViewPropertyAnimator rotation(float paramFloat);
  
  public abstract ViewPropertyAnimator rotationBy(float paramFloat);
  
  public abstract ViewPropertyAnimator rotationX(float paramFloat);
  
  public abstract ViewPropertyAnimator rotationXBy(float paramFloat);
  
  public abstract ViewPropertyAnimator rotationY(float paramFloat);
  
  public abstract ViewPropertyAnimator rotationYBy(float paramFloat);
  
  public abstract ViewPropertyAnimator scaleX(float paramFloat);
  
  public abstract ViewPropertyAnimator scaleXBy(float paramFloat);
  
  public abstract ViewPropertyAnimator scaleY(float paramFloat);
  
  public abstract ViewPropertyAnimator scaleYBy(float paramFloat);
  
  public abstract ViewPropertyAnimator setDuration(long paramLong);
  
  public abstract ViewPropertyAnimator setInterpolator(Interpolator paramInterpolator);
  
  public abstract ViewPropertyAnimator setListener(Animator.AnimatorListener paramAnimatorListener);
  
  public abstract ViewPropertyAnimator setStartDelay(long paramLong);
  
  public abstract void start();
  
  public abstract ViewPropertyAnimator translationX(float paramFloat);
  
  public abstract ViewPropertyAnimator translationXBy(float paramFloat);
  
  public abstract ViewPropertyAnimator translationY(float paramFloat);
  
  public abstract ViewPropertyAnimator translationYBy(float paramFloat);
  
  public abstract ViewPropertyAnimator x(float paramFloat);
  
  public abstract ViewPropertyAnimator xBy(float paramFloat);
  
  public abstract ViewPropertyAnimator y(float paramFloat);
  
  public abstract ViewPropertyAnimator yBy(float paramFloat);
}
