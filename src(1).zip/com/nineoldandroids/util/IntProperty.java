package com.nineoldandroids.util;

public abstract class IntProperty<T>
  extends Property<T, Integer>
{
  public IntProperty(String paramString)
  {
    super(Integer.class, paramString);
  }
  
  public final void set(Object paramObject, Integer paramInteger)
  {
    set(paramObject, Integer.valueOf(paramInteger.intValue()));
  }
  
  public abstract void setValue(Object paramObject, int paramInt);
}
