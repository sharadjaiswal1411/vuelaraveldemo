package com.nineoldandroids.util;

public abstract class FloatProperty<T>
  extends Property<T, Float>
{
  public FloatProperty(String paramString)
  {
    super(Float.class, paramString);
  }
  
  public final void set(Object paramObject, Float paramFloat)
  {
    setValue(paramObject, paramFloat.floatValue());
  }
  
  public abstract void setValue(Object paramObject, float paramFloat);
}
