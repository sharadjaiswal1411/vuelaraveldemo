package com.nineoldandroids.util;

public abstract class Property<T, V>
{
  private final String mName;
  private final Class<V> mType;
  
  public Property(Class paramClass, String paramString)
  {
    mName = paramString;
    mType = paramClass;
  }
  
  public static Property of(Class paramClass1, Class paramClass2, String paramString)
  {
    return new ReflectiveProperty(paramClass1, paramClass2, paramString);
  }
  
  public abstract Object get(Object paramObject);
  
  public String getName()
  {
    return mName;
  }
  
  public Class getType()
  {
    return mType;
  }
  
  public boolean isReadOnly()
  {
    return false;
  }
  
  public void set(Object paramObject1, Object paramObject2)
  {
    throw new UnsupportedOperationException("Property " + getName() + " is read-only");
  }
}
