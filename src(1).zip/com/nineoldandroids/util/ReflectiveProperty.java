package com.nineoldandroids.util;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class ReflectiveProperty<T, V>
  extends Property<T, V>
{
  private static final String PREFIX_GET = "get";
  private static final String PREFIX_IS = "is";
  private static final String PREFIX_SET = "set";
  private Field mField;
  private Method mGetter;
  private Method mSetter;
  
  public ReflectiveProperty(Class paramClass1, Class paramClass2, String paramString)
  {
    super(paramClass2, paramString);
    char c = Character.toUpperCase(paramString.charAt(0));
    String str = paramString.substring(1);
    str = c + str;
    Object localObject1 = "get" + str;
    try
    {
      Method localMethod1 = paramClass1.getMethod((String)localObject1, null);
      mGetter = localMethod1;
    }
    catch (NoSuchMethodException localNoSuchMethodException3)
    {
      try
      {
        localObject1 = paramClass1.getDeclaredMethod((String)localObject1, null);
        mGetter = ((Method)localObject1);
        localObject1 = mGetter;
        ((Method)localObject1).setAccessible(true);
      }
      catch (NoSuchMethodException localNoSuchMethodException2)
      {
        for (;;)
        {
          Object localObject2 = "is" + str;
          try
          {
            Method localMethod2 = paramClass1.getMethod((String)localObject2, null);
            mGetter = localMethod2;
          }
          catch (NoSuchMethodException localNoSuchMethodException4)
          {
            try
            {
              localObject2 = paramClass1.getDeclaredMethod((String)localObject2, null);
              mGetter = ((Method)localObject2);
              localObject2 = mGetter;
              ((Method)localObject2).setAccessible(true);
            }
            catch (NoSuchMethodException localNoSuchMethodException1)
            {
              try
              {
                paramClass1 = paramClass1.getField(paramString);
                mField = paramClass1;
                paramClass1 = mField;
                paramClass1 = paramClass1.getType();
                boolean bool = typesMatch(paramClass2, paramClass1);
                if (bool) {
                  return;
                }
                paramClass1 = new NoSuchPropertyException("Underlying type (" + paramClass1 + ") " + "does not match Property type (" + paramClass2 + ")");
                throw paramClass1;
              }
              catch (NoSuchFieldException paramClass1)
              {
                throw new NoSuchPropertyException("No accessor method or field found for property with name " + paramString);
              }
            }
          }
        }
      }
      paramClass2 = "set" + localNoSuchMethodException1;
      try
      {
        paramClass1 = paramClass1.getDeclaredMethod(paramClass2, new Class[] { paramString });
        mSetter = paramClass1;
        paramClass1 = mSetter;
        paramClass1.setAccessible(true);
        return;
      }
      catch (NoSuchMethodException paramClass1) {}
    }
    paramString = mGetter.getReturnType();
    if (!typesMatch(paramClass2, paramString)) {
      throw new NoSuchPropertyException("Underlying type (" + paramString + ") " + "does not match Property type (" + paramClass2 + ")");
    }
  }
  
  private boolean typesMatch(Class paramClass1, Class paramClass2)
  {
    return (paramClass2 == paramClass1) || ((paramClass2.isPrimitive()) && (((paramClass2 == Float.TYPE) && (paramClass1 == Float.class)) || ((paramClass2 == Integer.TYPE) && (paramClass1 == Integer.class)) || ((paramClass2 == Boolean.TYPE) && (paramClass1 == Boolean.class)) || ((paramClass2 == Long.TYPE) && (paramClass1 == Long.class)) || ((paramClass2 == Double.TYPE) && (paramClass1 == Double.class)) || ((paramClass2 == Short.TYPE) && (paramClass1 == Short.class)) || ((paramClass2 == Byte.TYPE) && (paramClass1 == Byte.class)) || ((paramClass2 == Character.TYPE) && (paramClass1 == Character.class))));
  }
  
  public Object get(Object paramObject)
  {
    Object localObject;
    if (mGetter != null)
    {
      localObject = mGetter;
      try
      {
        paramObject = ((Method)localObject).invoke(paramObject, null);
        return paramObject;
      }
      catch (IllegalAccessException paramObject)
      {
        throw new AssertionError();
      }
      catch (InvocationTargetException paramObject)
      {
        throw new RuntimeException(paramObject.getCause());
      }
    }
    if (mField != null)
    {
      localObject = mField;
      try
      {
        paramObject = ((Field)localObject).get(paramObject);
        return paramObject;
      }
      catch (IllegalAccessException paramObject)
      {
        throw new AssertionError();
      }
    }
    throw new AssertionError();
  }
  
  public boolean isReadOnly()
  {
    return (mSetter == null) && (mField == null);
  }
  
  public void set(Object paramObject1, Object paramObject2)
  {
    Object localObject;
    if (mSetter != null)
    {
      localObject = mSetter;
      try
      {
        ((Method)localObject).invoke(paramObject1, new Object[] { paramObject2 });
        return;
      }
      catch (IllegalAccessException paramObject1)
      {
        throw new AssertionError();
      }
      catch (InvocationTargetException paramObject1)
      {
        throw new RuntimeException(paramObject1.getCause());
      }
    }
    if (mField != null)
    {
      localObject = mField;
      try
      {
        ((Field)localObject).set(paramObject1, paramObject2);
        return;
      }
      catch (IllegalAccessException paramObject1)
      {
        throw new AssertionError();
      }
    }
    throw new UnsupportedOperationException("Property " + getName() + " is read-only");
  }
}
