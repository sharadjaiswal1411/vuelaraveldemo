package com.nineoldandroids.util;

public class NoSuchPropertyException
  extends RuntimeException
{
  public NoSuchPropertyException(String paramString)
  {
    super(paramString);
  }
}
