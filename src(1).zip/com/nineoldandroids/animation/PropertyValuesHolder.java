package com.nineoldandroids.animation;

import android.util.Log;
import com.nineoldandroids.util.FloatProperty;
import com.nineoldandroids.util.IntProperty;
import com.nineoldandroids.util.Property;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;

public class PropertyValuesHolder
  implements Cloneable
{
  private static Class[] DOUBLE_VARIANTS;
  private static Class[] FLOAT_VARIANTS;
  private static Class[] INTEGER_VARIANTS;
  private static final TypeEvaluator sFloatEvaluator;
  private static final HashMap<Class, HashMap<String, Method>> sGetterPropertyMap = new HashMap();
  private static final TypeEvaluator sIntEvaluator = new IntEvaluator();
  private static final HashMap<Class, HashMap<String, Method>> sSetterPropertyMap;
  private Object mAnimatedValue;
  private TypeEvaluator mEvaluator;
  private Method mGetter = null;
  KeyframeSet mKeyframeSet = null;
  protected Property mProperty;
  final ReentrantReadWriteLock mPropertyMapLock = new ReentrantReadWriteLock();
  String mPropertyName;
  Method mSetter = null;
  final Object[] mTmpValueArray = new Object[1];
  Class mValueType;
  
  static
  {
    sFloatEvaluator = new FloatEvaluator();
    FLOAT_VARIANTS = new Class[] { Float.TYPE, Float.class, Double.TYPE, Integer.TYPE, Double.class, Integer.class };
    INTEGER_VARIANTS = new Class[] { Integer.TYPE, Integer.class, Float.TYPE, Double.TYPE, Float.class, Double.class };
    DOUBLE_VARIANTS = new Class[] { Double.TYPE, Double.class, Float.TYPE, Integer.TYPE, Float.class, Integer.class };
    sSetterPropertyMap = new HashMap();
  }
  
  private PropertyValuesHolder(Property paramProperty)
  {
    mProperty = paramProperty;
    if (paramProperty != null) {
      mPropertyName = paramProperty.getName();
    }
  }
  
  private PropertyValuesHolder(String paramString)
  {
    mPropertyName = paramString;
  }
  
  static String getMethodName(String paramString1, String paramString2)
  {
    String str = paramString1;
    if (paramString2 != null)
    {
      if (paramString2.length() == 0) {
        return paramString1;
      }
      char c = Character.toUpperCase(paramString2.charAt(0));
      paramString2 = paramString2.substring(1);
      str = paramString1 + c + paramString2;
    }
    return str;
  }
  
  private Method getPropertyFunction(Class paramClass1, String paramString, Class paramClass2)
  {
    Object localObject1 = null;
    Class[] arrayOfClass = null;
    String str = getMethodName(paramString, mPropertyName);
    if (paramClass2 == null) {
      try
      {
        paramString = paramClass1.getMethod(str, null);
        return paramString;
      }
      catch (NoSuchMethodException localNoSuchMethodException1)
      {
        paramString = arrayOfClass;
        try
        {
          paramClass2 = paramClass1.getDeclaredMethod(str, null);
          paramClass1 = paramClass2;
          paramString = paramClass1;
          paramClass2.setAccessible(true);
          return paramClass1;
        }
        catch (NoSuchMethodException paramClass1)
        {
          Log.e("PropertyValuesHolder", "Couldn't find no-arg method for property " + mPropertyName + ": " + localNoSuchMethodException1);
          return paramString;
        }
      }
    }
    arrayOfClass = new Class[1];
    int j;
    int i;
    if (mValueType.equals(Float.class))
    {
      paramString = FLOAT_VARIANTS;
      j = paramString.length;
      i = 0;
      paramClass2 = localNoSuchMethodException1;
    }
    Object localObject2;
    for (;;)
    {
      if (i >= j) {
        break label259;
      }
      localObject2 = paramString[i];
      arrayOfClass[0] = localObject2;
      try
      {
        Method localMethod1 = paramClass1.getMethod(str, arrayOfClass);
        mValueType = localObject2;
        return localMethod1;
      }
      catch (NoSuchMethodException localNoSuchMethodException2)
      {
        try
        {
          Method localMethod2 = paramClass1.getDeclaredMethod(str, arrayOfClass);
          paramClass2 = localMethod2;
          localMethod2.setAccessible(true);
          mValueType = localObject2;
          return localMethod2;
        }
        catch (NoSuchMethodException localNoSuchMethodException3)
        {
          i += 1;
        }
      }
      if (mValueType.equals(Integer.class))
      {
        paramString = INTEGER_VARIANTS;
        break;
      }
      if (mValueType.equals(Double.class))
      {
        paramString = DOUBLE_VARIANTS;
        break;
      }
      paramString = new Class[1];
      paramString[0] = mValueType;
      break;
    }
    label259:
    Log.e("PropertyValuesHolder", "Couldn't find setter/getter for property " + mPropertyName + " with value type " + mValueType);
    return paramClass2;
  }
  
  public static PropertyValuesHolder ofFloat(Property paramProperty, float... paramVarArgs)
  {
    return new FloatPropertyValuesHolder(paramProperty, paramVarArgs);
  }
  
  public static PropertyValuesHolder ofFloat(String paramString, float... paramVarArgs)
  {
    return new FloatPropertyValuesHolder(paramString, paramVarArgs);
  }
  
  public static PropertyValuesHolder ofInt(Property paramProperty, int... paramVarArgs)
  {
    return new IntPropertyValuesHolder(paramProperty, paramVarArgs);
  }
  
  public static PropertyValuesHolder ofInt(String paramString, int... paramVarArgs)
  {
    return new IntPropertyValuesHolder(paramString, paramVarArgs);
  }
  
  public static PropertyValuesHolder ofKeyframe(Property paramProperty, Keyframe... paramVarArgs)
  {
    KeyframeSet localKeyframeSet = KeyframeSet.ofKeyframe(paramVarArgs);
    if ((localKeyframeSet instanceof IntKeyframeSet)) {
      return new IntPropertyValuesHolder(paramProperty, (IntKeyframeSet)localKeyframeSet);
    }
    if ((localKeyframeSet instanceof FloatKeyframeSet)) {
      return new FloatPropertyValuesHolder(paramProperty, (FloatKeyframeSet)localKeyframeSet);
    }
    paramProperty = new PropertyValuesHolder(paramProperty);
    mKeyframeSet = localKeyframeSet;
    mValueType = paramVarArgs[0].getType();
    return paramProperty;
  }
  
  public static PropertyValuesHolder ofKeyframe(String paramString, Keyframe... paramVarArgs)
  {
    KeyframeSet localKeyframeSet = KeyframeSet.ofKeyframe(paramVarArgs);
    if ((localKeyframeSet instanceof IntKeyframeSet)) {
      return new IntPropertyValuesHolder(paramString, (IntKeyframeSet)localKeyframeSet);
    }
    if ((localKeyframeSet instanceof FloatKeyframeSet)) {
      return new FloatPropertyValuesHolder(paramString, (FloatKeyframeSet)localKeyframeSet);
    }
    paramString = new PropertyValuesHolder(paramString);
    mKeyframeSet = localKeyframeSet;
    mValueType = paramVarArgs[0].getType();
    return paramString;
  }
  
  public static PropertyValuesHolder ofObject(Property paramProperty, TypeEvaluator paramTypeEvaluator, Object... paramVarArgs)
  {
    paramProperty = new PropertyValuesHolder(paramProperty);
    paramProperty.setObjectValues(paramVarArgs);
    paramProperty.setEvaluator(paramTypeEvaluator);
    return paramProperty;
  }
  
  public static PropertyValuesHolder ofObject(String paramString, TypeEvaluator paramTypeEvaluator, Object... paramVarArgs)
  {
    paramString = new PropertyValuesHolder(paramString);
    paramString.setObjectValues(paramVarArgs);
    paramString.setEvaluator(paramTypeEvaluator);
    return paramString;
  }
  
  private void setupGetter(Class paramClass)
  {
    mGetter = setupSetterOrGetter(paramClass, sGetterPropertyMap, "get", null);
  }
  
  private Method setupSetterOrGetter(Class paramClass1, HashMap paramHashMap, String paramString, Class paramClass2)
  {
    Method localMethod = null;
    try
    {
      mPropertyMapLock.writeLock().lock();
      HashMap localHashMap = (HashMap)paramHashMap.get(paramClass1);
      if (localHashMap != null) {
        localMethod = (Method)localHashMap.get(mPropertyName);
      }
      Object localObject = localMethod;
      if (localMethod == null)
      {
        localMethod = getPropertyFunction(paramClass1, paramString, paramClass2);
        paramString = localMethod;
        paramClass2 = localHashMap;
        if (localHashMap == null)
        {
          paramClass2 = new HashMap();
          paramHashMap.put(paramClass1, paramClass2);
        }
        paramClass2.put(mPropertyName, localMethod);
        localObject = paramString;
      }
      mPropertyMapLock.writeLock().unlock();
      return localObject;
    }
    catch (Throwable paramClass1)
    {
      mPropertyMapLock.writeLock().unlock();
      throw paramClass1;
    }
  }
  
  private void setupValue(Object paramObject, Keyframe paramKeyframe)
  {
    if (mProperty != null) {
      paramKeyframe.setValue(mProperty.get(paramObject));
    }
    if (mGetter == null) {}
    try
    {
      setupGetter(paramObject.getClass());
      Method localMethod = mGetter;
      paramKeyframe.setValue(localMethod.invoke(paramObject, new Object[0]));
      return;
    }
    catch (InvocationTargetException paramObject)
    {
      Log.e("PropertyValuesHolder", paramObject.toString());
      return;
    }
    catch (IllegalAccessException paramObject)
    {
      Log.e("PropertyValuesHolder", paramObject.toString());
    }
  }
  
  void calculateValue(float paramFloat)
  {
    mAnimatedValue = mKeyframeSet.getValue(paramFloat);
  }
  
  public PropertyValuesHolder clone()
  {
    try
    {
      Object localObject = super.clone();
      localObject = (PropertyValuesHolder)localObject;
      mPropertyName = mPropertyName;
      mProperty = mProperty;
      KeyframeSet localKeyframeSet = mKeyframeSet;
      localKeyframeSet = localKeyframeSet.clone();
      mKeyframeSet = localKeyframeSet;
      mEvaluator = mEvaluator;
      return localObject;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException) {}
    return null;
  }
  
  Object getAnimatedValue()
  {
    return mAnimatedValue;
  }
  
  public String getPropertyName()
  {
    return mPropertyName;
  }
  
  void init()
  {
    TypeEvaluator localTypeEvaluator;
    if (mEvaluator == null)
    {
      if (mValueType != Integer.class) {
        break label44;
      }
      localTypeEvaluator = sIntEvaluator;
    }
    for (;;)
    {
      mEvaluator = localTypeEvaluator;
      if (mEvaluator == null) {
        break;
      }
      mKeyframeSet.setEvaluator(mEvaluator);
      return;
      label44:
      if (mValueType == Float.class) {
        localTypeEvaluator = sFloatEvaluator;
      } else {
        localTypeEvaluator = null;
      }
    }
  }
  
  void setAnimatedValue(Object paramObject)
  {
    if (mProperty != null) {
      mProperty.set(paramObject, getAnimatedValue());
    }
    if (mSetter != null)
    {
      Object localObject1 = mTmpValueArray;
      try
      {
        Object localObject2 = getAnimatedValue();
        localObject1[0] = localObject2;
        localObject1 = mSetter;
        localObject2 = mTmpValueArray;
        ((Method)localObject1).invoke(paramObject, (Object[])localObject2);
        return;
      }
      catch (InvocationTargetException paramObject)
      {
        Log.e("PropertyValuesHolder", paramObject.toString());
        return;
      }
      catch (IllegalAccessException paramObject)
      {
        Log.e("PropertyValuesHolder", paramObject.toString());
      }
    }
  }
  
  public void setEvaluator(TypeEvaluator paramTypeEvaluator)
  {
    mEvaluator = paramTypeEvaluator;
    mKeyframeSet.setEvaluator(paramTypeEvaluator);
  }
  
  public void setFloatValues(float... paramVarArgs)
  {
    mValueType = Float.TYPE;
    mKeyframeSet = KeyframeSet.ofFloat(paramVarArgs);
  }
  
  public void setIntValues(int... paramVarArgs)
  {
    mValueType = Integer.TYPE;
    mKeyframeSet = KeyframeSet.ofInt(paramVarArgs);
  }
  
  public void setKeyframes(Keyframe... paramVarArgs)
  {
    int j = paramVarArgs.length;
    Keyframe[] arrayOfKeyframe = new Keyframe[Math.max(j, 2)];
    mValueType = paramVarArgs[0].getType();
    int i = 0;
    while (i < j)
    {
      arrayOfKeyframe[i] = paramVarArgs[i];
      i += 1;
    }
    mKeyframeSet = new KeyframeSet(arrayOfKeyframe);
  }
  
  public void setObjectValues(Object... paramVarArgs)
  {
    mValueType = paramVarArgs[0].getClass();
    mKeyframeSet = KeyframeSet.ofObject(paramVarArgs);
  }
  
  public void setProperty(Property paramProperty)
  {
    mProperty = paramProperty;
  }
  
  public void setPropertyName(String paramString)
  {
    mPropertyName = paramString;
  }
  
  void setupEndValue(Object paramObject)
  {
    setupValue(paramObject, (Keyframe)mKeyframeSet.mKeyframes.get(mKeyframeSet.mKeyframes.size() - 1));
  }
  
  void setupSetter(Class paramClass)
  {
    mSetter = setupSetterOrGetter(paramClass, sSetterPropertyMap, "set", mValueType);
  }
  
  void setupSetterAndGetter(Object paramObject)
  {
    Object localObject3;
    if (mProperty != null)
    {
      Object localObject1 = mProperty;
      try
      {
        ((Property)localObject1).get(paramObject);
        localObject1 = mKeyframeSet.mKeyframes;
        localObject1 = ((ArrayList)localObject1).iterator();
        for (;;)
        {
          boolean bool = ((Iterator)localObject1).hasNext();
          if (!bool) {
            break;
          }
          localObject2 = (Keyframe)((Iterator)localObject1).next();
          bool = ((Keyframe)localObject2).hasValue();
          if (!bool)
          {
            localObject3 = mProperty;
            ((Keyframe)localObject2).setValue(((Property)localObject3).get(paramObject));
          }
        }
        localClass = paramObject.getClass();
      }
      catch (ClassCastException localClassCastException)
      {
        Log.e("PropertyValuesHolder", "No such property (" + mProperty.getName() + ") on target object " + paramObject + ". Trying reflection instead");
        mProperty = null;
      }
    }
    Class localClass;
    if (mSetter == null) {
      setupSetter(localClass);
    }
    Object localObject2 = mKeyframeSet.mKeyframes.iterator();
    while (((Iterator)localObject2).hasNext())
    {
      localObject3 = (Keyframe)((Iterator)localObject2).next();
      if (!((Keyframe)localObject3).hasValue())
      {
        if (mGetter == null) {
          setupGetter(localClass);
        }
        Method localMethod = mGetter;
        try
        {
          ((Keyframe)localObject3).setValue(localMethod.invoke(paramObject, new Object[0]));
        }
        catch (InvocationTargetException localInvocationTargetException)
        {
          Log.e("PropertyValuesHolder", localInvocationTargetException.toString());
        }
        catch (IllegalAccessException localIllegalAccessException)
        {
          Log.e("PropertyValuesHolder", localIllegalAccessException.toString());
        }
      }
    }
  }
  
  void setupStartValue(Object paramObject)
  {
    setupValue(paramObject, (Keyframe)mKeyframeSet.mKeyframes.get(0));
  }
  
  public String toString()
  {
    return mPropertyName + ": " + mKeyframeSet.toString();
  }
  
  static class FloatPropertyValuesHolder
    extends PropertyValuesHolder
  {
    float mFloatAnimatedValue;
    FloatKeyframeSet mFloatKeyframeSet;
    private FloatProperty mFloatProperty;
    
    public FloatPropertyValuesHolder(Property paramProperty, FloatKeyframeSet paramFloatKeyframeSet)
    {
      super(null);
      mValueType = Float.TYPE;
      mKeyframeSet = paramFloatKeyframeSet;
      mFloatKeyframeSet = ((FloatKeyframeSet)mKeyframeSet);
      if ((paramProperty instanceof FloatProperty)) {
        mFloatProperty = ((FloatProperty)mProperty);
      }
    }
    
    public FloatPropertyValuesHolder(Property paramProperty, float... paramVarArgs)
    {
      super(null);
      setFloatValues(paramVarArgs);
      if ((paramProperty instanceof FloatProperty)) {
        mFloatProperty = ((FloatProperty)mProperty);
      }
    }
    
    public FloatPropertyValuesHolder(String paramString, FloatKeyframeSet paramFloatKeyframeSet)
    {
      super(null);
      mValueType = Float.TYPE;
      mKeyframeSet = paramFloatKeyframeSet;
      mFloatKeyframeSet = ((FloatKeyframeSet)mKeyframeSet);
    }
    
    public FloatPropertyValuesHolder(String paramString, float... paramVarArgs)
    {
      super(null);
      setFloatValues(paramVarArgs);
    }
    
    void calculateValue(float paramFloat)
    {
      mFloatAnimatedValue = mFloatKeyframeSet.getFloatValue(paramFloat);
    }
    
    public FloatPropertyValuesHolder clone()
    {
      FloatPropertyValuesHolder localFloatPropertyValuesHolder = (FloatPropertyValuesHolder)super.clone();
      mFloatKeyframeSet = ((FloatKeyframeSet)mKeyframeSet);
      return localFloatPropertyValuesHolder;
    }
    
    Object getAnimatedValue()
    {
      return Float.valueOf(mFloatAnimatedValue);
    }
    
    void setAnimatedValue(Object paramObject)
    {
      if (mFloatProperty != null)
      {
        mFloatProperty.setValue(paramObject, mFloatAnimatedValue);
        return;
      }
      if (mProperty != null)
      {
        mProperty.set(paramObject, Float.valueOf(mFloatAnimatedValue));
        return;
      }
      if (mSetter != null)
      {
        Object localObject = mTmpValueArray;
        float f = mFloatAnimatedValue;
        localObject[0] = Float.valueOf(f);
        localObject = mSetter;
        Object[] arrayOfObject = mTmpValueArray;
        try
        {
          ((Method)localObject).invoke(paramObject, arrayOfObject);
          return;
        }
        catch (InvocationTargetException paramObject)
        {
          Log.e("PropertyValuesHolder", paramObject.toString());
          return;
        }
        catch (IllegalAccessException paramObject)
        {
          Log.e("PropertyValuesHolder", paramObject.toString());
        }
      }
    }
    
    public void setFloatValues(float... paramVarArgs)
    {
      super.setFloatValues(paramVarArgs);
      mFloatKeyframeSet = ((FloatKeyframeSet)mKeyframeSet);
    }
    
    void setupSetter(Class paramClass)
    {
      if (mProperty != null) {
        return;
      }
      super.setupSetter(paramClass);
    }
  }
  
  static class IntPropertyValuesHolder
    extends PropertyValuesHolder
  {
    int mIntAnimatedValue;
    IntKeyframeSet mIntKeyframeSet;
    private IntProperty mIntProperty;
    
    public IntPropertyValuesHolder(Property paramProperty, IntKeyframeSet paramIntKeyframeSet)
    {
      super(null);
      mValueType = Integer.TYPE;
      mKeyframeSet = paramIntKeyframeSet;
      mIntKeyframeSet = ((IntKeyframeSet)mKeyframeSet);
      if ((paramProperty instanceof IntProperty)) {
        mIntProperty = ((IntProperty)mProperty);
      }
    }
    
    public IntPropertyValuesHolder(Property paramProperty, int... paramVarArgs)
    {
      super(null);
      setIntValues(paramVarArgs);
      if ((paramProperty instanceof IntProperty)) {
        mIntProperty = ((IntProperty)mProperty);
      }
    }
    
    public IntPropertyValuesHolder(String paramString, IntKeyframeSet paramIntKeyframeSet)
    {
      super(null);
      mValueType = Integer.TYPE;
      mKeyframeSet = paramIntKeyframeSet;
      mIntKeyframeSet = ((IntKeyframeSet)mKeyframeSet);
    }
    
    public IntPropertyValuesHolder(String paramString, int... paramVarArgs)
    {
      super(null);
      setIntValues(paramVarArgs);
    }
    
    void calculateValue(float paramFloat)
    {
      mIntAnimatedValue = mIntKeyframeSet.getIntValue(paramFloat);
    }
    
    public IntPropertyValuesHolder clone()
    {
      IntPropertyValuesHolder localIntPropertyValuesHolder = (IntPropertyValuesHolder)super.clone();
      mIntKeyframeSet = ((IntKeyframeSet)mKeyframeSet);
      return localIntPropertyValuesHolder;
    }
    
    Object getAnimatedValue()
    {
      return Integer.valueOf(mIntAnimatedValue);
    }
    
    void setAnimatedValue(Object paramObject)
    {
      if (mIntProperty != null)
      {
        mIntProperty.setValue(paramObject, mIntAnimatedValue);
        return;
      }
      if (mProperty != null)
      {
        mProperty.set(paramObject, Integer.valueOf(mIntAnimatedValue));
        return;
      }
      if (mSetter != null)
      {
        Object localObject = mTmpValueArray;
        int i = mIntAnimatedValue;
        localObject[0] = Integer.valueOf(i);
        localObject = mSetter;
        Object[] arrayOfObject = mTmpValueArray;
        try
        {
          ((Method)localObject).invoke(paramObject, arrayOfObject);
          return;
        }
        catch (InvocationTargetException paramObject)
        {
          Log.e("PropertyValuesHolder", paramObject.toString());
          return;
        }
        catch (IllegalAccessException paramObject)
        {
          Log.e("PropertyValuesHolder", paramObject.toString());
        }
      }
    }
    
    public void setIntValues(int... paramVarArgs)
    {
      super.setIntValues(paramVarArgs);
      mIntKeyframeSet = ((IntKeyframeSet)mKeyframeSet);
    }
    
    void setupSetter(Class paramClass)
    {
      if (mProperty != null) {
        return;
      }
      super.setupSetter(paramClass);
    }
  }
}
