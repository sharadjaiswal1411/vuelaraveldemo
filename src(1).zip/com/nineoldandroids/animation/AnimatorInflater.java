package com.nineoldandroids.animation;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.util.Xml;
import android.view.animation.AnimationUtils;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class AnimatorInflater
{
  private static final int[] Animator = { 16843073, 16843160, 16843198, 16843199, 16843200, 16843486, 16843487, 16843488 };
  private static final int[] AnimatorSet = { 16843490 };
  private static final int AnimatorSet_ordering = 0;
  private static final int Animator_duration = 1;
  private static final int Animator_interpolator = 0;
  private static final int Animator_repeatCount = 3;
  private static final int Animator_repeatMode = 4;
  private static final int Animator_startOffset = 2;
  private static final int Animator_valueFrom = 5;
  private static final int Animator_valueTo = 6;
  private static final int Animator_valueType = 7;
  private static final int[] PropertyAnimator = { 16843489 };
  private static final int PropertyAnimator_propertyName = 0;
  private static final int TOGETHER = 0;
  private static final int VALUE_TYPE_FLOAT = 0;
  
  public AnimatorInflater() {}
  
  private static Animator createAnimatorFromXml(Context paramContext, XmlPullParser paramXmlPullParser)
    throws XmlPullParserException, IOException
  {
    return createAnimatorFromXml(paramContext, paramXmlPullParser, Xml.asAttributeSet(paramXmlPullParser), null, 0);
  }
  
  private static Animator createAnimatorFromXml(Context paramContext, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, AnimatorSet paramAnimatorSet, int paramInt)
    throws XmlPullParserException, IOException
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a15 = a14\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
  }
  
  public static Animator loadAnimator(Context paramContext, int paramInt)
    throws Resources.NotFoundException
  {
    Object localObject1 = null;
    Object localObject2 = null;
    Object localObject3 = null;
    try
    {
      XmlResourceParser localXmlResourceParser = paramContext.getResources().getAnimation(paramInt);
      localObject2 = localXmlResourceParser;
      localObject3 = localObject2;
      localObject1 = localObject2;
      paramContext = createAnimatorFromXml(paramContext, localXmlResourceParser);
      if (localXmlResourceParser != null)
      {
        localXmlResourceParser.close();
        return paramContext;
      }
    }
    catch (XmlPullParserException paramContext)
    {
      localObject1 = localObject3;
      localObject2 = new Resources.NotFoundException("Can't load animation resource ID #0x" + Integer.toHexString(paramInt));
      localObject1 = localObject3;
      ((Exception)localObject2).initCause(paramContext);
      localObject1 = localObject3;
      throw ((Throwable)localObject2);
    }
    catch (Throwable paramContext)
    {
      if (localObject1 != null) {
        localObject1.close();
      }
      throw paramContext;
    }
    catch (IOException paramContext)
    {
      localObject1 = localObject2;
      localObject3 = new Resources.NotFoundException("Can't load animation resource ID #0x" + Integer.toHexString(paramInt));
      localObject1 = localObject2;
      ((Exception)localObject3).initCause(paramContext);
      localObject1 = localObject2;
      throw ((Throwable)localObject3);
    }
    return paramContext;
  }
  
  private static ValueAnimator loadAnimator(Context paramContext, AttributeSet paramAttributeSet, ValueAnimator paramValueAnimator)
    throws Resources.NotFoundException
  {
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, Animator);
    long l1 = localTypedArray.getInt(1, 0);
    long l2 = localTypedArray.getInt(2, 0);
    int i = localTypedArray.getInt(7, 0);
    paramAttributeSet = paramValueAnimator;
    if (paramValueAnimator == null) {
      paramAttributeSet = new ValueAnimator();
    }
    int j;
    label76:
    int m;
    label87:
    int k;
    label102:
    int n;
    label113:
    float f1;
    label201:
    float f2;
    if (i == 0)
    {
      i = 1;
      paramValueAnimator = localTypedArray.peekValue(5);
      if (paramValueAnimator == null) {
        break label328;
      }
      j = 1;
      if (j == 0) {
        break label334;
      }
      m = type;
      paramValueAnimator = localTypedArray.peekValue(6);
      if (paramValueAnimator == null) {
        break label340;
      }
      k = 1;
      if (k == 0) {
        break label346;
      }
      n = type;
      int i1;
      if ((j == 0) || (m < 28) || (m > 31))
      {
        i1 = i;
        if (k != 0)
        {
          i1 = i;
          if (n >= 28)
          {
            i1 = i;
            if (n > 31) {}
          }
        }
      }
      else
      {
        i1 = 0;
        paramAttributeSet.setEvaluator(new ArgbEvaluator());
      }
      if (i1 == 0) {
        break label431;
      }
      if (j == 0) {
        break label390;
      }
      if (m != 5) {
        break label352;
      }
      f1 = localTypedArray.getDimension(5, 0.0F);
      if (k == 0) {
        break label376;
      }
      if (n != 5) {
        break label363;
      }
      f2 = localTypedArray.getDimension(6, 0.0F);
      label222:
      paramAttributeSet.setFloatValues(new float[] { f1, f2 });
    }
    label328:
    label334:
    label340:
    label346:
    label352:
    label363:
    label376:
    label390:
    label431:
    label452:
    label532:
    label572:
    label587:
    do
    {
      for (;;)
      {
        paramAttributeSet.setDuration(l1);
        paramAttributeSet.setStartDelay(l2);
        if (localTypedArray.hasValue(3)) {
          paramAttributeSet.setRepeatCount(localTypedArray.getInt(3, 0));
        }
        if (localTypedArray.hasValue(4)) {
          paramAttributeSet.setRepeatMode(localTypedArray.getInt(4, 1));
        }
        i = localTypedArray.getResourceId(0, 0);
        if (i > 0) {
          paramAttributeSet.setInterpolator(AnimationUtils.loadInterpolator(paramContext, i));
        }
        localTypedArray.recycle();
        return paramAttributeSet;
        i = 0;
        break;
        j = 0;
        break label76;
        m = 0;
        break label87;
        k = 0;
        break label102;
        n = 0;
        break label113;
        f1 = localTypedArray.getFloat(5, 0.0F);
        break label201;
        f2 = localTypedArray.getFloat(6, 0.0F);
        break label222;
        paramAttributeSet.setFloatValues(new float[] { f1 });
        continue;
        if (n == 5) {}
        for (f1 = localTypedArray.getDimension(6, 0.0F);; f1 = localTypedArray.getFloat(6, 0.0F))
        {
          paramAttributeSet.setFloatValues(new float[] { f1 });
          break;
        }
        if (j == 0) {
          break label587;
        }
        if (m == 5)
        {
          i = (int)localTypedArray.getDimension(5, 0.0F);
          if (k == 0) {
            break label572;
          }
          if (n != 5) {
            break label532;
          }
          j = (int)localTypedArray.getDimension(6, 0.0F);
        }
        for (;;)
        {
          paramAttributeSet.setIntValues(new int[] { i, j });
          break;
          if ((m >= 28) && (m <= 31))
          {
            i = localTypedArray.getColor(5, 0);
            break label452;
          }
          i = localTypedArray.getInt(5, 0);
          break label452;
          if ((n >= 28) && (n <= 31)) {
            j = localTypedArray.getColor(6, 0);
          } else {
            j = localTypedArray.getInt(6, 0);
          }
        }
        paramAttributeSet.setIntValues(new int[] { i });
      }
    } while (k == 0);
    if (n == 5) {
      i = (int)localTypedArray.getDimension(6, 0.0F);
    }
    for (;;)
    {
      paramAttributeSet.setIntValues(new int[] { i });
      break;
      if ((n >= 28) && (n <= 31)) {
        i = localTypedArray.getColor(6, 0);
      } else {
        i = localTypedArray.getInt(6, 0);
      }
    }
  }
  
  private static ObjectAnimator loadObjectAnimator(Context paramContext, AttributeSet paramAttributeSet)
    throws Resources.NotFoundException
  {
    ObjectAnimator localObjectAnimator = new ObjectAnimator();
    loadAnimator(paramContext, paramAttributeSet, localObjectAnimator);
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, PropertyAnimator);
    localObjectAnimator.setPropertyName(paramContext.getString(0));
    paramContext.recycle();
    return localObjectAnimator;
  }
}
