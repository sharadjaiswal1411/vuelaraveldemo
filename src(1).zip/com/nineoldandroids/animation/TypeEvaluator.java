package com.nineoldandroids.animation;

public abstract interface TypeEvaluator<T>
{
  public abstract Object evaluate(float paramFloat, Object paramObject1, Object paramObject2);
}
