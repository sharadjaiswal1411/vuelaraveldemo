<?php

/**
 * Theme Mobile Before Footer Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_mbbfftradcatids =  admania_get_option('ad_rmcatlist31');			
$admania_mbbftr_extractcatids = explode(',',$admania_mbbfftradcatids);			
			
$admania_mbbfftrtagids = admania_get_option('ad_rmtaglist31');
$admania_mbbfftrtagids_extractids = explode(',',$admania_mbbfftrtagids);

$admania_mbbfftrpostids = admania_get_option('ad_rmpostlist31');
$admania_mbbfftr_extractids = explode(',',$admania_mbbfftrpostids);

$admania_mbbfftrpageids = admania_get_option('ad_rmpagelist31');
$admania_mbbfftr_pgextractids = explode(',',$admania_mbbfftrpageids);			
			
if((!is_category($admania_mbbftr_extractcatids)) && (!is_tag($admania_mbbfftrtagids_extractids)) && (!is_single($admania_mbbfftr_extractids)) && (!is_page($admania_mbbfftr_pgextractids))) {

if(admania_get_option('mb_bfftrad_act') != false):
  
?>

<div class="admania_mbbffooterad admania_themead">
  <?php
       	if((admania_get_lveditoption('flvedtmb_bfftrhtmlad') != false) || (admania_get_lveditoption('flvedtmb_bfftrgooglead') != false) || (admania_get_lveditoption('admania_lvedtimg_url49') != false)) {
			
			if(admania_get_lveditoption('flvedtmb_bfftrhtmlad') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('flvedtmb_bfftrhtmlad'));
			
			}
			if(admania_get_lveditoption('flvedtmb_bfftrgooglead') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('flvedtmb_bfftrgooglead'));
			}
			
			if((admania_get_lveditoption('admania_lvedtimg_url49') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url42') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url42')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url49') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url49')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			}
 
 else {
			if(admania_get_option('mb_bfftrhtmlad') != false):
			
			echo wp_kses_stripslashes(admania_get_option('mb_bfftrhtmlad'));
			
			endif;
			
			if(admania_get_option('mb_bfftrgooglead') != false):
			
			echo wp_kses_stripslashes(admania_get_option('mb_bfftrgooglead'));
			
			endif;
			
			if((admania_get_option('admania_adimg_url52') != false) || (admania_get_option('admania_adimgtg_url52') != false) ):
			?>
			<a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url52')); ?>">
				<?php if(admania_get_option('admania_adimg_url52') != false) { ?>
				<img src="<?php echo esc_url(admania_get_option('admania_adimg_url52')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
				<?php } ?>
			</a>
			<?php			
			endif; 
			}
				if(current_user_can('administrator')){			
?>				
<div class="admania_adeditablead1 admania_lvetresitem49">				
	<i class="fa fa-edit"></i>
	<?php esc_html_e('Edit','admania'); ?>
</div>			 
<?php } ?>	

</div>
<?php 
 endif;
 }
		
