<?php

/**
 * Theme Boxed Before Footer Section Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_boxedrmvcatids14 =  admania_get_option('ad_rmcatGrid61');			
$admania_boxedrmvcatids_extractids14 = explode(',',$admania_boxedrmvcatids14);
		
$admania_boxedrmvtagids14 = admania_get_option('ad_rmtagGrid61');
$admania_boxedrmvtagids_extractids14 = explode(',',$admania_boxedrmvtagids14);	

$admania_boxedrmvpostids14 = admania_get_option('ad_rmpostGrid61');
$admania_boxedrmvpostids_extractids14 = explode(',',$admania_boxedrmvpostids14);

$admania_boxedrmvpageids14 = admania_get_option('ad_rmpageGrid61');
$admania_boxedrmvpageids_extractids14 = explode(',',$admania_boxedrmvpageids14);		
			
if((!is_category($admania_boxedrmvcatids_extractids14)) && (!is_tag($admania_boxedrmvtagids_extractids14)) && (!is_single($admania_boxedrmvpostids_extractids14)) && (!is_page($admania_boxedrmvpageids_extractids14))) {
 
  if(admania_get_option('bxd_lytftrad') != false):
  
  ?>

<div class="admania_themead">
  <?php
  
     	if((admania_get_lveditoption('bxd_bfftrhtmlad') != false) || (admania_get_lveditoption('bxd_bfftrglead') != false) || (admania_get_lveditoption('admania_lvedtimg_url54') != false)) {
			if(admania_get_lveditoption('bxd_bfftrhtmlad') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_bfftrhtmlad'));
			
			}
			if(admania_get_lveditoption('bxd_bfftrglead') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_bfftrglead'));
			}
			
			if((admania_get_lveditoption('admania_lvedtimg_url54') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url54') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url54')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url54') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url54')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			}
 
  else {
 
            if(admania_get_option('bxd_rotlytftrhtmlcd') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
 
			if(admania_get_option('bxd_lytftrhtmlcd') != false):
			
			echo wp_kses_stripslashes(admania_get_option('bxd_lytftrhtmlcd'));
			
			endif;
			
			
			if(admania_get_option('bxd_rotlytftrhtmlcd') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('bxd_rotlytftrhtmlcd')); ?>
			</div>
			<?php
            }
			
			if(admania_get_option('bxd_rotlytftrglecd') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if(admania_get_option('bxd_lytftrglecd') != false):
			
			echo wp_kses_stripslashes(admania_get_option('bxd_lytftrglecd'));
			
			endif;
			
		    if(admania_get_option('bxd_rotlytftrglecd') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('bxd_rotlytftrglecd')); ?>
			</div>
			<?php
            }
			
			if((admania_get_option('admania_rotadimg_url61') != false) || (admania_get_option('admania_rotadimgtg_url61') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if((admania_get_option('admania_adimg_url61') != false) || (admania_get_option('admania_adimgtg_url61') != false) ):
			?>
			<a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url61')); ?>">
			<?php if(admania_get_option('admania_adimg_url61') != false) { ?>
			<img src="<?php echo esc_url(admania_get_option('admania_adimg_url61')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			<?php } ?>
			</a>
			<?php
			
			endif; 
			
			 if((admania_get_option('admania_rotadimg_url61') != false) || (admania_get_option('admania_rotadimgtg_url61') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url61')); ?>">
				<?php if(admania_get_option('admania_rotadimg_url61') != false) { ?>
				<img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url61')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
				<?php } ?>
				</a>
			</div>
			<?php
            }
			
			
			}
			
	if(current_user_can('administrator')){			
?>				
<div class="admania_adeditablead1 admania_lvetresitem54">				
	<i class="fa fa-edit"></i>
	<?php esc_html_e('Edit','admania'); ?>
</div>			 
<?php } ?>	

</div>
<?php 
 endif;
 }
