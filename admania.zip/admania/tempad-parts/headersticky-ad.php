<?php
/**
 * Theme Single Post Bottom Sticky Ad Section for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
 

//ThemeOptions Variables   
 
 
$admania_rmvcatids20 =  admania_get_option('ad_rmcatlist26');			
$admania_rmvcatids_extractids20 = explode(',',$admania_rmvcatids20);			
			
$admania_rmvtagids20 = admania_get_option('ad_rmtaglist26');
$admania_rmvtagids_extractids20 = explode(',',$admania_rmvtagids20);			
			
    if((!is_category($admania_rmvcatids_extractids20)) && (!is_tag($admania_rmvtagids_extractids20))) {	
	
	if((admania_get_option('sngle_stickyheaderadeb') != false) || ((admania_get_lveditoption('header_stickyhtmlad') != false) || (admania_get_lveditoption('header_stickygglead') != false) || (admania_get_lveditoption('admania_lvedtimg_url44') != false))) {	
	
	?>
	
	<div class="admania_headersgstkyad admania_themead"> 
	
	   
	<?php
			 
	if((admania_get_lveditoption('header_stickyhtmlad') != false) || (admania_get_lveditoption('header_stickygglead') != false) || (admania_get_lveditoption('admania_lvedtimg_url44') != false)) {

			if(admania_get_lveditoption('header_stickyhtmlad') != false):			
			
			echo wp_kses_stripslashes(admania_get_lveditoption('header_stickyhtmlad'));			
			
			endif;
			
			if(admania_get_lveditoption('header_stickygglead') != false):
		

			echo wp_kses_stripslashes(admania_get_lveditoption('header_stickygglead'));				
			
			
			endif;
			
			if((admania_get_lveditoption('admania_lvedtimg_url44') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url44') != false) ):
			
			?>
			
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url44')); ?>">
			
			<?php if(admania_get_lveditoption('admania_lvedtimg_url44') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url44')); ?>" alt="<?php esc_html_e('adimage','admania');?>"/>
			<?php } ?>
			
			</a>	
            <?php					
			endif;
        }
	else {
	
	if(admania_get_option('sngle_stickyheaderadeb') != false):
	
			if(admania_get_option('sngle_rotstickyheaderhtmlad') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	

 
			if(admania_get_option('sngle_stickyheaderhtmlad') != false):
			
			echo wp_kses_stripslashes(admania_get_option('sngle_stickyheaderhtmlad'));
			
			endif;
			
			if(admania_get_option('sngle_rotstickyheaderhtmlad') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('sngle_rotstickyheaderhtmlad')); ?>
			</div>
			<?php
            }
			
			if(admania_get_option('sngle_rotstickyheadergglead') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if(admania_get_option('sngle_stickyheadergglead') != false):
			
			echo wp_kses_stripslashes(admania_get_option('sngle_stickyheadergglead'));
			
			endif;
			
			if(admania_get_option('sngle_rotstickyheadergglead') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('sngle_rotstickyheadergglead')); ?>
			</div>
			<?php
            }
			
			if((admania_get_option('admania_rotadimg_url47') != false) || (admania_get_option('admania_rotadimgtg_url47') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if((admania_get_option('admania_adimg_url47') != false) || (admania_get_option('admania_adimgtg_url47') != false) ):
			?>
			<a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url47')); ?>">
				<?php if(admania_get_option('admania_adimg_url47') != false) { ?>
				<img src="<?php echo esc_url(admania_get_option('admania_adimg_url47')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			<?php } ?>
			</a>
			<?php endif; 

			if((admania_get_option('admania_rotadimg_url47') != false) || (admania_get_option('admania_rotadimgtg_url47') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url47')); ?>">
				<?php if(admania_get_option('admania_rotadimg_url47') != false) { ?>
				<img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url47')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
				<?php } ?>
				</a>
			</div>
			<?php
            }			

 endif;		
 } 

 
if(current_user_can('administrator')){			
	?>				
	<div class="admania_adeditablead1 admania_lvetresitem44">				
		<i class="fa fa-edit"></i>
		<?php esc_html_e('Edit','admania'); ?>
	</div>			 
<?php } ?>
<i class="fa fa-close admania_sstkyadclose"></i>
</div>
<?php 
 }
 }
