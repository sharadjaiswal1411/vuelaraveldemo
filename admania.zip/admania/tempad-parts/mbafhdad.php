<?php

/**
 * Theme Mobile After Header Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_mbafhdrmvcatids =  admania_get_option('ad_rmcatlist28');			
$admania_afhdrmvcatid_extractid = explode(',',$admania_mbafhdrmvcatids);			
			
$admania_afhdtagids = admania_get_option('ad_rmtaglist28');
$admania_afhdtagids_extractids = explode(',',$admania_afhdtagids);

$admania_afhdrmvpostids = admania_get_option('ad_rmpostlist28');
$admania_afhdrmv_extractids = explode(',',$admania_afhdrmvpostids);

$admania_afhdrmvpageids = admania_get_option('ad_rmpagelist28');
$admania_afhdpageids_extractids = explode(',',$admania_afhdrmvpageids);			
			
if((!is_category($admania_afhdrmvcatid_extractid)) && (!is_tag($admania_afhdtagids_extractids)) && (!is_single($admania_afhdrmv_extractids)) && (!is_page($admania_afhdpageids_extractids))) {

if(admania_get_option('hdr_afhdad_act') != false):
  
?>
<div class="admanina_afterheaderad admania_mbafterheaderad">
<div class="admania_mbafhdad admania_themead">
  <?php
       	if((admania_get_lveditoption('flvedtmb_afhdhmlad') != false) || (admania_get_lveditoption('flvedtmb_afhdgooglead') != false) || (admania_get_lveditoption('admania_lvedtimg_url46') != false)) {
			
			if(admania_get_lveditoption('flvedtmb_afhdhmlad') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('flvedtmb_afhdhmlad'));
			
			}
			if(admania_get_lveditoption('flvedtmb_afhdgooglead') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('flvedtmb_afhdgooglead'));
			}
			
			if((admania_get_lveditoption('admania_lvedtimg_url46') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url46') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url46')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url46') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url46')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			}
 
 else {
			if(admania_get_option('hdr_afhdhtmlad') != false):
			
			echo wp_kses_stripslashes(admania_get_option('hdr_afhdhtmlad'));
			
			endif;
			
			if(admania_get_option('hdr_afhdgooglead') != false):
			
			echo wp_kses_stripslashes(admania_get_option('hdr_afhdgooglead'));
			
			endif;
			
			if((admania_get_option('admania_adimg_url49') != false) || (admania_get_option('admania_adimgtg_url49') != false) ):
			?>
			  <a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url49')); ?>">
			  <?php if(admania_get_option('admania_adimg_url49') != false) { ?>
			  <img src="<?php echo esc_url(admania_get_option('admania_adimg_url49')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			  <?php } ?>
			  </a>
			  <?php
			
			endif; 
			}
			?>	

</div>
</div>
<?php 
 endif;
 }
		
