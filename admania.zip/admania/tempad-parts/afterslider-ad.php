<?php

/**
 * Theme Home Page After Slider Section Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_hmafsdrrmvcatids1 =  admania_get_option('ad_rmcatafsld1');			
$admania_hmafsdrrmvcatids_extractids1 = explode(',',$admania_hmafsdrrmvcatids1);
		
$admania_hmafsdrrmvtagids1 = admania_get_option('ad_rmtagafsld1');
$admania_hmafsdrrmvtagids_extractids1 = explode(',',$admania_hmafsdrrmvtagids1);

$admania_hmafsdrrmvpostids1 = admania_get_option('ad_rmpostafsld1');
$admania_hmafsdrrmvpostids_extractids1 = explode(',',$admania_hmafsdrrmvpostids1);	

$admania_hmafsdrrmvpageids1 = admania_get_option('ad_rmpageafsld1');
$admania_hmafsdrrmvpageids_extractids1 = explode(',',$admania_hmafsdrrmvpageids1);				
			
if((!is_category($admania_hmafsdrrmvcatids_extractids1)) && (!is_tag($admania_hmafsdrrmvtagids_extractids1)) && (!is_single($admania_hmafsdrrmvpostids_extractids1)) && (!is_page($admania_hmafsdrrmvpageids_extractids1))) {
 
 
if(admania_get_option('hm_aftrsldrad') != false):
  
  ?>

<div class="admania_afterslider admania_themead">
  <?php
  
  
   	if((admania_get_lveditoption('hdr_lvedlhtmlad7') != false) || (admania_get_lveditoption('hdr_lvedlglead7') != false) || (admania_get_lveditoption('admania_lvedtimg_url7') != false)) {
			
			
			
			if(admania_get_lveditoption('hdr_rotlvedlhtmlad7') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			
			if(admania_get_lveditoption('hdr_lvedlhtmlad7') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('hdr_lvedlhtmlad7'));
			
			}
			
		    if(admania_get_lveditoption('hdr_rotlvedlhtmlad7') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlvedlhtmlad7')); ?>
			</div>
			<?php
            }
			
			if(admania_get_lveditoption('hdr_rotlvedlglead7') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			
			if(admania_get_lveditoption('hdr_lvedlglead7') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('hdr_lvedlglead7'));
			}
			
			if(admania_get_lveditoption('hdr_rotlvedlglead7') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlvedlglead7')); ?>
			</div>
			<?php
            }
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url7') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url7') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if((admania_get_lveditoption('admania_lvedtimg_url7') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url7') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url7')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url7') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url7')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url7') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url7') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtrimgtg_url7')); ?>">
			<?php if(admania_get_lveditoption('admania_rotlvedtimg_url7') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtimg_url7')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			</div>
			<?php
            }
			
			}
 else {
  
			if(admania_get_option('hm_rotaftrsldrhtmlad') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			if(admania_get_option('hm_aftrsldrhtmlad') != false):
			
			echo wp_kses_stripslashes(admania_get_option('hm_aftrsldrhtmlad'));
			
			endif;
			
			if(admania_get_option('hm_rotaftrsldrhtmlad') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('hm_rotaftrsldrhtmlad')); ?>
			</div>
			<?php
            }
			
			if(admania_get_option('hm_rotaftrsldrgglead') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if(admania_get_option('hm_aftrsldrgglead') != false):
			
			echo wp_kses_stripslashes(admania_get_option('hm_aftrsldrgglead'));
			
			endif;
			
			if(admania_get_option('hm_rotaftrsldrgglead') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('hm_rotaftrsldrgglead')); ?>
			</div>
			<?php
            }
			
			if((admania_get_option('admania_rotadimg_url7') != false) || (admania_get_option('admania_rotadimgtg_url7') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if((admania_get_option('admania_adimg_url7') != false) || (admania_get_option('admania_adimgtg_url7') != false) ):
			?>
			  <a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url7')); ?>">
			  <?php if(admania_get_option('admania_adimg_url7') != false) { ?>
			  <img src="<?php echo esc_url(admania_get_option('admania_adimg_url7')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			  <?php } ?>
			  </a>
			  <?php						
			endif; 
	
	
	
			if((admania_get_option('admania_rotadimg_url7') != false) || (admania_get_option('admania_rotadimgtg_url7') != false)) {
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			  <a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url7')); ?>">
			  <?php if(admania_get_option('admania_rotadimg_url7') != false) { ?>
			  <img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url7')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			  <?php } ?>
			  </a>
			</div>
			<?php
            }
	
    }	
			
if(current_user_can('administrator')){			
?>				
<div class="admania_adeditablead1 admania_lvetresitem7">				
	<i class="fa fa-edit"></i>
	<?php esc_html_e('Edit','admania'); ?>
</div>			 
<?php } ?>	
			
</div>
<?php 
 endif;
}
