<?php

/**
 * Theme Home Page5 Grid Post Section Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_boxedrmvcatids11 =  admania_get_option('ad_rmcatGrid43');			
$admania_boxedrmvcatids_extractids11 = explode(',',$admania_boxedrmvcatids11);
		
$admania_boxedrmvtagids11 = admania_get_option('ad_rmtagGrid43');
$admania_boxedrmvtagids_extractids11 = explode(',',$admania_boxedrmvtagids11);

$admania_boxedrmvpostids11 = admania_get_option('ad_rmpostGrid43');
$admania_boxedrmvpostids_extractids11 = explode(',',$admania_boxedrmvpostids11);	

$admania_boxedrmvpageids11 = admania_get_option('ad_rmpageGrid43');
$admania_boxedrmvpageids_extractids11 = explode(',',$admania_boxedrmvpageids11);				
			
if((!is_category($admania_boxedrmvcatids_extractids11)) && (!is_tag($admania_boxedrmvtagids_extractids11)) && (!is_single($admania_boxedrmvpostids_extractids11))  && (!is_page($admania_boxedrmvpageids_extractids11))) {
 
  if(admania_get_option('bxd_lyt_gridadad2') != false):
  
  ?>

<div class="admania_boxedgriditem admania_boxedgriditemlast admania_themead">
  <?php
  
     	if((admania_get_lveditoption('bxd_posthtmlad2') != false) || (admania_get_lveditoption('bxd_postglead2') != false) || (admania_get_lveditoption('admania_lvedtimg_url51') != false)) {
			if(admania_get_lveditoption('bxd_posthtmlad2') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_posthtmlad2'));
			
			}
			if(admania_get_lveditoption('bxd_postglead2') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_postglead2'));
			}
			
			if((admania_get_lveditoption('admania_lvedtimg_url51') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url51') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url51')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url51') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url51')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			}
 
  else {
 
			if(admania_get_option('bxd_rotlytpsadhtml12') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
 
			if(admania_get_option('bxd_lytpsadhtml12') != false):
			
			echo wp_kses_stripslashes(admania_get_option('bxd_lytpsadhtml12'));
			
			endif;
			
			if(admania_get_option('bxd_rotlytpsadhtml12') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('bxd_rotlytpsadhtml12')); ?>
			</div>
			<?php
            }
			
			
			if(admania_get_option('bxd_rotlytgglead12') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if(admania_get_option('bxd_lytgglead12') != false):
			
			echo wp_kses_stripslashes(admania_get_option('bxd_lytgglead12'));
			
			endif;
			
			
			if(admania_get_option('bxd_rotlytgglead12') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('bxd_rotlytgglead12')); ?>
			</div>
			<?php
            }
			
			
			if((admania_get_option('admania_rotadimg_url58') != false) || (admania_get_option('admania_rotadimgtg_url58') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			
			if((admania_get_option('admania_adimg_url58') != false) || (admania_get_option('admania_adimgtg_url58') != false) ):
			?>
			<a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url58')); ?>">
			<?php if(admania_get_option('admania_adimg_url58') != false) { ?>
			<img src="<?php echo esc_url(admania_get_option('admania_adimg_url58')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			<?php } ?>
			</a>
			<?php
			
			endif; 
			
			if((admania_get_option('admania_rotadimg_url58') != false) || (admania_get_option('admania_rotadimgtg_url58') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				 <a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url58')); ?>">
				<?php if(admania_get_option('admania_rotadimg_url58') != false) { ?>
				<img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url58')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
				<?php } ?>
				</a>
			</div>
			<?php
            }
			
			}
			
	if(current_user_can('administrator')){			
?>				
<div class="admania_adeditablead1 admania_lvetresitem51">				
	<i class="fa fa-edit"></i>
	<?php esc_html_e('Edit','admania'); ?>
</div>			 
<?php } ?>	

</div>
<?php 
 endif;
 }
