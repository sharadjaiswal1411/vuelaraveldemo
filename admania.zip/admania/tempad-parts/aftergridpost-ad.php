<?php

/**
 * Theme Home Page After Grid Post Section Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_rmvcatids7 =  admania_get_option('ad_rmcatlist8');			
$admania_rmvcatids_extractids7 = explode(',',$admania_rmvcatids7);			
			
$admania_rmvtagids7 = admania_get_option('ad_rmtaglist8');
$admania_rmvtagids_extractids7 = explode(',',$admania_rmvtagids7);	

$admania_rmvpostids7 = admania_get_option('ad_rmpostlist8');
$admania_rmvpostids_extractids7 = explode(',',$admania_rmvpostids7);		

$admania_rmvpageids7 = admania_get_option('ad_rmpagelist8');
$admania_rmvpageids_extractids7 = explode(',',$admania_rmvpageids7);		
			
if((!is_category($admania_rmvcatids_extractids7)) && (!is_tag($admania_rmvtagids_extractids7)) && (!is_single($admania_rmvpostids_extractids7)) && (!is_page($admania_rmvpageids_extractids7))) {
 
  if(admania_get_option('hm_aftrgridad') != false):
  
  ?>

<div class="admania_afterslider admania_aftergridpst admania_themead">
  <?php
  
     	if((admania_get_lveditoption('hdr_lvedlhtmlad8') != false) || (admania_get_lveditoption('hdr_lvedlglead8') != false) || (admania_get_lveditoption('admania_lvedtimg_url8') != false)) {
			
			
			
if(admania_get_lveditoption('hdr_rotlvedlhtmlad8') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if(admania_get_lveditoption('hdr_lvedlhtmlad8') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('hdr_lvedlhtmlad8'));
			
			}
			
				
		if(admania_get_lveditoption('hdr_rotlvedlhtmlad8') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlvedlhtmlad8')); ?>
			</div>
			<?php
            }
			
						
if(admania_get_lveditoption('hdr_rotlvedlglead8') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			
			if(admania_get_lveditoption('hdr_lvedlglead8') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('hdr_lvedlglead8'));
			}
			
			
							
		if(admania_get_lveditoption('hdr_rotlvedlglead8') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlvedlglead8')); ?>
			</div>
			<?php
            }
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url8') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url8') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if((admania_get_lveditoption('admania_lvedtimg_url8') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url8') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url8')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url8') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url8')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			}



			if((admania_get_lveditoption('admania_rotlvedtimg_url8') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url8') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtrimgtg_url8')); ?>">
			<?php if(admania_get_lveditoption('admania_rotlvedtimg_url8') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtimg_url8')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			</div>
			<?php
            }			
			
			}
 
  else {
 
 	  
			if(admania_get_option('hm_rotaftrgridhtmlad') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
 
			if(admania_get_option('hm_aftrgridhtmlad') != false):
			
			echo wp_kses_stripslashes(admania_get_option('hm_aftrgridhtmlad'));
			
			endif;
			
			
			if(admania_get_option('hm_rotaftrgridhtmlad') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('hm_rotaftrgridhtmlad')); ?>
			</div>
			<?php
            }
			
			if(admania_get_option('hm_rotaftrgridgglead') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if(admania_get_option('hm_aftrgridgglead') != false):
			
			echo wp_kses_stripslashes(admania_get_option('hm_aftrgridgglead'));
			
			endif;
			
			if(admania_get_option('hm_rotaftrgridgglead') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('hm_rotaftrgridgglead')); ?>
			</div>
			<?php
            }
			
			if((admania_get_option('admania_rotadimg_url8') != false) || (admania_get_option('admania_rotadimgtg_url8') != false) ){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
		
			
			
			if((admania_get_option('admania_adimg_url8') != false) || (admania_get_option('admania_adimgtg_url8') != false) ):
			?>
			  <a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url8')); ?>">
			  <?php if(admania_get_option('admania_adimg_url8') != false) { ?>
			  <img src="<?php echo esc_url(admania_get_option('admania_adimg_url8')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			  <?php } ?>
			  </a>
			<?php
			
			endif; 
			
			
			if((admania_get_option('admania_rotadimg_url8') != false) || (admania_get_option('admania_rotadimgtg_url8') != false) ){
			
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url8')); ?>">
			<?php if(admania_get_option('admania_rotadimg_url8') != false) { ?>
			<img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url8')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			<?php } ?>
			</a>
			</div>
		  <?php
			}
  }	
	if(current_user_can('administrator')){			
?>				
<div class="admania_adeditablead1 admania_lvetresitem8">				
	<i class="fa fa-edit"></i>
	<?php esc_html_e('Edit','admania'); ?>
</div>			 
<?php } ?>	

</div>
<?php 
 endif;
 }
