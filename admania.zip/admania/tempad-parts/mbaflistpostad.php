<?php

/**
 * Theme Mobile After List Post Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_mbaflistpostcatids =  admania_get_option('ad_rmcatlist30');			
$admania_aflistpst_extractids = explode(',',$admania_mbaflistpostcatids);			
			
$admania_aflistpsttagids = admania_get_option('ad_rmtaglist30');
$admania_aflistpsttagids_extractids = explode(',',$admania_aflistpsttagids);

$admania_aflistpostids = admania_get_option('ad_rmpostlist30');
$admania_aflistpost_extractids = explode(',',$admania_aflistpostids);

$admania_aflistpostpgids = admania_get_option('ad_rmpagelist30');
$admania_aflistpost_pgextractids = explode(',',$admania_aflistpostpgids);			
			
if((!is_category($admania_aflistpst_extractids)) && (!is_tag($admania_aflistpsttagids_extractids)) && (!is_single($admania_aflistpost_extractids)) && (!is_page($admania_aflistpost_pgextractids))) {

if(admania_get_option('listpost_afad_act') != false):
  
?>

<div class="admania_mbaflistpstad admania_themead">
  <?php
       	if((admania_get_lveditoption('flvedtmb_aflspsthtmlad') != false) || (admania_get_lveditoption('flvedtmb_aflspstgooglead') != false) || (admania_get_lveditoption('admania_lvedtimg_url48') != false)) {
			
			if(admania_get_lveditoption('flvedtmb_aflspsthtmlad') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('flvedtmb_aflspsthtmlad'));
			
			}
			if(admania_get_lveditoption('flvedtmb_aflspstgooglead') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('flvedtmb_aflspstgooglead'));
			}
			
			if((admania_get_lveditoption('admania_lvedtimg_url48') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url49') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url49')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url48') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url48')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			}
 
 else {
			if(admania_get_option('listpost_afhtmlad') != false):
			
			echo wp_kses_stripslashes(admania_get_option('listpost_afhtmlad'));
			
			endif;
			
			if(admania_get_option('listpost_afgooglead') != false):
			
			echo wp_kses_stripslashes(admania_get_option('listpost_afgooglead'));
			
			endif;
			
			if((admania_get_option('admania_adimg_url51') != false) || (admania_get_option('admania_adimgtg_url51') != false) ):
			?>
			<a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url51')); ?>">
				<?php if(admania_get_option('admania_adimg_url51') != false) { ?>
				<img src="<?php echo esc_url(admania_get_option('admania_adimg_url51')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
				<?php } ?>
			</a>
			<?php			
			endif; 
			}
			?>	

</div>
<?php 
 endif;
 }
		
