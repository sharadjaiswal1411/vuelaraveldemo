<?php

/**
 * Theme Mobile Before Header Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_mbbfhdrmvcatids =  admania_get_option('ad_rmcatlist27');			
$admania_bfhdrmvcatid_extractid = explode(',',$admania_mbbfhdrmvcatids);			
			
$admania_bfhdtagids = admania_get_option('ad_rmtaglist27');
$admania_bfhdtagids_extractids = explode(',',$admania_bfhdtagids);

$admania_bfhdrmvpostids = admania_get_option('ad_rmpostlist27');
$admania_bfhdrmv_extractids = explode(',',$admania_bfhdrmvpostids);

$admania_bfhdrmvpageids = admania_get_option('ad_rmpagelist27');
$admania_bfhdpageids_extractids = explode(',',$admania_bfhdrmvpageids);			
			
if((!is_category($admania_bfhdrmvcatid_extractid)) && (!is_tag($admania_bfhdtagids_extractids)) && (!is_single($admania_bfhdrmv_extractids)) && (!is_page($admania_bfhdpageids_extractids))) {

if(admania_get_option('hdr_bfad_act') != false):
  
?>

<div class="admania_mbbfhdad admania_themead">
  <?php
       	if((admania_get_lveditoption('flvedtmb_bfhdhmlad') != false) || (admania_get_lveditoption('flvedtmb_bfhdgooglead') != false) || (admania_get_lveditoption('admania_lvedtimg_url45') != false)) {
			
			if(admania_get_lveditoption('flvedtmb_bfhdhmlad') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('flvedtmb_bfhdhmlad'));
			
			}
			if(admania_get_lveditoption('flvedtmb_bfhdgooglead') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('flvedtmb_bfhdgooglead'));
			}
			
			if((admania_get_lveditoption('admania_lvedtimg_url45') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url45') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url45')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url45') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url45')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			}
 
 else {
			if(admania_get_option('hdr_bfhtmlad') != false):
			
			echo wp_kses_stripslashes(admania_get_option('hdr_bfhtmlad'));
			
			endif;
			
			if(admania_get_option('hdr_bfgooglead') != false):
			
			echo wp_kses_stripslashes(admania_get_option('hdr_bfgooglead'));
			
			endif;
			
			if((admania_get_option('admania_adimg_url48') != false) || (admania_get_option('admania_adimgtg_url48') != false) ):
			?>
  <a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url48')); ?>">
  <?php if(admania_get_option('admania_adimg_url48') != false) { ?>
  <img src="<?php echo esc_url(admania_get_option('admania_adimg_url48')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
  <?php } ?>
  </a>
  <?php
			
			endif; 
			}
			 ?>	

</div>
<?php 
 endif;
 }
		
