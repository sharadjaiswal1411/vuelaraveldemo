<?php

/**
 * Theme Home Page2 After Slider Section Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_lay4rmvcatids6 =  admania_get_option('ad_rmlyt2afsrcat');			
$admania_lay4rmvcatids_extractids6 = explode(',',$admania_lay4rmvcatids6);			
			
$admania_lay2rmvtagids6 = admania_get_option('ad_rmlyt2afsrtag');
$admania_lay2rmvtagids_extractids6 = explode(',',$admania_lay2rmvtagids6);	

$admania_lay4rmvpostids6 =  admania_get_option('ad_rmlyt2afsrpost');			
$admania_lay4rmvpostids_extractids6 = explode(',',$admania_lay4rmvpostids6);			
			
$admania_lay2rmvpageids6 = admania_get_option('ad_rmlyt2afsrpage');
$admania_lay2rmvpageids_extractids6 = explode(',',$admania_lay2rmvpageids6);			
			
if((!is_category($admania_lay4rmvcatids_extractids6)) && (!is_tag($admania_lay2rmvtagids_extractids6)) && (!is_single($admania_lay4rmvpostids_extractids6)) && (!is_page($admania_lay2rmvpageids_extractids6))) {
 
 
  if(admania_get_option('hm_lay2_aftrsldrad') != false):
  
  ?>

<div class="admania_afterslider admania_themead">
  <?php
  
  
   	if((admania_get_lveditoption('hdr_lay2lvedlhtmlad7') != false) || (admania_get_lveditoption('hdr_lay2lvedlglead7') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url24') != false)) {
			
			
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad7') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if(admania_get_lveditoption('hdr_lay2lvedlhtmlad7') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('hdr_lay2lvedlhtmlad7'));
			
			}
			
			
					
		if(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad7') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad7')); ?>
			</div>
			<?php
            }
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlglead7') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			
			if(admania_get_lveditoption('hdr_lay2lvedlglead7') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('hdr_lay2lvedlglead7'));
			}
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlglead7') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay2lvedlglead7')); ?>
			</div>
			<?php
            }
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url24') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url24') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if((admania_get_lveditoption('admania_lvedtimg_url24') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url24') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url24')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url24') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url24')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url24') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url24') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtrimgtg_url24')); ?>">
			<?php if(admania_get_lveditoption('admania_rotlvedtimg_url24') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtimg_url24')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			</div>
			<?php
            }
			
			}
 else {
  
  
           if(admania_get_option('hm_lay2_rotaftrsldrhtmlad') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
 
			if(admania_get_option('hm_lay2_aftrsldrhtmlad') != false):
			
			echo wp_kses_stripslashes(admania_get_option('hm_lay2_aftrsldrhtmlad'));
			
			endif;
			
			if(admania_get_option('hm_lay2_rotaftrsldrhtmlad') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('hm_lay2_rotaftrsldrhtmlad')); ?>
			</div>
			<?php
            }
			
			if(admania_get_option('hm_lay2_rotaftrsldrgglead') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if(admania_get_option('hm_lay2_aftrsldrgglead') != false):
			
			echo wp_kses_stripslashes(admania_get_option('hm_lay2_aftrsldrgglead'));
			
			endif;
			
			if(admania_get_option('hm_lay2_rotaftrsldrgglead') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('hm_lay2_rotaftrsldrgglead')); ?>
			</div>
			<?php
            }
			
			if((admania_get_option('admania_rotlay2_adimg_url25') != false) || (admania_get_option('admania_rotlay2adimgtg_url25') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			
			if((admania_get_option('admania_lay2_adimg_url25') != false) || (admania_get_option('admania_lay2adimgtg_url25') != false) ):
			?>
		  <a href="<?php echo esc_url(admania_get_option('admania_lay2adimgtg_url25')); ?>">
		  <?php if(admania_get_option('admania_lay2_adimg_url25') != false) { ?>
		  <img src="<?php echo esc_url(admania_get_option('admania_lay2_adimg_url25')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		  <?php } ?>
		  </a>
		<?php			
		endif; 
		
		   if((admania_get_option('admania_rotlay2_adimg_url25') != false) || (admania_get_option('admania_rotlay2adimgtg_url25') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_option('admania_rotlay2adimgtg_url25')); ?>">
			<?php if(admania_get_option('admania_rotlay2_adimg_url25') != false) { ?>
			<img src="<?php echo esc_url(admania_get_option('admania_rotlay2_adimg_url25')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			<?php } ?>
			</a>
			</div>
			<?php
            }
		
		
		}	
			
if(current_user_can('administrator')){			
?>				
<div class="admania_adeditablead1 admania_lvetresitem24">				
	<i class="fa fa-edit"></i>
	<?php esc_html_e('Edit','admania'); ?>
</div>			 
<?php } ?>	
			
</div>
<?php 
 endif;
 }
