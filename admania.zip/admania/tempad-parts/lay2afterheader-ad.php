<?php

/**
 * Theme Layout2 After Header Section Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */

 if(!is_404()) {
 
			$admania_lay4rmvcatids2 =  admania_get_option('ad_rmcatlist22');			
			$admania_lay4rmvcatids_extractids2 = explode(',',$admania_lay4rmvcatids2);			
			
			$admania_lay2rmvtagids2 = admania_get_option('ad_rmtaglist22');
			$admania_lay2rmvtagids_extractids2 = explode(',',$admania_lay2rmvtagids2);

            $admania_lay2rmvpostids2 = admania_get_option('ad_rmpostlist22');
			$admania_lay2rmvpostids_extractids2 = explode(',',$admania_lay2rmvpostids2);	

			$admania_lay2rmvpageids2 = admania_get_option('ad_rmpagelist22');
			$admania_lay2rmvpageids_extractids2 = explode(',',$admania_lay2rmvpageids2);				
			
			if((!is_category($admania_lay4rmvcatids_extractids2)) && (!is_tag($admania_lay2rmvtagids_extractids2)) && (!is_single($admania_lay2rmvpostids_extractids2)) && (!is_page($admania_lay2rmvpageids_extractids2))) {
 
 if(admania_get_option('hdr_adtplay2_act1') != false): ?>

<div class="admanina_lay2afterheader admania_themead">
  <?php
     
	if((admania_get_lveditoption('hdr_lay2lvedlhtmlad3') != false) || (admania_get_lveditoption('hdr_lay2lvedlglead3') != false) || ((admania_get_lveditoption('admania_lvedtimg_url23') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url23') != false))) {
			
			
			
		if(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad3') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if(admania_get_lveditoption('hdr_lay2lvedlhtmlad3') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('hdr_lay2lvedlhtmlad3'));
			
			}
			
					
		if(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad3') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad3')); ?>
			</div>
			<?php
            }
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlglead3') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if(admania_get_lveditoption('hdr_lay2lvedlglead3') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('hdr_lay2lvedlglead3'));
			}
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlglead3') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay2lvedlglead3')); ?>
			</div>
			<?php
            }
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url23') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url23') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if((admania_get_lveditoption('admania_lvedtimg_url23') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url23') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url23')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url23') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url23')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url23') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url23') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtrimgtg_url23')); ?>">
			<?php if(admania_get_lveditoption('admania_rotlvedtimg_url23') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtimg_url23')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			</div>
			<?php
            }
			
			}
			else {
				
			  
			if(admania_get_option('hdr_rotlay2htmlcd1') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }		
				
			if(admania_get_option('hdr_lay2htmlcd1') != false):
			
			echo wp_kses_stripslashes(admania_get_option('hdr_lay2htmlcd1'));
			
			endif;
			
			if(admania_get_option('hdr_rotlay2htmlcd1') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('hdr_rotlay2htmlcd1')); ?>
			</div>
			<?php
            }
			
			if(admania_get_option('hdr_rotlay2glecd1') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if(admania_get_option('hdr_lay2glecd1') != false):
			
			echo wp_kses_stripslashes(admania_get_option('hdr_lay2glecd1'));
			
			endif;
			
			if(admania_get_option('hdr_rotlay2glecd1') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('hdr_rotlay2glecd1')); ?>
			</div>
			<?php
            }
			
			if((admania_get_option('admania_rotadimg_url24') != false) || (admania_get_option('admania_rotadimgtg_url24') != false) ){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if((admania_get_option('admania_adimg_url24') != false) || (admania_get_option('admania_adimgtg_url24') != false) ):
			?>
			<a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url24')); ?>">
			<?php if(admania_get_option('admania_adimg_url24') != false) { ?>
			<img src="<?php echo esc_url(admania_get_option('admania_adimg_url24')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			<?php } ?>
			</a>
			<?php endif;  
  
			if((admania_get_option('admania_rotadimg_url24') != false) || (admania_get_option('admania_rotadimgtg_url24') != false) ){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url24')); ?>">
			<?php if(admania_get_option('admania_rotadimg_url24') != false) { ?>
			<img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url24')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			<?php } ?>
			</a>
			</div>
			<?php
            }	
  
   }
    if(current_user_can('administrator')){			
			?>				
             <div class="admania_adeditablead1 admania_lvetresitem23">				
			 <i class="fa fa-edit"></i>
			 <?php esc_html_e('Edit','admania'); ?>
			 </div>			
			 
	<?php } ?>
</div>
<?php endif;
}
}?>
