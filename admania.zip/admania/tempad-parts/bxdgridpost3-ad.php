<?php

/**
 * Theme Home Page5 Grid Post Section Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_boxedrmvcatids9 =  admania_get_option('ad_rmcatGrid59');			
$admania_boxedrmvcatids_extractids9 = explode(',',$admania_boxedrmvcatids9);
		
$admania_boxedrmvtagids9 = admania_get_option('ad_rmtagGrid59');
$admania_boxedrmvtagids_extractids9 = explode(',',$admania_boxedrmvtagids9);		

$admania_boxedrmvpostids9 = admania_get_option('ad_rmpostGrid59');
$admania_boxedrmvpostids_extractids9 = explode(',',$admania_boxedrmvpostids9);

$admania_boxedrmvpageids9 = admania_get_option('ad_rmpageGrid59');
$admania_boxedrmvpageids_extractids9 = explode(',',$admania_boxedrmvpageids9);			
			
if((!is_category($admania_boxedrmvcatids_extractids9)) && (!is_tag($admania_boxedrmvtagids_extractids9)) && (!is_single($admania_boxedrmvpostids_extractids9)) && (!is_page($admania_boxedrmvpageids_extractids9))) {
 
  if(admania_get_option('bxd_lyt_gridadad3') != false):
  
  ?>

<div class="admania_boxedgriditem admania_themead">
  <?php
  
     	if((admania_get_lveditoption('bxd_posthtmlad3') != false) || (admania_get_lveditoption('bxd_postglead3') != false) || (admania_get_lveditoption('admania_lvedtimg_url52') != false)) {
			if(admania_get_lveditoption('bxd_posthtmlad3') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_posthtmlad3'));
			
			}
			if(admania_get_lveditoption('bxd_postglead3') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_postglead3'));
			}
			
			if((admania_get_lveditoption('admania_lvedtimg_url52') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url52') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url52')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url52') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url52')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			}
 
  else {
	  
	        if(admania_get_option('bxd_rotlytpsadhtml13') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
	  
 
			if(admania_get_option('bxd_lytpsadhtml13') != false):
			
			echo wp_kses_stripslashes(admania_get_option('bxd_lytpsadhtml13'));
			
			endif;
			
			if(admania_get_option('bxd_rotlytpsadhtml13') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('bxd_rotlytpsadhtml13')); ?>
			</div>
			<?php
            }
			
			 if(admania_get_option('bxd_rotlytgglead13') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if(admania_get_option('bxd_lytgglead13') != false):
			
			echo wp_kses_stripslashes(admania_get_option('bxd_lytgglead13'));
			
			endif;
			
			if(admania_get_option('bxd_rotlytgglead13') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('bxd_rotlytgglead13')); ?>
			</div>
			<?php
            }
			
			if((admania_get_option('admania_rotadimg_url59') != false) || (admania_get_option('admania_rotadimgtg_url59') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if((admania_get_option('admania_adimg_url59') != false) || (admania_get_option('admania_adimgtg_url59') != false) ):
			?>
  <a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url59')); ?>">
  <?php if(admania_get_option('admania_adimg_url59') != false) { ?>
  <img src="<?php echo esc_url(admania_get_option('admania_adimg_url59')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
  <?php } ?>
  </a>
  <?php
			
			endif; 
			
			if((admania_get_option('admania_rotadimg_url59') != false) || (admania_get_option('admania_rotadimgtg_url59') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url59')); ?>">
				<?php if(admania_get_option('admania_rotadimg_url59') != false) { ?>
				<img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url59')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
				<?php } ?>
				</a>
			</div>
			<?php
            }
			
			
			}
			
	if(current_user_can('administrator')){			
?>				
<div class="admania_adeditablead1 admania_lvetresitem52">				
	<i class="fa fa-edit"></i>
	<?php esc_html_e('Edit','admania'); ?>
</div>			 
<?php } ?>	

</div>
<?php 
 endif;
 }
