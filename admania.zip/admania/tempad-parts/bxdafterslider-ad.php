<?php

/**
 * Theme Boxed After Slider Section Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_bxdafsldcatids1 =  admania_get_option('ad_rmcatGrid51');			
$admania_bxdafsld_extractids1 = explode(',',$admania_bxdafsldcatids1);			
			
$admania_afsldtagids1 = admania_get_option('ad_rmtagGrid51');
$admania_afsldtgids_extractids1 = explode(',',$admania_afsldtagids1);	

$admania_afsldpostids1 =  admania_get_option('ad_rmpostGrid51');			
$admania_afsldpostids_extractids1 = explode(',',$admania_afsldpostids1);			
			
$admania_bxdrmvpageids1 = admania_get_option('ad_rmpageGrid51');
$admania_bxdpageids_extractids1 = explode(',',$admania_bxdrmvpageids1);			
			
if((!is_category($admania_bxdafsld_extractids1)) && (!is_tag($admania_afsldtgids_extractids1)) && (!is_single($admania_afsldpostids_extractids1)) && (!is_page($admania_bxdpageids_extractids1))) {
 
 
  if(admania_get_option('admania_bxdafsldrad') != false):
  
  ?>

<div class="admania_boxedafsldad admania_themead">
  <?php
  
  
   	if((admania_get_lveditoption('bxd_afsldhtmlad') != false) || (admania_get_lveditoption('bxd_afsldglead') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url49') != false)) {
			
			
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad7') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if(admania_get_lveditoption('bxd_afsldhtmlad') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_afsldhtmlad'));
			
			}
			
			
					
		if(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad7') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad7')); ?>
			</div>
			<?php
            }
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlglead7') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			
			if(admania_get_lveditoption('bxd_afsldglead') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_afsldglead'));
			}
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlglead7') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay2lvedlglead7')); ?>
			</div>
			<?php
            }
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url24') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url24') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if((admania_get_lveditoption('admania_lvedtimg_url49') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url49') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url49')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url49') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url49')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url24') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url24') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtrimgtg_url24')); ?>">
			<?php if(admania_get_lveditoption('admania_rotlvedtimg_url24') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtimg_url24')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			</div>
			<?php
            }
			
			}
 else {
  
  
           if(admania_get_option('bxd_rotafhdrhtmlcode') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
 
			if(admania_get_option('bxd_afhdrhtmlcode') != false):
			
			echo wp_kses_stripslashes(admania_get_option('bxd_afhdrhtmlcode'));
			
			endif;
			
			if(admania_get_option('bxd_rotafhdrhtmlcode') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('bxd_rotafhdrhtmlcode')); ?>
			</div>
			<?php
            }
			
			if(admania_get_option('bxd_rotafhdrglecd') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if(admania_get_option('bxd_afhdrglecd') != false):
			
			echo wp_kses_stripslashes(admania_get_option('bxd_afhdrglecd'));
			
			endif;
			
			if(admania_get_option('bxd_rotafhdrglecd') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('bxd_rotafhdrglecd')); ?>
			</div>
			<?php
            }
			
			if((admania_get_option('admania_rotadimg_url56') != false) || (admania_get_option('admania_rotadimgtg_url56') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			
			if((admania_get_option('admania_adimg_url56') != false) || (admania_get_option('admania_adimgtg_url56') != false) ):
			?>
		  <a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url56')); ?>">
		  <?php if(admania_get_option('admania_adimg_url56') != false) { ?>
		  <img src="<?php echo esc_url(admania_get_option('admania_adimg_url56')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		  <?php } ?>
		  </a>
		<?php			
		endif; 
		
		   if((admania_get_option('admania_rotadimg_url56') != false) || (admania_get_option('admania_rotadimgtg_url56') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url56')); ?>">
			<?php if(admania_get_option('admania_rotadimg_url56') != false) { ?>
			<img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url56')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			<?php } ?>
			</a>
			</div>
			<?php
            }
		
		
		}	
			
if(current_user_can('administrator')){			
?>				
<div class="admania_adeditablead1 admania_lvetresitem49">				
	<i class="fa fa-edit"></i>
	<?php esc_html_e('Edit','admania'); ?>
</div>			 
<?php } ?>	
			
</div>
<?php 
 endif;
 }
