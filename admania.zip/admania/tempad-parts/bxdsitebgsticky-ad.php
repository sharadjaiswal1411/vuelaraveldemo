<?php 


/**
 * Theme Home Page3 Header Ad.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 

			
			$admania_bxdrmcatids =  admania_get_option('ad_rmcatGrid48');			
			$admania_bxdrmcatids_extractids = explode(',',$admania_bxdrmcatids);			
			
			$admania_bxdrmtagids = admania_get_option('ad_rmtagGrid48');
			$admania_bxdrmtagids_extractids = explode(',',$admania_bxdrmtagids);			
			
			$admania_bxdrmpostids = admania_get_option('ad_rmpostGrid48');
			$admania_bxdrmpostids_extractids = explode(',',$admania_bxdrmpostids);
			
			$admania_bxdrmpageids = admania_get_option('ad_rmpageGrid48');
			$admania_bxdrmpageids_extractids = explode(',',$admania_bxdrmpageids);
			
				
		
			if(((!is_category($admania_bxdrmcatids_extractids)) && (!is_tag($admania_bxdrmtagids_extractids)) && (!is_single($admania_bxdrmpostids_extractids)) && (!is_page($admania_bxdrmpageids_extractids)))) {
					
			
			if(admania_get_option('boxed_siteleftads') != false): ?>
			
			<div class="admania_sitesideleftads admania_themead">
			
			<?php
			
			if((admania_get_lveditoption('bxd_sitelfthtmlad') != false) || (admania_get_lveditoption('bxd_sitelftglead') != false) || ((admania_get_lveditoption('admania_lvedtimg_url45') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url45') != false))) {
			
						
			if(admania_get_lveditoption('hdr_rotlay3lvedlhtmlad') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if(admania_get_lveditoption('bxd_sitelfthtmlad') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_sitelfthtmlad'));
			
			}
			
			if(admania_get_lveditoption('hdr_rotlay3lvedlhtmlad') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay3lvedlhtmlad')); ?>
			</div>
			<?php
            }
			
			if(admania_get_lveditoption('hdr_rotlay3lvedlglead') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			
			if(admania_get_lveditoption('bxd_sitelftglead') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_sitelftglead'));
			}
			
			if(admania_get_lveditoption('hdr_rotlay3lvedlglead') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay3lvedlglead')); ?>
			</div>
			<?php
            }
			
			
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url27') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url27') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			
			
			if((admania_get_lveditoption('admania_lvedtimg_url45') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url45') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url45')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url45') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url45')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			}

			if((admania_get_lveditoption('admania_rotlvedtimg_url27') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url27') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtrimgtg_url27')); ?>">
			<?php if(admania_get_lveditoption('admania_rotlvedtimg_url27') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtimg_url27')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			</div>
			<?php
            }			
			
			}
			
			else {

            if(admania_get_option('boxed_stlfthtmlad') != false) {	

            if(admania_get_option('boxed_rotstlfthtmlad') != false){
			?>
			<div class="admania_lyt3rothad1 test">	
			<?php
            }				
			  	
			echo wp_kses_stripslashes(admania_get_option('boxed_stlfthtmlad'));  
   		
			
            if(admania_get_option('boxed_rotstlfthtmlad') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<?php 	echo wp_kses_stripslashes(admania_get_option('boxed_rotstlfthtmlad')); ?>
			</div>
			<?php
            }	
          		
			
            }

            if(admania_get_option('boxed_stlftgglead') != false){	


            if(admania_get_option('boxed_rotstlftgglead') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			echo wp_kses_stripslashes(admania_get_option('boxed_stlftgglead'));
			
			if(admania_get_option('boxed_rotstlftgglead') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<?php 	echo wp_kses_stripslashes(admania_get_option('boxed_rotstlftgglead')); ?>
			</div>
			<?php
            }	
			
			}
			
			
			if((admania_get_option('admania_adimg_url53') != false) || (admania_get_option('admania_adimgtg_url53') != false) ){
			
			if((admania_get_option('admania_rotadimg_url53') != false) || (admania_get_option('admania_rotadimgtg_url53') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
            ?>			
			 <a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url53')); ?>">
			<?php if(admania_get_option('admania_adimg_url53') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_option('admania_adimg_url53')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			 if((admania_get_option('admania_rotadimg_url53') != false) || (admania_get_option('admania_rotadimgtg_url53') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url53')); ?>">
			<?php if(admania_get_option('admania_rotadimg_url53') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url53')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			</div>
			<?php
            }
          		
			} 
			
			}									
			
			if(current_user_can('administrator')){			
			
			?>		
			
             <div class="admania_adeditablead1 admania_lvetresitem45">				
			 <i class="fa fa-edit"></i>
			 <?php esc_html_e('Edit','admania'); ?>
			 </div>			
			 
			 <?php } ?>
		
			 </div>
			 
			 <?php 
			 endif; 
			 
			 }
			 
			 
			 ?>