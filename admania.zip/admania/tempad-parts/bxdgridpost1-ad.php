<?php

/**
 * Theme Home Page5 Grid Post Section Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_bxdrmvcatids7 =  admania_get_option('ad_rmcatGrid57');			
$admania_bxdrmvcatids_extractids7 = explode(',',$admania_bxdrmvcatids7);
		
$admania_bxdrmvtagids7 = admania_get_option('ad_rmtagGrid57');
$admania_bxdrmvtagids_extractids7 = explode(',',$admania_bxdrmvtagids7);		

$admania_bxdrmvpostids7 = admania_get_option('ad_rmpostGrid57');
$admania_bxdrmvpostids_extractids7 = explode(',',$admania_bxdrmvpostids7);	

$admania_bxdrmvpageids7 = admania_get_option('ad_rmpageGrid57');
$admania_bxdrmvpageids_extractids7 = explode(',',$admania_bxdrmvpageids7);
	
			
if((!is_category($admania_bxdrmvcatids_extractids7)) && (!is_tag($admania_bxdrmvtagids_extractids7)) && (!is_single($admania_bxdrmvpostids_extractids7)) && (!is_page($admania_bxdrmvpageids_extractids7))) {
 
  if(admania_get_option('bxd_lyt_gridad') != false):
  
  ?>

<div class="admania_boxedgriditem  admania_themead">
  <?php
  
     	if((admania_get_lveditoption('bxd_posthtmlad1') != false) || (admania_get_lveditoption('bxd_postglead1') != false) || (admania_get_lveditoption('admania_lvedtimg_url50') != false)) {
			if(admania_get_lveditoption('bxd_posthtmlad1') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_posthtmlad1'));
			
			}
			if(admania_get_lveditoption('bxd_postglead1') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_postglead1'));
			}
			
			if((admania_get_lveditoption('admania_lvedtimg_url50') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url50') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url50')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url50') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url50')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			}
 
  else {
 
			if(admania_get_option('bxd_rotlytpsadhtml1') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
 
			if(admania_get_option('bxd_lytpsadhtml1') != false):
			
			echo wp_kses_stripslashes(admania_get_option('bxd_lytpsadhtml1'));
			
			endif;
			
			if(admania_get_option('bxd_rotlytpsadhtml1') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('bxd_rotlytpsadhtml1')); ?>
			</div>
			<?php
            }
			
			
			
			if(admania_get_option('bxd_rotlytgglead1') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			
			if(admania_get_option('bxd_lytgglead1') != false):
			
			echo wp_kses_stripslashes(admania_get_option('bxd_lytgglead1'));
			
			endif;
			
			if(admania_get_option('bxd_rotlytgglead1') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('bxd_rotlytgglead1')); ?>
			</div>
			<?php
            }
			
			
			if((admania_get_option('admania_rotadimg_url57') != false) || (admania_get_option('admania_rotadimgtg_url57') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			
			
			if((admania_get_option('admania_adimg_url57') != false) || (admania_get_option('admania_adimgtg_url57') != false) ):
			?>
			  <a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url57')); ?>">
			  <?php if(admania_get_option('admania_adimg_url57') != false) { ?>
			  <img src="<?php echo esc_url(admania_get_option('admania_adimg_url57')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			  <?php } ?>
			  </a>
			<?php
			
			endif; 
			
			
			
			if((admania_get_option('admania_rotadimg_url57') != false) || (admania_get_option('admania_rotadimgtg_url57') != false)){

			?>
			</div>
			<div class="admania_lyt3rothad2">	
			  <a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url57')); ?>">
			  <?php if(admania_get_option('admania_rotadimg_url57') != false) { ?>
			  <img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url57')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			  <?php } ?>
			  </a>
			</div>
			<?php
            }
			
			}
			
	if(current_user_can('administrator')){			
?>				
<div class="admania_adeditablead1 admania_lvetresitem50">				
	<i class="fa fa-edit"></i>
	<?php esc_html_e('Edit','admania'); ?>
</div>			 
<?php } ?>	

</div>
<?php 
 endif;
 }
