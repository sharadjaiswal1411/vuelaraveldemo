<?php 


/**
 * Theme Home Page3 Header Ad.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 

			
			$admania_bxdrmcatids =  admania_get_option('ad_rmcatGrid49');			
			$admania_bxdrmcatids_extractids = explode(',',$admania_bxdrmcatids);			
			
			$admania_bxdrmtagids = admania_get_option('ad_rmtagGrid49');
			$admania_bxdrmtagids_extractids = explode(',',$admania_bxdrmtagids);			
			
			$admania_bxdrmpostids = admania_get_option('ad_rmpostGrid49');
			$admania_bxdrmpostids_extractids = explode(',',$admania_bxdrmpostids);
			
			$admania_bxdrmpageids = admania_get_option('ad_rmpageGrid49');
			$admania_bxdrmpageids_extractids = explode(',',$admania_bxdrmpageids);
			
				
		
			if(((!is_category($admania_bxdrmcatids_extractids)) && (!is_tag($admania_bxdrmtagids_extractids)) && (!is_single($admania_bxdrmpostids_extractids)) && (!is_page($admania_bxdrmpageids_extractids)))) {
					
			
			if(admania_get_option('boxed_sitergtads') != false): ?>
			
			<div class="admania_sitesiderightads admania_themead">
			
			<?php
			
			if((admania_get_lveditoption('bxd_sitergtglead') != false) || (admania_get_lveditoption('hdr_lay3lvedlglead') != false) || ((admania_get_lveditoption('admania_lvedtimg_url46') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url46') != false))) {
			
						
			if(admania_get_lveditoption('hdr_rotlay3lvedlhtmlad') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if(admania_get_lveditoption('bxd_sitergtglead') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_sitergtglead'));
			
			}
			
			if(admania_get_lveditoption('hdr_rotlay3lvedlhtmlad') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay3lvedlhtmlad')); ?>
			</div>
			<?php
            }
			
			if(admania_get_lveditoption('hdr_rotlay3lvedlglead') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			
			if(admania_get_lveditoption('hdr_lay3lvedlglead') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('hdr_lay3lvedlglead'));
			}
			
			if(admania_get_lveditoption('hdr_rotlay3lvedlglead') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay3lvedlglead')); ?>
			</div>
			<?php
            }
			
			
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url27') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url27') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			
			
			if((admania_get_lveditoption('admania_lvedtimg_url46') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url46') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url46')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url46') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url46')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			}

			if((admania_get_lveditoption('admania_rotlvedtimg_url27') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url27') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtrimgtg_url27')); ?>">
			<?php if(admania_get_lveditoption('admania_rotlvedtimg_url27') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtimg_url27')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			</div>
			<?php
            }			
			
			}
			
			else {

            if(admania_get_option('boxed_strgthtmlad') != false) {	

            if(admania_get_option('boxed_rotstrgthtmlad') != false){
			?>
			<div class="admania_lyt3rothad1 test">	
			<?php
            }				
			  	
			echo wp_kses_stripslashes(admania_get_option('boxed_strgthtmlad'));  
   		
			
            if(admania_get_option('boxed_rotstrgthtmlad') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<?php 	echo wp_kses_stripslashes(admania_get_option('boxed_rotstrgthtmlad')); ?>
			</div>
			<?php
            }	
          		
			
            }

            if(admania_get_option('boxed_strgtgglead') != false){	


            if(admania_get_option('boxed_rotstrgtgglead') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			echo wp_kses_stripslashes(admania_get_option('boxed_strgtgglead'));
			
			if(admania_get_option('boxed_rotstrgtgglead') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<?php 	echo wp_kses_stripslashes(admania_get_option('boxed_rotstrgtgglead')); ?>
			</div>
			<?php
            }	
			
			}
			
			
			if((admania_get_option('admania_adimg_url54') != false) || (admania_get_option('admania_adimgtg_url54') != false) ){
			
			if((admania_get_option('admania_rotadimg_url54') != false) || (admania_get_option('admania_rotadimgtg_url54') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
            ?>			
			 <a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url54')); ?>">
			<?php if(admania_get_option('admania_adimg_url54') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_option('admania_adimg_url54')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			 if((admania_get_option('admania_rotadimg_url54') != false) || (admania_get_option('admania_rotadimgtg_url54') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url54')); ?>">
			<?php if(admania_get_option('admania_rotadimg_url54') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url54')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			</div>
			<?php
            }
          		
			} 
			
			}									
			
			if(current_user_can('administrator')){			
			
			?>		
			
             <div class="admania_adeditablead1 admania_lvetresitem46">				
			 <i class="fa fa-edit"></i>
			 <?php esc_html_e('Edit','admania'); ?>
			 </div>			
			 
			 <?php } ?>
		
			 </div>
			 
			 <?php 
			 endif; 
			 
			 }
			 
			 
			 ?>