<?php

/**
 * Theme Mobile After Header Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_mbafsldrmvcatids =  admania_get_option('ad_rmcatlist29');			
$admania_afhdrmvcatid_extractid = explode(',',$admania_mbafsldrmvcatids);			
			
$admania_afhdtagids = admania_get_option('ad_rmtaglist29');
$admania_afhdtagids_extractids = explode(',',$admania_afhdtagids);

$admania_afhdrmvpostids = admania_get_option('ad_rmpostlist29');
$admania_afhdrmv_extractids = explode(',',$admania_afhdrmvpostids);

$admania_afhdrmvpageids = admania_get_option('ad_rmpagelist29');
$admania_afhdpageids_extractids = explode(',',$admania_afhdrmvpageids);			
			
if((!is_category($admania_afhdrmvcatid_extractid)) && (!is_tag($admania_afhdtagids_extractids)) && (!is_single($admania_afhdrmv_extractids)) && (!is_page($admania_afhdpageids_extractids))) {

if(admania_get_option('sld_afad_act') != false):
  
?>

<div class="admania_mbafsldad admania_themead">
  <?php
       	if((admania_get_lveditoption('flvedtmb_afsldhtmlad') != false) || (admania_get_lveditoption('flvedtmb_afsldgooglead') != false) || (admania_get_lveditoption('admania_lvedtimg_url47') != false)) {
			
			if(admania_get_lveditoption('flvedtmb_afsldhtmlad') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('flvedtmb_afsldhtmlad'));
			
			}
			if(admania_get_lveditoption('flvedtmb_afsldgooglead') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('flvedtmb_afsldgooglead'));
			}
			
			if((admania_get_lveditoption('admania_lvedtimg_url47') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url47') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url47')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url47') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url47')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			}
 
 else {
			if(admania_get_option('sld_afhtmlad') != false):
			
			echo wp_kses_stripslashes(admania_get_option('sld_afhtmlad'));
			
			endif;
			
			if(admania_get_option('sld_afgooglead') != false):
			
			echo wp_kses_stripslashes(admania_get_option('sld_afgooglead'));
			
			endif;
			
			if((admania_get_option('admania_adimg_url50') != false) || (admania_get_option('admania_adimgtg_url50') != false) ):
			?>
  <a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url50')); ?>">
  <?php if(admania_get_option('admania_adimg_url50') != false) { ?>
  <img src="<?php echo esc_url(admania_get_option('admania_adimg_url50')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
  <?php } ?>
  </a>
  <?php
			
			endif; 
			}
				if(current_user_can('administrator')){			
?>				
<div class="admania_adeditablead1 admania_lvetresitem47">				
	<i class="fa fa-edit"></i>
	<?php esc_html_e('Edit','admania'); ?>
</div>			 
<?php } ?>	

</div>
<?php 
 endif;
 }
		
