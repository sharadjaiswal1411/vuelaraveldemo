<?php

/**
 * Theme Home Page After list Post Section Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_lay4rmvcatids7 =  admania_get_option('ad_rmcatlist24');			
$admania_lay4rmvcatids_extractids7 = explode(',',$admania_lay4rmvcatids7);
		
$admania_lay2rmvtagids7 = admania_get_option('ad_rmtaglist24');
$admania_lay2rmvtagids_extractids7 = explode(',',$admania_lay2rmvtagids7);		

$admania_lay2rmvpostids7 = admania_get_option('ad_rmpostlist24');
$admania_lay2rmvpostids_extractids7 = explode(',',$admania_lay2rmvpostids7);	

$admania_lay2rmvpageids7 = admania_get_option('ad_rmpagelist24');
$admania_lay2rmvpageids_extractids7 = explode(',',$admania_lay2rmvpageids7);		
			
if((!is_category($admania_lay4rmvcatids_extractids7)) && (!is_tag($admania_lay2rmvtagids_extractids7)) && (!is_single($admania_lay2rmvpostids_extractids7)) && (!is_page($admania_lay2rmvpageids_extractids7))) {
 
  if(admania_get_option('hm_aftrListad') != false):
  
  ?>

<div class="admania_afterslider admania_afterlistpst admania_themead">
  <?php
  
     	if((admania_get_lveditoption('hdr_lay2lvedlhtmlad8') != false) || (admania_get_lveditoption('hdr_lay2lvedlglead8') != false) || (admania_get_lveditoption('admania_lvedtimg_url25') != false)) {
			
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad8') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if(admania_get_lveditoption('hdr_lay2lvedlhtmlad8') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('hdr_lay2lvedlhtmlad8'));
			
			}
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad8') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad8')); ?>
			</div>
			<?php
            }
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlglead8') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if(admania_get_lveditoption('hdr_lay2lvedlglead8') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('hdr_lay2lvedlglead8'));
			}
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlglead8') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay2lvedlglead8')); ?>
			</div>
			<?php
            }
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url25') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url25') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			
			
			if((admania_get_lveditoption('admania_lvedtimg_url25') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url25') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url25')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url25') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url25')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url25') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url25') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtrimgtg_url25')); ?>">
			<?php if(admania_get_lveditoption('admania_rotlvedtimg_url25') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtimg_url25')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			</div>
			<?php
            }
			
			}
 
  else {
 
 	  
			if(admania_get_option('hm_rotaftrListhtmlad') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
 
			if(admania_get_option('hm_aftrListhtmlad') != false):
			
			echo wp_kses_stripslashes(admania_get_option('hm_aftrListhtmlad'));
			
			endif;
			
			if(admania_get_option('hm_rotaftrListhtmlad') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('hm_rotaftrListhtmlad')); ?>
			</div>
			<?php
            }
			
			if(admania_get_option('hm_rotaftrListgglead') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
 
			
			if(admania_get_option('hm_aftrListgglead') != false):
			
			echo wp_kses_stripslashes(admania_get_option('hm_aftrListgglead'));
			
			endif;
			
			if(admania_get_option('hm_rotaftrListgglead') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('hm_rotaftrListgglead')); ?>
			</div>
			<?php
            }
			
			if((admania_get_option('admania_rotadimg_url26') != false) || (admania_get_option('admania_rotadimgtg_url26') != false) ){
			?>
			<div class="admania_lyt3rothad1">	
			<?php	
			}

			
			if((admania_get_option('admania_adimg_url26') != false) || (admania_get_option('admania_adimgtg_url26') != false) ):
			?>
			<a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url26')); ?>">
			<?php if(admania_get_option('admania_adimg_url26') != false) { ?>
			<img src="<?php echo esc_url(admania_get_option('admania_adimg_url26')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			<?php } ?>
			</a>
			<?php
			
			endif; 
			
			if((admania_get_option('admania_rotadimg_url26') != false) || (admania_get_option('admania_rotadimgtg_url26') != false) ){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url26')); ?>">
				<?php if(admania_get_option('admania_rotadimg_url26') != false) { ?>
				<img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url26')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
				<?php } ?>
				</a>
			</div>
			<?php
			}
			
			}
			
	if(current_user_can('administrator')){			
?>				
<div class="admania_adeditablead1 admania_lvetresitem25">				
	<i class="fa fa-edit"></i>
	<?php esc_html_e('Edit','admania'); ?>
</div>			 
<?php } ?>	

</div>
<?php 
 endif;
 }
