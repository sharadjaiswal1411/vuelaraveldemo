<?php

/**
 * Theme Boxed After Header Section Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */

 if(!is_404()) {
 
			$admania_bxdrmvcatids3 =  admania_get_option('ad_rmcatGrid50');			
			$admania_bxdrmvcatids_extractids3 = explode(',',$admania_bxdrmvcatids3);			
			
			$admania_bxdrmvtagids3 = admania_get_option('ad_rmtagGrid50');
			$admania_bxdrmvtagids_extractids3 = explode(',',$admania_bxdrmvtagids3);

            $admania_bxdrmvpostids3 = admania_get_option('ad_rmpostGrid50');
			$admania_bxdrmvpostids_extractids3 = explode(',',$admania_bxdrmvpostids3);	

			$admania_bxdrmvpageids3 = admania_get_option('ad_rmpageGrid50');
			$admania_bxdrmvpageids_extractids3 = explode(',',$admania_bxdrmvpageids3);				
			
			if((!is_category($admania_bxdrmvcatids_extractids3)) && (!is_tag($admania_bxdrmvtagids_extractids3)) && (!is_single($admania_bxdrmvpostids_extractids3)) && (!is_page($admania_bxdrmvpageids_extractids3))) {
 
 if(admania_get_option('admania_bxdafhdrad') != false): ?>

<div class="admania_boxedafhdrad admania_themead">
  <?php
     
	if((admania_get_lveditoption('bxd_afhdhtmlad') != false) || (admania_get_lveditoption('bxd_afhdglead') != false) || ((admania_get_lveditoption('admania_lvedtimg_url48') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url48') != false))) {
			
			
			
		if(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad3') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if(admania_get_lveditoption('bxd_afhdhtmlad') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_afhdhtmlad'));
			
			}
			
					
		if(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad3') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad3')); ?>
			</div>
			<?php
            }
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlglead3') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if(admania_get_lveditoption('bxd_afhdglead') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_afhdglead'));
			}
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlglead3') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay2lvedlglead3')); ?>
			</div>
			<?php
            }
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url23') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url23') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if((admania_get_lveditoption('admania_lvedtimg_url48') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url48') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url48')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url48') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url48')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url23') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url23') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtrimgtg_url23')); ?>">
			<?php if(admania_get_lveditoption('admania_rotlvedtimg_url23') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtimg_url23')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			</div>
			<?php
            }
			
			}
			else {
				
			  
			if(admania_get_option('bxd_rotafhdrhtmlcode') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }		
				
			if(admania_get_option('bxd_afhdrhtmlcode') != false):
			
			echo wp_kses_stripslashes(admania_get_option('bxd_afhdrhtmlcode'));
			
			endif;
			
			if(admania_get_option('bxd_rotafhdrhtmlcode') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('bxd_rotafhdrhtmlcode')); ?>
			</div>
			<?php
            }
			
			if(admania_get_option('bxd_rotafhdrglecd') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if(admania_get_option('bxd_afhdrglecd') != false):
			
			echo wp_kses_stripslashes(admania_get_option('bxd_afhdrglecd'));
			
			endif;
			
			if(admania_get_option('bxd_rotafhdrglecd') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('bxd_rotafhdrglecd')); ?>
			</div>
			<?php
            }
			
			if((admania_get_option('admania_rotadimg_url55') != false) || (admania_get_option('admania_rotadimgtg_url55') != false) ){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if((admania_get_option('admania_adimg_url55') != false) || (admania_get_option('admania_adimgtg_url55') != false) ):
			?>
			<a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url55')); ?>">
			<?php if(admania_get_option('admania_adimg_url55') != false) { ?>
			<img src="<?php echo esc_url(admania_get_option('admania_adimg_url55')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			<?php } ?>
			</a>
			<?php endif;  
  
			if((admania_get_option('admania_rotadimg_url55') != false) || (admania_get_option('admania_rotadimgtg_url55') != false) ){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url55')); ?>">
			<?php if(admania_get_option('admania_rotadimg_url55') != false) { ?>
			<img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url55')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			<?php } ?>
			</a>
			</div>
			<?php
            }	
  
   }
    if(current_user_can('administrator')){			
			?>				
             <div class="admania_adeditablead1 admania_lvetresitem48">				
			 <i class="fa fa-edit"></i>
			 <?php esc_html_e('Edit','admania'); ?>
			 </div>			
			 
	<?php } ?>
</div>
<?php endif;
}
}?>
