<?php

/**
 * Theme Home Page5 Grid Post Section Ad for our theme.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 
$admania_boxedrmvcatids13 =  admania_get_option('ad_rmcatGrid60');			
$admania_boxedrmvcatids_extractids13 = explode(',',$admania_boxedrmvcatids13);
		
$admania_boxedrmvtagids13 = admania_get_option('ad_rmtagGrid60');
$admania_boxedrmvtagids_extractids13 = explode(',',$admania_boxedrmvtagids13);	

$admania_boxedrmvpostids13 = admania_get_option('ad_rmpostGrid60');
$admania_boxedrmvpostids_extractids13 = explode(',',$admania_boxedrmvpostids13);

$admania_boxedrmvpageids13 = admania_get_option('ad_rmpageGrid60');
$admania_boxedrmvpageids_extractids13 = explode(',',$admania_boxedrmvpageids13);		
			
if((!is_category($admania_boxedrmvcatids_extractids13)) && (!is_tag($admania_boxedrmvtagids_extractids13)) && (!is_single($admania_boxedrmvpostids_extractids13)) && (!is_page($admania_boxedrmvpageids_extractids13))) {
 
  if(admania_get_option('bxd_lyt_gridadad4') != false):
  
  ?>

<div class="admania_boxedgriditem admania_boxedgriditemlast admania_themead">
  <?php
  
     	if((admania_get_lveditoption('bxd_posthtmlad4') != false) || (admania_get_lveditoption('bxd_postglead4') != false) || (admania_get_lveditoption('admania_lvedtimg_url53') != false)) {
			if(admania_get_lveditoption('bxd_posthtmlad4') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_posthtmlad4'));
			
			}
			if(admania_get_lveditoption('bxd_postglead4') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_postglead4'));
			}
			
			if((admania_get_lveditoption('admania_lvedtimg_url53') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url53') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url53')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url53') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url53')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			}
 
  else {
 
            if(admania_get_option('bxd_rotlytpsadhtml14') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
 
			if(admania_get_option('bxd_lytpsadhtml14') != false):
			
			echo wp_kses_stripslashes(admania_get_option('bxd_lytpsadhtml14'));
			
			endif;
			
			
			if(admania_get_option('bxd_rotlytpsadhtml14') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('bxd_rotlytpsadhtml14')); ?>
			</div>
			<?php
            }
			
			if(admania_get_option('bxd_rotlytgglead14') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if(admania_get_option('bxd_lytgglead14') != false):
			
			echo wp_kses_stripslashes(admania_get_option('bxd_lytgglead14'));
			
			endif;
			
		    if(admania_get_option('bxd_rotlytgglead14') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('bxd_rotlytgglead14')); ?>
			</div>
			<?php
            }
			
			if((admania_get_option('admania_rotadimg_url60') != false) || (admania_get_option('admania_rotadimgtg_url60') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if((admania_get_option('admania_adimg_url60') != false) || (admania_get_option('admania_adimgtg_url60') != false) ):
			?>
			<a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url60')); ?>">
			<?php if(admania_get_option('admania_adimg_url60') != false) { ?>
			<img src="<?php echo esc_url(admania_get_option('admania_adimg_url60')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			<?php } ?>
			</a>
			<?php
			
			endif; 
			
			 if((admania_get_option('admania_rotadimg_url60') != false) || (admania_get_option('admania_rotadimgtg_url60') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url60')); ?>">
				<?php if(admania_get_option('admania_rotadimg_url60') != false) { ?>
				<img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url60')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
				<?php } ?>
				</a>
			</div>
			<?php
            }
			
			
			}
			
	if(current_user_can('administrator')){			
?>				
<div class="admania_adeditablead1 admania_lvetresitem53">				
	<i class="fa fa-edit"></i>
	<?php esc_html_e('Edit','admania'); ?>
</div>			 
<?php } ?>	

</div>
<?php 
 endif;
 }
