<?php
/**
 * The template for displaying the header
 *
 * 
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head itemscope="itemscope" itemtype="http://schema.org/WebSite">
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<?php if( true != admania_get_option('admania_responsive')): ?>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<?php endif; ?>
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php esc_url(bloginfo( 'pingback_url' )); ?>">
	<?php endif;		
	/**
	* This hook is important for wordpress plugins and other many things
	*/
	wp_head();
	
	if( false != admania_get_option('admania_header_script')): 	
		echo wp_kses_stripslashes(admania_get_option('admania_header_script'));	
	endif;
	
	

?>
</head>

<?php 
 
$admania_blog_layout = ((admania_get_option('admania_blog_scheme')) ? admania_get_option('admania_blog_scheme') : 'amblyt1');
	

if( $admania_blog_layout == 'amblyt6'): 	

$admania_blog_bdyclass = 'admania_boxedlayout';

else:

$admania_blog_bdyclass = '';
		
endif;

?>

<body <?php body_class(''.esc_attr($admania_blog_bdyclass).''); ?> itemscope="itemscope" itemtype="http://schema.org/WebPage">

<div class="admania_sitecontainer">

   <?php
   if(admania_get_option('admania_adblockaact') != 1) {
   ?>
    <div class="admania_adblock_detector" id="admania_adb_enabled">
		<div class="admania_adb_enabledinner">
		<div class="admania_adb_enbtp">
		<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
		</div>
		<div class="admania_adb_enbtm">
		    <h6><?php echo esc_html(admania_get_option('admania_adblocktitle') ? admania_get_option('admania_adblocktitle') : 'Oh Snap!' );  ?></h6>
			<p><?php  echo esc_html(admania_get_option('admania_adblockdesp') ? admania_get_option('admania_adblockdesp') : 'Please turnoff your ad blocking mode for viewing your site content');  ?></p>
		</div>
		</div>
	</div>
	<?php
   }
	/*
	*  Include the front-end liveeditor options template.			
	*/		
	get_template_part('lib/includes/admania','frontliveeditor');
	
	?>  
	
	
	
	<header class="admania_siteheader" itemscope="" itemtype="http://schema.org/WPHeader">
		
		
		<?php 
		
		$admania_header_type = ((admania_get_option('admania_headertype_scheme')) ? admania_get_option('admania_headertype_scheme') : 'amheader1');
		
		
				
		if((admania_get_option('admania_enmblayout') != '') && (wp_is_mobile())) {

		get_template_part('tempad-parts/mbbfhdad');
		
        get_template_part('tempheader-parts/mbheader','content'); // layout1 header content
		
		}
		else {
		
		if(($admania_blog_layout == 'amblyt6')) {
			get_template_part('tempheader-parts/amlayout6header','content'); // boxed layout header content
		}

        else {		
			
		if($admania_header_type == 'amheader1') { 
		
			get_template_part('tempheader-parts/amlayout1header','content'); // layout1 header content
	   
	    }  
		elseif($admania_header_type == 'amheader2') { 
	   
			get_template_part('tempad-parts/lay2headertop','ad'); // layout2 header ad
	   
			get_template_part('tempheader-parts/amlayout2header','content'); // layout2 header content
			
		}
	    elseif($admania_header_type == 'amheader3') {  
		
			get_template_part('tempheader-parts/amlayout3header','content'); // layout3 header content
			
	    }
		
		elseif($admania_header_type == 'amheader4') {  
		
			get_template_part('tempheader-parts/amlayout4header','content'); // layout4 header content
			
	    }
		
		elseif($admania_header_type == 'amheader5') {  
		
			get_template_part('tempheader-parts/amlayout5header','content'); // layout5 header-content
			
	    }
		}
		}
		
		?>
	</header>
	


<div class="admania_siteinner">


<?php 

if((admania_get_option('admania_enmblayout') != '') && (!wp_is_mobile())) {

if(($admania_blog_layout != 'amblyt3') && ($admania_blog_layout != 'amblyt4') && ($admania_blog_layout != 'amblyt5') && ($admania_blog_layout != 'amblyt6')) { 
?>
	
<div class="admanina_afterheaderad">

<?php 
if($admania_blog_layout == 'amblyt1') { 
/*
 *  Include the after header Ad template.			
*/
		
get_template_part('tempad-parts/afterheader','ad');

}
elseif($admania_blog_layout == 'amblyt2') {

/*
 *  Include the after header Ad template.			
*/
		
get_template_part('tempad-parts/lay2afterheader','ad');

}
?>

</div>

<?php
}
}

else {
if(wp_is_mobile()) {
	
/*
 *  Include the after header Ad template.			
*/
		
get_template_part('tempad-parts/mbafhdad');

}
}

if($admania_blog_layout == 'amblyt6') { 

if((admania_get_option('admania_enmblayout') != '') && (!wp_is_mobile())) {

if(admania_get_option('boxed_siteleftads') != '') { 
?>
<div class="admania_sitesideleftad">
<?php
/*
 *  Include the site sticky Ad template.			
*/

get_template_part('tempad-parts/bxdsitebgsticky','ad');
?>
</div>
<?php
}

if(admania_get_option('admania_bxdafhdrad') != '') { 
/*
 *  Include the After Header Ad template.			
*/

get_template_part('tempad-parts/bxdafterheader','ad');

}	
}
}
