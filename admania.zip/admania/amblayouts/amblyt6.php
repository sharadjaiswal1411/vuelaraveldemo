<?php
/**
 * The template for displaying admania bloglayout6 content
 *
 * @package WordPress
 * @subpackage admania
 * @since admania 1.0
 */
 
get_header(); 

echo '<main id="admania_maincontent" class="admania_sitemaincontent">';

			 if(is_home() && !is_paged()) {
						
			/*
			* Include the Slider Section content Template.			
			*/
			
			get_template_part('tempslider-parts/bly7slider','content'); // layout6 slider-content
		

			/*
			* Include the After Slider Section Ad content Template.			
			*/
			get_template_part('tempad-parts/bxdafterslider','ad');			
			
			 }
			?>
			
								
		
           <div class="admania_contentarea">	
			
		    
					
					<?php
				
						if ( have_posts() ) : 			
								
		                $admania_bylineck = admania_get_option('admania_ebylfp');
						$admania_counter = 0;
		
						//Start the loop.
						while ( have_posts() ) : the_post();
														
		                $admania_counter++;		
						
						 if($admania_counter  == 4):
									
						/*
						* Include the After post Section Ad1 content Template.			
						*/
						get_template_part('tempad-parts/bxdgridpost1','ad');
						
						/*
						* Include the After post Section Ad2 content Template.			
						*/
						
						get_template_part('tempad-parts/bxdgridpost2','ad');
						
						endif;
						
						
						if($admania_counter  == 9):
						
						/*
						* Include the After post Section Ad3 content Template.			
						*/
						get_template_part('tempad-parts/bxdgridpost3','ad');
						
						/*
						* Include the After post Section Ad4 content Template.			
						*/
						
						get_template_part('tempad-parts/bxdgridpost4','ad');
						
						endif;
										
						
						
				 /*
				 * Include the Post-Format-specific template for the content.			
				 */		   
				if((1 == $admania_counter % 3) || (2 == $admania_counter % 3)):
		   
			
				
				if ($admania_counter % 3 == 2):
					 
					 $admania_bxdclassgrid = 'admania_boxedgriditemlast';
					 
					 else:
					 
					 $admania_bxdclassgrid = '';	 

				endif;
		       ?>		       	   
		    <div class="admania_boxedgriditem <?php echo esc_attr($admania_bxdclassgrid); ?>">
		   <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		  			    
		   <?php  admania_featuredimage(); ?>
											
			<div class="admania_boxedpostentry">
							 <?php   
							 if( 1 != (int) $admania_bylineck )  {
							?>
							<div class="admania_boxedpostecat">
							<?php
						  	 if(admania_get_option('admania_pcategory') != TRUE) {
							 esc_html_e('In','admania'); ?>
						     <?php the_category(' , '); 					  
							 }
							 ?>
							 </div>
							 <?php
							 }
							?>  		
					
			 <?php the_title( sprintf( '<h2 class="admania_entrytitle" itemprop="headline"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );?>
			<?php   
			 if( 1 != (int) $admania_bylineck )  {				
			?>	
		    <div class="admania_boxedpostbyline">
			<?php   
			if(admania_get_option('admania_ppostedby') != TRUE) {	 ?>
			<?php  esc_html_e('By','admania'); ?>
			<?php the_author_posts_link(); 
			}			
			if(admania_get_option('admania_ppostedon') != TRUE) { ?>
			<div class="admania_entrybylinecd">-</div>
			<?php  esc_html_e('On','admania'); ?>
			<?php the_time(get_option( 'date_format')); ?>			
			<?php } ?>			
			</div>
			 <?php
			 }
		
			$admania_boxedtrimexcerpt = get_the_excerpt();	
			$admania_boxedshortexcerpt = wp_trim_words( $admania_boxedtrimexcerpt, $amnum_words = 18, $ammore = '.' ); 
			if(!empty($admania_boxedshortexcerpt) != ''){
			?>
			<div class="admania_boxedpostdes">
			<p><?php echo wp_kses_stripslashes($admania_boxedshortexcerpt); ?> </p>
			</div>			
			<div class="admania_boxedreadmore">
					<a href="<?php esc_url(the_permalink()); ?>"><?php  esc_html_e('Read More','admania'); ?></a>
			</div>
			<?php
			}
			?>	
	
	        <!-- #entrycontent -## -->
	        </div>
			</article>
		    </div>
		  <!-- #post-## -->
		   <?php 
		   elseif(($admania_counter % 3 == 0)):		   
		   ?>
		    <div class="admania_boxedlistitem">
		   <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		  
			
		   <?php  admania_featuredimage(); ?>
						
						
						<div class="admania_boxedpostentry">
							 <?php   
							 if( 1 != (int) $admania_bylineck )  {
							?>
							<div class="admania_boxedpostecat">
							<?php
						  	 if(admania_get_option('admania_pcategory') != TRUE) {
							 esc_html_e('In','admania'); ?>
						     <?php the_category(' , '); 					  
							 }
							 ?>
							 </div>
							 <?php
							 }
							?>  		
					
			 <?php the_title( sprintf( '<h2 class="admania_entrytitle" itemprop="headline"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );?>
			<?php   
			 if( 1 != (int) $admania_bylineck )  {				
			?>	
		    <div class="admania_boxedpostbyline">
			<?php   
			if(admania_get_option('admania_ppostedby') != TRUE) {	 ?>
			<?php  esc_html_e('By','admania'); ?>
			<?php the_author_posts_link(); 
			}			
			if(admania_get_option('admania_ppostedon') != TRUE) { ?>
			<div class="admania_entrybylinecd">-</div>
			<?php  esc_html_e('On','admania'); ?>
			<?php the_time(get_option( 'date_format')); ?>			
			<?php } ?>			
			</div>
			 <?php
			 }
		
			$admania_boxedtrimexcerpt = get_the_excerpt();	
			$admania_boxedshortexcerpt = wp_trim_words( $admania_boxedtrimexcerpt, $amnum_words = 18, $ammore = '.' ); 
			if(!empty($admania_boxedshortexcerpt) != ''){
			?>
			<div class="admania_boxedpostdes">
			<p><?php echo wp_kses_stripslashes($admania_boxedshortexcerpt); ?> </p>
			</div>			
			<div class="admania_boxedreadmore">
					<a href="<?php esc_url(the_permalink()); ?>"><?php  esc_html_e('Read More','admania'); ?></a>
			</div>
			<?php
			}
			?>	
	
	        <!-- #entrycontent -## -->
	        </div>
			</article>
		    </div>
			<?php
		    endif;
		   						
					
						
						//	End the loop.
						
						endwhile;			

						// If no content, include the "No posts found" template.
						else :
			
						?>
						<p class="admania_nocntpost">
							<?php esc_html_e('Sorry No Posts were Found..!','admania');  ?>
						</p>
						<?php	

						endif;
				
						admania_paging_nav(); // admania-pagination
											
									
					
				/*
				* Include the Before Footer Section Ad content Template.			
				*/
				get_template_part('tempad-parts/bxdbffooter','ad');
				?>
				
	
		
		
		<div class="admania_contentareafooter">
			<div class="screen-reader-text"><?php esc_html_e('It is main inner container footer text','admania'); ?></div>
		</div>
			
</div>

<!-- .content-area -->

<?php if(admania_get_option('admania_dabothsidebar') != 1) { ?>

<div class="admania_primarycontentarea">


        <?php
		
		 /*
		 * Include the Right Sidebar Section Ad Template.			
		 */
	
		
		get_template_part('tempad-parts/rightsidebar','ad');

		get_sidebar('right'); // Theme Right Sidebar

		?>
</div>


			
			 
<?php
}				
echo '</main>';  //site-main 

get_footer(); 
 
 
