<?php
/**
 * The template for displaying admania bloglayout5 content
 *
 * @package WordPress
 * @subpackage admania
 * @since admania 1.0
 */
 
get_header(); 


echo '<main id="admania_maincontent" class="admania_sitemaincontent admania_mbsitemain">';


			if(is_home() && !is_paged()) {
			
                /*
				 * Include the Slider And Featured Content Template.			
				 */

				get_template_part('tempslider-parts/mbslider','content');	
				
		      }
			  
			    /*
				 * Include the Home Page After Slider Section Ad Template.			
				 */
	             
			get_template_part('tempad-parts/mbafsliderad');		
				
				
						if ( have_posts() ) : 			
						
                        $admania_mbadinc = 0;
						
						//Start the loop.
						while ( have_posts() ) : the_post();	
						
						$admania_mbadinc++;
						
						if($admania_mbadinc % 4 == 0):
						
						 /*
						 * Include the Home Page After List Post Section Ad Template.			
						 */
						get_template_part('tempad-parts/mbaflistpostad');	
						
						endif;
										
						?>
						
						<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
							
							 <div class="admania_mbfeaturedimg">
								
								<?php
								
								    global $post;
	
								    $admania_thumb = get_post_thumbnail_id();
									$admania_imgurl = wp_get_attachment_url( $admania_thumb,'full'); //get img URL
									$admania_fwidth = '150';
									$admania_fheight = '100';
									
									$admania_ytdimg = get_post_meta($post->ID, '_admania_featured_videourl', true); 
									$admania_youtube_matchexp = "/\s*[a-zA-Z\/\/:\.]*youtube.com\/watch\?v=([a-zA-Z0-9\-_]+)([a-zA-Z0-9\/\*\-\_\?\&\;\%\=\.]*)/i";  
									$admania_vimeomatchexp = "/https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)/";
									$admania_souncloudmatchexp = "%(?:https?://)(?:www\.)?soundcloud\.com/([\-a-z0-9_]+/[\-a-z0-9_]+)%im";
									$admania_framename = "iframe";
									
									$admania_image = admania_autoresize( $admania_imgurl, $admania_fwidth, $admania_fheight, true ); //resize & crop img

									if(($admania_ytdimg != "")  || ($admania_image != "")){
									
									if($admania_ytdimg != "") {
									
									if(preg_match($admania_youtube_matchexp , $admania_ytdimg)) {	
									
									$admania_yuvid = preg_replace($admania_youtube_matchexp,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"https://www.youtube.com/embed/$1\" allowfullscreen></iframe>",$admania_ytdimg);
									
									echo wp_kses_stripslashes($admania_yuvid);
									
									}
								
									elseif(preg_match($admania_vimeomatchexp , $admania_ytdimg)) {
									
									$admania_vimeovideos = preg_replace( $admania_vimeomatchexp ,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"https://player.vimeo.com/video/$3\" allowfullscreen></iframe>",$admania_ytdimg);
									
									echo wp_kses_stripslashes($admania_vimeovideos);
									
									}
									
									elseif(preg_match( $admania_souncloudmatchexp , $admania_ytdimg)) {	
									
									$admania_souncloudsng = preg_replace( $admania_souncloudmatchexp ,'<'.esc_attr($admania_framename).' width="'.absint($admania_fwidth).'" height="'.absint($admania_fheight).'" scrolling="no" src="https://w.soundcloud.com/player/?url=https://soundcloud.com/$1&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>',$admania_ytdimg); 
									
									echo wp_kses_stripslashes($admania_souncloudsng);
									
									}
								
									} 		
								
									elseif($admania_image != "" && $admania_ytdimg == "" ) { 
									?>
									<a href="<?php the_permalink(); ?>">
										<img src="<?php echo esc_url($admania_image); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
									</a>
									<?php 
									} 	

									}
									else {
										
									if (!has_post_thumbnail($post->ID) ) {
											   
									$admania_postdetails = get_post($post->ID);
										
									preg_match_all( '/<img .*?(?=src)src=\"([^\"]+)\"/si', $admania_postdetails->post_content, $admania_allpics );
									if (is_array($admania_allpics[1]) && count($admania_allpics[1])>0) {
										$admania_pic = $admania_allpics[1][0];
									if (strpos($admania_pic,"?")>0) {
										$admania_pic = substr($admania_pic,0,strpos($admania_pic,"?"));
									}
										
										$admania_exturl =  $admania_pic;
									}
									 if(!empty($admania_exturl) != ''){
									?>
									<a href="<?php the_permalink(); ?>">
										<img src="<?php echo esc_url($admania_exturl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" width="<?php echo intval($admania_fwidth); ?>px;" height="<?php echo intval($admania_fheight);?>px;"/>
									</a>
									 <?php
									 }

									}
                                    else {		
									 if (has_post_thumbnail($post->ID) ) {
									 ?>
									 <a href="<?php the_permalink(); ?>">
										<img src="<?php echo esc_url($admania_imgurl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" width="<?php echo intval($admania_fwidth); ?>px;" height="<?php echo intval($admania_fheight);?>px;" />
									 </a>
									 <?php
									}		
									}   									
										
									}
									?>
									</div>
	
									<div class="admaniamb_entrycontent">							
										<h2>
											<a href="<?php the_permalink(); ?>">
												<?php the_title(); ?>
											</a>
										</h2> 
										<?php if(admania_get_option('admania_ebylfp') != TRUE) { ?>
										<div class="admania_slidermeta1">
											<div class="admania_slidercat1">
												<?php if(admania_get_option('admania_ppostedby') != TRUE) { ?>
												<?php esc_html_e('By','admania'); ?>
												<?php  the_author_posts_link(); ?>
												-
												<?php }
												   if(admania_get_option('admania_ppostedon') != TRUE) { ?>
														<?php esc_html_e('On','admania'); ?>
														<?php the_time(get_option( 'date_format')); 
												   }                                   
												if(admania_get_option('admania_pcategory') != TRUE) { ?>
												-
												<?php esc_html_e('In','admania'); ?>
												<?php the_category(' , '); 
												} 
												?>									  
											</div>
										</div>
										<?php } ?>								
							</div>			
							
							<!-- #entrycontent -## -->
							
						</article>

						<?php
						
						//	End the loop.
						
						endwhile;			

						// If no content, include the "No posts found" template.
						else :
			
						?>
						<p class="admania_nocntpost">
							<?php esc_html_e('Sorry No Posts were Found..!','admania');  ?>
						</p>
						<?php	

						endif;
				
						admania_paging_nav(); // admania-pagination												
														
			
echo '</main>';  //site-main 

/*
* Include the Home Page Before Footer Ad Template.			
*/
get_template_part('tempad-parts/mbbffooterad');	

get_footer(); 
 
 
