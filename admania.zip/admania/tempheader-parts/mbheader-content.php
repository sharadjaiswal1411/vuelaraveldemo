<?php

/**
 * Theme Mobile Header Content.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */


?>

<div class="admania_mobileheader">
	<div class="admania_headerinner">
         <div class="admania_mbheaderleft">	
		  	<?php if(has_nav_menu('admania-primary-menu')): ?>	                			
				<nav class="admania_menu admania_mblaytmenu" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
					<?php 
					$admania_walker = new admania_walker_nav_menu;
					wp_nav_menu(array( 'menu' => 'admania-primary-menu', 'theme_location' => 'admania-primary-menu','walker' => $admania_walker ) );  
					?>
				</nav>	
			<?php endif; ?>	
		 </div>		 
		 <div class="admania_mbheadermiddle">	
					    <?php 
						$admania_cstmurllogo = '';
						if(admania_get_option('admania_custom_logo_activestatus') != false) { 				
						$admania_cstmurllogo = admania_autoresize(admania_get_option('admania_custom_logo'),186,36);
						if(is_home()): 
						?>
						<h1 class="admania_sitetitle" itemprop="headline">
						<a href="<?php echo esc_url(home_url('/')); ?>" title="<?php bloginfo( 'name' ); ?>">
						<img src="<?php echo esc_url($admania_cstmurllogo); ?>" alt="<?php bloginfo( 'name' ); ?>" itemprop="image"/>
						</a>
						</h1>
						<?php else: ?>
						<a href="<?php echo esc_url(home_url('/')); ?>" title="<?php bloginfo( 'name' ); ?>" class="admania_fontstlye">
						<img src=" <?php echo esc_url($admania_cstmurllogo); ?>" alt="<?php bloginfo( 'name' ); ?>" itemprop="image"/>
						</a>
						<?php 
						
						endif;				
						}
						elseif (is_home()) { ?>
						<h1 class="admania_sitetitle admania_restitle1" itemprop="headline">
						<a href="<?php echo esc_url(home_url('/')); ?>" title="<?php bloginfo( 'name' ); ?>">
						<?php bloginfo( 'name' ); ?>
						</a>									
						</h1> 
					   <p><?php bloginfo( 'description' );  ?></p>						
						<?php } 				
						else { ?>
						<div class="admania_sitetitle admania_restitle" itemprop="headline"> 
						<a href="<?php echo esc_url(home_url('/'));  ?>" title="<?php bloginfo( 'name' ); ?>" class="admania_fontstlye">
						<?php bloginfo( 'name' ); ?>
						</a>  
						<p><?php bloginfo( 'description' );  ?></p>						
						</div>
						<?php }	?>	
		 </div>		 
		 <div class="admania_mbheaderright">	
		 <?php $admania_searchck = admania_get_option('admania_hdrsrch');											
				if(   1 != (int) $admania_searchck ):
                ?>						
				<div class="admania_lay5headerright">
                    <span class="admania-la5searchicon">				
					<i class="fa fa-search"></i>
					</span>
				</div>
				<div class="admania_lay5headersearchouter">
				<?php get_search_form(); ?>
				</div>
				<?php endif; ?>			
		 </div>			
	</div>
</div>