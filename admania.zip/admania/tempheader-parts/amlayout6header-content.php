<?php

/**
 * Theme Boxed header content.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
         
?>
<div class="admania_boxedheadertop">
<div class="admania_boxedheaderinner">
<?php if(has_nav_menu('admania-secondary-menu')): ?>
<div class="admania_leftheader">
<nav class="admania_secondarymenu" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
<?php 
	$admania_walker = new admania_walker_nav_menu;
	wp_nav_menu(array( 'menu' => 'admania-secondary-menu', 'theme_location' => 'admania-secondary-menu','walker' => $admania_walker ) );  
?>
</nav>	
</div>
<?php endif; ?>
<div class="admania_rightheader">
		<div class="admania_headertopsocial">
		<ul>
		<?php
		if(admania_get_option('admania_hdfacebook') != false){
		?>
		<li><a href="<?php echo esc_url(admania_get_option('admania_hdfacebook')); ?>" class="admania_socialiconfb" target="_blank"><i class="fa fa-facebook"></i></a></li>
		<?php } 
        if(admania_get_option('admania_hdtwitter') != false) {
		?>
		<li><a href="<?php echo esc_url(admania_get_option('admania_hdtwitter')); ?>" class="admania_socialicontwt" target="_blank"><i class="fa fa-twitter"></i></a></li>
		<?php } 
		if(admania_get_option('admania_hdgoogleplus') != false) {
		?>
		<li><a href="<?php echo esc_url(admania_get_option('admania_hdgoogleplus')); ?>" class="admania_socialicongle" target="_blank"><i class="fa fa-google-plus"></i></a></li>
		<?php
		} 
		if(admania_get_option('admania_hdlinkedin') != false) {
		?>
		<li><a href="<?php echo esc_url(admania_get_option('admania_hdlinkedin')); ?>" class="admania_socialiconlnk" target="_blank"><i class="fa fa-linkedin"></i></a></li>
		<?php
		} 
		if(admania_get_option('admania_hdyoutube') != false) {
		?>
		<li><a href="<?php echo esc_url(admania_get_option('admania_hdyoutube')); ?>" class="admania_socialiconyt" target="_blank"><i class="fa fa-youtube"></i></a></li>
		<?php
		} 
		if(admania_get_option('admania_hdinstagram') != false) {
		?>
		<li><a href="<?php echo esc_url(admania_get_option('admania_hdinstagram')); ?>" class="admania_socialiconins" target="_blank"><i class="fa fa-instagram"></i></a></li>
		<?php
		} 
		if(admania_get_option('admania_hdpinterest') != false) {
		?>
		<li><a href="<?php echo esc_url(admania_get_option('admania_hdpinterest')); ?>" class="admania_socialiconpin" target="_blank"><i class="fa fa-pinterest"></i></a></li>
		<?php
		} 
		if(admania_get_option('admania_hdrss') != false) {
		?>
		<li><a href="<?php echo esc_url(admania_get_option('admania_hdrss')); ?>" class="admania_socialiconrss" target="_blank"><i class="fa fa-rss"></i></a></li>
		<?php
		}
		if(admania_get_option('admania_hdtg') != false) {
		?>
		<li><a href="<?php echo esc_url(admania_get_option('admania_hdtg')); ?>" class="admania_socialicontg" target="_blank"><i class="fa fa-telegram"></i></a></li>
		<?php
		} 	 		
		?>
		</ul>
		</div>
</div>
</div>
</div>
<div class="admania_boxedheaderbot">
<div class="admania_boxedheaderinner">
	<div class="admania_leftheader">
	     <?php
		 $admania_bxdcstmurllogo = '';
		 if(admania_get_option('admania_custom_logo_activestatus') != false) { 
		 $admania_bxdcstmurllogo = admania_autoresize(admania_get_option('admania_custom_logo'),200,67);		 
				    if(is_home()): ?>
					<h1 class="admania_sitetitle" itemprop="headline">
					<a href="<?php echo esc_url(home_url('/')); ?>" title="<?php bloginfo( 'name' ); ?>">
					<img src="<?php echo esc_url($admania_bxdcstmurllogo); ?>" alt="<?php bloginfo( 'name' ); ?>" itemprop="image"/>
					</a>
					</h1>
					<?php else: ?>
					<a href="<?php echo esc_url(home_url('/')); ?>" title="<?php bloginfo( 'name' ); ?>" class="admania_fontstlye">
					<img src=" <?php echo esc_url($admania_bxdcstmurllogo); ?>" alt="<?php bloginfo( 'name' ); ?>" itemprop="image"/>
					</a>
					<?php 
					
					endif;				
					}
				    elseif (is_home()) { ?>
					<h1 class="admania_sitetitle admania_restitle1" itemprop="headline">
					<a href="<?php echo esc_url(home_url('/')); ?>" title="<?php bloginfo( 'name' ); ?>">
					<?php bloginfo( 'name' ); ?>
					</a>									
					</h1> 
                   <p><?php bloginfo( 'description' );  ?></p>						
					<?php } 				
					else { ?>
					<div class="admania_sitetitle admania_restitle" itemprop="headline"> 
					<a href="<?php echo esc_url(home_url('/'));  ?>" title="<?php bloginfo( 'name' ); ?>" class="admania_fontstlye">
					<?php bloginfo( 'name' ); ?>
					</a>  
					<p><?php bloginfo( 'description' );  ?></p>						
					</div>
					<?php }	?>
</div>
	<div class="admania_rightheader">
<?php if(has_nav_menu('admania-primary-menu')): ?>
<nav class="admania_boxedmenu admania_menu admania_lay4_menu" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
<?php 
	$admania_walker = new admania_walker_nav_menu;
	wp_nav_menu(array( 'menu' => 'admania-primary-menu', 'theme_location' => 'admania-primary-menu','walker' => $admania_walker ) );  
?>
</nav>	
<?php endif; 
	if(!is_404()) {
 
			$admania_bxdrmvcatids2 =  admania_get_option('ad_rmcatGrid62');			
			$admania_bxdrmvcatids_extractids2 = explode(',',$admania_bxdrmvcatids2);			
			
			$admania_bxdrmvtagids = admania_get_option('ad_rmtagGrid62');
			$admania_bxdrmvtagids_extractids2 = explode(',',$admania_bxdrmvtagids);

            $admania_bxdrmvpostids2 = admania_get_option('ad_rmpostGrid62');
			$admania_bxdrmvpostids_extractids2 = explode(',',$admania_bxdrmvpostids2);	

			$admania_bxdrmvpageids2 = admania_get_option('ad_rmpageGrid62');
			$admania_bxdrmvpageids_extractids2 = explode(',',$admania_bxdrmvpageids2);				
			
			if((!is_category($admania_bxdrmvcatids_extractids2)) && (!is_tag($admania_bxdrmvtagids_extractids2)) && (!is_single($admania_bxdrmvpostids_extractids2)) && (!is_page($admania_bxdrmvpageids_extractids2))) {
 
 if(admania_get_option('admania_bxdhdrgtad') != false): ?>

<div class="admania_rightheaderbotad admania_themead">
  <?php
     
	if((admania_get_lveditoption('bxd_hdrgthtmlad') != false) || (admania_get_lveditoption('bxd_hdrgtglead') != false) || ((admania_get_lveditoption('admania_lvedtimg_url47') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url47') != false))) {
			
			
			
		if(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad3') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if(admania_get_lveditoption('bxd_hdrgthtmlad') != false) {
			
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_hdrgthtmlad'));
			
			}
			
					
		if(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad3') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay2lvedlhtmlad3')); ?>
			</div>
			<?php
            }
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlglead3') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if(admania_get_lveditoption('bxd_hdrgtglead') != false ) {
			echo wp_kses_stripslashes(admania_get_lveditoption('bxd_hdrgtglead'));
			}
			
			if(admania_get_lveditoption('hdr_rotlay2lvedlglead3') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php 	echo wp_kses_stripslashes(admania_get_lveditoption('hdr_rotlay2lvedlglead3')); ?>
			</div>
			<?php
            }
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url23') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url23') != false)){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }
			
			if((admania_get_lveditoption('admania_lvedtimg_url47') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url47') != false) ){
			?>
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url47')); ?>">
			<?php if(admania_get_lveditoption('admania_lvedtimg_url47') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_lvedtimg_url47')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			<?php
			
			} 
			
			if((admania_get_lveditoption('admania_rotlvedtimg_url23') != false) || (admania_get_lveditoption('admania_rotlvedtrimgtg_url23') != false)){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtrimgtg_url23')); ?>">
			<?php if(admania_get_lveditoption('admania_rotlvedtimg_url23') != false) { ?>
			 <img src="<?php echo esc_url(admania_get_lveditoption('admania_rotlvedtimg_url23')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
		    <?php } ?>
			 </a>
			</div>
			<?php
            }
			
			}
			else {
				
			  
			if(admania_get_option('admania_rotrgthdhtmlcode') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }		
				
			if(admania_get_option('admania_bxdhdrgthtmlad') != false):
			
			echo wp_kses_stripslashes(admania_get_option('admania_bxdhdrgthtmlad'));
			
			endif;
			
			if(admania_get_option('admania_rotrgthdhtmlcode') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('admania_rotrgthdhtmlcode')); ?>
			</div>
			<?php
            }
			
			if(admania_get_option('admania_rotrgthdglead') != false){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if(admania_get_option('admania_rgthdglead') != false):
			
			echo wp_kses_stripslashes(admania_get_option('admania_rgthdglead'));
			
			endif;
			
			if(admania_get_option('admania_rotrgthdglead') != false){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
				<?php echo wp_kses_stripslashes(admania_get_option('admania_rotrgthdglead')); ?>
			</div>
			<?php
            }
			
			if((admania_get_option('admania_rotadimg_url62') != false) || (admania_get_option('admania_rotadimgtg_url62') != false) ){
			?>
			<div class="admania_lyt3rothad1">	
			<?php
            }	
			
			if((admania_get_option('admania_adimg_url62') != false) || (admania_get_option('admania_adimgtg_url62') != false) ):
			?>
			<a href="<?php echo esc_url(admania_get_option('admania_adimgtg_url62')); ?>">
			<?php if(admania_get_option('admania_adimg_url62') != false) { ?>
			<img src="<?php echo esc_url(admania_get_option('admania_adimg_url62')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			<?php } ?>
			</a>
			<?php endif;  
  
			if((admania_get_option('admania_rotadimg_url62') != false) || (admania_get_option('admania_rotadimgtg_url62') != false) ){
			?>
			</div>
			<div class="admania_lyt3rothad2">	
			<a href="<?php echo esc_url(admania_get_option('admania_rotadimgtg_url62')); ?>">
			<?php if(admania_get_option('admania_rotadimg_url62') != false) { ?>
			<img src="<?php echo esc_url(admania_get_option('admania_rotadimg_url62')); ?>" alt="<?php esc_html_e('adimage','admania'); ?>"/>
			<?php } ?>
			</a>
			</div>
			<?php
            }	
  
   }
    if(current_user_can('administrator')){			
			?>				
             <div class="admania_adeditablead1 admania_lvetresitem47">				
			 <i class="fa fa-edit"></i>
			 <?php esc_html_e('Edit','admania'); ?>
			 </div>			
			 
	<?php } ?>
</div>
<?php endif;
}
}
?>
</div>
</div>
</div>		
	