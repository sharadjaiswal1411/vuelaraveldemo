<?php

/**
 * Theme slider content Section for boxed layout.
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */
 
 ?>

<!-- #Admania-SliderSection  -## -->

<?php 
if(admania_get_option('hm_slideractive7') != false):  
?>

<div class="admania_boxedlayfeatured">	
		
<div class="admania_boxedlayftdinner" id="admania_boxedowldemo">
 <?php

    $admania_sld7catidsoptn7 = admania_get_option('hm_sliderctgrsid7') ;	
	$admania_sldckthecatpst7 = admania_get_option('hm_sliderctgs7');		
	$admania_ckthesldpst7 = admania_get_option('hm_sliderpstids7');
	$admania_postperpage7 = admania_get_option('hm_sliderpostperpage7');		
	$admania_latestpstck7 = admania_get_option('hm_sliderrandorlatst7');


	if($admania_latestpstck7 == 'Random'):

	$admania_postorder7 = 'rand';

	else:

	$admania_postorder7 = 'date';

	endif;

if((!empty($admania_sld7catidsoptn7) != '')):	
  $admania_sldcategory_idopts7 = explode(',',$admania_sld7catidsoptn7);	
   $admaniaheaderslider_lay7args = array(
   'cat'=>$admania_sldcategory_idopts7,
   'orderby'=>$admania_postorder7,
   'posts_per_page'=>$admania_postperpage7,
   'ignore_sticky_posts' => 1
   );
  

endif;
	
	
if((!empty($admania_sldckthecatpst7) != '')):

$admaniaheaderslider_lay7args = array( 
'category_name' => $admania_sldckthecatpst7,
'orderby'=>$admania_postorder7,
'posts_per_page'=>$admania_postperpage7,
'ignore_sticky_posts' => 1 
);
	
endif;

if((!empty($admania_ckthesldpst7) != '')):

$admania_ckthesldrpst_id7 = explode(',',$admania_ckthesldpst7);
$admaniaheaderslider_lay7args = array( 
'post__in' => $admania_ckthesldrpst_id7,
'orderby'=>$admania_postorder7,
'posts_per_page'=>$admania_postperpage7,
'ignore_sticky_posts' => 1
);

endif;

if(((!empty($admania_sldckthecatpst7) != '') || (!empty($admania_ckthesldpst7) != '') || (!empty($admania_sld7catidsoptn7) != '') )){
 // the query  
 
    $admaniaheaderslider_lay7query = new WP_Query( $admaniaheaderslider_lay7args ); 	
	while ( $admaniaheaderslider_lay7query->have_posts() ) : $admaniaheaderslider_lay7query->the_post();
	
	$admania_fwidth = '300';
	$admania_fheight = '201';
	
	$admania_thumb = get_post_thumbnail_id();
 	$admania_imgurl = wp_get_attachment_url( $admania_thumb,'full'); //get img URL
	$admania_image = admania_autoresize( $admania_imgurl, $admania_fwidth, $admania_fheight, true ); //resize & crop img
	
	$admania_ytdimg = get_post_meta($post->ID, '_admania_featured_videourl', true); 
	$admania_youtube_matchexp = "/\s*[a-zA-Z\/\/:\.]*youtube.com\/watch\?v=([a-zA-Z0-9\-_]+)([a-zA-Z0-9\/\*\-\_\?\&\;\%\=\.]*)/i";  
	$admania_vimeomatchexp = "/https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)/";
	$admania_souncloudmatchexp = "%(?:https?://)(?:www\.)?soundcloud\.com/([\-a-z0-9_]+/[\-a-z0-9_]+)%im";
	$admania_framename = "iframe";
	
	if (!has_post_thumbnail($post->ID) ) {
			   
	$admania_postdetails = get_post($post->ID);
		
	preg_match_all( '/<img .*?(?=src)src=\"([^\"]+)\"/si', $admania_postdetails->post_content, $admania_allpics );
	if (is_array($admania_allpics[1]) && count($admania_allpics[1])>0) {
		$admania_pic = $admania_allpics[1][0];
	if (strpos($admania_pic,"?")>0) {
		$admania_pic = substr($admania_pic,0,strpos($admania_pic,"?"));
	}
		
		$admania_exturl =  $admania_pic;
	}
	}
	
			
	?>
  <div class="admania_boxedlayftditem">
    <?php			  
	if(($admania_ytdimg != "")  || ($admania_image != "")){
	
	if($admania_ytdimg != "") {
	
	if(preg_match($admania_youtube_matchexp , $admania_ytdimg)) {	
	
	$admania_yuvid = preg_replace($admania_youtube_matchexp,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"//www.youtube.com/embed/$1\" allowfullscreen></iframe>",$admania_ytdimg);
	
	echo wp_kses_stripslashes($admania_yuvid);
	
	}
	
	elseif(preg_match($admania_vimeomatchexp , $admania_ytdimg)) {
	
	$admania_vimeovideos = preg_replace( $admania_vimeomatchexp ,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"//player.vimeo.com/video/$3\" allowfullscreen></iframe>",$admania_ytdimg);
	
	echo wp_kses_stripslashes($admania_vimeovideos);
	
	}
	
	elseif(preg_match( $admania_souncloudmatchexp , $admania_ytdimg)) {	
	
	$admania_souncloudsng = preg_replace( $admania_souncloudmatchexp ,'<'.esc_attr($admania_framename).' width="'.absint($admania_fwidth).'" height="'.absint($admania_fheight).'" scrolling="no" src="https://www.soundcloud.com/player/?url=https://soundcloud.com/$2&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>',$admania_ytdimg); 
	
	echo wp_kses_stripslashes($admania_souncloudsng);
	
	}
	
	} 
	
	elseif($admania_image != "" && $admania_ytdimg == "" ) { 
	?>
    <img src="<?php echo esc_url($admania_image); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
    <?php 
	}
	
	} 
	else{
	if(!empty($admania_exturl) != ''){
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_exturl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" width="<?php echo intval($admania_fwidth); ?>px;" height="<?php echo intval($admania_fheight);?>px;"/>
	</a>
	<?php
	}
	else {		
	if (has_post_thumbnail($post->ID)) {
	 ?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_imgurl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
	<?php
	}		
	}   
	
    }
	?>
	
	<div class="admania_boxedsldehdr">
	<?php if(admania_get_option('admania_ebylfp') != TRUE) { ?>
	<div class="admania_boxedsldecat">		
		 <?php if(admania_get_option('admania_pcategory') != TRUE) { 		  
		  the_category(' , '); 		  
		  }
		  ?>
	</div>
	<?php } ?>
	<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
	<?php
	$admania_trimexcerpt = get_the_excerpt();	
	$admania_shortexcerpt = wp_trim_words( $admania_trimexcerpt, $amnum_words = 12, $ammore = '… ' ); 
	if(!empty($admania_shortexcerpt) != ''){
	?>
	<div class="admania_boxeddes">
	<p><?php echo wp_kses_stripslashes($admania_shortexcerpt); ?> </p>
	</div>		
<?php
}
?>			
</div>
	
    

  </div>
  <?php 
   endwhile; 
   wp_reset_postdata();
   }
   ?>

</div>	
</div>
<?php 
endif;
 ?>


