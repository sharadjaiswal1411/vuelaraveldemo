<?php
/**
 * Custom template tags for Admania
 *
 * @package WordPress
 * @subpackage Admania
 * @since Admania 1.0
 */



/*-----------------------------------------------------------------------------------*/
# Admania Previous/next post navigation.
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'admania_postnav' ) ) :

function admania_postnav() {

global $post;

$admania_prev_post = '';
$admania_nxt_post = '';

$admania_prev_post = get_previous_post();				 
$admania_next_post = get_next_post();


				 
	if(!empty($admania_prev_post) || !empty($admania_next_post) ):
	
	if(!empty($admania_prev_post) == ''):
	$admania_nxtpst_class = 'admania_nxtpst_dsgn';
	else:
	$admania_nxtpst_class = '';
	endif;
	
	?>

<div class="admania_prenext <?php echo esc_attr($admania_nxtpst_class); ?>"> <!--Single post prev/next-->
  
  <?php
  
  
  if(admania_get_option('admania_singleprevcontent') != false):
  
  $admania_prevpagicontent = admania_get_option('admania_singleprevcontent');
  
  else:
  
  $admania_prevpagicontent = 'Prev Post';
  
  endif;
  
  if(admania_get_option('admania_singlenextcontent') != false):
  
  $admania_nextpagicontent = admania_get_option('admania_singlenextcontent');
  
  else:
  
  $admania_nextpagicontent = 'Next Post';
  
  endif;
  
  the_post_navigation( array(
	'prev_text' => 
				'<span> <i class="fa fa-angle-double-left"></i> </span>'.
				'<div class="admania_snlgepdsg">'.esc_html($admania_prevpagicontent).'</div>'.
				'<div class="admania_snlgenpntit">%title</div>',
	'next_text' => 
				'<span> <i class="fa fa-angle-double-right"></i> </span>'.
				'<div class="admania_snlgepdsg">'.esc_html($admania_nextpagicontent).'</div>'.
				'<div class="admania_snlgenpntit">%title</div>',					
 ) );

  
 
?>
</div>
<!-- preview / next -->

<?php 				
	endif;
}

endif;

 

/*-----------------------------------------------------------------------------------*/
# Admania Get Theme Options
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'admania_get_option' ) ) :

function admania_get_option( $admania_optionname ) {
	
	$admania_get_options = get_option( 'admania_theme_settings' );
	
	if( !empty( $admania_get_options[$admania_optionname] ))
		 return htmlspecialchars_decode($admania_get_options[$admania_optionname]);
		
	return false ;
}

endif;

/*-----------------------------------------------------------------------------------*/
# Admania Live Editor Get Theme Options
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'admania_get_lveditoption' ) ) :

function admania_get_lveditoption( $admania_lvedtoptionname ) {
	
	$admania_get_lveditoptions = get_option( 'admania_frontliveeditor_settings' );
	
	if( !empty( $admania_get_lveditoptions[$admania_lvedtoptionname] ))
		 return wp_kses_stripslashes($admania_get_lveditoptions[$admania_lvedtoptionname]);
		
	return false ;
}

endif;

/*-----------------------------------------------------------------------------------*/
# Admania post count views 
/*-----------------------------------------------------------------------------------*/

if( ! function_exists( 'admania_set_post_views' )):

function admania_set_post_views($postID) { 
$admaniacount_key = 'admania_post_views_count';
$admania_count = get_post_meta($postID, $admaniacount_key, true);
if($admania_count=='')
{
$admania_count = 0;
delete_post_meta($postID, $admaniacount_key);
add_post_meta($postID, $admaniacount_key, '0');
}else{
$admania_count++;
update_post_meta($postID, $admaniacount_key, $admania_count);
}
}

endif;

/*-----------------------------------------------------------------------------------*/
# Admania Track post views 
/*-----------------------------------------------------------------------------------*/

if( ! function_exists( 'admania_track_post_views' )):

function admania_track_post_views ($post_id) {
if ( !is_single() ) return;
if ( empty ( $post_id) ) {
global $post;
$post_id = $post->ID;   
}
admania_set_post_views($post_id);

}

endif;

add_action( 'wp_head', 'admania_track_post_views'); // add action to load the data in wp-head

/*-----------------------------------------------------------------------------------*/
# Admania get the post count view 
/*-----------------------------------------------------------------------------------*/

if( ! function_exists( 'admania_get_post_views' )):

function admania_get_post_views($postID){
$admaniacount_key = 'admania_post_views_count';
$admaniacount = get_post_meta($postID, $admaniacount_key, true);
if($admaniacount==''){
delete_post_meta($postID, $admaniacount_key);
add_post_meta($postID, $admaniacount_key, '0');
return "0";
}
return $admaniacount;
}

endif;

//To keep the count accurate, lets get rid of prefetching
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);

// Remove issues with prefetching adding extra views
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);	

/*-----------------------------------------------------------------------------------*/

# Admania Crop the wp post thumbnail image

/*-----------------------------------------------------------------------------------*/



/**

 * Title         : Aqua Resizer

 * Description   : Resizes WordPress images on the fly

 * Version       : 1.2.1

 * Author        : Syamil MJ

 * Author URI    : http://aquagraphite.com

 * License       : WTFPL - http://sam.zoy.org/wtfpl/

 * Documentation : https://github.com/sy4mil/Aqua-Resizer/

 *

 * @param string  $url      - (required) must be uploaded using wp media uploader

 * @param int     $width    - (required)

 * @param int     $height   - (optional)

 * @param bool    $crop     - (optional) default to soft crop

 * @param bool    $single   - (optional) returns an array if false

 * @param bool    $upscale  - (optional) resizes smaller images

 * @uses  wp_upload_dir()

 * @uses  image_resize_dimensions()

 * @uses  wp_get_image_editor()

 *

 * @return str|array

 */



if(!class_exists('admania_autoresize')) {

    class Admania_Aqexception extends Exception {}



    class admania_autoresize

    {

        /**

         * The singleton instance

         */

        static private $instance = null;



        /**

         * Should an Admania_Aqexception be thrown on error?

         * If false (default), then the error will just be logged.

         */

        public $throwOnError = false;



        /**

         * No initialization allowed

         */

        private function __construct() {}



        /**

         * No cloning allowed

         */

        private function __clone() {}



        /**

         * For your custom default usage you may want to initialize an admania_autoresize object by yourself and then have own defaults

         */

        static public function getInstance() {

            if(self::$instance == null) {

                self::$instance = new self;

            }



            return self::$instance;

        }



        /**

         * Run, forest.

         */

        public function process( $url, $width = null, $height = null, $crop = null, $single = true, $upscale = false ) {

            try {

                // Validate inputs.

                if (!$url)

                    throw new Admania_Aqexception('$url parameter is required');

                if (!$width)

                    throw new Admania_Aqexception('$width parameter is required');



                // Caipt'n, ready to hook.

                if ( true === $upscale ) add_filter( 'image_resize_dimensions', array($this, 'admania_aqupscale'), 10, 6 );



                // Define upload path & dir.

                $upload_info = wp_upload_dir();

                $upload_dir = $upload_info['basedir'];

                $upload_url = $upload_info['baseurl'];

                

                $http_prefix = "http://";

                $https_prefix = "https://";

                $relative_prefix = "//"; // The protocol-relative URL

                

                /* if the $url scheme differs from $upload_url scheme, make them match 

                   if the schemes differe, images don't show up. */

                if(!strncmp($url,$https_prefix,strlen($https_prefix))){ //if url begins with https:// make $upload_url begin with https:// as well

                    $upload_url = str_replace($http_prefix,$https_prefix,$upload_url);

                }

                elseif(!strncmp($url,$http_prefix,strlen($http_prefix))){ //if url begins with http:// make $upload_url begin with http:// as well

                    $upload_url = str_replace($https_prefix,$http_prefix,$upload_url);      

                }

                elseif(!strncmp($url,$relative_prefix,strlen($relative_prefix))){ //if url begins with // make $upload_url begin with // as well

                    $upload_url = str_replace(array( 0 => "$http_prefix", 1 => "$https_prefix"),$relative_prefix,$upload_url);

                }                



                // Check if $img_url is local.

                if ( false === strpos( $url, $upload_url ) )

                    throw new Admania_Aqexception('Image must be local: ' . $url);



                // Define path of image.

                $rel_path = str_replace( $upload_url, '', $url );

                $img_path = $upload_dir . $rel_path;



                // Check if img path exists, and is an image indeed.

                if ( ! file_exists( $img_path ) or ! getimagesize( $img_path ) )

                    throw new Admania_Aqexception('Image file does not exist (or is not an image): ' . $img_path);



                // Get image info.

                $info = pathinfo( $img_path );

                $ext = $info['extension'];

                list( $orig_w, $orig_h ) = getimagesize( $img_path );



                // Get image size after cropping.

                $dims = image_resize_dimensions( $orig_w, $orig_h, $width, $height, $crop );

                $dst_w = $dims[4];

                $dst_h = $dims[5];



                // Return the original image only if it exactly fits the needed measures.

                if ( ! $dims && ( ( ( null === $height && $orig_w == $width ) xor ( null === $width && $orig_h == $height ) ) xor ( $height == $orig_h && $width == $orig_w ) ) ) {

                    $img_url = $url;

                    $dst_w = $orig_w;

                    $dst_h = $orig_h;

                } else {

                    // Use this to check if cropped image already exists, so we can return that instead.

                    $suffix = "{$dst_w}x{$dst_h}";

                    $dst_rel_path = str_replace( '.' . $ext, '', $rel_path );

                    $destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";



                    if ( ! $dims || ( true == $crop && false == $upscale && ( $dst_w < $width || $dst_h < $height ) ) ) {

                        // Can't resize, so return false saying that the action to do could not be processed as planned.

                        throw new Admania_Aqexception('Unable to resize image because image_resize_dimensions() failed');

                    }

                    // Else check if cache exists.

                    elseif ( file_exists( $destfilename ) && getimagesize( $destfilename ) ) {

                        $img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";

                    }

                    // Else, we resize the image and return the new resized image url.

                    else {

                        $editor = wp_get_image_editor( $img_path );

                        if ( is_wp_error( $editor ) || is_wp_error( $editor->resize( $width, $height, $crop ) ) ) {

                            throw new Admania_Aqexception('Unable to get WP_Image_Editor: ' . 

                                                   $editor->get_error_message() . ' (is GD or ImageMagick installed?)');

                        }

                        $resized_file = $editor->save();

                        if ( ! is_wp_error( $resized_file ) ) {

                            $resized_rel_path = str_replace( $upload_dir, '', $resized_file['path'] );

                            $img_url = $upload_url . $resized_rel_path;

                        } else {

                            throw new Admania_Aqexception('Unable to save resized image file: ' . $editor->get_error_message());

                        }

                    }

                }



                // Okay, leave the ship.

                if ( true === $upscale ) remove_filter( 'image_resize_dimensions', array( $this, 'admania_aqupscale' ) );


                // Return the output.

                if ( $single ) {

                    // str return.

                    $image = $img_url;

                } else {

                    // array return.

                    $image = array (

                        0 => $img_url,

                        1 => $dst_w,

                        2 => $dst_h

                    );

                }

                return $image;

            }

            catch (Admania_Aqexception $ex) {

                //error_log('admania_autoresize.process() error: ' . $ex->getMessage());

                if ($this->throwOnError) {

                    // Bubble up exception.

                    throw $ex;

                }

                else {

                    // Return false, so that this patch is backwards-compatible.

                    return false;

                }

            }

        }

        /**

         * Callback to overwrite WP computing of thumbnail measures

         */

        function admania_aqupscale( $default, $orig_w, $orig_h, $dest_w, $dest_h, $crop ) {

            if ( ! $crop ) return null; // Let the wordpress default function handle this.



            // Here is the point we allow to use larger image size than the original one.

            $aspect_ratio = $orig_w / $orig_h;

            $new_w = $dest_w;

            $new_h = $dest_h;



            if ( ! $new_w ) {

                $new_w = intval( $new_h * $aspect_ratio );

            }



            if ( ! $new_h ) {

                $new_h = intval( $new_w / $aspect_ratio );

            }



            $size_ratio = max( $new_w / $orig_w, $new_h / $orig_h );



            $crop_w = round( $new_w / $size_ratio );

            $crop_h = round( $new_h / $size_ratio );



            $s_x = floor( ( $orig_w - $crop_w ) / 2 );

            $s_y = floor( ( $orig_h - $crop_h ) / 2 );



            return array( 0, 0, (int) $s_x, (int) $s_y, (int) $new_w, (int) $new_h, (int) $crop_w, (int) $crop_h );

        }

    }

}


if(!function_exists('admania_autoresize')) {



    /**

     * This is just a tiny wrapper function for the class above so that there is no

     * need to change any code in your own WP themes. Usage is still the same :)

     */

    function admania_autoresize( $url, $width = null, $height = null, $crop = null, $single = true, $upscale = false ) {

        /* WPML Fix */

        if ( defined( 'ICL_SITEPRESS_VERSION' ) ){

            global $sitepress;

            $url = $sitepress->convert_url( $url, $sitepress->get_default_language() );

        }

        /* WPML Fix */



        $admania_autoresize = admania_autoresize::getInstance();

        return $admania_autoresize->process( $url, $width, $height, $crop, $single, $upscale );

    }

}

/*-----------------------------------------------------------------------------------*/
# Admania RelatedPost
/*-----------------------------------------------------------------------------------*/


if(! function_exists( 'admania_relatedpost' ) ):

function admania_relatedpost() {

if(is_single()) {
	
global $post;

$post_id = $post->ID;

$admania_bylineck = admania_get_option('admania_ebylfp');

if(admania_get_option('admania_choserd1') != false):
$admania_choserd1 = admania_get_option('admania_choserd1');
else:
$admania_choserd1 = 'latest';
endif;

if($admania_choserd1 == 'latest'):

$admania_orderbychs1 = 'date';

elseif($admania_choserd1 == 'random'):

$admania_orderbychs1 = 'rand';

else:

$admania_orderbychs1 = 'date';

endif;


if(admania_get_option('admania_choserd2') != false):
$admania_choserd2 = admania_get_option('admania_choserd2');
else:
$admania_choserd2 = 'latest';
endif;



if($admania_choserd2 == 'latest'):

$admania_orderbychs2 = 'date';

elseif($admania_choserd2 == 'random'):

$admania_orderbychs2 = 'rand';

else:

$admania_orderbychs2 = 'date';

endif;

	if((admania_get_option('admania-enable-related-post-by-tag')) != false) // related posts display by tag
	{
	
	
	if(admania_get_option('admania_relatedpostbytagcount') != false):
	
	$admania_rpbytag = admania_get_option('admania_relatedpostbytagcount');
	
	else:
	
	$admania_rpbytag = '3';
	
	endif;
	

		
	$admania_tags = wp_get_post_tags($post->ID);
	if ($admania_tags) {
	
	$admania_tag_ids = array();
	foreach($admania_tags as $individual_tag) $admania_tag_ids[] = $individual_tag->term_id;
	$admania_reltagargs=array(
	'tag__in' => $admania_tag_ids,
	'orderby'=>$admania_orderbychs2,
	'post__not_in' => array($post->ID),
	'posts_per_page'=> $admania_rpbytag, // Number of related posts that will be displayed.
    'ignore_sticky_posts'=>1,	
	);
	$admania_rel_tagquery = new wp_query( $admania_reltagargs );
	if( $admania_rel_tagquery->have_posts() ) {				
	
	echo '<div class="admania_related_posts">
	<h5 class="admania_related_postsheading">'.esc_html__('You May Also Like','admania').'</h5><ul>';
	while( $admania_rel_tagquery->have_posts() ) {
	$admania_rel_tagquery->the_post(); 
	
	?>
<li>
  <?php			  
  
  if(admania_get_option('admania_dabothsidebar') == 1) {
	  $admaniafeatured_imgwidth1 = 372;
		$admaniafeatured_imgheight1 = 255;
  }
  else{
					  
		$admaniafeatured_imgwidth1 = 250;
		$admaniafeatured_imgheight1 = 150;
  }

		$admania_postthumb1 = get_post_thumbnail_id();
		$admaniapost_imgsrc = wp_get_attachment_url( $admania_postthumb1,'full'); //get img URL	
		$admania_relatedimgurl = admania_autoresize($admaniapost_imgsrc,$admaniafeatured_imgwidth1,$admaniafeatured_imgheight1,true);					 
		$admania_featdvidurl = get_post_meta($post->ID, '_admania_featured_videourl', true); 
		$admania_youtube_matchexp = "/\s*[a-zA-Z\/\/:\.]*youtube.com\/watch\?v=([a-zA-Z0-9\-_]+)([a-zA-Z0-9\/\*\-\_\?\&\;\%\=\.]*)/i";  
		$admania_vimeo_matchexp = "/https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)/";
		$admania_souncloud_matchexp = "%(?:https?://)(?:www\.)?soundcloud\.com/([\-a-z0-9_]+/[\-a-z0-9_]+)%im";
		$admania_framename = "iframe";  



   		    if($admania_featdvidurl != false || $admania_relatedimgurl != false) {
						
			if($admania_featdvidurl != false) {

				if(preg_match($admania_youtube_matchexp , $admania_featdvidurl)) {
						
				$admania_featdvidurl = preg_replace($admania_youtube_matchexp,"<".esc_attr($admania_framename)." width=\"".absint($admaniafeatured_imgwidth1)."\" height=\"".absint($admaniafeatured_imgheight1)."\" src=\"//www.youtube.com/embed/$1\"  allowfullscreen></iframe>",$admania_featdvidurl);
						
				echo wp_kses_stripslashes($admania_featdvidurl);					
						
			}
						
			elseif(preg_match($admania_vimeo_matchexp , $admania_featdvidurl)) {						
												
				$admania_vimeovideos = preg_replace( $admania_vimeo_matchexp ,"<".esc_attr($admania_framename)." width=\"".absint($admaniafeatured_imgwidth1)."\" height=\"".absint($admaniafeatured_imgheight1)."\" src=\"//player.vimeo.com/video/$3\"  allowfullscreen></iframe>",$admania_featdvidurl);
						
				echo wp_kses_stripslashes($admania_vimeovideos);
						
			}
						
			elseif(preg_match( $admania_souncloud_matchexp , $admania_featdvidurl)) {
						
				$admania_souncloudsng = preg_replace( $admania_souncloud_matchexp ,'<'.esc_attr($admania_framename).' width="'.absint($admaniafeatured_imgwidth1).'" height="'.absint($admaniafeatured_imgheight1).'" src="https://w.soundcloud.com/player/?url=https://soundcloud.com/$1&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>',$admania_featdvidurl); 
						
				echo wp_kses_stripslashes($admania_souncloudsng);	
						
			}					
				
			}
						
			elseif($admaniapost_imgsrc != false && $admania_featdvidurl == false ) { 
			?>
  <a  href="<?php esc_url(the_permalink()); ?>" title="<?php esc_html(the_title()); ?>"> <img src="<?php echo esc_url($admania_relatedimgurl);  ?>" alt="<?php esc_html_e('image','admania'); ?>"/> </a>
  <?php 
			}
			}
			
				else {
		
    if (!has_post_thumbnail($post->ID) ) {
			   
	$admania_postdetails = get_post($post->ID);
		
	preg_match_all( '/<img .*?(?=src)src=\"([^\"]+)\"/si', $admania_postdetails->post_content, $admania_allpics );
	if (is_array($admania_allpics[1]) && count($admania_allpics[1])>0) {
		$admania_pic = $admania_allpics[1][0];
	if (strpos($admania_pic,"?")>0) {
		$admania_pic = substr($admania_pic,0,strpos($admania_pic,"?"));
	}
		
		$admania_exturl =  $admania_pic;
	}
	 if(!empty($admania_exturl) != ''){
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_exturl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" width="<?php echo intval($admaniafeatured_imgwidth1); ?>px;" height="<?php echo intval($admaniafeatured_imgheight1);?>px;"/>
	</a>
	 <?php
	 }

	}
else {
		
	if (has_post_thumbnail($post->ID) ) {
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admaniapost_imgsrc); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
	<?php
	}		
	}
   
  	
		
	}
			
	        ?>
  <div class="admania_rel_entry_meta">
    <?php the_title( sprintf( '<h2 class="admania_entry_title" itemprop="headline"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );?>
    <?php  if( 1 != (int) $admania_bylineck )  { ?>
    <div class="admania_entry_cat">
      <?php if(admania_get_option('admania_ppostedon') != TRUE) { ?>
      <span class="admania_date">
      <?php esc_html_e('On','admania'); ?>
      <?php the_time(get_option( 'date_format' )); ?>
      </span>
      <?php }
	 if(admania_get_option('admania_pcategory') != TRUE) { ?>
      <span class="admania_dividerlne">|</span> <span class="admania_catgory">
      <?php esc_html_e('In','admania'); ?>
      <?php  the_category(' ,');?>
      </span>
      <?php  } ?>
    </div>
    <?php  } ?>
  </div>
</li>
<?php		
	}
	echo '</ul></div>';
	} }
	
	wp_reset_postdata(); 
	}

if((admania_get_option('admania-enable-related-post-by-category')) == false) // related posts display by category
	{
		
		
		if(admania_get_option('admania_relatedpostbycategorycount') != false){
		
		$admania_rpbycategory = admania_get_option('admania_relatedpostbycategorycount');
		
		}
		else{
		
		$admania_rpbycategory = '3';
		
		}
		
	
	$admania_categories = get_the_category($post->ID);
	if ($admania_categories) {		
	
	$category_ids = array();
	foreach($admania_categories as $admania_individual_category) $admania_category_ids[] = $admania_individual_category->term_id;
	$admania_catrelargs = array(
	'category__in' => $category_ids,
	'orderby'=>$admania_orderbychs1,
	'post__not_in' => array($post->ID),
	'posts_per_page'=> $admania_rpbycategory, // Number of related posts that will be displayed.
	'ignore_sticky_posts'=>1,	
	);
				
	$admania_relcat_query = new wp_query( $admania_catrelargs );
	
		
	if( $admania_relcat_query->have_posts() ) {
		
	 
	echo '<div class="admania_related_posts">
	<h5 class="admania_related_postsheading">'.esc_html__('You May Also Like','admania').'</h5><ul>';
	while( $admania_relcat_query->have_posts() ) {
	$admania_relcat_query->the_post(); 
	?>
<li>
  <?php			  
	
		 if(admania_get_option('admania_dabothsidebar') == 1) {
			$admaniafeatured_imgwidth1 = 372;
			$admaniafeatured_imgheight1 = 255;
		}
		else{
					  
		$admaniafeatured_imgwidth1 = 250;
		$admaniafeatured_imgheight1 = 150;
		
		}

		$admania_postthumb1 = get_post_thumbnail_id();
		$admaniapost_imgsrc = wp_get_attachment_url( $admania_postthumb1,'full'); //get img URL	
		$admania_relatedimgurl = admania_autoresize($admaniapost_imgsrc,$admaniafeatured_imgwidth1,$admaniafeatured_imgheight1,true);		 
		$admania_featdvidurl = get_post_meta($post->ID, '_admania_featured_videourl', true); 
		$admania_youtube_matchexp = "/\s*[a-zA-Z\/\/:\.]*youtube.com\/watch\?v=([a-zA-Z0-9\-_]+)([a-zA-Z0-9\/\*\-\_\?\&\;\%\=\.]*)/i";  
		$admania_vimeo_matchexp = "/https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)/";
		$admania_souncloud_matchexp = "%(?:https?://)(?:www\.)?soundcloud\.com/([\-a-z0-9_]+/[\-a-z0-9_]+)%im";
		$admania_framename = "iframe";  			  
						
          if($admania_featdvidurl != false || $admania_relatedimgurl != false) {
						
			if($admania_featdvidurl != false) {

				if(preg_match($admania_youtube_matchexp , $admania_featdvidurl)) {
						
				$admania_featdvidurl = preg_replace($admania_youtube_matchexp,"<".esc_attr($admania_framename)." width=\"".absint($admaniafeatured_imgwidth1)."\" height=\"".absint($admaniafeatured_imgheight1)."\" src=\"//www.youtube.com/embed/$1\"  allowfullscreen></iframe>",$admania_featdvidurl);
						
				echo wp_kses_stripslashes($admania_featdvidurl);					
						
			}
						
			elseif(preg_match($admania_vimeo_matchexp , $admania_featdvidurl)) {						
												
				$admania_vimeovideos = preg_replace( $admania_vimeo_matchexp ,"<".esc_attr($admania_framename)." width=\"".absint($admaniafeatured_imgwidth1)."\" height=\"".absint($admaniafeatured_imgheight1)."\" src=\"//player.vimeo.com/video/$3\"  allowfullscreen></iframe>",$admania_featdvidurl);
						
				echo wp_kses_stripslashes($admania_vimeovideos);
						
			}
						
			elseif(preg_match( $admania_souncloud_matchexp , $admania_featdvidurl)) {
						
				$admania_souncloudsng = preg_replace( $admania_souncloud_matchexp ,'<'.esc_attr($admania_framename).' width="'.absint($admaniafeatured_imgwidth1).'" height="'.absint($admaniafeatured_imgheight1).'" src="https://w.soundcloud.com/player/?url=https://soundcloud.com/$1&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>',$admania_featdvidurl); 
						
				echo wp_kses_stripslashes($admania_souncloudsng);	
						
			}					
				
			}
						
			elseif($admaniapost_imgsrc != false && $admania_featdvidurl == false ) { 
			?>
  <a  href="<?php esc_url(the_permalink()); ?>" title="<?php esc_html(the_title()); ?>"> <img src="<?php echo esc_url($admania_relatedimgurl);  ?>" alt="<?php esc_html_e('image','admania'); ?>"/> </a>
  <?php 
			}
			}
			
				else {
		
    if (!has_post_thumbnail($post->ID) ) {
			   
	$admania_postdetails = get_post($post->ID);
		
	preg_match_all( '/<img .*?(?=src)src=\"([^\"]+)\"/si', $admania_postdetails->post_content, $admania_allpics );
	if (is_array($admania_allpics[1]) && count($admania_allpics[1])>0) {
		$admania_pic = $admania_allpics[1][0];
	if (strpos($admania_pic,"?")>0) {
		$admania_pic = substr($admania_pic,0,strpos($admania_pic,"?"));
	}
		
		$admania_exturl =  $admania_pic;
	}
	 if(!empty($admania_exturl) != ''){
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_exturl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" width="<?php echo intval($admaniafeatured_imgwidth1); ?>px;" height="<?php echo intval($admaniafeatured_imgheight1);?>px;"/>
	</a>
	 <?php
	 }

	}  	
	else {
		
	if (has_post_thumbnail($post->ID) ) {
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admaniapost_imgsrc); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
	<?php
	}		
	}
		
	}
				        
	        ?>
  <div class="admania_rel_entry_meta">
    <?php the_title( sprintf( '<h2 class="admania_entry_title" itemprop="headline"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );?>
    <?php  if( 1 != (int) $admania_bylineck )  {  ?>
    <div class="admania_entry_cat">
      <?php
	   if(admania_get_option('admania_ppostedon') != TRUE) { ?>
      <span class="admania_date">
      <?php  esc_html_e('On','admania'); ?>
      <?php the_time(get_option( 'date_format' )); ?>
      </span>
      <?php
	  }
	   if(admania_get_option('admania_pcategory') != TRUE) { ?>
      <span class="admania_dividerlne">|</span> <span class="admania_catgory">
      <?php  esc_html_e('In','admania'); ?>
      <?php  the_category(' ,');?>
      </span>
      <?php }  ?>
    </div>
    <?php }  ?>
  </div>
</li>
<?php

	}
	echo '</ul></div>';
	} 
	}
	
	wp_reset_postdata();
	
	}

}
}

endif;

/*-----------------------------------------------------------------------------------*/
# Admania Pagination
/*-----------------------------------------------------------------------------------*/


if ( ! function_exists( 'admania_paging_nav' ) ) :
/**
 *
 * @global WP_Query   $wp_query   WordPress Query object.
 * @global WP_Rewrite $wp_rewrite WordPress Rewrite object.
 */
function admania_paging_nav() {

 if(admania_get_option('admania_hmpgpaginationno') != true) {
	
	global $wp_query, $wp_rewrite;

	// Don't print empty markup if there's only one page.
	if ( $wp_query->max_num_pages < 2 ) {
		return;
	}

	$admania_paged        = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
	$admania_pagenum_link = html_entity_decode( get_pagenum_link() );
	$admania_query_args   = array();
	$admania_url_parts    = explode( '?', $admania_pagenum_link );

	if ( isset( $admania_url_parts[1] ) ) {
		wp_parse_str( $admania_url_parts[1], $admania_query_args );
	}

	$admania_pagenum_link = remove_query_arg( array_keys( $admania_query_args ), $admania_pagenum_link );
	$admania_pagenum_link = trailingslashit( $admania_pagenum_link ) . '%_%';

	$admania_format  = $wp_rewrite->using_index_permalinks() && ! strpos( $admania_pagenum_link, 'index.php' ) ? 'index.php/' : '';
	$admania_format .= $wp_rewrite->using_permalinks() ? user_trailingslashit( $wp_rewrite->pagination_base . '/%#%', 'paged' ) : '?paged=%#%';

	// Set up paginated links.
	$admania_pagenav_links = paginate_links( array(
		'base'     => $admania_pagenum_link,
		'format'   => $admania_format,
		'total'    => $wp_query->max_num_pages,
		'current'  => $admania_paged,
		'mid_size' => 1,
		'add_args' => array_map( 'urlencode', $admania_query_args ),
		'prev_text' => esc_html__( '&larr; Previous', 'admania' ),
		'next_text' => esc_html__( 'Next &rarr;', 'admania' ),
	) );

	if ( $admania_pagenav_links ) :

	?>
<div class="admania_pagination"> <?php echo wp_kses_stripslashes($admania_pagenav_links); ?> </div>
<!-- .admania_pagination -->

<?php
	endif;
}
}
endif;


/*-----------------------------------------------------------------------------------*/
# Admania FeaturedImage
/*-----------------------------------------------------------------------------------*/


if ( ! function_exists( 'admania_featuredimage' ) ) :
 
function admania_featuredimage() { 

    global $post,$admania_counter;
	
	$admania_thumb = get_post_thumbnail_id();
 	$admania_imgurl = wp_get_attachment_url( $admania_thumb,'full'); //get img URL
	
	$admania_ytdimg = get_post_meta($post->ID, '_admania_featured_videourl', true); 
	$admania_youtube_matchexp = "/\s*[a-zA-Z\/\/:\.]*youtube.com\/watch\?v=([a-zA-Z0-9\-_]+)([a-zA-Z0-9\/\*\-\_\?\&\;\%\=\.]*)/i";  
	$admania_vimeomatchexp = "/https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)/";
	$admania_souncloudmatchexp = "%(?:https?://)(?:www\.)?soundcloud\.com/([\-a-z0-9_]+/[\-a-z0-9_]+)%im";
	$admania_framename = "iframe";
	
	$admania_blog_layout = ((admania_get_option('admania_blog_scheme')) ? admania_get_option('admania_blog_scheme') : 'amblyt1');
	

	if($admania_blog_layout == 'amblyt1') {		
	
	if(admania_get_option('admania_dabothsidebar') == 1) {
	$admania_fwidth = '1200';
	$admania_fheight = '700';
	}
	else{
	
	if(admania_get_option('layt4_cnt_frstlaytlstsdbr') == 1) {
	$admania_fwidth = '859';
	$admania_fheight = '450';
	}
	else {	
	$admania_fwidth = '653';
	$admania_fheight = '393';
	}
	}
		
	$admania_image = admania_autoresize( $admania_imgurl, $admania_fwidth, $admania_fheight, true ); //resize & crop img

	if(($admania_ytdimg != "")  || ($admania_image != "")){
	
	if($admania_ytdimg != "") {
	
	if(preg_match($admania_youtube_matchexp , $admania_ytdimg)) {	
	
	$admania_yuvid = preg_replace($admania_youtube_matchexp,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"https://www.youtube.com/embed/$1\" allowfullscreen></iframe>",$admania_ytdimg);
	
	echo wp_kses_stripslashes($admania_yuvid);
	
	}
	
	elseif(preg_match($admania_vimeomatchexp , $admania_ytdimg)) {
	
	$admania_vimeovideos = preg_replace( $admania_vimeomatchexp ,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"https://player.vimeo.com/video/$3\" allowfullscreen></iframe>",$admania_ytdimg);
	
	echo wp_kses_stripslashes($admania_vimeovideos);
	
	}
	
	elseif(preg_match( $admania_souncloudmatchexp , $admania_ytdimg)) {	
	
	$admania_souncloudsng = preg_replace( $admania_souncloudmatchexp ,'<'.esc_attr($admania_framename).' width="'.absint($admania_fwidth).'" height="'.absint($admania_fheight).'" scrolling="no" src="https://w.soundcloud.com/player/?url=https://soundcloud.com/$1&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>',$admania_ytdimg); 
	
	echo wp_kses_stripslashes($admania_souncloudsng);
	
	}
	
	} 		
	
	elseif($admania_image != "" && $admania_ytdimg == "" ) { 
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_image); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
	<?php 
	} 	

	}
	else {
		
	if (!has_post_thumbnail($post->ID) ) {
			   
	$admania_postdetails = get_post($post->ID);
		
	preg_match_all( '/<img .*?(?=src)src=\"([^\"]+)\"/si', $admania_postdetails->post_content, $admania_allpics );
	if (is_array($admania_allpics[1]) && count($admania_allpics[1])>0) {
		$admania_pic = $admania_allpics[1][0];
	if (strpos($admania_pic,"?")>0) {
		$admania_pic = substr($admania_pic,0,strpos($admania_pic,"?"));
	}
		
		$admania_exturl =  $admania_pic;
	}
	 if(!empty($admania_exturl) != ''){
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_exturl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" width="<?php echo intval($admania_fwidth); ?>px;" height="<?php echo intval($admania_fheight);?>px;"/>
	</a>
	 <?php
	 }

	} 	
	
	else {
		
	if (has_post_thumbnail($post->ID) ) {
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_imgurl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
	<?php
	}		
	}
   
	}
    }

    elseif($admania_blog_layout == 'amblyt2') {	
	
	
	if(admania_get_option('admania_dabothsidebar') == 1) {
		 if(((!is_single()) && (!is_page()))) {
	$admania_fwidth = '370';
	$admania_fheight = '240';
	}
	else{
	$admania_fwidth = '1200';
	$admania_fheight = '700';	
	}
	}
	
	else{
	
    if(((!is_single()) && (!is_page()))) {
	$admania_fwidth = '370';
	$admania_fheight = '240';
	}
	else{
	$admania_fwidth = '864';
	$admania_fheight = '450';	
	}
	
	}
	
	
	$admania_image = admania_autoresize( $admania_imgurl, $admania_fwidth, $admania_fheight, true ); //resize & crop img
	
	?>
	
	<div class="admania_entryimage">
  <?php
	if(($admania_ytdimg != "")  || ($admania_image != "")){
	
	if($admania_ytdimg != "") {
	
	if(preg_match($admania_youtube_matchexp , $admania_ytdimg)) {	
	
	$admania_yuvid = preg_replace($admania_youtube_matchexp,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"//www.youtube.com/embed/$1\" allowfullscreen></iframe>",$admania_ytdimg);
	
	echo wp_kses_stripslashes($admania_yuvid);
	
	}
	
	elseif(preg_match($admania_vimeomatchexp , $admania_ytdimg)) {
	
	$admania_vimeovideos = preg_replace( $admania_vimeomatchexp ,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"//player.vimeo.com/video/$3\" allowfullscreen></iframe>",$admania_ytdimg);
	
	echo wp_kses_stripslashes($admania_vimeovideos);
	
	}
	
	elseif(preg_match( $admania_souncloudmatchexp , $admania_ytdimg)) {	
	
	$admania_souncloudsng = preg_replace( $admania_souncloudmatchexp ,'<'.esc_attr($admania_framename).' width="'.absint($admania_fwidth).'" height="'.absint($admania_fheight).'" scrolling="no" src="https://w.soundcloud.com/player/?url=https://soundcloud.com/$1&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>',$admania_ytdimg); 
	
	echo wp_kses_stripslashes($admania_souncloudsng);
	
	}
	
	} 		
	
	elseif($admania_image != "" && $admania_ytdimg == "" ) { 
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_image); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
    <?php 
	}
   
	}
	else {
		
   if (!has_post_thumbnail($post->ID) ) {
			   
	$admania_postdetails = get_post($post->ID);
		
	preg_match_all( '/<img .*?(?=src)src=\"([^\"]+)\"/si', $admania_postdetails->post_content, $admania_allpics );
	if (is_array($admania_allpics[1]) && count($admania_allpics[1])>0) {
		$admania_pic = $admania_allpics[1][0];
	if (strpos($admania_pic,"?")>0) {
		$admania_pic = substr($admania_pic,0,strpos($admania_pic,"?"));
	}
		
		$admania_exturl =  $admania_pic;
	}
	 if(!empty($admania_exturl) != ''){
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_exturl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" width="<?php echo intval($admania_fwidth); ?>px;" height="<?php echo intval($admania_fheight);?>px;"/>
	</a>
	 <?php
	 }

	}

else {
		
	if (has_post_thumbnail($post->ID) ) {
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_imgurl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
	<?php
	}		
	}	
		
	}
	?>	 
	</div>
    <?php	
    }
    elseif($admania_blog_layout == 'amblyt3') {	
	$admania_ftdimgclass = '';
	
	if(admania_get_option('admania_dabothsidebar') == 1) {
	
   if(((!is_single()) && (!is_page()))) {
	
	$admania_fwidth = '360';
	$admania_fheight = '234';
   }
   
   else {
	   
	$admania_fwidth = '1200';
	$admania_fheight = '700';
	   
   }
	
	}
	
	else {
	
    if(((!is_single()) && (!is_page()))) {
	$admania_fwidth = '259';
	$admania_fheight = '168';
	$admania_ftdimgclass = 'admania_gridpostimg';
	}
	else{
	$admania_fwidth = '864';
	$admania_fheight = '450';	
	}
	}

	$admania_image = admania_autoresize( $admania_imgurl, $admania_fwidth, $admania_fheight, true ); //resize & crop img
	
	?>
	
	<div class="admania_entryimage <?php echo esc_attr($admania_ftdimgclass); ?>">
    <?php
	if(($admania_ytdimg != "")  || ($admania_image != "")){
	
	if($admania_ytdimg != "") {
	
	if(preg_match($admania_youtube_matchexp , $admania_ytdimg)) {	
	
	$admania_yuvid = preg_replace($admania_youtube_matchexp,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"//www.youtube.com/embed/$1\" allowfullscreen></iframe>",$admania_ytdimg);
	
	echo wp_kses_stripslashes($admania_yuvid);
	
	}
	
	elseif(preg_match($admania_vimeomatchexp , $admania_ytdimg)) {
	
	$admania_vimeovideos = preg_replace( $admania_vimeomatchexp ,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"//player.vimeo.com/video/$3\" allowfullscreen></iframe>",$admania_ytdimg);
	
	echo wp_kses_stripslashes($admania_vimeovideos);
	
	}
	
	elseif(preg_match( $admania_souncloudmatchexp , $admania_ytdimg)) {	
	
	$admania_souncloudsng = preg_replace( $admania_souncloudmatchexp ,'<'.esc_attr($admania_framename).' width="'.absint($admania_fwidth).'" height="'.absint($admania_fheight).'" scrolling="no" src="https://w.soundcloud.com/player/?url=https://soundcloud.com/$1&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>',$admania_ytdimg); 
	
	echo wp_kses_stripslashes($admania_souncloudsng);
	
	}
	
	} 		
	
	elseif($admania_image != "" && $admania_ytdimg == "" ) { 
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_image); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
	<?php 
	}

    elseif($admania_image == "" && $admania_ytdimg == "" ) { 
	
	the_post_thumbnail();

	} 	
	}
	else {
		
    if (!has_post_thumbnail($post->ID) ) {
			   
	$admania_postdetails = get_post($post->ID);
		
	preg_match_all( '/<img .*?(?=src)src=\"([^\"]+)\"/si', $admania_postdetails->post_content, $admania_allpics );
	if (is_array($admania_allpics[1]) && count($admania_allpics[1])>0) {
		$admania_pic = $admania_allpics[1][0];
	if (strpos($admania_pic,"?")>0) {
		$admania_pic = substr($admania_pic,0,strpos($admania_pic,"?"));
	}
		
		$admania_exturl =  $admania_pic;
	}
	 if(!empty($admania_exturl) != ''){
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_exturl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" width="<?php echo intval($admania_fwidth); ?>px;" height="<?php echo intval($admania_fheight);?>px;"/>
	</a>
	 <?php
	 }

	}

	else {
		
	if (has_post_thumbnail($post->ID) ) {
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_imgurl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
	<?php
	}		
	}	  	
		
	}
	?>	 
	</div>
<?php	
}
elseif($admania_blog_layout == 'amblyt4') {	

if(admania_get_option('admania_dabothsidebar') == 1) {
	 if(is_single() || is_page()) {
	$admania_fwidth = '1200';
	$admania_fheight = '700';
	 }
	 else {
		$admania_fwidth = '850';
	$admania_fheight = '450'; 
	 }
}

else {


    if(is_single() || is_page()) {
	if(admania_get_option('layt4_cnt_lstsdbr') == 1) {
	$admania_fwidth = '859';
	$admania_fheight = '450';
	}
	elseif(admania_get_option('layt4_cnt_rgtsdbr') == 1){
	$admania_fwidth = '680';
	$admania_fheight = '408';	
	}	
	else {
	$admania_fwidth = '653';
	$admania_fheight = '408';
	}
	}
	else {
		if((admania_get_option('layt4_cnt_rgtsdbr') == 1) && (admania_get_option('layt4_cnt_lstsdbr') == 1)) {
		$admania_fwidth = '871';
	$admania_fheight = '453';		
		}
		else {
    if(admania_get_option('layt4_cnt_lstsdbr') == 1) {
	$admania_fwidth = '611';
	$admania_fheight = '382';
	}
	elseif(admania_get_option('layt4_cnt_rgtsdbr') == 1){
	$admania_fwidth = '680';
	$admania_fheight = '408';	
	}	
	else {
	$admania_fwidth = '472';
	$admania_fheight = '295';
	}
		}	
	}
}
	$admania_image = admania_autoresize( $admania_imgurl, $admania_fwidth, $admania_fheight, true ); //resize & crop img

	if(($admania_ytdimg != "")  || ($admania_image != "")){
	
	if($admania_ytdimg != "") {
	
	if(preg_match($admania_youtube_matchexp , $admania_ytdimg)) {	
	
	$admania_yuvid = preg_replace($admania_youtube_matchexp,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"//www.youtube.com/embed/$1\" allowfullscreen></iframe>",$admania_ytdimg);
	
	echo wp_kses_stripslashes($admania_yuvid);
	
	}
	
	elseif(preg_match($admania_vimeomatchexp , $admania_ytdimg)) {
	
	$admania_vimeovideos = preg_replace( $admania_vimeomatchexp ,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"//player.vimeo.com/video/$3\" allowfullscreen></iframe>",$admania_ytdimg);
	
	echo wp_kses_stripslashes($admania_vimeovideos);
	
	}
	
	elseif(preg_match( $admania_souncloudmatchexp , $admania_ytdimg)) {	
	
	$admania_souncloudsng = preg_replace( $admania_souncloudmatchexp ,'<'.esc_attr($admania_framename).' width="'.absint($admania_fwidth).'" height="'.absint($admania_fheight).'" scrolling="no" src="https://w.soundcloud.com/player/?url=https://soundcloud.com/$1&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>',$admania_ytdimg); 
	
	echo wp_kses_stripslashes($admania_souncloudsng);
	
	}
	
	} 		
	
	elseif($admania_image != "" && $admania_ytdimg == "" ) { 
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_image); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
	<?php 
	} 	

	}
	else {
		
if (!has_post_thumbnail($post->ID) ) {
			   
	$admania_postdetails = get_post($post->ID);
		
	preg_match_all( '/<img .*?(?=src)src=\"([^\"]+)\"/si', $admania_postdetails->post_content, $admania_allpics );
	if (is_array($admania_allpics[1]) && count($admania_allpics[1])>0) {
		$admania_pic = $admania_allpics[1][0];
	if (strpos($admania_pic,"?")>0) {
		$admania_pic = substr($admania_pic,0,strpos($admania_pic,"?"));
	}
		
		$admania_exturl =  $admania_pic;
	}
	 if(!empty($admania_exturl) != ''){
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_exturl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" width="<?php echo intval($admania_fwidth); ?>px;" height="<?php echo intval($admania_fheight);?>px;"/>
	</a>
	 <?php
	 }

	} 	
	else {		
	if (has_post_thumbnail($post->ID) ) {
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_imgurl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
	<?php
	}		
	}	  
		
	}
}

elseif($admania_blog_layout == 'amblyt5') {	

    $admania_bylineck = admania_get_option('admania_ebylfp');
	
	if(admania_get_option('admania_dabothsidebar') == 1) {
	 if(is_single() || is_page()) {
	$admania_fwidth = '1200';
	$admania_fheight = '700';
	 }
	 else {
		$admania_fwidth = '576';
	$admania_fheight = '360'; 
	 }
    }

else {

    if(is_single() || is_page()) {
	$admania_fwidth = '859';
	$admania_fheight = '447';
	}
	else {
	$admania_fwidth = '418';
	$admania_fheight = '261';	
	}
}
	$admania_image = admania_autoresize( $admania_imgurl, $admania_fwidth, $admania_fheight, true ); //resize & crop img
	
	if(!is_single() && !is_page()) {
		
		if (!has_post_thumbnail($post->ID) ) {
			   
	$admania_postdetails = get_post($post->ID);
		
	preg_match_all( '/<img .*?(?=src)src=\"([^\"]+)\"/si', $admania_postdetails->post_content, $admania_allpics );
	if (is_array($admania_allpics[1]) && count($admania_allpics[1])>0) {
		$admania_pic = $admania_allpics[1][0];
	if (strpos($admania_pic,"?")>0) {
		$admania_pic = substr($admania_pic,0,strpos($admania_pic,"?"));
	}
		
		$admania_exturl =  $admania_pic;
	}
		}
		
			
	if (has_post_thumbnail($post->ID) ) {
		
		$admania_exturl =  $admania_imgurl;	
	}		
			
		
		if(($admania_image == "") && ($admania_ytdimg == "") && (!empty($admania_exturl) == '')):
		$admania_wotftdimage = 'admania_layt5wotftimg';
		else:
		$admania_wotftdimage = '';
		endif;
    ?>
   	<div class="admanialayt5_entryheader <?php echo esc_attr($admania_wotftdimage); ?>">
	
	<?php	
	}   
	
    if(($admania_ytdimg != "")  || ($admania_image != "")){
	
	if($admania_ytdimg != "") {
	
	if(preg_match($admania_youtube_matchexp , $admania_ytdimg)) {	
	
	$admania_yuvid = preg_replace($admania_youtube_matchexp,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"//www.youtube.com/embed/$1\" allowfullscreen></iframe>",$admania_ytdimg);
	
	echo wp_kses_stripslashes($admania_yuvid);
	
	}
	
	elseif(preg_match($admania_vimeomatchexp , $admania_ytdimg)) {
	
	$admania_vimeovideos = preg_replace( $admania_vimeomatchexp ,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"//player.vimeo.com/video/$3\" allowfullscreen></iframe>",$admania_ytdimg);
	
	echo wp_kses_stripslashes($admania_vimeovideos);
	
	}
	
	elseif(preg_match( $admania_souncloudmatchexp , $admania_ytdimg)) {	
	
	$admania_souncloudsng = preg_replace( $admania_souncloudmatchexp ,'<'.esc_attr($admania_framename).' width="'.absint($admania_fwidth).'" height="'.absint($admania_fheight).'" scrolling="no" src="https://w.soundcloud.com/player/?url=https://soundcloud.com/$1&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>',$admania_ytdimg); 
	
	echo wp_kses_stripslashes($admania_souncloudsng);
	
	}
	
	} 		
	
	elseif($admania_image != "" && $admania_ytdimg == "" ) { 
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_image); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
	<?php 
	}
	}
	else {
		

	if(!empty($admania_exturl) != ''){
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_exturl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" width="<?php echo intval($admania_fwidth); ?>px;" height="<?php echo intval($admania_fheight);?>px;"/>
	</a>
	<?php

	}

    else {		
	if (has_post_thumbnail($post->ID) ) {
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_imgurl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
	<?php
	}		
	}	    	
		
	}

if(!is_single() && !is_page()) { 	
	?>
	
	<div class="admanialayt5_entrymeta_ads">
            <?php							
				if(admania_get_option('admania_ebylfp') != TRUE) {
				if(admania_get_option('admania_pcategory') != TRUE) {
			?>
			<div class="admania_entrymeta admanialayt5_entrymeta"> 
				<?php esc_html_e('In','admania'); ?>
				<?php the_category(' , '); ?>
			</div>				
			<?php } } ?>
			<div class="admania_entryheader admania_layt4entryheader">
				<?php the_title( sprintf( '<h2 class="admania_entrytitle" itemprop="headline"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );?>
					<div class="admania_entrybyline admania_layt5entrybyline">
						<?php if ( is_sticky() && is_home() && ! is_paged() ) : ?>
					<span class="admania_stickypost">
						<?php esc_html_e( 'Featured', 'admania' ); ?>
					</span>
					<div class="admania_entrybylinecd">|</div>
						<?php endif; ?>
						<?php
										if( 1 != (int) $admania_bylineck )  { 
										   if(admania_get_option('admania_ppostedby') != TRUE) {
                                            echo get_avatar( get_the_author_meta( 'user_email' ), 15 );											   
										   esc_html_e('By','admania'); ?>
											<?php the_author_posts_link(); ?>
											<div class="admania_entrybylinecd">|</div>
											<?php  }
										if(admania_get_option('admania_ppostedon') != TRUE) {
										?>
											<?php esc_html_e('On','admania'); ?>
											<?php the_time(get_option( 'date_format'));	  	  
										}
										}
									?>
								</div>
			</div>
	</div>
	<?php
	}
	if(!is_single() && !is_page()) { 	
	?>
</div>
<?php
}
}


elseif($admania_blog_layout == 'amblyt6') {	



if(admania_get_option('admania_dabothsidebar') == 1) {
	if(((!is_single()) && (!is_page()))) {
	$admania_fwidth = '327';
	$admania_fheight = '218';
	}
	else{
	$admania_fwidth = '1000';
	$admania_fheight = '700';	
	}
	}
	
	else{
	
    if(((!is_single()) && (!is_page()))) {
	$admania_fwidth = '327';
	$admania_fheight = '218';
	}
	else{
	$admania_fwidth = '687';
	$admania_fheight = '358';	
	}
	
	}
		
	$admania_image = admania_autoresize( $admania_imgurl, $admania_fwidth, $admania_fheight, true ); //resize & crop img
	if(((!is_single()) && (!is_page()))) {
	?>
	<div class="admania_boxedpostimg">
	
    <?php
	}
	if(($admania_ytdimg != "")  || ($admania_image != "")){
	
	if($admania_ytdimg != "") {
	
	if(preg_match($admania_youtube_matchexp , $admania_ytdimg)) {	
	
	$admania_yuvid = preg_replace($admania_youtube_matchexp,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"//www.youtube.com/embed/$1\" allowfullscreen></iframe>",$admania_ytdimg);
	
	echo wp_kses_stripslashes($admania_yuvid);
	
	}
	
	elseif(preg_match($admania_vimeomatchexp , $admania_ytdimg)) {
	
	$admania_vimeovideos = preg_replace( $admania_vimeomatchexp ,"<".esc_attr($admania_framename)." width=\"".absint($admania_fwidth)."\" height=\"".absint($admania_fheight)."\" src=\"//player.vimeo.com/video/$3\" allowfullscreen></iframe>",$admania_ytdimg);
	
	echo wp_kses_stripslashes($admania_vimeovideos);
	
	}
	
	elseif(preg_match( $admania_souncloudmatchexp , $admania_ytdimg)) {	
	
	$admania_souncloudsng = preg_replace( $admania_souncloudmatchexp ,'<'.esc_attr($admania_framename).' width="'.absint($admania_fwidth).'" height="'.absint($admania_fheight).'" scrolling="no" src="https://w.soundcloud.com/player/?url=https://soundcloud.com/$1&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>',$admania_ytdimg); 
	
	echo wp_kses_stripslashes($admania_souncloudsng);
	
	}
	
	} 		
	
	elseif($admania_image != "" && $admania_ytdimg == "" ) { 
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_image); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
    <?php 
	}

   
	}
	else {
		
   if (!has_post_thumbnail($post->ID) ) {
			   
	$admania_postdetails = get_post($post->ID);
		
	preg_match_all( '/<img .*?(?=src)src=\"([^\"]+)\"/si', $admania_postdetails->post_content, $admania_allpics );
	if (is_array($admania_allpics[1]) && count($admania_allpics[1])>0) {
		$admania_pic = $admania_allpics[1][0];
	if (strpos($admania_pic,"?")>0) {
		$admania_pic = substr($admania_pic,0,strpos($admania_pic,"?"));
	}
		
		$admania_exturl =  $admania_pic;
	}
	 if(!empty($admania_exturl) != ''){
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_exturl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" width="<?php echo intval($admania_fwidth); ?>px;" height="<?php echo intval($admania_fheight);?>px;"/>
	</a>
	 <?php
	 }

	}

	else {		
	if (has_post_thumbnail($post->ID) ) {
	?>
	<a href="<?php the_permalink(); ?>">
		<img src="<?php echo esc_url($admania_imgurl); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_html_e('img','admania'); ?>" />
	</a>
	<?php
	}		
	}	  	
		
	}
	if(((!is_single()) && (!is_page()))) {
	?>	 
	</div>
    <?php
	}	
    }

}
endif;


/*-----------------------------------------------------------------------------------*/
# Admania Breadcrumb
/*-----------------------------------------------------------------------------------*/



if ( ! function_exists( 'admania_breadcrumb' ) ) :

function admania_breadcrumb() {
global $post;
	$admania_delimiter = '/';	
	echo '<div class="admania_breadcrumb">';	
	$admania_homeLink = home_url();
	echo '<a href="' . esc_url($admania_homeLink) . '" class="bcb">'.esc_html__('Home','admania').'</a> ' . esc_attr($admania_delimiter) . ' ';
	

if ( is_single() && !is_attachment() ) {

	if ( get_post_type() != 'post' ) {
	
		$admania_post_type = get_post_type_object(get_post_type());
		$admania_slug = $admania_post_type->rewrite;
		echo '<a href="' . esc_url($admania_homeLink) . '/' . esc_html($admania_slug['slug']) . '/">' . esc_html($admania_post_type->labels->singular_name) . '</a>' . esc_attr($admania_delimiter) . ' ';
		echo esc_html(get_the_title());
	
	} 

else {

	$admania_cat = get_the_category(); 
	$admania_cat = $admania_cat[0];
	echo get_category_parents($admania_cat, TRUE, ' ' . $admania_delimiter . ' ');
	echo esc_html(get_the_title());
	
}
} 


elseif ( is_attachment() ) {

	$admania_parent_id  = $post->post_parent;
	$admania_breadcrumbs = array();
	while ($admania_parent_id) {
	$admania_page = get_page($admania_parent_id);
	$admania_breadcrumbs[] = '<a href="' . esc_url(get_permalink($admania_page->ID)) . '">' . esc_html(get_the_title($admania_page->ID)) . '</a>';
	$admania_parent_id    = $admania_page->post_parent;
	}
	$admania_breadcrumbs = array_reverse($admania_breadcrumbs);
	foreach ($admania_breadcrumbs as $admania_crumb) echo ' ' . wp_kses_stripslashes($admania_crumb) . ' ' . wp_kses_stripslashes($admania_delimiter) . ' ';
	echo esc_html(get_the_title());

} 

elseif ( is_page() && !$post->post_parent ) {

	echo esc_html(get_the_title());
	
} 

elseif ( is_page() && $post->post_parent ) {

	$admania_parent_id  = $post->post_parent;
	$admania_breadcrumbs = array();
	while ($admania_parent_id) {
	$admania_page = get_page($admania_parent_id);
	$admania_breadcrumbs[] = '<a href="' . esc_url(get_permalink($admania_page->ID)) . '">' . esc_html(get_the_title($admania_page->ID)) . '</a>';
	$admania_parent_id    = $admania_page->post_parent;
	
}

$admania_breadcrumbs = array_reverse($admania_breadcrumbs);
foreach ($admania_breadcrumbs as $admania_crumb) 
echo ' ' . wp_kses_stripslashes($admania_crumb) . ' ' . wp_kses_stripslashes($admania_delimiter) . ' ';
echo esc_html(get_the_title());

} 

if ( get_query_var('paged') ) {
if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo '(';
echo ('Page') . ' ' . get_query_var('paged');
if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
}

echo '</div>';

}

endif;

	
/*-----------------------------------------------------------------------------------*/
# Adds Admania post content ad
/*-----------------------------------------------------------------------------------*/	
	
	if(! function_exists( 'admania_adcontent' )):
	function admania_adcontent($admania_content){
		
	 if ( class_exists( 'Woocommerce' ) ):
	 
	 return $admania_content;
	 
	 else:
	 
	 global $post,$admania_options,$admania_posttype;
	 
     $admania_posttypes = get_post( $post->ID );
	 
     $admania_posttype = $admania_posttypes->post_type; // post type 	
	 
 	 if (((!is_single()) && (!is_page()))) return $admania_content;
	       	
	if($admania_posttype == 'post') {
	
	 //Single Post Metabox Variables 
 
	$admania_pstadenable3 = get_post_meta($post->ID, '_admania_pstadenable3', true);
	$admania_bfpstadhtmlcd3 = get_post_meta($post->ID, '_admania_bfpstadhtmlcd3', true);
	$admania_bfpstadglecd3 = get_post_meta($post->ID, '_admania_bfpstadglecd3', true);
	$admania_bfpstadimg3 = get_post_meta($post->ID, '_admania_bfpstadimg3', true);
	$admania_bfpstadimglnk3 = get_post_meta($post->ID, '_admania_bfpstadimglnk3', true);
	$admania_pstadpstnbr1 = get_post_meta($post->ID, '_admania_pstadpstnbr1', true); 
	
	if($admania_pstadenable3 != false) {
	$admania_paragraphAfter = $admania_pstadpstnbr1;
	}
	else {
	
	$admania_paragraphAfter = admania_get_option('snglepst_aftrnthparano'); //Enter number of paragraphs to display ad after.

	}
	
	$admania_content = explode("</p>", $admania_content);
	$admania_newcontent = '';
	for ($i = 0; $i < count($admania_content); $i++) {
	if ($i == $admania_paragraphAfter) {
	
	    $admania_rmvcatids11 =  admania_get_option('ad_rmcatlist12');			
$admania_rmvcatids_extractids11 = explode(',',$admania_rmvcatids11);			
			
$admania_rmvtagids11 = admania_get_option('ad_rmtaglist12');
$admania_rmvtagids_extractids11 = explode(',',$admania_rmvtagids11);			
			
    if((!is_category($admania_rmvcatids_extractids11)) && (!is_tag($admania_rmvtagids_extractids11))) {
	
		if(($admania_pstadenable3 != false) || (admania_get_option('sngle_pstinrnthad') != false)) { 
		 
		$admania_newcontent.= '<div class="admania_aftrnthprad admania_themead">';
	   
  	    if((admania_get_lveditoption('hdr_lvedlhtmlad12') != false) || (admania_get_lveditoption('hdr_lvedlglead12') != false) || (admania_get_lveditoption('admania_lvedtimg_url12') != false)) {
						
 
			if(admania_get_lveditoption('hdr_lvedlhtmlad12') != false):			
			
			$admania_newcontent.= admania_get_lveditoption('hdr_lvedlhtmlad12');			
			
			endif;
			
			if(admania_get_lveditoption('hdr_lvedlglead12') != false):

			$admania_newcontent.= admania_get_lveditoption('hdr_lvedlglead12');	
			
			endif;
			
			if((admania_get_lveditoption('admania_lvedtimg_url12') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url12') != false) ):
			
			$admania_newcontent.= '<a href="'.esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url12')).'">';	
			
			$admania_newcontent.= ' <img src="'.esc_url(admania_get_lveditoption('admania_lvedtimg_url12')).'" alt="'.esc_html__('adimage','admania').'"/>';
			
			$admania_newcontent.= '</a>';			
					
			endif; 	
	
	        
			
			}
	else {
	if($admania_pstadenable3 != false) {
	
		
 
			if($admania_bfpstadhtmlcd3 != false):			
			
			$admania_newcontent.= $admania_bfpstadhtmlcd3;			
			
			endif;
			
			if($admania_bfpstadglecd3 != false):

			$admania_newcontent.= $admania_bfpstadglecd3;	
			
			endif;
			
			if(($admania_bfpstadimg3 != false) || ($admania_bfpstadimglnk3 != false) ):
			
			$admania_newcontent.= '<a href="'.esc_url($admania_bfpstadimglnk3).'">';	
			
			$admania_newcontent.= ' <img src="'.esc_url($admania_bfpstadimg3).'" alt="'.esc_html__('adimage','admania').'"/>';
			
			$admania_newcontent.= '</a>';			
					
			endif; 
	
	
	
	
	}
	
	else {
	if (admania_get_option('sngle_pstinrnthad') != '') {		
	
 
            if(admania_get_option('sngle_rotpstinrnthhtmlad') != false){
			
			$admania_newcontent.= '<div class="admania_lyt3rothad1">';	
			
            }	
 
			if(admania_get_option('sngle_pstinrnthhtmlad') != false):			
			
			$admania_newcontent.= admania_get_option('sngle_pstinrnthhtmlad');			
			
			endif;
			
			if(admania_get_option('sngle_rotpstinrnthhtmlad') != false){
			
			$admania_newcontent.= '</div>';			
			$admania_newcontent.= '<div class="admania_lyt3rothad2">';	
			$admania_newcontent.=  wp_kses_stripslashes(admania_get_option('sngle_rotpstinrnthhtmlad')); 
			$admania_newcontent.= '</div>';
						
            }
			
			if(admania_get_option('sngle_rotpstinrnthgglead') != false){
			
			$admania_newcontent.= '<div class="admania_lyt3rothad1">';	
			
            }	
			
			
			if(admania_get_option('sngle_pstinrnthgglead') != false):

			$admania_newcontent.= admania_get_option('sngle_pstinrnthgglead');	
			
			endif;
			
			if(admania_get_option('sngle_rotpstinrnthgglead') != false){
			
			$admania_newcontent.= '</div>';			
			$admania_newcontent.= '<div class="admania_lyt3rothad2">';	
			$admania_newcontent.=  wp_kses_stripslashes(admania_get_option('sngle_rotpstinrnthgglead')); 
			$admania_newcontent.= '</div>';
						
            }
			
			if((admania_get_option('admania_rotadimg_url13') != false) || (admania_get_option('admania_rotadimgtg_url13') != false)){
			
			$admania_newcontent.= '<div class="admania_lyt3rothad1">';	
			
            }	
			
			
			if((admania_get_option('admania_adimg_url13') != false) || (admania_get_option('admania_adimgtg_url13') != false) ):
			
			$admania_newcontent.= '<a href="'.esc_url(admania_get_option('admania_adimgtg_url13')).'">';	
			
			$admania_newcontent.= ' <img src="'.esc_url(admania_get_option('admania_adimg_url13')).'" alt="'.esc_html__('adimage','admania').'"/>';
			
			$admania_newcontent.= '</a>';			
					
			endif; 
			
			
			if((admania_get_option('admania_rotadimg_url13') != false) || (admania_get_option('admania_rotadimgtg_url13') != false)){
				
			$admania_newcontent.= '</div>';			
			$admania_newcontent.= '<div class="admania_lyt3rothad2">';	
			$admania_newcontent.= '<a href="'.esc_url(admania_get_option('admania_rotadimgtg_url13')).'">';				
			$admania_newcontent.= ' <img src="'.esc_url(admania_get_option('admania_rotadimg_url13')).'" alt="'.esc_html__('adimage','admania').'"/>';
			$admania_newcontent.= '</a>';	
			$admania_newcontent.= '</div>';
						
            }
	
	
	
	}
	}
	}	
	if(current_user_can('administrator')){			
    $admania_newcontent.= '<div class="admania_adeditablead1 admania_lvetresitem12">';				
	$admania_newcontent.= '<i class="fa fa-edit"></i>';
	$admania_newcontent.= ''.esc_html__('Edit','admania').'';
    $admania_newcontent.= '</div>';			 
    } 
	$admania_newcontent.= '</div>';
	}
	}
	}	
	
	$admania_newcontent.= $admania_content[$i];
	}
	
	return $admania_newcontent;
	
	}

	elseif($admania_posttype == 'page') {	
	
	// Page Metabox Variables  

	$admania_pgepstadenable3 = get_post_meta($post->ID, '_admania_pgepstadenable3', true);
	$admania_bfpgepstadhtmlcd3 = get_post_meta($post->ID, '_admania_bfpgepstadhtmlcd3', true);
	$admania_bfpgepstadglecd3 = get_post_meta($post->ID, '_admania_bfpgepstadglecd3', true);
	$admania_bfpgepstadimg3 = get_post_meta($post->ID, '_admania_bfpgepstadimg3', true);
	$admania_bfpgepstadimglnk3 = get_post_meta($post->ID, '_admania_bfpgepstadimglnk3', true); 
    $admania_pgepstadpgepstnbr1 = get_post_meta($post->ID, '_admania_pgepstadpgepstnbr1', true); 
	
	if($admania_pgepstadenable3 != false) {
	$admania_pgeparagraphAfter = $admania_pgepstadpgepstnbr1;
	}
	else {
	$admania_pgeparagraphAfter = admania_get_option('pagepst_aftrnthparano'); //Enter number of paragraphs to display ad after.
	}
	$admania_content = explode("</p>", $admania_content);
	$admania_pgnewcontent = '';
	for ($pi = 0; $pi < count($admania_content); $pi++) {
	if ($pi == $admania_pgeparagraphAfter) {
	$admania_rmvcatids17 =  admania_get_option('ad_rmcatlist18');			
	$admania_rmvcatids_extractids17 = explode(',',$admania_rmvcatids17);			
	$admania_rmvtagids17 = admania_get_option('ad_rmtaglist18');
	$admania_rmvtagids_extractids17 = explode(',',$admania_rmvtagids17);			
			
    if((!is_category($admania_rmvcatids_extractids17)) && (!is_tag($admania_rmvtagids_extractids17))) {	
	
	if(($admania_pgepstadenable3 != false) || (admania_get_option('page_pstinrnthad') != '')) {
	
		$admania_pgnewcontent.= '<div class="admania_pgaftrnthprad admania_themead">';
	   
  	    if((admania_get_lveditoption('hdr_lvedlhtmlad19') != false) || (admania_get_lveditoption('hdr_lvedlglead19') != false) || (admania_get_lveditoption('admania_lvedtimg_url19') != false)) {
					 
			if(admania_get_lveditoption('hdr_lvedlhtmlad19') != false):			
			
			$admania_pgnewcontent.= admania_get_lveditoption('hdr_lvedlhtmlad19');			
			
			endif;
			
			if(admania_get_lveditoption('hdr_lvedlglead19') != false):

			$admania_pgnewcontent.= admania_get_lveditoption('hdr_lvedlglead19');	
			
			endif;
			
			if((admania_get_lveditoption('admania_lvedtimg_url19') != false) || (admania_get_lveditoption('admania_lvedtrimgtg_url19') != false) ):
			
			$admania_pgnewcontent.= '<a href="'.esc_url(admania_get_lveditoption('admania_lvedtrimgtg_url19')).'">';	
			
			$admania_pgnewcontent.= ' <img src="'.esc_url(admania_get_lveditoption('admania_lvedtimg_url19')).'" alt="'.esc_html__('adimage','admania').'"/>';
			
			$admania_pgnewcontent.= '</a>';			
					
			endif; 	
	   }
	
	else {
	
	if($admania_pgepstadenable3 != false) {		
 
			if($admania_bfpgepstadhtmlcd3 != false):			
			
			$admania_pgnewcontent.= $admania_bfpgepstadhtmlcd3;			
			
			endif;
			
			if($admania_bfpgepstadglecd3 != false):

			$admania_pgnewcontent.= $admania_bfpgepstadglecd3;	
			
			endif;
			
			if(($admania_bfpgepstadimg3 != false) || ($admania_bfpgepstadimglnk3 != false) ):
			
			$admania_pgnewcontent.= '<a href="'.esc_url($admania_bfpgepstadimglnk3).'">';	
			
			$admania_pgnewcontent.= ' <img src="'.esc_url($admania_bfpgepstadimg3).'" alt="'.esc_html__('adimage','admania').'"/>';
			
			$admania_pgnewcontent.= '</a>';			
					
			endif; 
	
	
	}
	else {
	if (admania_get_option('page_pstinrnthad') != '') {	

            if(admania_get_option('page_rotpstinrnthhtmlad') != false){
			
			$admania_pgnewcontent.= '<div class="admania_lyt3rothad1">';	
			
            }	
	
	 
			if(admania_get_option('page_pstinrnthhtmlad') != false):			
			
			$admania_pgnewcontent.= admania_get_option('page_pstinrnthhtmlad');			
			
			endif;
			
				
			if(admania_get_option('page_rotpstinrnthhtmlad') != false){
			
			$admania_pgnewcontent.= '</div>';			
			$admania_pgnewcontent.= '<div class="admania_lyt3rothad2">';	
			$admania_pgnewcontent.=  wp_kses_stripslashes(admania_get_option('page_rotpstinrnthhtmlad')); 
			$admania_pgnewcontent.= '</div>';
						
            }
			
			if(admania_get_option('page_rotpstinrnthgglead') != false){
			
			$admania_pgnewcontent.= '<div class="admania_lyt3rothad1">';	
			
            }	
			
			if(admania_get_option('page_pstinrnthgglead') != false):

			$admania_pgnewcontent.= admania_get_option('page_pstinrnthgglead');	
			
			endif;
			
			if(admania_get_option('page_rotpstinrnthgglead') != false){
			
			$admania_pgnewcontent.= '</div>';			
			$admania_pgnewcontent.= '<div class="admania_lyt3rothad2">';	
			$admania_pgnewcontent.=  wp_kses_stripslashes(admania_get_option('page_rotpstinrnthgglead')); 
			$admania_pgnewcontent.= '</div>';
						
            }
			
			
			if((admania_get_option('admania_rotadimg_url20') != false) || (admania_get_option('admania_rotadimgtg_url20') != false)){
			
			$admania_pgnewcontent.= '<div class="admania_lyt3rothad1">';	
			
            }	
			
			
			if((admania_get_option('admania_adimg_url20') != false) || (admania_get_option('admania_adimgtg_url20') != false) ):
			
			$admania_pgnewcontent.= '<a href="'.esc_url(admania_get_option('admania_adimgtg_url20')).'">';	
			
			$admania_pgnewcontent.= ' <img src="'.esc_url(admania_get_option('admania_adimg_url20')).'" alt="'.esc_html__('adimage','admania').'"/>';
			
			$admania_pgnewcontent.= '</a>';			
					
			endif; 
			
			if((admania_get_option('admania_rotadimg_url20') != false) || (admania_get_option('admania_rotadimgtg_url20') != false)){
			
			$admania_pgnewcontent.= '</div>';			
			$admania_pgnewcontent.= '<div class="admania_lyt3rothad2">';	
			$admania_pgnewcontent.= '<a href="'.esc_url(admania_get_option('admania_rotadimgtg_url20')).'">';				
			$admania_pgnewcontent.= ' <img src="'.esc_url(admania_get_option('admania_rotadimg_url20')).'" alt="'.esc_html__('adimage','admania').'"/>';
			$admania_pgnewcontent.= '</a>';	
			$admania_pgnewcontent.= '</div>';
            			
			
            }
	
	
	
	}
	}
	}
	if(current_user_can('administrator')){			
    $admania_pgnewcontent.= '<div class="admania_adeditablead1 admania_lvetresitem19">';				
	$admania_pgnewcontent.= '<i class="fa fa-edit"></i>';
	$admania_pgnewcontent.= ''.esc_html__('Edit','admania').'';
    $admania_pgnewcontent.= '</div>';			 
    } 
	$admania_pgnewcontent.= '</div>';
	}
	}
	}
	$admania_pgnewcontent.= $admania_content[$pi];
	}
		
	return $admania_pgnewcontent;
	
	}
	
	else {
	return $admania_content;
	}
   
    endif;
	
	}
	

    endif;
	
	add_filter('the_content', 'admania_adcontent');
	
/*-----------------------------------------------------------------------------------*/
# Admania Post/Page Entry Meta
/*-----------------------------------------------------------------------------------*/


if ( ! function_exists( 'admania_entrymeta' ) ) :

function admania_entrymeta() {	
global $post;
      if(is_single()) {	
		
		if(admania_get_option('admania_ebylfp') != TRUE) { ?>
<div class="admania_entrybyline admania_entrypgbyline">
  <?php  if(admania_get_option('admania_ppostedby') != TRUE) {	  ?>
  <div class="admania_entryauthor">
    <?php
		echo get_avatar( get_the_author_meta( 'user_email' ), 20 );
		?>
    <?php
	   esc_html_e('By','admania');
	   ?>
    <?php the_author_posts_link(); ?>
  </div>
  <div class="admania_entryline"> / </div>
  <?php  }     
	if(admania_get_option('admania_ppostedon') != TRUE) {
	 ?>
  <div class="admania_entrydate">
    <?php
	   esc_html_e('On','admania');
	   ?>
    <?php the_time(get_option( 'date_format')); ?>
  </div>
  <div class="admania_entryline"> / </div>
  <?php  }
   if(admania_get_option('admania_ppostedtime') != TRUE) {
   ?>
    <div class="admania_entrydate">
    <?php
	   esc_html_e('At','admania');
	?>
    <?php the_time(get_option( 'time_format')); ?>
    </div>   
    <div class="admania_entryline"> / </div>
   <?php
   }
   if(admania_get_option('admania_pcategory') != TRUE) {
   ?>
  <div class="admania_entrycategory">
    <?php
	   esc_html_e('In','admania');
	   ?>
    <?php the_category(' , '); ?>
  </div>
  <?php  }
	 $admania_postformat = get_post_format();
	
	 if(!empty($admania_postformat)) { ?>
  <div class="admania_entryline"> / </div>
  <div class="admania_entry_format"> <i class="fa admania_fontaws"></i> <a href="<?php echo esc_url( get_post_format_link( $admania_postformat ));?>">
    <?php  echo esc_html($admania_postformat); ?>
    </a> </div>
  <?php
			
	 }
	 if(admania_get_option('admania_dsebyvw') != TRUE) {	 
	 ?>
  <div class="admania_viewcnt"> <?php echo admania_get_post_views($post->ID); ?> <span class="admania_view_text">
    <?php esc_html_e('Views','admania'); ?>
    </span> </div>
  <?php  } ?>
</div>
<?php  }
}

if(is_page()) {
		if(admania_get_option('admania_ebylfpage') != '') {
		?>
<div class="admania_entrybyline admania_entrypgbyline">
  <?php if(admania_get_option('padmania_ppostedby') != '') {  ?>
  <div class="admania_entryauthor">
    <?php
		echo get_avatar( get_the_author_meta( 'user_email' ), 20 );
		?>
    <?php esc_html_e('By','admania'); ?>
    <?php the_author_posts_link(); ?>
  </div>
  <div class="admania_entryline"> / </div>
  <?php  } 
	 if(admania_get_option('padmania_ppostedon') != '') {
	 ?>
  <div class="admania_entrydate">
    <?php esc_html_e('On','admania'); ?>
    <?php the_time(get_option( 'date_format')); ?>
  </div>
  <?php  }
	
	 if(admania_get_option('padmania_ppview') != '') {
	 ?>
  <div class="admania_viewcnt"> <?php echo admania_get_post_views($post->ID); ?> <span class="admania_view_text">
    <?php esc_html_e('Views','admania'); ?>
    </span> </div>
  <?php  } ?>
</div>
<?php } 
}	 
}	
endif;
	

	
	
/*-----------------------------------------------------------------------------------*/
# ADMANIA REMOVE ADD TO CART BUTTON ON PRODUCT ARCHIVE (SHOP) */
/*-----------------------------------------------------------------------------------*/	

if (class_exists( 'Woocommerce' )):

/*STEP 1 - REMOVE ADD TO CART BUTTON ON PRODUCT ARCHIVE (SHOP) */
if ( ! function_exists( 'admania_remove_loop_button' ) ) :
function admania_remove_loop_button(){	
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
}
endif;

add_action('init','admania_remove_loop_button');

/*-----------------------------------------------------------------------------------*/
# ADMANIA REMOVE ADD TO CART BUTTON ON PRODUCT ARCHIVE (SHOP) */
/*-----------------------------------------------------------------------------------*/	

/*STEP 2 -ADD NEW BUTTON THAT LINKS TO PRODUCT PAGE FOR EACH PRODUCT   */

add_action('woocommerce_before_shop_loop_item_title','admania_replace_add_to_cart',10);
if ( ! function_exists( 'admania_replace_add_to_cart' ) ) :
function admania_replace_add_to_cart() {
global $product;
echo apply_filters( 'woocommerce_loop_add_to_cart_link',
    sprintf( '<a href="%s" rel="nofollow" data-quantity="1" data-product_id="%s" data-product_sku="%s" class="button %s product_type_%s ajax_add_to_cart admania_add_to_cart"><i class="fa fa-shopping-cart"></i> %s</a>',
        esc_url( $product->add_to_cart_url() ),
        esc_attr( $product->id ),
        esc_attr( $product->get_sku() ),
        $product->is_purchasable() ? 'add_to_cart_button' : '',
        esc_attr( $product->product_type ),
        esc_html( $product->add_to_cart_text() )
    ),
$product);

}
endif;

/*-----------------------------------------------------------------------------------*/
# ADMANIA REMOVE ADD TO CART BUTTON ON PRODUCT ARCHIVE (SHOP) */
/*-----------------------------------------------------------------------------------*/	

add_action('woocommerce_shop_loop_item_title', 'admania_add_star_rating');
if ( ! function_exists( 'admania_add_star_rating' ) ) :
function admania_add_star_rating()
{
global $woocommerce, $product;
$admania_average = $product->get_average_rating();

echo '<div class="star-rating"><span style="width:'.( ( $admania_average / 5 ) * 100 ) . '%"><strong itemprop="ratingValue" class="rating">'.esc_attr($admania_average).'</strong> '.__( 'out of 5', 'woocommerce' ).'</span></div>';
}
endif;
endif;



/*-----------------------------------------------------------------------------------*/
# Adds admania walker navmenu
/*-----------------------------------------------------------------------------------*/


if(!class_exists('admania_walker_nav_menu')): 

class admania_walker_nav_menu extends Walker_Nav_Menu {
    function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
        global $wp_query,$post;

        $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
        $class_names = $value = '';
		
		$post_meta_array = get_post_meta($item->ID);				
		$is_mzmegamu = !empty($post_meta_array['_menu_item_megamenu'][0]) ? $post_meta_array['_menu_item_megamenu'][0]:'';
		$is_admania_mgmu = ($is_mzmegamu !== '') ? true : false;
		
	
		
		if ( $is_admania_mgmu != '') {
			
			$is_mzmgmu = "menu-item-has-children";
			
		}
		
		else {
			
			$is_mzmgmu = "";
		}

        $classes = empty( $item->classes ) ? array() : (array) $item->classes;

        $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) );
        $class_names = ' class="'. esc_attr( $class_names ) . ' '.esc_attr($is_mzmgmu).'"';

        $output .= $indent . '<li id="menu-item-'. $item->ID . '"' . $value . $class_names . '>';
        $attributes  = ! empty( $item->attr_title ) ? ' title="'  . esc_attr( $item->attr_title ) .'"' : '';
        $attributes .= ! empty( $item->target )     ? ' target="' . esc_attr( $item->target     ) .'"' : '';
        $attributes .= ! empty( $item->xfn )        ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';
        $attributes .= ! empty( $item->url )        ? ' href="'   . esc_attr( $item->url        ) .'"' : '';
        $attributes .= ' class= "main-link"';


        $prepend = '';
        $append = '';
        $description  = '';

        $item_output = $args->before;
        $item_output .= '<a '. $attributes .'>';
        $item_output .= $args->link_before .$prepend.apply_filters( 'the_title', $item->title, $item->ID ).$append;
        $item_output .= $description.$args->link_after;
        $item_output .= '</a>';
			

        if ( $is_admania_mgmu != ''  ) {
            ob_start(); ?>
            <ul class="admania_megamenu sub-menu admania_mgmowl">		
			 <?php  
			        $admania_megamnquery = new WP_Query( array( 'category_name' => $item->title, 'posts_per_page' => get_option('posts_per_page') ) );
				    if ( $admania_megamnquery->have_posts() ) {
				    while ( $admania_megamnquery->have_posts() ) {
					$admania_megamnquery->the_post();
					$admania_mgmnimgid = get_post_thumbnail_id();
					$admania_mgmnwidthimg = '262';
					$admania_mgmnheightimg = '157';
					$admania_mgmnimgurl = wp_get_attachment_url( $admania_mgmnimgid,'full'); //get img URL
					$admania_mgmnimg = admania_autoresize( $admania_mgmnimgurl, $admania_mgmnwidthimg, $admania_mgmnheightimg, true ); //resize & crop img
					$admania_ytdimg = get_post_meta($post->ID, '_featured_videourl', true); 
					$admania_youtube_matchexp = "/\s*[a-zA-Z\/\/:\.]*youtube.com\/watch\?v=([a-zA-Z0-9\-_]+)([a-zA-Z0-9\/\*\-\_\?\&\;\%\=\.]*)/i";  
					$admania_vimeomatchexp = "/https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)/";
					$admania_souncloudmatchexp = "%(?:https?://)(?:www\.)?soundcloud\.com/([\-a-z0-9_]+/[\-a-z0-9_]+)%im";
					$admania_framename = "iframe";		
			    ?>
				<li class="admania_mgmnitem">
				<?php
				if($admania_ytdimg != "" || $admania_mgmnimg != "" ):
			    ?>
				<div class="admania_mgmnitemlist">
				<?php
		
				if($admania_ytdimg != "") {
				
				if(preg_match($admania_youtube_matchexp , $admania_ytdimg)) {	
				
				$admania_yuvid = preg_replace($admania_youtube_matchexp,"<".esc_attr($admania_framename)." width=\"".absint($admaniatb1_widthimg)."\" height=\"292\" src=\"//www.youtube.com/embed/$1\" allohdrullscreen></iframe>",$admania_ytdimg);
				
				echo wp_kses_stripslashes($admania_yuvid);
					?>
				 <h3 class="admania_megamenucattit"><a href="<?php the_permalink(); ?>" class="admania_catsubtit" rel="bookmark"><?php the_title(); ?></a></h3>

				<?php
				}
				
				elseif(preg_match($admania_vimeomatchexp , $admania_ytdimg)) {
				
				$admania_vimeovideos = preg_replace( $admania_vimeomatchexp ,"<".esc_attr($admania_framename)." width=\"".absint($admaniatb1_widthimg)."\" height=\"292\" src=\"//player.vimeo.com/video/$3\" allohdrullscreen></iframe>",$admania_ytdimg);
				
				echo wp_kses_stripslashes($admania_vimeovideos);
					?>
				 <h3 class="admania_megamenucattit"><a href="<?php the_permalink(); ?>" class="admania_catsubtit" rel="bookmark"><?php the_title(); ?></a></h3>

				<?php
				}
				
				elseif(preg_match( $admania_souncloudmatchexp , $admania_ytdimg)) {	
				
				$admania_souncloudsng = preg_replace( $admania_souncloudmatchexp ,'<'.esc_attr($admania_framename).' width="'.absint($admaniatb1_widthimg).'" height="292" scrolling="no" src="https://w.soundcloud.com/player/?url=https://soundcloud.com/$1&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>',$admania_ytdimg); 
				
				echo wp_kses_stripslashes($admania_souncloudsng);
				
				?>
				 <h3 class="admania_megamenucattit"><a href="<?php the_permalink(); ?>" class="admania_catsubtit" rel="bookmark"><?php the_title(); ?></a></h3>

				<?php
				
				}
				
				} 		
				
				elseif($admania_mgmnimg != "" && $admania_ytdimg == "" ) { 
				?>				
				<a href="<?php the_permalink(); ?>" class="admania_mgmnthumb" rel="bookmark">
					  <img src="<?php echo esc_url($admania_mgmnimg); ?>" title="<?php esc_attr(the_title());  ?>" alt="<?php esc_attr(the_title());  ?>" />
					  </a>
					  <h5 class="admania_megamenucattit"><a href="<?php the_permalink(); ?>" class="admania_catsubtit" rel="bookmark"><?php the_title(); ?></a></h5>
					  <?php 
				} 
                ?>
				</div>
				<?php
				
				 else:
				 ?>
				 <div class="admania_mgmnitemlist">
                <h5 class="admania_megamenucattit"><a href="<?php the_permalink(); ?>" class="admania_catsubtit" rel="bookmark"><?php the_title(); ?></a></h5>
				 </div>
				 <?php				 
				endif;
				?>
				<?php if(admania_get_option('admania_ebylfp') != 1): ?>	
				<div class="admania_entrysmeta  admania_entrymeta admania_mgmnmeta">
				<?php if(admania_get_option('admania_ppostedby') != 1): ?>
				<span class="admania_entrysbyline">
				<?php echo get_avatar( get_the_author_meta( 'user_email' ), 20 ); ?>
				<?php esc_html_e('By','admania'); ?><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author"> <?php echo get_the_author(); ?> </a> 
				</span>-
				<?php endif; if(admania_get_option('admania_ppostedon') != 1): ?>
				<span class="admania_entrysbyline">
				<i class="fa fa-calendar"></i><span class="admania_viewtxt admania_sviewtxt"><?php esc_html_e('On','admania'); ?></span><?php the_time(get_option( 'date_format')); ?> 
				</span>
				<?php endif; ?>
				</div>	
				<?php endif; ?>
				</li>
				<?php
				}
				}
				wp_reset_postdata(); ?>				
				</ul> <?php
				$item_output .= ob_get_contents();
				ob_end_clean();
        }

        $item_output .= $args->after;
        $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
    }
}

endif;


/*-----------------------------------------------------------------------------------*/
# Adds admania walker navmenu custom fields
/*-----------------------------------------------------------------------------------*/
  
if(!class_exists('Admania_Nav_Menu_Item_Custom_Fields')): 
 
class Admania_Nav_Menu_Item_Custom_Fields {
 
	static $options = array(
			'item' => '
				<div class="additional-menu-field-{name} {container_class} admania_mgmnbkstgs">			
					<label for="edit-menu-item-{name}-{id}">{label}</label>
					<div class="megamenu">
						<select name="{name}" id="select-mega-menu-{id}">
							<option value="">Hide</option>
							<option value="{admania_mega1}">Show</option>							
						</select>
						<input type="{input_type}" id="edit-menu-item-{name}-{id}" class="widefat code edit-menu-item-{name}" name="menu-item-{name}[{id}]" value="{value}">
					</div>                   
				</div>
			',
						
						
			
		);
 
	static function setup() {
		self::$options['fields'] = array(
			'megamenu' => array(
				'name'            => 'megamenu',
				'label'           => esc_html__('Select Mega Menu To Show', 'admania'),
				'container_class' => 'menu-megamenu',
				'input_type'      => 'hidden',
			),
						
		);	
	
 
		add_filter( 'wp_edit_nav_menu_walker', function () {
			return 'Admania_Walker_Nav_Menu_Edit';
		});
		add_filter( 'admania_nav_menu_item_additional_fields', array( __CLASS__, 'admania_megamn_addfields' ), 10, 5 );
		add_action( 'save_post', array( __CLASS__, 'admania_meagmenu_savepost' ) );
	}
 
	static function get_fields_schema() {
		$schema = array();
		foreach(self::$options['fields'] as $name => $field) {
			if (empty($field['name'])) {
				$field['name'] = $name;
			}
			$schema[] = $field;
		}
		return $schema;
	}
 
	static function get_menu_item_postmeta_key($name) {
		return '_menu_item_' . $name;
	}
 
	/**
	 * Inject the
	 * @hook {action} save_post
*/
	static function admania_megamn_addfields($new_fields, $item_output, $item, $depth, $args) {
		$schema = self::get_fields_schema($item->ID);
		foreach($schema as $field) {
			$field['value'] = get_post_meta($item->ID, self::get_menu_item_postmeta_key($field['name']), true);
			$field['id'] = $item->ID;
			//Tried to implement selected() here but was unsuccesfull, so I just left it like this, the mega fields aren't necessary, you can add them by hand
			$field['admania_mega1'] = 'admania_mega1';           		
			$new_fields .= str_replace(
				array_map(function($key){ return '{' . $key . '}'; }, array_keys($field)),
				array_values(array_map('esc_attr', $field)),
				self::$options['item']
			);
		}
		return $new_fields;
	}
	/**
	 * Save the newly submitted fields
	 * @hook {action} save_post
	*/
	static function admania_meagmenu_savepost($post_id) {
		if (get_post_type($post_id) !== 'nav_menu_item') {
			return;
		}
		$fields_schema = self::get_fields_schema($post_id);
		foreach($fields_schema as $field_schema) {
			$form_field_name = 'menu-item-' . $field_schema['name'];
			if (isset($_POST[$form_field_name][$post_id])) {
				$key = self::get_menu_item_postmeta_key($field_schema['name']);
				$value = stripslashes($_POST[$form_field_name][$post_id]);
				update_post_meta($post_id, $key, $value);
			}
		}
	}
}
  
endif;

add_action( 'init', array( 'Admania_Nav_Menu_Item_Custom_Fields', 'setup' ) );

/*-----------------------------------------------------------------------------------*/
# Adds admania walker navmenu custom fields edit
/*-----------------------------------------------------------------------------------*/

require_once ABSPATH . 'wp-admin/includes/nav-menu.php';

if(!class_exists('Admania_Walker_Nav_Menu_Edit')): 

class Admania_Walker_Nav_Menu_Edit extends Walker_Nav_Menu_Edit {
	function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
		$item_output = '';
		parent::start_el($item_output, $item, $depth, $args, $id);
		$new_fields = apply_filters( 'admania_nav_menu_item_additional_fields', '', $item_output, $item, $depth, $args );
		// Inject $new_fields before: <div class="menu-item-actions description-wide submitbox">
		if ($new_fields) {
			$item_output = preg_replace('/(?=<div[^>]+class="[^"]*submitbox)/', $new_fields, $item_output);
		}
		$output .= $item_output;
	}
}

endif;
